<!--
  Sync Impact Report
  ==================
  Version change: 1.0.0 → 2.0.0
  Modification: Stack-agnostic rewrite. All references to specific
  frameworks, languages, ORMs, databases, runtimes, IDEs, and package
  managers were removed. Principles are now expressed in terms the
  spec/story itself can populate at runtime.

  Modified principles:
    - I. Behavioral Fidelity — generalized (any source system)
    - II. Contract-First Design — generalized (any service protocol)
    - III. Test-Driven Development — generalized (any test framework)
    - IV. Clean Architecture Integrity — generalized (any language)
    - V. Agentic Pipeline Discipline — unchanged in intent
    - VI. Source-Anchored Rewrite — generalized (any source code)
    - VII. Code Quality & Type Safety — generalized
  Removed sections:
    - Technology Stack Constraints (now defined by the story/plan)
  Templates aligned:
    - .specify/templates/* describe structure, not stack
  Follow-up: Stack-specific rules (versions, lint commands, build
  commands, naming conventions) MUST be declared in the story's
  spec.md / plan.md, not in this constitution.
-->

> **Canonical location note:** The authoritative, portfolio-scoped
> constitution for each portfolio lives at
> `portfolios/{portfolio}/specs/constitution.md` (created from
> `.specify/templates/constitution-template.md` by
> `/speckit.constitution`). This file is the repo-level,
> stack-agnostic baseline that applies when no portfolio-scoped
> constitution exists; portfolio-scoped constitutions take
> precedence for their portfolio.

# Project Constitution

## Core Principles

### I. Behavioral Fidelity (NON-NEGOTIABLE)

When a feature modernizes, replaces, or re-implements an existing
system, the new code MUST preserve the exact observable behavior of
the source system:

- Business logic MUST produce identical outputs for identical inputs
  (same calculation results, same validation rules, same error
  messages).
- Data operations MUST maintain the same transactional boundaries
  and isolation semantics as the source.
- Batch / scheduled processing MUST preserve the same sequencing,
  file handling, and restart/recovery semantics.
- Error handling MUST match legacy behavior (same error codes, same
  status values, same abend/rollback conditions).
- Service contracts MUST match the existing interfaces they replace
  (preserve field names, data types, lengths, and validation rules).
- All business rules, edits, and calculations documented in the
  source MUST be implemented without deviation.
- When source behavior is ambiguous or contradictory, document the
  ambiguity in an ADR (Architecture Decision Record) and obtain SME
  sign-off before proceeding.

**Rationale:** Modernization is a change of technology, NOT a
rewrite of business logic. Any behavioral change constitutes a
defect. Domain rules encoded in legacy systems must be preserved
exactly to maintain regulatory compliance and business continuity.

### II. Contract-First Design

All service interfaces MUST follow contract-first design:

- Interface contracts (WSDL, OpenAPI, Protobuf, GraphQL schema,
  or whatever format the target stack uses) MUST be defined BEFORE
  any implementation code is written.
- Contracts MUST be derived from the API contracts the story
  specifies (its Conversation section), refined by the pack's LLD in
  `architecture/LLD/` when one exists.
- For a migration, service operations, request/response messages,
  and data contracts MUST align with the original interfaces the
  story's COBOL Reference cites (or `architecture/current-state/`,
  when a pack still carries it as reference).
- Data contract fields MUST preserve legacy field names, data
  types, and lengths.
- Contracts MUST be reviewed and approved by the architect before
  implementation begins.
- Hand-written service implementations MUST conform to the approved
  contract; code generation from contracts is allowed only when the
  story explicitly permits it.
- All breaking changes to contracts require an Impact Analysis
  document and SME approval.

**Rationale:** Contract-first ensures that service interfaces are
stable, predictable, and aligned with the legacy system contracts
that downstream consumers depend on. In phased migrations, services
go live incrementally while the rest of the legacy estate remains
operational; contract fidelity is essential for coexistence.

### III. Test-Driven Development (NON-NEGOTIABLE)

All implementation work MUST follow Test-Driven Development (TDD):

- Unit tests MUST be written BEFORE the implementation code they
  verify.
- Follow the Red-Green-Refactor cycle: write a failing test →
  implement the minimum code to pass → refactor for clarity.
- Every public method, business rule, calculation, and validation
  MUST have corresponding unit tests.
- Integration tests MUST verify data access, persistence mappings,
  and service contracts.
- Behavior-driven tests MUST compare new outputs against captured
  source-system outputs for the same inputs.
- The story's plan.md MUST name the test framework, mocking
  library, and assertion library to be used; tests MUST use those.
- All tests MUST pass with zero errors and zero warnings before
  code review.
- Test data MUST be derived from legacy program test cases,
  production data samples, or SME-provided scenarios.
- Code coverage threshold is set per story in plan.md; default
  minimum is 80% line coverage on changed code.

**Rationale:** Legacy programs often have minimal automated test
coverage; modernization is the first opportunity to establish a
comprehensive test suite. TDD ensures that every piece of migrated
logic is validated and that regressions are caught early.

### IV. Clean Architecture Integrity

All code MUST follow Clean Architecture layering. The concrete
project shape (folder names, module boundaries, DI container, ORM)
is declared in plan.md, but the layering rules below are universal:

**Layers (dependency flow: top → bottom only):**

1. **Presentation / Service Edge**
   - MUST NOT contain business logic
   - MUST delegate all processing to the application layer
   - MUST handle only protocol concerns (HTTP, SOAP, gRPC, CLI…)

2. **Application** (orchestration)
   - MUST coordinate workflows across domain and data access
   - MUST enforce transaction boundaries
   - MUST NOT contain data access code

3. **Domain** (business logic and domain models)
   - MUST contain all business rules and calculations
   - MUST be pure code with no external dependencies (no ORM,
     logger, or third-party packages)
   - MUST NOT reference any other layer

4. **Data Access**
   - MUST handle all persistence operations
   - MUST implement the Repository pattern (or an equivalent
     pattern declared in plan.md)
   - MUST reference Domain only

5. **Infrastructure** (cross-cutting concerns)
   - MUST provide logging, serialization, configuration, telemetry
   - MUST be consumed by Presentation and Application layers
   - MUST NOT reference Domain or Data Access

**Rules:**

- A layer MUST NOT reference layers above it in the hierarchy.
- Domain and Infrastructure MUST have zero dependencies between
  each other.
- Application and Data Access MUST NOT have circular dependencies.
- All inter-layer communication MUST use interfaces defined in the
  consuming layer.
- No hard-coded dependencies; the DI container named in plan.md is
  used for wiring.

**Rationale:** Clean Architecture ensures that business logic is
isolated, testable, and independent of infrastructure concerns.
This separation is essential for migrating complex business rules
without introducing coupling to any one framework.

### V. Agentic Pipeline Discipline

All reverse-engineering and forward-engineering work MUST follow
the agentic pipeline sequence defined by the project's
orchestrators (see `.claude/agents/` and CLAUDE.md).

**Rules:**

- Agents MUST run in the prescribed sequence; skipping agents is
  prohibited.
- Human gates MUST NOT be bypassed; create
  `.gates/{agent-id}.approved` files after architect review.
- Quality gates MUST pass with a score ≥ 70/100 before proceeding
  to the next phase.
- All agent outputs MUST be committed to the repository and
  validated against JSON schemas in `schemas/`.
- If an agent fails validation, fix the root cause and re-run the
  agent; do NOT manually edit agent outputs.
- When debugging agent failures, consult agent skill files in
  `.claude/skills/` for context.

**Rationale:** The agentic pipeline ensures consistent,
repeatable, and auditable analysis and design work. Each agent
builds on verified outputs from previous agents, and quality gates
prevent propagation of errors downstream.

### VI. Source-Anchored Rewrite

All implementation work that re-implements existing behavior MUST
be source-anchored to the original program / module:

- BEFORE writing any new code, read the corresponding source in
  `inputs/source/` (or wherever the story's spec.md points to).
- Extract all business rules, calculations, data validations, and
  conditional logic directly from the source.
- Document the source-to-target mapping in inline code comments
  citing the source file and line number (e.g.,
  `// source: PROG.cbl:342 — IF WS-PREMIUM > 0 THEN ...`).
- When a source program has complex nested conditionals, copy the
  source as a block comment before implementing the equivalent.
- All deviations from source logic MUST be documented in an ADR
  with SME approval.

**Rationale:** Legacy programs encode years of business knowledge,
edge cases, and regulatory requirements. Attempting to rewrite
logic "from scratch" or "from memory" inevitably introduces
defects. Source-anchored rewrite ensures that every line of new
code is traceable to a specific source location, enabling
verification and audit.

### VII. Code Quality & Type Safety

Code quality standards apply across stacks. The concrete style
guide, lint configuration, and formatter are declared in plan.md;
the principles below MUST hold for any choice:

**Naming:**
- Identifiers MUST follow the conventions of the chosen language /
  framework (declared in plan.md). Whatever convention is chosen,
  apply it consistently across the codebase.
- Avoid abbreviations; prefer full names that convey intent.
- Boolean names MUST read as predicates (`isReady`, `hasItems`,
  `canSubmit`, `shouldRetry`).

**Type Safety:**
- All public APIs MUST have explicit parameter and return types.
- Avoid dynamically-typed escape hatches (e.g., `any`, `dynamic`,
  `Object`, raw maps) at API boundaries.
- Numeric domains: use the platform's exact-decimal type for
  monetary amounts; never floating-point binary types.
- Validate inputs at trust boundaries (service edges, external
  callers); trust types inside internal layers.

**Style:**
- One statement per line; lines kept within the project's
  configured line length.
- Braces / explicit blocks for all control structures.
- Resource lifetime MUST be managed by the language's idiomatic
  mechanism (RAII, `using`, `with`, try-with-resources, `defer`…).

**Error Handling:**
- Use exceptions (or the language's idiomatic error channel) for
  exceptional conditions only.
- Log all errors with the logger named in plan.md before
  propagating or recovering.
- Do NOT swallow errors silently.
- Return descriptive error messages and preserve legacy error
  codes where the spec requires parity.

**Documentation:**
- Doc comments for all public APIs in the language's idiomatic
  format.
- Inline comments only where the *why* is non-obvious.
- Reference source program / line numbers when re-implementing
  legacy logic.
- Architecture decisions live in `architecture/decisions/` as ADRs.

**Rationale:** Legacy code is often weakly typed and lightly
documented. Modernization is an opportunity to apply modern
engineering practices uniformly. The stack-specific *how* is
chosen per story; the principles above are stack-agnostic.

## Stack Selection

This constitution does NOT prescribe a language, framework, ORM,
database, package manager, IDE, or test framework. Those choices
are made per feature and declared in:

- **spec.md** — describes the business problem and the target
  system's externally visible behavior.
- **plan.md** — declares the language, framework, ORM, database,
  DI container, logger, test framework, mocking library, assertion
  library, build command, lint command, test command, and coverage
  threshold.
- **tasks.md** — references the choices in plan.md.

All speckit commands and agents read the stack from plan.md. They
MUST NOT assume any specific stack. If a command references a
build / lint / test tool, it MUST source that tool's invocation
from plan.md, not hard-code it.

## Development Workflow & Quality Gates

### Feature Branch Workflow

1. Create feature branch: `git checkout -b <feature-id>` (e.g.,
   `002-add-payment-handler`)
2. Run speckit workflow:
   - `@speckit.specify` → generate spec.md
   - `@speckit.clarify` → resolve underspecified items
   - `@speckit.plan` → generate plan.md (declares the stack)
   - `@speckit.tasks` → generate tasks.md
   - `@speckit.analyze` → cross-artifact consistency check
   - `@speckit.implement` → execute all tasks
   - `@speckit.review` → final quality review
3. Run validation using the commands declared in plan.md:
   - Build with 0 errors
   - All unit tests pass
   - Coverage at or above the threshold in plan.md
4. Commit changes with conventional commit message
   (`feat:`, `fix:`, `docs:`, `refactor:`, `test:`).
5. Create pull request for review.

### Quality Gates

**Gate 1: Specification Review**
- spec.md MUST define all functional and non-functional
  requirements
- Acceptance criteria MUST be testable and verifiable
- SME sign-off required before planning phase

**Gate 2: Implementation Plan Review**
- plan.md MUST declare the stack (language, framework, ORM,
  database, DI, logger, test framework, build/lint/test commands,
  coverage threshold)
- plan.md MUST cover technical design, data model, test strategy
- tasks.md MUST have a complete task breakdown with dependencies
- Architect sign-off required before implementation

**Gate 3: Code Review**
- Code MUST pass the lint / static analysis tools declared in
  plan.md
- Unit test coverage MUST meet plan.md's threshold
- All tests MUST pass
- At least one senior developer approval required

**Gate 4: Integration Testing**
- End-to-end tests MUST verify service contracts
- Behavior-comparison tests MUST match source-system outputs
- QA sign-off required before merge to main

### Pull Request Checklist

Every PR MUST include:

1. Feature specification (spec.md, plan.md, tasks.md in
   `specs/<feature-id>/`)
2. All tasks marked complete in tasks.md
3. Solution builds with 0 errors using plan.md's build command
4. All unit tests pass (100% pass rate)
5. Coverage report meets plan.md's threshold
6. Only production code in PR (temporary scaffolding removed)
7. README.md updated where feature documentation is expected
8. Security documentation for any newly introduced dependencies
   with known CVEs
9. Conventional commit message
10. At least one approving review from senior developer or
    architect

## Governance

This constitution supersedes all other coding practices,
conventions, and guidelines. All code reviews, agent invocations,
and quality gates MUST verify compliance with these principles.

**Amendment Process:**

- Proposed amendments MUST be documented in a pull request with
  rationale
- Amendments require approval from at least 2 architects
- After approval, update the constitution version number using
  semantic versioning:
  - **MAJOR**: Breaking changes to principles, removal of
    constraints
  - **MINOR**: New principle added, new constraint added
  - **PATCH**: Clarifications, typo fixes, formatting changes
- Update `LAST_AMENDED_DATE` to current date
- Add entry to the Sync Impact Report at the top of this file
- Update dependent templates in `.specify/templates/` to align
  with amended principles

**Complexity Justification:**

- Every deviation from these principles MUST be justified in an
  ADR
- ADRs MUST include: context, decision, consequences, alternatives
  considered
- ADRs MUST be reviewed and approved by architect before
  implementation

**Compliance Verification:**

- Every PR review MUST include a constitution compliance check
- Quality gate validators check for principle violations
- Agents operating on generated code MUST reference this
  constitution for guidance

---

**Version**: 2.0.0 | **Ratified**: 2026-06-01 | **Last Amended**: 2026-06-30
