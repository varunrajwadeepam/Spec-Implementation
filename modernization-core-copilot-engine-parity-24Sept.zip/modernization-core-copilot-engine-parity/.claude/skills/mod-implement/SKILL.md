---
name: mod-implement
description: Portfolio-aware alias for the full speckit implementation workflow for one story, equivalent to speckit.orchestrate. Resolves the portfolio, creates the story's spec folder under portfolios/{portfolio}/specs/{story-id}/, and runs specify through review.
argument-hint: "STORY-ACME-CORE-MU-01-01-001 [portfolio=ACME-CORE] [base=ACME-CORE]"
---

# mod-implement

`/mod-implement` is an **alias** for `/speckit.orchestrate` — same arguments, same behavior.

## Usage

```bash
/mod-implement STORY-ACME-CORE-MU-01-01-001
/mod-implement STORY-MU-ACMEREF-SUBSET-01-02-001 portfolio=ACME-REF-subset
```

## What to do when invoked

Read `.claude/skills/speckit.orchestrate/SKILL.md` in full and execute it exactly, passing the
arguments through unchanged. Do not follow any other copy of the workflow — that file is the single
source of truth for portfolio resolution order, base-branch handling, the seven phases
(specify → clarify → plan → tasks → analyze → implement → review), prerequisites, and error handling.

The alias exists only so the entry point has a name that says what it does; keeping a second copy of
the steps here is how the two drifted apart before (this file once told users to pre-create the story
branch, which makes the orchestrator abort).
