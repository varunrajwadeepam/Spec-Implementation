---
name: speckit.review
description: Post-implementation quality review of a completed feature. Scores the implementation across 7 weighted dimensions (spec compliance, test coverage, code quality, architecture, constitution compliance, error handling, performance) out of 100, pass threshold 70, and writes review-report.md. Use after /speckit.implement finishes and before opening a merge request.
argument-hint: "(no arguments)"
---

# speckit.review

Review completed implementation for quality, correctness, and compliance with specification and Constitution principles.

## Usage

```
/speckit.review
```

Invoke after `/speckit.implement` completes to perform comprehensive quality review.

## Purpose

Perform comprehensive quality review of completed implementation against specification, design documents, Constitution principles, and coding standards. Produce scored validation report identifying strengths, issues, and recommendations.

## When to Use

- After `/speckit.implement` completes all tasks
- Before creating pull request
- When implementation quality verification needed
- After major refactoring or changes

## Example workflow

```bash
# 1. Specify feature
/speckit.specify STORY-{portfolio}-MU-XX-YY-ZZZ "feature description"

# 2. Clarify ambiguities
/speckit.clarify

# 3. Create technical plan
/speckit.plan

# 4. Implement
/speckit.implement

# 5. Review (you are here)
/speckit.review

# 6. Create PR if approved
git push origin {story-id}
```

## Inputs

This skill reads from the feature directory and codebase:
- `spec.md` - Feature specification and acceptance criteria
- `plan.md` - Technical implementation plan (declares the stack, build/lint/test commands, coverage threshold)
- `tasks.md` - Task breakdown and completion status
- `research.md` - Design decisions and rationale (if exists)
- `data-model.md` - Entity definitions (if exists)
- `contracts/` - Interface contracts (if exists)
- `source-audit.md` - Source system mapping (migrations only; if the portfolio pack ships one)
- Implementation files referenced in tasks.md
- Test files referenced in tasks.md
- Build output for warnings/errors

## Outputs

Produces `review-report.md` in the feature directory with:
- Executive summary with overall score
- Dimension-by-dimension scoring
- Detailed findings (strengths, issues, recommendations)
- Constitution principles compliance check
- Source traceability verification (if migration)
- Test coverage analysis
- Code quality assessment
- Security review
- Performance validation
- Documentation completeness

**Approval statuses**:
- **90-100 pts**: APPROVED - Ready for pull request
- **70-89 pts**: APPROVED WITH RECOMMENDATIONS - Can proceed with minor fixes
- **< 70 pts**: CHANGES REQUIRED - Fix critical/major issues before PR

## Quality Dimensions

### 1. Specification Compliance (25 points)
- All user stories implemented
- All functional requirements met
- Acceptance criteria satisfied
- Edge cases handled
- Out-of-scope items not implemented

### 2. Test Coverage (20 points)
- Unit tests for all public methods
- Test coverage at or above the threshold declared in plan.md (default 80%)
- Tests follow AAA pattern (Arrange-Act-Assert)
- Test names descriptive and follow the convention declared in plan.md
- Edge cases tested
- Performance/concurrency tests (if required)

### 3. Code Quality (20 points)
- Clean, readable code
- Consistent naming conventions (per plan.md's style guide)
- Appropriate abstraction level
- Single Responsibility Principle
- DRY (Don't Repeat Yourself)
- No code smells (long methods, complex conditionals, etc.)
- Doc comments complete in the language's idiomatic format
- Inline comments for non-obvious logic only

### 4. Architecture & Design (15 points)
- Follows Clean Architecture
- Appropriate design patterns
- Separation of concerns
- Dependency injection used correctly (via the container declared in plan.md)
- No tight coupling
- Interface segregation

### 5. Constitution Compliance (10 points)
- Verify each active Constitution principle (loaded per `portfolio-resolution` §8: `portfolios/{portfolio}/specs/constitution.md`, else `.specify/memory/constitution.md`)
- Score against whatever principles are currently defined in the project constitution
- If no constitution exists, score based on general engineering best practices (TDD, Clean Architecture, Type Safety, Incremental Delivery)

### 6. Error Handling (5 points)
- Errors handled appropriately using the idiom declared in plan.md
- Error messages descriptive
- No silently swallowed errors
- Proper error / exception types used
- Logging on error paths

### 7. Performance (5 points)
- Performance targets met (if specified)
- No obvious performance issues
- Efficient algorithms and data structures
- Minimal allocations in hot paths

## Execution Steps

**Before step 1 — load portfolio context (MANDATORY).** Read
`.claude/skills/portfolio-resolution/SKILL.md` in full and follow it exactly. It
resolves the portfolio name, loads and validates `portfolios/{portfolio}/portfolio.yaml`,
locates skills pack-first (pack `skills/` → `subset_of` ancestors → `.claude/skills/`),
and defines the mandatory load order for the pack's **client**, **domain**, and
**target-stack-conventions** skills plus the authoritative
`portfolios/{portfolio}/{target_stack.definition}`.

Do not paraphrase or re-implement those rules here — that file is the single source
of truth, and skipping it is how this phase ends up generating output with no client
or domain knowledge loaded at all, which produces confidently wrong results rather
than an error.

1. **Setup**: Run `.specify/scripts/bash/check-prerequisites.sh --json --require-tasks --include-tasks` to get FEATURE_DIR and file paths.

2. **Load Context**: Read all design documents (spec, plan, tasks, research, data-model, contracts, source-audit if it exists). From plan.md, capture the declared stack and the build / lint / test commands and coverage threshold.

3. **Identify Implementation Files**: Extract file paths from tasks.md to find all implemented and test files.

4. **Specification Compliance Review**:
   - Compare implemented features against user stories in spec.md
   - Verify all functional requirements (FR-XXX) implemented
   - Check acceptance criteria met
   - Identify missing features or extra features (out-of-scope)
   - Score 0-25 points

5. **Test Coverage Review**:
   - Count test methods per implementation class
   - Verify tests for all public methods
   - Check test naming conventions match plan.md
   - Verify AAA pattern in test methods
   - Run the project's test command (from plan.md: e.g., `dotnet test`, `npm test`, `mvn test`, `pytest`)
   - Check for coverage gaps against the threshold declared in plan.md
   - Score 0-20 points

6. **Code Quality Review**:
   - Read implementation files
   - Check method lengths (< 50 lines ideal)
   - Check cyclomatic complexity (< 10 ideal)
   - Verify doc comments on public APIs in the language's idiomatic format
   - Check naming conventions against plan.md's style guide
   - Look for code smells (long parameter lists, nested conditionals, etc.)
   - Score 0-20 points

7. **Architecture & Design Review**:
   - Verify Clean Architecture layers respected
   - Check dependency injection usage
   - Verify interface segregation
   - Check for tight coupling
   - Verify design patterns used appropriately
   - Score 0-15 points

8. **Constitution Compliance Review**:
   - Load the constitution (`portfolios/{portfolio}/specs/constitution.md`, else the engine default `.specify/memory/constitution.md` — `portfolio-resolution` §8) (if present; resolve portfolio from `PORTFOLIO_NAME` in `.env` or explicit parameter) and extract active principles
   - For each principle, verify the implementation complies:
     - **Behavioral Fidelity** (if migration): source traceability comments present and parity verified
     - **TDD**: tasks.md shows tests written before implementation
     - **Clean Architecture**: layers and dependency direction respected
     - **Source-Anchored**: traceability comments (if migration) or design decision references
     - **Type Safety**: strong typing used, no `any` or `object` where specific type possible
     - **Incremental Delivery**: tasks.md shows phased implementation
   - If no constitution file exists, score based on general best practices above
   - Score 0-10 points (all or nothing per principle)

9. **Error Handling Review**:
   - Check that the error-handling idiom declared in plan.md is applied consistently
   - Verify errors logged before propagating or recovering
   - Check error / exception types appropriate
   - Verify no silently swallowed errors
   - Score 0-5 points

10. **Performance Review**:
    - Check algorithm complexity (O(n) vs O(n²) etc.)
    - Look for unnecessary allocations in loops
    - Verify performance tests exist (if spec requires)
    - Check for obvious performance issues
    - Score 0-5 points

11. **Additional Checks**:
    - **Security**: Check for injection (SQL, command, log), XSS, hardcoded secrets, unsafe deserialization
    - **Documentation**: Verify README/quickstart.md updated
    - **Build**: Run the project's build command (from plan.md) with warnings as errors
    - **Lint**: Run the lint / static-analysis command declared in plan.md on all changed files
    - **Migrations Only**: Verify source-to-target parity (all source behaviors preserved)

12. **Generate Report**: Write `review-report.md` with:
    - Executive summary (overall score, pass/fail, key findings)
    - Dimension scores table
    - Strengths (bullet list)
    - Issues (bullet list with severity: Critical/Major/Minor/Info)
    - Recommendations (bullet list)
    - Constitution compliance table
    - Test coverage summary
    - Files reviewed list
    - Approval status (APPROVED / APPROVED WITH RECOMMENDATIONS / CHANGES REQUIRED)

13. **Report Results**: Display executive summary and approval status. Recommend next steps based on score:
    - **90-100**: APPROVED - Ready for pull request
    - **70-89**: APPROVED WITH RECOMMENDATIONS - Can proceed but address recommendations
    - **< 70**: CHANGES REQUIRED - Fix critical/major issues before PR

## Scoring Guidelines

**Overall Pass Threshold**: ≥ 70/100

**Dimension Pass Thresholds**:
- Specification Compliance: ≥ 20/25 (80%)
- Test Coverage: ≥ 16/20 (80%)
- Code Quality: ≥ 14/20 (70%)
- Architecture & Design: ≥ 10/15 (67%)
- Constitution Compliance: ≥ 7/10 (70%)
- Error Handling: ≥ 3/5 (60%)
- Performance: ≥ 3/5 (60%)

**Issue Severity Definitions**:
- **Critical**: Blocks deployment, violates Constitution principle, security vulnerability, data loss risk
- **Major**: Functional defect, missing key feature, poor performance, inadequate test coverage
- **Minor**: Code smell, missing documentation, style violation, non-optimal implementation
- **Info**: Observation, suggestion for future enhancement, clarification needed

## Example Output Structure

```markdown
# Implementation Review Report: [FEATURE NAME]

**Date**: [DATE]
**Reviewer**: automated review (Claude Code / Copilot)
**Branch**: [BRANCH NAME]
**Overall Score**: [SCORE]/100 - [PASS/FAIL]

---

## Executive Summary

[2-3 sentence summary of implementation quality]

**Approval Status**: [APPROVED / APPROVED WITH RECOMMENDATIONS / CHANGES REQUIRED]

---

## Dimension Scores

| Dimension | Score | Max | Pass? | Notes |
|-----------|-------|-----|-------|-------|
| Specification Compliance | X | 25 | ✅/❌ | [brief note] |
| Test Coverage | X | 20 | ✅/❌ | [brief note] |
| Code Quality | X | 20 | ✅/❌ | [brief note] |
| Architecture & Design | X | 15 | ✅/❌ | [brief note] |
| Constitution Compliance | X | 10 | ✅/❌ | [brief note] |
| Error Handling | X | 5 | ✅/❌ | [brief note] |
| Performance | X | 5 | ✅/❌ | [brief note] |
| **TOTAL** | **X** | **100** | **✅/❌** | |

---

## Strengths

- [Bullet list of positive findings]

---

## Issues

### Critical
- [List of critical issues requiring immediate fix]

### Major
- [List of major issues]

### Minor
- [List of minor issues]

### Info
- [List of observations]

---

## Recommendations

1. [Prioritized list of recommended actions]

---

## Constitution Principles Compliance

| Principle | Status | Evidence |
|-----------|--------|----------|
| [Each active principle from constitution.md] | ✅/❌/N/A | [evidence] |

---

## Test Coverage Summary

- **Total Tests**: X
- **Pass Rate**: X% (Y passed, Z failed)
- **Coverage**: X% (if measurable)
- **Missing Tests**: [list any gaps]

---

## Files Reviewed

**Implementation Files** (X files):
- [list of implementation files with line counts]

**Test Files** (X files):
- [list of test files with test counts]

---

## Next Steps

[Recommended actions based on score]
```

## Review Principles

1. **Objective**: Focus on measurable criteria, not subjective preferences
2. **Constructive**: Frame issues as opportunities for improvement
3. **Evidence-Based**: Every issue/strength must reference specific code
4. **Actionable**: Recommendations must be specific and implementable
5. **Proportional**: Severity matches actual impact (don't mark style issues as Critical)
6. **Stack-Agnostic**: All concrete commands and identifiers come from plan.md, not from any hard-coded stack

## Notes

- Review is automated but comprehensive — human review still recommended
- Score thresholds are guidelines; critical issues can block even high scores
- Focus on what's implemented, not what could be added (unless specified in spec)
- For migrations, source-system parity is mandatory — missing features are Critical issues
- Constitution principle violations are automatic score penalties
