---
name: speckit.orchestrate
description: Portfolio-aware orchestration of the complete speckit implementation workflow (specify, clarify, plan, tasks, analyze, implement, review) for one story. Resolves the portfolio from the story ID, resolves and checks out the base branch, creates portfolios/{portfolio}/specs/{story-id}/, then runs every phase in order. Use this as the single entry point for implementing a story end to end.
argument-hint: "STORY-ACME-CORE-MU-01-01-001 [portfolio=ACME-CORE] [base=ACME-CORE]"
---

# speckit.orchestrate

Portfolio-aware orchestration of the complete speckit implementation workflow.

## Usage

```bash
# Automatic portfolio detection from story ID
/speckit.orchestrate STORY-ACME-CORE-MU-01-01-001

# Explicit portfolio (REQUIRED when story ID doesn't embed portfolio)
/speckit.orchestrate STORY-MU-ACMEREF-SUBSET-01-02-001 portfolio=ACME-REF-subset
```

## What it does

Orchestrates the complete implementation workflow with automatic portfolio-scoped folder creation:

1. **Detect Portfolio** - Extract from story ID pattern `STORY-{PORTFOLIO}-...` or read from `.env`
2. **Put HEAD on the base branch** - so `/speckit.specify` cuts the story branch from the right place
3. **Run Workflow** - Execute every phase from the **repo root** (the helper scripts resolve all paths themselves and write into `portfolios/{portfolio}/specs/{story-id}/`):
   - `/speckit.specify` - Generate spec.md from story document
   - `/speckit.clarify` - Identify and resolve ambiguities  
   - `/speckit.plan` - Create technical implementation plan
   - `/speckit.tasks` - Generate dependency-ordered tasks
   - `/speckit.analyze` - Non-destructive cross-artifact consistency and quality analysis across spec.md, plan.md, and tasks.md
   - `/speckit.implement` - Execute all tasks
   - `/speckit.review` - Quality validation

## Workflow Steps

| Step | Skill | Output | Purpose |
|------|-------|--------|---------|
| 1 | `/speckit.specify` | `spec.md` | Generate feature specification from the story |
| 2 | `/speckit.clarify` | Updated `spec.md` | Identify and resolve ambiguities (≤5 questions) |
| 3 | `/speckit.plan` | `plan.md`, `research.md` | Create the technical implementation plan |
| 4 | `/speckit.tasks` | `tasks.md` | Generate the dependency-ordered task list |
| 5 | `/speckit.analyze` | `analyze-status.json` | Non-destructive cross-artifact consistency and quality analysis across spec.md, plan.md, tasks.md |
| 6 | `/speckit.implement` | Code files | Execute all tasks from tasks.md |
| 7 | `/speckit.review` | `review-report.md` | Quality validation (7 scored dimensions, ≥70/100) |

## Portfolio Detection

> **Authority.** The resolution rules below are a summary for the reader. The
> executable contract is `.claude/skills/portfolio-resolution/SKILL.md` — read it
> in full and follow it exactly, including the pack-first skill search and the
> mandatory client → domain → extras → migration → stack load order. Where this
> summary and that file disagree, that file wins.

Portfolio is resolved **once** at the start, in this precedence order:

1. **Explicit parameter**: `portfolio=ACME-REF-subset` in command (highest priority)
2. **Story ID**: matched against installed packs (see below)
3. **Environment file**: `PORTFOLIO_NAME` from project-root `.env` — only when the ID names no installed pack
4. **Error if none found**: Stop and ask the user

Pass the resolved value on to every phase as `portfolio=<name>` so no phase re-resolves it differently.

Once resolved, the portfolio value is used for all path lookups in this run.

### Story ID Matching

Matching is done against the **installed packs** — every directory under
`portfolios/` that has a `portfolio.yaml` — not against a name-shape regex. The
story ID has its `STORY-`/`EPIC-` (and legacy `MU-`) prefix stripped, and the
longest installed pack name that prefixes the remainder wins:

| Story ID | Installed pack | Resolves to |
|---|---|---|
| `STORY-ACME-CORE-MU-01-01-001` | `ACME-CORE` | `ACME-CORE` |
| `STORY-TRDOC421-MU-01-01-001` | `TRDOC421` | `TRDOC421` |
| `STORY-MEETING-ROOM-BOOKING-MU-01-01-001` | `MEETING-ROOM-BOOKING` | `MEETING-ROOM-BOOKING` |
| `STORY-ACME-REF-subset-MU-01-02-001` | `ACME-REF-subset` | `ACME-REF-subset` |

This is why matching is pack-driven: the previous regex
(`^STORY-([A-Z]+-[A-Z0-9]+)-MU-`) required exactly two uppercase hyphen-separated
segments, so it matched none of the one-segment, three-segment, or mixed-case
packs above.

**When the ID names no pack at all** (e.g. `STORY-MU-ACMEREF-SUBSET-01-02-001`,
where `ACMEREF` ≠ `ACME-REF`, or a custom-code feature like
`MRBS-001-meeting-room-booking`), resolution falls back to an existing
`portfolios/*/specs/{id}/` folder, then to locating `{id}.md` inside a pack's
`docs/epics/`. If none of those resolve, pass `portfolio=<name>` explicitly or set
`PORTFOLIO_NAME` in `.env`.

## Folder Structure Created

All artifacts are created in `portfolios/{portfolio}/specs/{story-id}/`:

```
portfolios/{portfolio}/specs/{story-id}/
├── spec.md              # Feature specification
├── plan.md              # Technical implementation plan
├── tasks.md             # Dependency-ordered task list
├── research.md          # Design decisions and ADRs
├── data-model.md        # Entity and database schema
├── review-report.md     # Quality review results
├── checklists/
│   └── requirements.md  # Requirements checklist
└── contracts/
    └── *.md             # Interface contracts
```

## Prerequisites

- Story must exist in `portfolios/{portfolio}/docs/epics/{MU-ID}/{EPIC-ID}/{story-id}.md`
- Portfolio must be resolvable (explicit parameter, Story ID pattern, or `.env`)
- **Do NOT pre-create the story branch or the spec folder.** `create-new-feature.sh` (run by `/speckit.specify`) creates both and refuses to run if either already exists. `/speckit.specify` (step 0e) checks out the base branch (the portfolio integration branch, e.g., `ACME-CORE`) and then cuts the new story branch from it. Pre-creating the branch yourself causes the orchestrator to abort with "branch already exists".
- The working tree MUST be clean before invoking (no uncommitted edits, no untracked files). The sync step refuses to run on a dirty tree and will not auto-stash.

## Implementation Steps

When this skill is invoked, Claude will:

1. **Resolve portfolio** using the precedence order in "Portfolio Detection" above
2. **Validate input** — confirm `portfolios/{portfolio}/portfolio.yaml` exists and the story file `{story-id}.md` exists under `portfolios/{portfolio}/docs/epics/`. Stop with "Story not found" otherwise.
3. **Resolve the base branch** (the portfolio integration branch — typically `ACME-CORE`, `UWR-POC`, etc., or `main` if none). Order of precedence:
   1. Explicit `base=<branch>` argument on the command.
   2. `SPECKIT_BASE_BRANCH=<branch>` in `.env`.
   3. A branch named exactly after the portfolio (e.g., `ACME-CORE` for portfolio `ACME-CORE`), if it exists locally or on `origin`.
   4. Default `main`.
   `/speckit.specify` step 0e uses this same order.
4. **Verify clean working tree.** `git status --porcelain` MUST be empty. If dirty, abort.
5. **Check out the base branch** (`git checkout <base>` + `git pull origin <base> --ff-only`) so the new story branch is cut from the right place. This step is delegated to `/speckit.specify` step 0e but the orchestrator confirms `HEAD` is on the base branch before delegating.
6. **Run the speckit workflow from the repo root**, passing `portfolio={portfolio}` to each phase:
   - `/speckit.specify {story-id} portfolio={portfolio}` creates the story branch from the base and the spec folder `portfolios/{portfolio}/specs/{story-id}/` (via `create-new-feature.sh`), and pins it as the active feature.
   - Every later phase finds that folder through `check-prerequisites.sh` / `setup-plan.sh`, which resolve it from the pinned feature — never from the current directory.
   - Do **not** `mkdir` the spec folder or `cd` into it: the first makes `create-new-feature.sh` abort, the second breaks every repo-relative `.specify/scripts/...` invocation.

## Example Execution

```bash
# User runs (portfolio embedded in story ID):
/speckit.orchestrate STORY-ACME-CORE-MU-01-01-001

# User runs (portfolio explicit — required when ID doesn't embed it):
/speckit.orchestrate STORY-MU-ACMEREF-SUBSET-01-02-001 portfolio=ACME-REF-subset

# Claude executes:
# 1. Resolve portfolio (explicit > story ID > .env > error)
# 2. Resolve base branch (base= arg > SPECKIT_BASE_BRANCH > portfolio integration branch > main)
# 3. Verify clean tree; abort if dirty
# 4. git checkout <base> && git pull origin <base> --ff-only
# 5. /speckit.specify (creates the story branch + portfolios/{portfolio}/specs/{story-id}/)
# 6. /speckit.clarify
# 7. /speckit.plan
# 8. /speckit.tasks
# 9. /speckit.analyze
# 10. /speckit.implement
# 11. /speckit.review
```

### Branch behavior

The new story branch (`STORY-ACME-CORE-MU-01-01-001` in the example above) is created by `/speckit.specify`, not by `/speckit.orchestrate` directly. The orchestrator's responsibility is to put `HEAD` on the correct base before delegating. If the user is already on a different story branch when invoking `/speckit.orchestrate` (a common mid-stream case), the orchestrator switches to the base branch first so the new story branch does not inherit the prior story's commits.

## Common Use Cases

### Standard workflow (most common)

```bash
# Do NOT pre-create the story branch — /speckit.specify step 0e cuts it from the base.
/speckit.orchestrate STORY-ACME-CORE-MU-01-01-001
# Review writes review-report.md; fix any issues if the score is < 70
git add . && git commit -m "feat(ACME-CORE): implement feature X"
```

### Resume after interruption

Every phase is individually resumable, because state lives on disk (the spec
folder, `analyze-status.json`, `IMPACT-APPROVED.md`) and in the branch name —
not in conversation context. Re-run from whichever phase was interrupted:

```bash
/speckit.tasks
/speckit.implement
```

### Re-run quality review only

```bash
/speckit.review
```

## Quality Gates

- **Spec clarity**: No ambiguities or underspecified areas (clarify step resolves)
- **Plan completeness**: All design decisions documented with ADRs
- **Task actionability**: All tasks have clear acceptance criteria
- **Implementation quality**: ≥70/100 on review score
- **Constitution compliance**: Every principle of the resolved constitution verified (see `portfolio-resolution` §8)

## Error Handling

| Error | Cause | Resolution |
|-------|-------|------------|
| "Cannot detect portfolio" | Story ID doesn't match pattern and no .env | Add `portfolio=` parameter or fix story ID format |
| "Story not found" | Story doesn't exist in docs/ | This repo no longer generates EPICs/stories — obtain the story file from the portfolio pack's `docs/epics/{MU-ID}/` first |
| "Working tree has uncommitted changes" | Dirty tree at invocation time | Commit or stash before re-running; the orchestrator never auto-stashes |
| "Cannot resolve base branch" | No `base=` arg, no `.env`, and no integration branch matching the portfolio | Pass `base=<branch>` explicitly, or set `SPECKIT_BASE_BRANCH` in `.env` |
| "Base branch has diverged from origin" | Local base branch ahead of remote (non-fast-forward) | Reconcile manually (rebase, reset, or merge) before re-running |
| "Branch already exists" | Story branch was pre-created or a prior run partially completed | Delete the partial branch (`git branch -D <story-id>`) or use the existing branch directly without re-running orchestrate |
| "Review score < 70" | Implementation quality issues | Fix issues in review-report.md and re-run /speckit.review |
| Files landed outside the pack | Individual skills were run without a resolvable portfolio | Artifacts belong in `portfolios/{portfolio}/specs/{story-id}/`. Re-run via `/speckit.orchestrate`, or pass `portfolio=<name>` to the individual skill |

## Related Skills

- Individual `/speckit.*` skills for manual workflow steps

## Notes

- Every phase runs from the repo root; the helper scripts compute pack-scoped paths themselves
- Portfolio detection is deterministic and reproducible
- Folder structure is created automatically by `/speckit.specify` — no manual setup needed
