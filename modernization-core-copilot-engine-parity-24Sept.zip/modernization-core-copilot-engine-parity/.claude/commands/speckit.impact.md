---
description: Analyze the impact of changes to shared code (interfaces, components, services) before implementation begins. MANDATORY per Constitution Principle II (Contract-First Design) for any change that touches shared / public surface area.
handoffs: 
  - label: Generate Task Breakdown
    agent: speckit.tasks
    prompt: Generate tasks for implementation based on the approved impact analysis
---

## User Input

```text
$ARGUMENTS
```

You **MUST** consider the user input before proceeding (if not empty).

## Outline

**Before step 1 — load portfolio context (MANDATORY).** Read
`.claude/skills/portfolio-resolution/SKILL.md` in full and follow it exactly. It
resolves the portfolio name, loads and validates `portfolios/{portfolio}/portfolio.yaml`,
locates skills pack-first (pack `skills/` → `subset_of` ancestors → `.claude/skills/`),
and defines the mandatory load order for the pack's **client**, **domain**, and
**target-stack-conventions** skills plus the authoritative
`portfolios/{portfolio}/{target_stack.definition}`.

Do not paraphrase or re-implement those rules here — that file is the single source
of truth, and skipping it is how this phase ends up generating output with no client
or domain knowledge loaded at all, which produces confidently wrong results rather
than an error.

Goal: Produce a comprehensive impact analysis for changes to shared code, identifying all consumers, breaking changes, migration paths, and risk levels. Required before implementation begins per Constitution Principle II (Contract-First Design).

**MANDATORY TRIGGERS** (Constitution Principle II — any of the following, regardless of stack):
- Modifying a shared interface, abstract base, or contract type
- Changing a component / module / type used across multiple features
- Updating a shared service, helper, pipe/filter, directive, middleware, or interceptor
- Modifying global state structure (store shape, action payloads, reducers, selectors, effects)
- Changing a published service contract (WSDL operation, REST endpoint, gRPC method, GraphQL schema, message contract)
- Changing routes, route guards, resolvers, or URL strategies
- Updating third-party dependencies in the project's package manager (any breaking version bump)
- Any change affecting a hybrid / interop / bridge layer between two stacks
- Any change crossing a deployment boundary (separately released artifact / service / library)

**SKIP if**:
- New feature with no shared code impact
- Isolated component (single consumer)
- Test-only changes
- Documentation updates

Execution steps:

1. **Setup & Context Loading**:
   - Run `.specify/scripts/bash/check-prerequisites.sh --json --paths-only` from repo root
   - Parse JSON fields: `FEATURE_DIR`, `FEATURE_SPEC`, `IMPL_PLAN`
   - Load spec.md and plan.md to understand the planned changes
   - Identify which files will be modified from plan.md "Project Structure" section

2. **Change Summary** (Executive Summary):
   - Extract what's being changed from plan.md
   - Determine change type (general categories — pick whichever apply, stack-independent):
     - Interface / abstract type modification (adding/removing/changing methods, properties, attributes)
     - Data schema change (adding/removing/renaming fields on a serialized contract type)
     - Service contract change (wire-format compatibility — WSDL, OpenAPI, gRPC, GraphQL, message envelope)
     - Component / module surface change (inputs, outputs, public API)
     - Function / method signature change (parameters, return type, exceptions)
     - Global state structure change (store shape, action payloads, event schema)
     - Third-party dependency update (version change, breaking change)
   - Assess if the change is breaking:
     - **Breaking**: Removes/renames/changes existing contracts (consumers must update)
     - **Non-breaking**: Adds new contracts (consumers can optionally adopt)
     - **Behavioral**: Same signature but different runtime behavior
   - Determine initial risk level: HIGH / MEDIUM / LOW (refined in step 5)

3. **Dependency Discovery** (Consumer Inventory):
   For EACH file being modified:
   
   a. **Identify changed symbols** (classes, interfaces, methods, properties, selectors, types, modules, etc.)
   
   b. **Search for all consumers** using Grep/Glob. Use search patterns appropriate to the source-tree layout declared in plan.md. Examples (adapt to your stack):
      - Type / interface name: `Grep pattern="<symbol>" output_mode="files_with_matches"`
      - Annotation / decorator / attribute: `Grep pattern="@?<AttributeName>" output_mode="files_with_matches"`
      - Component / element usage: `Grep pattern="<component-selector|ComponentName"` (HTML / templated languages)
      - Module imports: `Grep pattern="from.*<module>|import.*<symbol>"` (or the language's idiomatic import syntax)
      - Wire contracts: check for external clients in the contracts location declared in plan.md
      - Global-state selectors / accessors: `Grep pattern="<accessor>\(.*<key>\)" output_mode="files_with_matches"`
   
   c. **Categorize consumers**:
      - Same project (internal)
      - Cross-project (within solution)
      - External clients (downstream API consumers)
      - Test files (unit tests, integration tests)
      - Interop / bridge layer (if a hybrid app crosses two stacks)
   
   d. **Document search commands used** (for reproducibility)
   
   e. **Read representative consumer files** to understand usage patterns

4. **Breaking Change Analysis**:
   For each modified symbol:
   
   a. **Compare OLD vs NEW contracts**:
      - OLD: Current state from Read tool on existing files
      - NEW: Target state from plan.md design
   
   b. **Classify severity**:
      - 🔴 **Compile-time / static-analysis**: Compiler / type-checker / linter error without consumer updates
      - 🟠 **Runtime**: Builds but throws at runtime (missing method, wrong type, schema mismatch)
      - 🟡 **Behavioral**: Builds/runs but produces different output
   
   c. **Identify affected consumers**: List specific files from step 3
   
   d. **Special cases** — common patterns that surface in many stacks. Refer to the project's stack guidance for the exact rules, but the principles are universal:
      - Adding a new fault / error type to an existing operation: usually non-breaking (additive)
      - Changing a contract namespace / package / module of a serialized type: breaking (schema identity changes)
      - Removing or renaming a published operation / endpoint / message: breaking
      - Adding a new optional input / parameter: usually non-breaking
      - Renaming an input / output / event name on a UI unit: breaking (consumers' templates / bindings break)
      - Adding a new global-state field: non-breaking (existing accessors still resolve)
      - Renaming a global-state field: breaking (existing accessors fail)
      - Changing serialization format / encoding (date format, number type, collection encoding): breaking, often silent

5. **Migration Path Definition**:
   For EACH breaking change (BC-001, BC-002, etc.):
   
   a. **Provide concrete code-level migration instructions**:
      - NOT: "Update consumers to use new interface"
      - YES: Show exact BEFORE/AFTER code snippets per consumer
   
   b. **Cover ALL consumers** identified in step 3:
      - Each consumer file gets specific migration code
      - Include changes in every language / artifact involved (source files, templates, schemas, configuration)
   
   c. **Include test updates**:
      - Test harness / setup configuration changes
      - Mock / stub / fake object updates
      - Assertion updates

6. **Risk Assessment**:
   For each changed item:
   
   a. **Count consumers**: N (from step 3)
   
   b. **Assess criticality**:
      - HIGH: Widely used (10+ consumers) OR on critical path (auth, booking, payment)
      - MEDIUM: Moderate use (3-9 consumers) OR on non-critical path
      - LOW: Isolated use (1-2 consumers) OR internal-only change
   
   c. **Justify risk rating**: Explain why HIGH/MEDIUM/LOW
   
   d. **Determine overall risk**: Highest individual risk level

7. **Test Coverage Plan**:
   
   a. **Identify existing tests** covering changed code:
      - Find test files from step 3 consumer search
      - Determine which tests will break (e.g., interface signature changed)
   
   b. **Define new tests required**:
      - Test new functionality (if added)
      - Test backward compatibility (if non-breaking change)
      - Test migration path (if breaking change)
   
   c. **List QA/E2E scenarios**:
      - User-facing flows affected (from spec.md user stories)
      - Integration points to verify

8. **Deployment Impact**:
   
   a. **Build impact**:
      - New packages / dependencies required? (check plan.md dependencies)
      - Breaking changes require coordinated deployment?
   
   b. **Deployment sequence**:
      - Single-artifact change → simple deploy
      - Multi-service / multi-artifact change → coordination required
   
   c. **Rollback plan**:
      - How to revert if production issues occur
      - Data / persisted-state concerns (global stores, local storage, DB schema, cached schemas)
      - Estimated rollback time

9. **Constitutional Compliance Re-check**:
   Verify change aligns with active Constitution principles (loaded per `portfolio-resolution` §8: `portfolios/{portfolio}/specs/constitution.md`, else `.specify/memory/constitution.md` — resolve portfolio from `PORTFOLIO_NAME` in `.env` or explicit parameter):
   - Behavioral Fidelity (if migration — source parity preserved)
   - Contract-First Design (any published service contract)
   - Test-Driven Development (tests planned)
   - Clean Architecture (layer dependencies valid)
   - Impact Analysis Required (this document)

10. **Generate impact-analysis.md**:
    Write to `FEATURE_DIR/impact-analysis.md` using this structure:
    
    ```markdown
    # Impact Analysis: [Feature Name]
    
    **Feature**: [Story ID]
    **Date**: [YYYY-MM-DD]
    **Analysis Type**: [Interface Change / Component Change / Service Contract / etc.]
    **Severity**: [Breaking / Non-breaking / Behavioral]
    
    ## Executive Summary
    - Change Type
    - Breaking Change: YES / NO
    - Impact Scope: N files modified, N consumers
    - Risk Level: HIGH / MEDIUM / LOW
    - Recommendation: PROCEED / CHANGES REQUIRED / BLOCKED
    
    ## Current State Analysis
    - What exists now (code snippets from Read tool)
    - How it's used (consumer patterns)
    - Who uses it (consumer count)
    
    ## Proposed Change
    - What changes (OLD vs NEW comparison)
    - What doesn't change
    
    ## Dependency Analysis
    - Files Referencing [Changed Symbol] (table from step 3)
    - Search commands used (reproducible)
    
    ## Breaking Change Analysis (if any)
    - BC-001: [Description]
      - Severity: 🔴 / 🟠 / 🟡
      - OLD contract vs NEW contract (side-by-side)
      - Consumers affected (file list)
    
    ## Migration Path (if breaking changes)
    - BC-001 Migration Instructions
      - Consumer A: BEFORE/AFTER code
      - Consumer B: BEFORE/AFTER code
      - Test updates: BEFORE/AFTER code
    
    ## Risk Assessment
    - Risk level per changed item (table)
    - Overall risk: HIGH / MEDIUM / LOW
    - Justification
    
    ## Test Coverage Plan
    - Existing tests (will they break?)
    - New tests required
    - QA scenarios to re-run
    
    ## Deployment Impact
    - Build impact
    - Deployment sequence
    - Rollback plan
    
    ## Constitutional Compliance
    - Constitution principles verified
    
    ## Approval
    - Status: Pending / Approved / Rejected
    - Sign-off required: Standard / Second Reviewer + QA (if HIGH risk)
    ```

11. **Report completion**:
    - Path to impact-analysis.md
    - Change type and severity
    - Risk level (HIGH/MEDIUM/LOW)
    - Breaking changes count
    - Consumers affected count
    - Recommendation: PROCEED / CHANGES REQUIRED
    - Next command: `/speckit.tasks` (if approved)

## Behavior Rules

- **Evidence-based**: All consumers found via actual Grep/Glob searches (not memory)
- **Complete**: Every consumer must have migration path (if breaking change)
- **Reproducible**: Document all search commands used
- **Actionable**: Migration instructions are concrete code snippets
- **Risk-proportional**: Risk ratings justified (not arbitrary)
- **Constitution-aligned**: Changes comply with all relevant principles

## Special Cases (general patterns)

The principles below are stack-independent. Substitute the concrete names from your stack (declared in plan.md) when applying them.

### Published Service Contracts (WSDL / OpenAPI / gRPC / GraphQL / message contracts)

**Adding a new optional error / fault type to an existing operation**:
- **Breaking?** NO (additive)
- **Impact**: New clients can discover the new error; old clients unaffected
- **Risk**: LOW

**Changing the namespace / package / version of a serialized data type**:
- **Breaking?** YES (schema identity changes)
- **Impact**: All external clients must regenerate proxies / models
- **Risk**: HIGH (if external clients exist)

**Removing or renaming a published operation / endpoint / message**:
- **Breaking?** YES (consumers can no longer find the operation)
- **Impact**: Clients calling the removed operation will fail at runtime
- **Risk**: HIGH

### UI Components / Modules

**Adding a new optional input / property**:
- **Breaking?** NO (consumers can optionally bind the new input)
- **Risk**: LOW

**Renaming an input or output / event name**:
- **Breaking?** YES (templates / bindings break)
- **Impact**: All consumers binding to the old name must update
- **Risk**: MEDIUM to HIGH (depends on usage)

### Global State / Store

**Adding a new state field**:
- **Breaking?** NO (additive — existing accessors still resolve)
- **Risk**: LOW

**Renaming a state field**:
- **Breaking?** YES (existing accessors fail)
- **Impact**: All accessors reading the old field name must update
- **Risk**: HIGH (global state is broadly consumed)

### Wire-Format Encoding

**Changing date format, number representation, or collection encoding on a published payload**:
- **Breaking?** YES (often silently)
- **Impact**: Consumers parse the wire payload using the old contract; values arrive as wrong type or wrong shape
- **Risk**: HIGH

## Error Handling

- If spec.md or plan.md missing: ERROR "Run /speckit.specify and /speckit.plan first"
- If no shared code changes detected: "No impact analysis required (isolated feature)"
- If grep searches find zero consumers but change is to shared code: WARN "Unexpectedly no consumers found; verify search patterns"
- If breaking change found but no migration path: ERROR "All breaking changes must have migration paths"

## Output Example

```markdown
# Impact Analysis: <Change Title>

**Change Type**: <e.g., "Adding a new fault contract to an existing service operation">
**Breaking Change**: NO / YES
**Risk Level**: LOW / MEDIUM / HIGH

## Executive Summary
- <One-sentence summary of what is being changed>
- <Breaking? Why or why not>
- <N files modified, M consumers analyzed (K affected)>
- <Any prior-art note: "Implementation already does X; this formalizes in Y">

## Dependency Analysis
<List the grep / search commands used, then the resulting consumer table>

## Breaking Change Analysis
<For each breaking change: BC-001, severity, OLD vs NEW, affected consumers. "None" if all additive.>

## Risk Assessment
**Overall: LOW / MEDIUM / HIGH**
- <Justification line 1>
- <Justification line 2>

## Recommendation
✅ **APPROVED TO PROCEED** / ⚠️ **CHANGES REQUIRED** / ❌ **BLOCKED**
```

Context for analysis: $ARGUMENTS
