# Engine audit — implementation pipeline coherence (2026-09-23)

Scope: the engine (`.claude/`, `.specify/`, `scripts/`, `schemas/`, `tests/`, CI, `CLAUDE.md`/`README.md`)
and the tracked packs, checked for whether the documented flow actually runs end to end and whether
the documents agree with each other and with the scripts.

Baseline at `a6d3b2c`:

| Check | Result |
|---|---|
| `bash tests/speckit-scripts.test.sh` | 76 passed |
| `scripts/gen-copilot.sh --check` (the CI job) | **FAIL** — `.github/skills/speckit-plan` stale (the LLD step added to `speckit.plan` in `d6e3082` was never regenerated) |
| `pytest tests/pipeline` | **6 failed** / 13 passed |
| `scripts/check-open-core.py` | **FAIL** — 45 issues |
| `scripts/install-portfolio.sh <pack>` | cannot run — `pyyaml` missing from `requirements.txt` (declared only in `pyproject.toml`) |

---

## A. The documented one-shot flow does not run

**A1 — Orchestrator pre-creates the spec folder; `create-new-feature.sh` then refuses it.**
`speckit.orchestrate` step 6 does `mkdir -p portfolios/{p}/specs/{story-id}` before
`/speckit.specify`, and `create-new-feature.sh` dies on `[ -e "$FEATURE_DIR" ]`. Reproduced in a
scratch clone:
`{"ERROR":"Spec folder already exists: .../specs/STORY-LEAVE-MANAGEMENT-MU-01-01-002. ..."}`.
*Why:* the orchestrator was written for upstream spec-kit (files created relative to cwd); the
scripts were later rewritten to resolve everything from the repo root and own folder creation.
*Patch:* the orchestrator does not create the folder; `/speckit.specify` does.

**A2 — Orchestrator `cd`s into the spec folder; every command runs scripts by repo-relative path.**
After `cd portfolios/X/specs/Y`, `.specify/scripts/bash/create-new-feature.sh` does not exist
(reproduced). Every command says "run … from repo root" — only the orchestrator (and CLAUDE.md's
"built-in speckit skills create files relative to the current directory") says otherwise.
*Patch:* stay at repo root; remove the cwd rationale from orchestrator, mod-implement, CLAUDE.md, README.

**A3 — Three different portfolio precedence orders.**

| Source | Order |
|---|---|
| `portfolio-resolution` §1 (declared single source of truth) | explicit > `.env` (no story-ID step at all) |
| `speckit.orchestrate`, `speckit.specify` §2c | explicit > story ID > `.env` |
| `mod-implement` | explicit > `.env` > story ID |
| `common.sh resolve_portfolio` (what actually runs) | explicit > `.env` > spec dir > story ID > story file |

Real consequence, visible in the LEAVE-MANAGEMENT validation report: local `.env` says
`PORTFOLIO_NAME=TRDOC421`, so the script resolves any story — including
`STORY-LEAVE-MANAGEMENT-…` — to TRDOC421 (which has no manifest) and fails.
*Patch:* one order everywhere — explicit > identifier (spec dir, pack-name prefix, story file) >
`.env`. `.env` is the default for runs with no identifier, not an override of a specific story ID.

**A4 — Two base-branch rules.** Orchestrator: `base=` > `SPECKIT_BASE_BRANCH` > branch named after the
portfolio > `main`. `speckit.specify` 0e: `base=` > `SPECKIT_BASE_BRANCH` > "most recent ancestor
branch in `git log`" (not determinable) > `main`. *Patch:* specify uses the orchestrator's rule.

**A5 — `mod-implement` contradicts the orchestrator it aliases.** It tells the user to
`git checkout -b STORY-…` first (the orchestrator says doing so aborts), claims it "skips steps if
artifacts already exist" (nothing implements that), and lists five phases instead of seven.
*Patch:* reduce it to a pure alias that delegates to `speckit.orchestrate`.

**A6 — `speckit.specify` 2b checks `specs/<feature-name>`** (repo root), not the pack-scoped folder.

## B. Rules that are loaded from places that don't exist

**B1 — The constitution is never applied.** Every phase loads
`portfolios/{portfolio}/specs/constitution.md` "if exists"; no pack has one. The engine's real
constitution (`.specify/memory/constitution.md`, principles I–VII) is referenced by nothing, so
spec/plan/analyze/review silently run with no constitution. *Patch:* pack file first, engine file
as fallback — defined once in `portfolio-resolution`.

**B2 — "Constitution XIII" does not exist.** `speckit.impact` and the spec template's checklist
cite it as the mandate; the constitution has seven principles. The real basis is Principle II
("All breaking changes to contracts require an Impact Analysis"). *Patch:* cite Principle II.

**B3 — Constitution still carries "Human Gates (AS-IS Pipeline)"** (A07/A09 gates on
`architecture/current-state|target-state/`) — retired pipeline. *Patch:* remove.

**B4 — `portfolio-resolution` still describes retired agents.** §3 scopes `domain_skill`
lookup and `stack_skill` to "LLD-phase / LLD-to-be agents only"; §5.6 says the stack skill is for
implementation agents. §6 hard-maps `net`/`java` to the engine skills and ignores the manifest's
`conventions_skill`, which contradicts CLAUDE.md ("conventions_skill may live in this pack").
*Patch:* stack skill = `manifest.target_stack.conventions_skill`, resolved pack-first, always.

**B5 — Schema descriptions** still mention `portfolios/shared-skills/` (removed) and "LLD agents".

## C. Documentation drift

**C1 — CLAUDE.md "Active agents" table lists 14 agents; `.claude/agents/` has 4.** The ten
`speckit.*` entries are commands (`.claude/commands/`) or skills. README line ~320 repeats it.
**C2 — Copilot mirror stale** (baseline table) — CI fails on this branch.

## D. Pack defects (content, not engine)

- **LEAVE-MANAGEMENT** — `target_stack.definition: inputs/target-stack-java.md` does not exist (the
  implementation ran with no authoritative stack file; pytest fails). LLD lives at
  `architecture/lld/` but every agent looks in `architecture/LLD/` (works only on case-insensitive
  macOS; fails on Linux CI / Copilot on Linux). No EPIC file exists for `EPIC-MU-01-01-01` (only the
  story). Spec folder has no `research.md`/`data-model.md`/`analyze-status.json` — plan and analyze
  did not produce their outputs.
- **MEETING-ROOM-BOOKING** — no `docs/epics/` (declared REQUIRED), spec id `MRBS-001-…` is a
  custom code. Orchestrator step 2 ("confirm `docs/epics/` exists") rejects this pack.

## E. Local environment (untracked, not committed)

- `.env` → `PORTFOLIO_NAME=TRDOC421`, `SPECKIT_BASE_BRANCH=spec/trdoc421-order-cancel`; TRDOC421 is not installed.
- `portfolios/TRDOC421/` is left-over build output with no `portfolio.yaml` — cause of 5 of the 6 pytest failures.

## F. Open-core / leftovers from the retired pipelines

- Client identifiers in engine files: `NPW`/`H421` in the one-off rename scripts
  (`align-mu-folders.sh`, `rename-*.sh`, `rename-subset-ids.ps1`), `story_status.py`,
  `README-story-status.md`; `Uwr.Services`/`UWRDB` in `Register-EventLogSource.ps1`,
  `Setup-IisHosting.ps1` + tests; `uwr.application` in `target-stack-java-conventions`.
- `reports/A09-BC-*-accuracy-report.md` — AS-IS/TSA-era output for client portfolio `NPW-H421-subset2`.
- `code-review/analyse-prompt.md` — unreferenced (only the `-dotnet`/`-java` variants are used).

---

## Resolution

Applied in the same change as this report:

- A1–A6: orchestrator no longer `mkdir`s/`cd`s (runs from repo root, passes `portfolio=` on);
  one resolution order everywhere (explicit > identifier > `.env`), implemented in
  `common.sh resolve_portfolio` and tested (`id > env`, `env when id names no pack`); one
  base-branch rule; `mod-implement` is a pure alias; specify checks the pack-scoped folder.
- B1–B5: `portfolio-resolution` §8 defines the constitution lookup (pack, else
  `.specify/memory/constitution.md`) and every phase uses it; "Constitution XIII" → Principle II;
  AS-IS human gates removed and Principle II's contract sources updated; retired LLD-phase wording
  removed; stack skill always comes from `target_stack.conventions_skill`; schema descriptions fixed.
- C1–C2: CLAUDE.md/README separate commands, skills and agents; Copilot mirror regenerated.
- `uwr.application` genericised; `pyyaml` added to `requirements.txt`; LEAVE-MANAGEMENT
  `architecture/lld` → `architecture/LLD` (and its spec references).
- `test_subset_inherits_parent_skills` required an installed client subset pack and so could never
  pass in the open repo; now a self-contained fixture covering parent, grandparent, own-copy-wins,
  engine fallback and not-found.

Verified in a clean clone with `.env` = `PORTFOLIO_NAME=TRDOC421`:
`create-new-feature.sh --feature-name STORY-LEAVE-MANAGEMENT-MU-01-01-002` now resolves
`LEAVE-MANAGEMENT` and creates the branch + spec folder; `check-prerequisites.sh` finds it.
Script tests 77/77; `gen-copilot.sh --check` ok.

Left for the owner: D (missing LEAVE stack definition / EPIC file; MRB has no stories — pack content
that shouldn't be invented), E (local files), and F deletions (need confirmation).
