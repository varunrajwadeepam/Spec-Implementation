# Project: Mainframe Modernization Engine — Implementation Pipeline

## What this is

An agentic **implementation pipeline** that turns an already-approved migration story into working, target-stack code, test-first, using the speckit (spec → clarify → plan → tasks → analyze → implement → review) workflow.

The repository is split into an **engine** (portfolio-agnostic: agents, shared skills, schemas, scripts) and **portfolio packs** (everything client-specific). The pack is the only plugin surface — adding a portfolio, a business domain, or a target stack requires **zero engine changes**.

**This repo no longer runs AS-IS reverse-engineering or LLD generation.** Those two pipelines (which used to produce bounded-context definitions, current/target-state architecture, API contracts, data flows, and EPICs/stories from raw COBOL/MFLens exports) have been retired from this engine. What remains is **Pipeline 3 — Implementation**: it consumes EPICs and user stories that already exist under a portfolio pack's `docs/epics/` (produced by a prior run of those pipelines elsewhere, or supplied directly by the client) and turns one story at a time into reviewed, tested code.

If a portfolio pack still carries AS-IS/LLD-era artifacts (`knowledge-store/*.json`, `architecture/current-state/`, `architecture/target-state/`, `architecture/LLD/`), they are kept as **optional read-only reference context** — nothing in this engine regenerates, revalidates, or depends on them being present. The one required input is the EPIC/story tree under `docs/epics/`.

All agents run inside **Claude Code** (CLI, desktop app, or web app) **or GitHub Copilot Chat in VS Code**, and load domain context from skills. See "Using this repo in GitHub Copilot" below for how the two are kept in sync.

---

## Commands, Skills and Agents

The pipeline phases are **slash commands** (`.claude/commands/speckit.*.md`) plus two phase **skills**
(`.claude/skills/speckit.orchestrate`, `.claude/skills/speckit.review`). The quality/utility **agents**
(subagents with their own context) live in `.claude/agents/` — there are four.

A pack may ship an optional `agents/` directory as an escape hatch, but forked per-client agents rot: express bespoke behavior as a pack skill listed in the manifest's `extra_skills` instead.

**Pipeline phases** (commands, except where noted):

| Command | Role |
|---|---|
| `speckit.orchestrate` / `mod-implement` (skills) | One-shot entry point: runs every phase below for one story |
| `speckit.constitution` | Create/update the project's engineering principles |
| `speckit.specify` | Turn a story into `spec.md` |
| `speckit.clarify` | Ask ≤5 clarifying questions, encode answers into the spec |
| `speckit.plan` | Produce `plan.md` / `research.md` (technical design, ADRs) |
| `speckit.tasks` | Generate dependency-ordered `tasks.md` |
| `speckit.checklist` | Generate a requirements-quality checklist |
| `speckit.analyze` | Non-destructive spec/plan/tasks consistency check |
| `speckit.implement` | Execute all tasks in `tasks.md` |
| `speckit.review` (skill) | Post-implementation quality review (7 scored dimensions) |
| `speckit.impact` | Impact analysis before touching shared/public surface area |
| `speckit.taskstoissues` | Convert `tasks.md` into GitHub issues |

**Agents** (`.claude/agents/`):

| Agent | Role |
|---|---|
| `lld-epic-story-validator` | Gate a story's/EPIC's quality (≥70/100) before implementation starts |
| `fwd-cobol-dotnet-consistency-checker` | Line-referenced COBOL-vs-.NET behavioral diff after implementation |
| `code-quality-analyzer` | Post-conversion code quality report (architecture, complexity, NFRs); runs in a forked context |
| `lld-to-story` | Turn an LLD dropped in `architecture/LLD/` into the EPIC/story file(s) `/speckit.orchestrate` needs; scaffolds a brand-new pack from `_template` first if `portfolio.yaml` doesn't exist yet — the step before the pipeline, not part of it |

---

## Portfolio Packs (the plugin contract)

A portfolio is a **self-contained pack** under `portfolios/{portfolio}/`, carrying its manifest, skills, inputs, and every generated artifact:

```
portfolios/{portfolio}/
├── portfolio.yaml       # manifest — REQUIRED; declares skills, target stack, codegen
├── skills/              # pack-private client / domain / stack-conventions skills
├── inputs/              # target-stack-*.md (authoritative stack definition); static-analysis/, source/ if the pack still carries them for reference
├── knowledge-store/     # optional — legacy AS-IS/LLD JSON artifacts, read-only reference only
├── architecture/        # optional — legacy CSA / TSA / LLD / diagrams / SAD, read-only reference only
├── docs/epics/          # REQUIRED — EPICs & stories; the input to this pipeline
├── POC/                 # generated implementation
├── specs/               # speckit artifacts, per story id
├── reports/
└── logs/
```

A subset pack declares `subset_of: PARENT` and inherits the parent's skills, so skills used by several sibling subsets live once in the parent's `skills/`. `portfolios/_template/` is the annotated starting point for a new pack.

### The manifest

```yaml
portfolio: MY-PORTFOLIO
description: One-line description of the estate
client_skill: my-client-modernization    # client landscape, governance, naming
domain_skill: my-business-domain         # technology-agnostic business knowledge
extra_skills: []                         # additional skills — the customization escape hatch
target_stack:
  id: net                                # route key: net | java | <custom>
  definition: inputs/target-stack-net.md # authoritative stack definition (pack-relative)
  conventions_skill: target-stack-net-conventions   # may live in this pack
codegen: cagen                           # cagen | handwritten
mflens:
  portfolio_id: null                     # numeric MFLens portfolioId, or null — legacy, only used by fwd-cobol-dotnet-consistency-checker
subset_of: null
```

Validated against `schemas/portfolio-manifest.schema.json`. There is **no hardcoded portfolio registry, no name-prefix inference, and no subset special-case** — the manifest is the only source of truth.

### Portfolio resolution

1. Pass as an argument: `portfolio=MY-PORTFOLIO`
2. Or let the story ID name it: `STORY-MY-PORTFOLIO-MU-…` is matched against the installed packs
3. Or set a default in the project-root `.env`: `PORTFOLIO_NAME=MY-PORTFOLIO` (used only when the ID names no installed pack)
4. None of these, or `portfolios/{portfolio}/portfolio.yaml` missing → the agent stops with an error.

All paths are pack-relative: `portfolios/{portfolio}/inputs/`, `portfolios/{portfolio}/docs/epics/`, `portfolios/{portfolio}/POC/`, `portfolios/{portfolio}/specs/`, `portfolios/{portfolio}/reports/`, `portfolios/{portfolio}/logs/`. Agents create output subdirectories automatically.

The authoritative resolution procedure is `.claude/skills/portfolio-resolution/SKILL.md` — agents Read it instead of embedding their own copy.

### Installing a pack

Packs may live in a separate (private) repository and be plugged in by symlink/junction, so generated outputs commit to the pack's own repo:

```bash
./scripts/install-portfolio.sh ../my-portfolios/portfolios/MY-PORTFOLIO   # or install-portfolio.ps1 on Windows
echo "PORTFOLIO_NAME=MY-PORTFOLIO" > .env
```

The install script validates the manifest against the schema and verifies every declared skill resolves. **That validation is the registration step** — nothing else needs editing.

### Adding a new portfolio, stack, or architecture

1. `cp -r portfolios/_template portfolios/MY-PORTFOLIO` and fill in `portfolio.yaml`.
2. Author the client and domain skills into the pack's `skills/`. For a subset, set `subset_of: PARENT` and put skills shared with sibling subsets in the parent's `skills/` instead.
3. **New target stack?** Write a conventions skill, ship it in the pack's `skills/`, and name it in `target_stack.conventions_skill`. Set `target_stack.id` to a supported route (`net`, `java`) or a custom id — a custom id requires the pack to supply its chain guidance via `extra_skills`.
4. Populate `docs/epics/{MU-ID}/` with the EPICs and stories to implement (from a prior AS-IS/LLD run, or supplied by the client). Optionally drop a `target-stack-*.md` named by `target_stack.definition`.
5. `./scripts/install-portfolio.sh <pack>` (validates), then run `/speckit.orchestrate {story-id}` (or `/mod-implement {story-id}`) to implement the first story.

---

## How to Run the Pipeline

### Pipeline 3 — Implementation (speckit)

**Prerequisites:**
- A portfolio pack installed with at least one EPIC/story under `portfolios/{portfolio}/docs/epics/{MU-ID}/`
- Story IDs follow `STORY-{PORTFOLIO}-MU-{wave}-{mu}-{story}`

**No story yet, only an LLD?** Drop the LLD document at `portfolios/{portfolio}/architecture/LLD/`
and run the `lld-to-story` agent (`portfolio=ACME-CORE`) — it turns the LLD into the EPIC/story
file(s) below, in the 3Cs format the pipeline and `lld-epic-story-validator` expect. **The portfolio
doesn't need to exist yet either** — if `portfolios/{portfolio}/portfolio.yaml` is missing, the
agent offers to scaffold a starter pack from `portfolios/_template/` (asking only for target
stack and codegen), so dropping the LLD into a bare `portfolios/{portfolio}/` directory is enough
to start; the scaffolded client/domain skills are stubs and must be filled in with real content
before `/speckit.plan`/`/speckit.implement` run for real. Then continue
with the one-shot entry point normally. `/speckit.plan` also re-reads anything under
`architecture/LLD/` on its own later, so the file doesn't need to be deleted after story generation.

**One-shot entry point:**

```bash
/speckit.orchestrate STORY-ACME-CORE-MU-01-01-001
# or
/mod-implement STORY-ACME-CORE-MU-01-01-001
```

Both auto-detect the portfolio from the story ID, create `portfolios/{portfolio}/specs/{story-id}/`, and run the full workflow: **specify → clarify → plan → tasks → analyze → implement → review**.

**Manual step-by-step (advanced):** from the repo root, run `/speckit.specify {story-id}` → `/speckit.clarify` → `/speckit.plan` → `/speckit.tasks` → `/speckit.analyze` → `/speckit.implement` → `/speckit.review` individually. `/speckit.specify` creates the branch and `portfolios/{portfolio}/specs/{story-id}/`; later phases find it from the pinned active feature.

**Quality gate before coding starts:** run `lld-epic-story-validator` against the target EPIC/story (`epic_id=`, `story_id=`, or `mu_id=`) — score ≥70/100 (EPIC/story) or ≥75/100 (MU) to proceed. See below.

**Quality gate after coding:** `/speckit.review` scores the implementation across 7 dimensions; `fwd-cobol-dotnet-consistency-checker` and `code-quality-analyzer` are available for deeper post-implementation QA (see below).

---

### Quality Validation & Gates

**EPIC/Story Validator:** `lld-epic-story-validator`

Validates EPICs and user stories — which are now a **static input**, not a generated artifact — for quality, consistency, and implementation readiness before coding starts. Scores artifacts across 6 dimensions:

1. **EPIC Structure** (20 pts) — Required sections, frontmatter, EPIC type correctness
2. **FR Traceability** (25 pts) — COBOL alignment, business rule references
3. **Story Quality** (20 pts) — 3Cs format, acceptance criteria, Definition of Done
4. **Cross-Artifact Consistency** (15 pts) — Story files exist, dependencies valid, effort estimation
5. **Scope Clarity** (10 pts) — In/Out scope definition, no layer violations
6. **Implementation Readiness** (10 pts) — Dependencies resolved, test guidance

**Usage:**
```
# Validate single EPIC
epic_id=EPIC-MU-UWR-01-02

# Validate EPIC with all its stories
epic_id=EPIC-MU-UWR-01-02 include_stories=true

# Validate single story
story_id=EPIC-02-005

# Validate entire Migration Unit
mu_id=MU-UWR-01
```

**Quality Gates:**
- **EPIC:** ≥70/100 to proceed to implementation
- **Story:** ≥70/100 to start coding
- **MU:** ≥75/100 to begin implementation phase

**Output:** Validation reports in `portfolios/{portfolio}/docs/epics/{MU-ID}/validation/`

---

**COBOL-to-.NET Consistency Checker:** `fwd-cobol-dotnet-consistency-checker`

Compares COBOL source programs (via the MFLens MCP server) against their .NET implementation counterparts and produces a line-referenced issues list. Detects behavioral mismatches between legacy and modernized code.

**Checks Performed:**
- **C-01:** Missing implementation (COBOL paragraphs with no .NET equivalent)
- **C-02:** Threshold/constant mismatches (e.g., credit score 750 vs 760)
- **C-03:** Exception code mismatches (error codes not preserved)
- **C-04:** Data type/precision mismatches (PIC 9(5)V99 → float instead of decimal)
- **C-05:** OCCURS cap not enforced (array length limits)
- **C-06:** Validation rules missing or different
- **C-07:** Error codes not mapped to .NET exceptions
- **C-08:** Control-flow sequence divergence
- **C-09:** Sub-program calls not implemented
- **C-10:** Action code logic divergence (AUTO/REFER/DECL)
- **C-11:** Score formula divergence
- **C-12:** Field name/comment mismatches (INFO level)

**Usage:**
```
# Check specific COBOL program
portfolio=ACME-CORE cobol_programs=SCORECALC.cbl dotnet_root=POC/ACME-CORE/

# Check all COBOL programs
portfolio=ACME-CORE cobol_programs=all dotnet_root=POC/ACME-CORE/

# Filter by severity
portfolio=ACME-CORE cobol_programs=all dotnet_root=POC/ACME-CORE/ severity_filter=MAJOR
```

**Severity Levels:**
- **CRITICAL:** Will produce wrong business output (wrong risk tier, wrong score, wrong action code)
- **MAJOR:** Could produce incorrect output in edge cases or leaves error paths unhandled
- **MINOR:** Style/naming divergence, missing doc references, non-functional differences
- **INFO:** Observation only; no functional impact

**Output:** Detailed consistency reports in `portfolios/{portfolio}/reports/cobol-dotnet-consistency-{date}.md` with exact line numbers for both COBOL and .NET code

---

## Skills

Skills provide domain context to agents. **Which skills load is declared by the pack manifest, never inferred by the engine.**

**Skill Architecture** — agents load, in order:

1. **Client skill** (`client_skill`) — client landscape, governance, naming, in-scope roster. Ships in the pack.
2. **Domain skill** (`domain_skill`) — technology-agnostic business-area knowledge. Ships in the pack.
3. **Extra skills** (`extra_skills`) — optional; the escape hatch for pack-specific behavior.
4. **Migration skill** — target-architecture conventions (engine).
5. **`cagen-programs`** — loaded only when the manifest declares `codegen: cagen`.
6. **Stack-conventions skill** (`target_stack.conventions_skill`) — loaded by implementation-time agents; may ship in the pack.
7. **`mermaid`** — only for agents that emit Mermaid.

**Skill path resolution** — every skill name resolves in this order, first hit wins:

1. `portfolios/{portfolio}/skills/{name}/SKILL.md` (the pack's own; also overrides an inherited or engine skill of the same name)
2. each `subset_of` ancestor's `skills/` — walking the chain to the top-level parent
3. `.claude/skills/{name}/SKILL.md` (engine shared skills)

`subset_of` is load-bearing, not documentation: it is how a parent holds the skills for its whole set. A `subset_of` naming a pack that is not installed, or a cycle in the chain, is a hard error.

This is what makes packs a true plugin surface: a pack contributes its client knowledge, its business domain, **and its target-stack conventions** without any engine change.

**Engine shared skills** (`.claude/skills/`, available to every portfolio):

- `portfolio-resolution` — **single source of truth** for manifest loading, pack-first skill resolution, and the mandatory load order. Agents Read this instead of embedding their own copy (same pattern as `mflens-mcp`). It contains no portfolio registry — nothing to update when a portfolio is added.
- `migration` — target-architecture conventions applied while implementing a story (COBOL/CICS/VSAM/MQ pattern mapping, WCF/Spring service layering, mandatory .NET/Java engineering standards)
- `cagen-programs` — CA:Gen (COOL:Gen) COBOL naming conventions; load when `codegen: cagen`
- `mflens-mcp` — MFLens MCP server usage contract; ALWAYS Read before calling any MFLens MCP tool. Server/ops reference is `mcp/README.md`
- `mermaid` — Mermaid diagram rules; load before writing any mermaid block
- `mod-implement` / `speckit.orchestrate` — portfolio-aware wrappers that run the full specify→review speckit workflow for a story, scoping every artifact under `portfolios/{portfolio}/specs/{story-id}/`
- `speckit.impact` (a command, `.claude/commands/speckit.impact.md`) — mandatory impact analysis before touching shared/public surface area
- `speckit.review` — post-implementation quality review

**Engine domain skills** (industry knowledge, not client knowledge — a pack may override by shipping a skill of the same name):

- `insurance-underwriting-domain` — how insurance underwriting works as a business discipline: policy lifecycle, risk assessment, products, US regulation (NAIC/ACORD/ISO). Technology- and client-agnostic. Reference it from a pack's `domain_skill` or `extra_skills` when the estate is an insurance carrier.

**Reference stack-conventions skills** (engine-provided; packs may substitute their own):

- `target-stack-net-conventions` — .NET 4.8 / WCF / EF6 / IIS (rule IDs [WSDL-*], [EF6-*], [PKG-*], [WCF-*], [IIS-*], [TEST-*], [COV-*]) — the `net` route
- `target-stack-java-conventions` — Java 21 / Spring Boot 3.4 / CXF / JPA (rule IDs [REST-*], [JPA-*], [DEP-*], [CXF-*], [DI-*], [TEST-*], [COV-*]) — the `java` route
- Version pins in both are defaults; the pack's `target_stack.definition` file is authoritative on conflict.

**Portfolio-contributed skills** live in their packs (`portfolios/{portfolio}/skills/`, or the parent's when shared across subsets) — this file deliberately does **not** catalog them, so adding a portfolio never requires editing the engine.

---

## COBOL Naming Conventions (`codegen: cagen` only)

Estates generated by **CA:Gen (COOL:Gen) 5.1** follow a strict prefix-based naming convention. This section applies **only** when the pack manifest declares `codegen: cagen`. On `codegen: handwritten`, program names carry no role information — classify from whatever static-analysis evidence the story carries (CICS entry detection, JCL steps, call-graph position, SQL access) and skip every prefix-based rule below.

**Critical Rule:** Only **IQP*** programs are CICS entry points and should map to service operations in the target stack (WCF `[ServiceContract]` operations for .NET, REST controller endpoints for Java).

| Prefix | Module Type | Target Pattern (.NET example / Java example) | Is Service Operation? |
|--------|-------------|-------------|------------------|
| **IQP*** | **Input/Interface Program** (CICS entry points) | WCF `[ServiceContract]` operation / REST `@RestController` endpoint | YES |
| **MQP*** | Main Processing Program (business logic) | Handler/Service classes | NO |
| **MDP*** | Main Data Program (orchestration) | Handler/Orchestrator classes | NO |
| **CQP*** | Common/Check Program (validation) | Validator classes | NO |
| **DDP*** | Data Display Program (database access) | Repository classes (EF6 / Spring Data JPA) | NO |
| **SDP*** | Status/Service Program (status checks) | Error handlers, utilities | NO |
| **PDP*** | Process/Procedure Program (processing logic) | Transformer/Processor classes | NO |
| **TDP*** | Transaction/Transform Program (data transformation) | Mapper/Transformer helper classes | NO (NOT a service operation) |

**When working with CA:Gen COBOL source:** load the `cagen-programs` skill for full convention details, examples, and migration patterns.

**Common Mistake:** TDP* programs are **data transformations**, NOT input operations. They must never be exposed as service operations.

**TIR\* runtime utilities → shared static library (ADR-CAGEN-TIR-UTILS).** CA:Gen `TIR*` modules (date/numeric/view conversion) carry the disposition **`shared-static-util`**: realise them as stateless **static** helpers in a shared reusable library (`cagen-runtime` / `{Solution}.Common`), called directly — **never** injected components, service operations, or stub/mock dependencies. This ADR is defined in the `cagen-programs` skill and enforced by the `[UTIL-*]` rules in the stack-conventions skills — implementation and review should reject any other realization. See `cagen-programs` for the full ADR.

---

## Schema Validation

`schemas/portfolio-manifest.schema.json` validates every pack's `portfolio.yaml` — never bypass this. The other schemas (`programs-enriched.schema.json`, `bounded-contexts.schema.json`, `dependency-graph.schema.json`, `capability-map.schema.json`, `integration-inventory.schema.json`, `target-state.schema.json`, `transitional-state.schema.json`, `consistency-report.schema.json`, `gaps-report.schema.json`) describe the shape of the **optional legacy knowledge-store artifacts** a pack may still carry from a prior AS-IS/LLD run — `lld-epic-story-validator` reads `programs-enriched.json`/`bounded-contexts.json` as optional context if present, but nothing in this engine generates or requires them.

---

## When Making Changes

- **Agents:** `.claude/agents/` (one .md file per agent with frontmatter)
- **Skills:** `.claude/skills/{skill-name}/SKILL.md`
- **Pipeline commands:** `.claude/commands/speckit.*.md` — the canonical source. After editing, run `scripts/gen-copilot.sh` to refresh the Copilot mirror (`.github/skills/`); CI rejects a stale or hand-edited mirror.
- **Helper scripts:** `.specify/scripts/bash/*.sh` (bash only; JSON on stdout, diagnostics on stderr). Tests: `bash tests/speckit-scripts.test.sh`.
- **Repo tooling:** `scripts/` (portfolio install, status dashboards, the Copilot generator)
- **Outputs:** Validated against `schemas/*.schema.json`

---

## Directory Structure

**Engine** (portfolio-agnostic — open by design):

```
.claude/
├── agents/           ← Quality/utility agents (lld-to-story, lld-epic-story-validator,
│                        fwd-cobol-dotnet-consistency-checker, code-quality-analyzer)
├── commands/         ← Slash commands (speckit.*)
└── skills/           ← Engine shared skills (portfolio-resolution, migration,
                        cagen-programs, mflens-mcp, mermaid, mod-implement,
                        speckit.orchestrate/impact/review, target-stack-*-conventions)

schemas/              ← JSON Schema definitions, incl. portfolio-manifest.schema.json
scripts/              ← PowerShell and Python scripts (portfolio install, story/spec status, renaming utilities)
mcp/
temp/                 ← Temporary documentation (gitignored)
```

**Portfolio packs** (everything client-specific — one mountable, deletable, permission-controllable unit):

```
portfolios/
├── _template/            ← annotated starting point for a new pack
└── {portfolio}/          ← a pack (may be a symlink/junction into a private repo)
    ├── portfolio.yaml    ← manifest: skills, target stack, codegen, MFLens id
    ├── skills/           ← pack-private client / domain / stack-conventions skills
    ├── inputs/
    │   ├── static-analysis/  ← optional — legacy MFLens CSV exports, read-only reference
    │   ├── source/           ← optional — legacy COBOL source files, read-only reference
    │   └── target-stack-*.md ← authoritative target stack definition
    ├── knowledge-store/  ← optional — legacy AS-IS/LLD JSON artifacts, read-only reference
    ├── architecture/     ← optional — legacy CSA / TSA / LLD / diagrams / SAD, read-only reference
    ├── docs/epics/       ← REQUIRED — EPICs and user stories (the input to this pipeline)
    ├── POC/              ← generated implementation
    ├── specs/            ← speckit artifacts, per story id
    ├── reports/          ← consistency and validation reports
    └── logs/             ← pipeline logs
```

Because outputs are written **inside** the pack, a symlinked pack's generated artifacts land in that pack's own git working tree — client data never reaches the engine repo.

---

## Implementation Workflow (Speckit)

**Portfolio-Aware Implementation:**

Use `/speckit.orchestrate {story-id}` to run the complete speckit workflow with automatic portfolio detection and folder setup:

```bash
# Automatic portfolio detection from story ID
/speckit.orchestrate STORY-ACME-CORE-MU-01-01-001

# Explicit portfolio override
/speckit.orchestrate STORY-ACME-CORE-MU-01-01-001 portfolio=ACME-CORE
```

This automatically:
1. Resolves the portfolio (explicit `portfolio=` > story ID matched against installed packs > `PORTFOLIO_NAME` in `.env`)
2. Checks out the base branch, then `/speckit.specify` cuts the story branch and creates `portfolios/{portfolio}/specs/{story-id}/`
3. Runs complete speckit workflow (specify → clarify → plan → tasks → analyze → implement → review)

**Manual Workflow (Advanced):**

Run the phases individually **from the repo root** — do not `mkdir` or `cd` into the spec folder
(`/speckit.specify` refuses an existing folder, and the helper scripts are invoked by repo-relative path):

```bash
/speckit.specify STORY-ACME-CORE-MU-01-01-001
/speckit.clarify
/speckit.plan
/speckit.tasks
/speckit.analyze
/speckit.implement
/speckit.review
```

**Why Portfolio Scoping Matters:**

- The helper scripts (`.specify/scripts/bash/`) compute every path from the repo root and the resolved portfolio — never from the current directory
- This project requires `portfolios/{portfolio}/specs/{story-id}/` for multi-portfolio support
- `/speckit.orchestrate` handles portfolio detection and folder setup automatically
- Portfolio is resolved against the installed packs (directories under `portfolios/` with a `portfolio.yaml`): the story ID is matched by pack-name prefix after stripping `STORY-`/`EPIC-`, with fallbacks to an existing `specs/{id}/` folder and to the story file location — so one-, two-, and three-segment pack names all work (`TRDOC421`, `ACME-CORE`, `MEETING-ROOM-BOOKING`)

---



## Using this repo in GitHub Copilot (VS Code)

The pipeline runs identically in VS Code Copilot Chat. Copilot reads `CLAUDE.md`, `.claude/skills/` and `.claude/agents/` natively; the only thing it cannot see is `.claude/commands/`, so those are mirrored as Agent Skills:

| Surface | Claude Code | Copilot |
|---|---|---|
| Pipeline commands | `/speckit.specify` … (`.claude/commands/`) | `/speckit-specify` … (`.github/skills/`, **generated**) |
| Orchestrator / review | `/speckit.orchestrate`, `/speckit.review` (`.claude/skills/`) | `/speckit-orchestrate`, `/speckit-review` (generated) |
| Everything else (skills, agents, `mod-implement`) | same names | same names, read natively |

The dot/hyphen split is upstream spec-kit's own convention: canonical templates are dotted; Copilot Agent Skill names cannot contain dots, so its generated skills are hyphenated and references inside them are rewritten. Type whichever form your tool exposes.

**Regenerate after editing any `.claude/commands/speckit.*.md` or `.claude/skills/speckit.*/SKILL.md`:**

```bash
scripts/gen-copilot.sh          # write .github/skills/ + .github/.generated-manifest.json
scripts/gen-copilot.sh --check  # what CI runs: fails on a stale or hand-edited mirror
scripts/gen-copilot.sh --lint   # source lints only
```

`.github/copilot-instructions.md` is a short hand-written pointer at `CLAUDE.md` and this table; it is not generated. `.vscode/settings.json` pre-approves the helper scripts for Copilot's terminal tool, as upstream does.

---
