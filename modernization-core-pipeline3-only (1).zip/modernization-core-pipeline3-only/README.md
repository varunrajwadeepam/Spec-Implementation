# COBOL Mainframe Modernisation — Implementation Pipeline (Engine / Core)

This repository — **`mainframe-modernization-core`**
([git.epam.com/epm-aimm/mainframe-modernization-core](https://git.epam.com/epm-aimm/mainframe-modernization-core)) —
is the **portfolio-agnostic engine**: agents, shared skills, schemas, and scripts for the
**implementation pipeline**. Given an already-approved migration story (an EPIC/story produced
upstream by AS-IS reverse-engineering and Low-Level Design — pipelines this engine no longer
runs), it drives the speckit workflow — specify → clarify → plan → tasks → analyze → implement →
review — to produce working, tested target-stack code (.NET Framework 4.8 **or** Java 21 / Spring
Boot, depending on the portfolio's declared stack).

**This is implementation-only.** AS-IS reverse-engineering and LLD generation (which used to turn
raw COBOL/MFLens exports into bounded contexts, Current/Target State Architecture, API contracts,
data flows, and the EPIC/story backlog itself) have been retired from this engine. A portfolio
pack now arrives with its `docs/epics/` already populated — from a prior run of those pipelines
elsewhere, or supplied directly by the client — and this engine implements from there. Any
AS-IS/LLD-era artifacts a pack still carries (`knowledge-store/*.json`, `architecture/`) are kept
as optional, read-only reference context; nothing here regenerates or requires them.

Everything client-specific lives in a **separate portfolio-pack repository** that plugs into this
engine on demand. The engine carries **no** client data, no COBOL source, and no registry of
portfolios — a pack contributes its own skills, inputs, target stack, and artifacts, and the
engine discovers it purely from the pack's manifest. This split is what lets the engine be shared
or open-sourced while client estates stay in private repos.

```
┌─────────────────────────────────────────────┐        ┌──────────────────────────────────────┐
│  THIS REPO — mainframe-modernization-core    │        │  SEPARATE (private) portfolio repo    │
│  engine: agents, skills, schemas, scripts    │◀──────▶│  portfolios/{PORTFOLIO}/  (a "pack")  │
│  portfolios/_template/  (pack format only)   │ plug   │  manifest · skills · inputs · outputs │
└─────────────────────────────────────────────┘  in    └──────────────────────────────────────┘
        (open by design, no client data)      symlink        (client data, its own git repo)
```

All agents run inside **Claude Code** and live in [`.claude/agents/`](.claude/agents/); domain
context is supplied by engine skills in [`.claude/skills/`](.claude/skills/) plus the skills each
portfolio pack contributes. Project-wide conventions (pack format, skill resolution, CA:Gen
naming) are documented in [`CLAUDE.md`](CLAUDE.md).

---

## Getting Started

### 1. Clone the engine and install dependencies

```bash
git clone https://git.epam.com/epm-aimm/mainframe-modernization-core.git
cd mainframe-modernization-core
pip install -r requirements.txt
```

Open the repo in **Claude Code** (CLI, desktop, or web) — that is where every agent runs.

### 2. Get a portfolio pack

A pack is a self-contained directory in its own repo, with at least one EPIC/story already
populated under `docs/epics/`. Either clone an existing one or create a new pack
([see below](#add-a-new-portfolio)):

```bash
git clone <your-portfolio-repo-url> ../my-portfolios     # e.g. ../my-portfolios/portfolios/ACME-CORE
```

### 3. Plug the pack into the engine

The install script **is the registration step** — it validates the manifest against
`schemas/portfolio-manifest.schema.json`, verifies every declared skill resolves, and symlinks
the pack into `portfolios/` so generated outputs commit to the **pack's own** repo, never here.

```bash
./scripts/install-portfolio.sh ../my-portfolios/portfolios/ACME-CORE     # macOS/Linux — symlink
.\scripts\install-portfolio.ps1 ..\my-portfolios\portfolios\ACME-CORE    # Windows — junction
echo "PORTFOLIO_NAME=ACME-CORE" > .env                                    # default portfolio (gitignored)
```

### 4. (Optional) Connect MFLens

`fwd-cobol-dotnet-consistency-checker` pulls COBOL source and static analysis from a live
**MFLens** instance over MCP, to diff a story's implementation against the legacy program it
replaces. The connection is configured in [`.mcp.json`](.mcp.json) (default
`http://localhost:8989/api/mcp`). Nothing else in the pipeline requires it.

### 5. Implement a story

In a Claude Code session:

```
/speckit.orchestrate STORY-ACME-CORE-MU-01-01-001
```

This is the whole pipeline — one command per story. Details below.

---

## The Pipeline — Implementation Only

```
┌───────────────────────────────────────┐
│  Forward Engineering (this engine)     │
│  /speckit.orchestrate {story-id}       │
│                                         │
│  in:  EPIC/story under docs/epics/     │
│  out: target-stack code + tests +      │
│       review report                    │
└───────────────────────────────────────┘
```

| Driver | Consumes | Produces |
|--------|----------|----------|
| `/speckit.orchestrate {story-id}` (or `/mod-implement {story-id}`) | An EPIC/story under `portfolios/{portfolio}/docs/epics/{MU-ID}/` | Working target-stack code + tests + a scored review report |

**Prerequisite:** the story already exists. This repo does not generate EPICs or stories — obtain
them from a prior AS-IS/LLD run, or from the client pack directly, and place them under
`docs/epics/{MU-ID}/`.

**Driver:** `/speckit.orchestrate {story-id}` — auto-detects the portfolio from the story ID,
creates `portfolios/{portfolio}/specs/{story-id}/`, and runs the full chain:

```bash
# Portfolio auto-detected from the story ID
/speckit.orchestrate STORY-ACME-CORE-MU-01-01-001

# Explicit portfolio override
/speckit.orchestrate STORY-ACME-CORE-MU-01-01-001 portfolio=ACME-CORE
```

**specify → clarify → plan → tasks → analyze → implement → review**, emitting target-stack code,
tests, and a review report per story. Individual speckit steps (`/speckit.specify`,
`/speckit.plan`, …) can be run manually from that folder — see
[`CLAUDE.md`](CLAUDE.md#implementation-workflow-speckit).

**Quality gate before coding starts:** `lld-epic-story-validator` scores the target EPIC/story
across 6 dimensions (structure, FR traceability, story quality, cross-artifact consistency, scope
clarity, implementation readiness). Thresholds: EPIC ≥70, Story ≥70, MU ≥75.

**Consistency checking after implementation:** `fwd-cobol-dotnet-consistency-checker` compares
COBOL programs (via MFLens) against their .NET/Java counterparts and produces a line-referenced
issue list (CRITICAL / MAJOR / MINOR / INFO) at
`portfolios/{portfolio}/reports/cobol-dotnet-consistency-{date}.md`.

**Post-implementation quality report:** `code-quality-analyzer` produces an architecture,
complexity, and NFR report on the converted code (runs in a forked context).

---

## Pipeline Status Report

```bash
# Speckit per-story status
python scripts/speckit_status.py --portfolio ACME-CORE

# Other output formats
python scripts/speckit_status.py --portfolio ACME-CORE --html --output portfolios/ACME-CORE/reports/speckit-status.html
python scripts/speckit_status.py --portfolio ACME-CORE --json
```

State is derived from the artifacts on disk (`portfolios/{portfolio}/specs/`) and supplemented by
`portfolios/{portfolio}/specs/speckit-state.json`. See
[`scripts/README-speckit-status.md`](scripts/README-speckit-status.md) for output format details,
and [`scripts/README-story-status.md`](scripts/README-story-status.md) for the companion
per-story/per-MU rollup (`scripts/story_status.py`).

---

## Portfolio Packs

A portfolio is a **self-contained pack** under `portfolios/{portfolio}/` carrying its manifest,
skills, inputs, and every generated artifact. The pack is the only plugin surface: adding a
portfolio or a target stack requires **zero engine changes**.

```
portfolios/{portfolio}/
├── portfolio.yaml    # manifest — declares skills, target stack, codegen provenance
├── skills/           # pack-private client / domain / stack-conventions skills
├── inputs/           # target-stack-*.md; static-analysis/, source/ if kept for reference
├── docs/epics/       # REQUIRED — EPICs and user stories (the input to this pipeline)
├── knowledge-store/  architecture/   # optional — legacy AS-IS/LLD artifacts, read-only reference
├── POC/  specs/  reports/  logs/
```

Resolve the portfolio with a `portfolio=ACME-CORE` argument or `PORTFOLIO_NAME` in `.env`; a
missing name or missing manifest stops the agent. The manifest — not a registry, not a name
prefix — declares which skills load:

```yaml
client_skill: acme-core-modernization
domain_skill: acme-core-domain
extra_skills: []
target_stack:
  id: net                                 # route key: net | java | <custom>
  definition: inputs/target-stack-net.md  # authoritative stack definition
  conventions_skill: target-stack-net-conventions   # may ship inside this pack
codegen: cagen                            # cagen | handwritten
```

Skill names resolve pack-first: the pack's own `skills/`, then each `subset_of` ancestor's
`skills/`, then `.claude/skills/`. That is what lets a pack contribute its own **target stack and
architecture conventions**, not just business knowledge — and it is why a subset pack ships no
`skills/` at all: the parent holds the skills for its whole set.

Packs live in a **separate private repository** and plug in by symlink, so generated outputs
commit to the pack's own repo — never to this engine. In this repo `.gitignore` excludes
`portfolios/*` (only `_template/` is tracked), so a client pack **cannot** be committed here by
accident.

### Add a new portfolio

Adding a portfolio touches **only the pack repo** — zero engine changes.

```bash
# 1. In the pack repo, copy the annotated template and name the directory after the portfolio
cp -r portfolios/_template ../my-portfolios/portfolios/ACME-CORE

# 2. Fill in ../my-portfolios/portfolios/ACME-CORE/portfolio.yaml
#      portfolio: ACME-CORE            (must equal the directory name)
#      client_skill / domain_skill     (authored under the pack's skills/)
#      target_stack.id: net | java | <custom>   +  definition + conventions_skill
#      codegen: cagen | handwritten

# 3. Author the pack skills and populate the required input
#      skills/{client-skill}/SKILL.md, skills/{domain-skill}/SKILL.md
#      docs/epics/{MU-ID}/                — EPICs and stories to implement (REQUIRED)
#      inputs/target-stack-net.md         — the file named by target_stack.definition

# 4. Commit the pack in ITS OWN repo
cd ../my-portfolios && git add portfolios/ACME-CORE && git commit -m "Add ACME-CORE pack" && git push

# 5. Back in the engine: install (validates the manifest — this IS registration) and select it
cd ../mainframe-modernization-core
./scripts/install-portfolio.sh ../my-portfolios/portfolios/ACME-CORE      # .ps1 on Windows
echo "PORTFOLIO_NAME=ACME-CORE" > .env

# 6. Implement the first story (in Claude Code)
#    /speckit.orchestrate STORY-ACME-CORE-MU-01-01-001
```

A **subset** pack narrows a parent estate — it declares `subset_of: PARENT` and inherits the
parent's skills, so it ships no `skills/` of its own. `scripts/check-open-core.py` is the CI guard
that keeps client content from leaking into the engine (denylist, pack-ignore check, manifest +
skill resolution). Run it before any engine MR.

---

## Development & CI

### Test suite

Install dependencies and run all tests:

```bash
pip install -r requirements.txt
python -m pytest tests/ -q
```

`tests/pipeline/test_portfolio_pack.py` is a contract test for the portfolio-pack plugin seam —
it protects the property that a portfolio (including its target stack) plugs in through its
manifest with zero engine changes, and fails if someone reintroduces a hardcoded registry or
name-prefix inference.

### Schema validation

`schemas/portfolio-manifest.schema.json` validates every pack's `portfolio.yaml` — the install
script checks this on every pack registration. The other schemas under `schemas/` describe the
shape of optional legacy knowledge-store artifacts a pack may still carry from a prior AS-IS/LLD
run; nothing in this engine generates or requires them.

---

## Validators & Quality Agents

| Agent | Checks |
|-------|--------|
| `lld-epic-story-validator` | Scores EPICs & stories across 6 dimensions before implementation starts (EPIC ≥70, Story ≥70, MU ≥75) |
| `fwd-cobol-dotnet-consistency-checker` | Line-referenced COBOL-vs-target-stack behavioral diff (C-01…C-12) |
| `code-quality-analyzer` | Architecture/complexity/NFR report on converted code |
| `speckit.review` | Post-implementation quality review across 7 dimensions |

A score below 70/100 blocks sign-off.

---

## Target Stack

The target stack is **declared by each pack's manifest** (`target_stack.id`, `target_stack.definition`,
`target_stack.conventions_skill`). Implementation agents derive all target-technology decisions
from the declared definition file — they never assume a stack. Two routes ship with the engine; a
pack can add its own by shipping a conventions skill:

| Concern | .NET (`target-stack-net.md`) | Java (`target-stack-java.md`) |
|---------|------------------------------|-------------------------------|
| Language / runtime | C# / .NET Framework 4.8 | Java 21 / Spring Boot 3.4 |
| Online services | WCF SOAP on IIS (`BasicHttpBinding`) | Spring REST controllers (Apache CXF for SOAP) |
| ORM | Entity Framework 6 | Spring Data JPA / Hibernate 6 |
| DI | Unity Container | Spring IoC |
| Logging | log4net / NLog | Logback |
| Testing | NUnit 3 + Moq + FluentAssertions | JUnit 5 + Mockito 5 + AssertJ |
| Coverage gate | SonarQube ≥80% new code | SonarQube ≥80%, JaCoCo |

Shared across both: legacy source is COBOL on z/OS (CICS/JCL/VSAM/Db2); the `fwd-*` consistency
checker reads it via **MFLens** (MCP); database **IBM Db2 LUW**. All agents run in **Claude Code**.

---

## Repository Layout

**Engine** — portfolio-agnostic, open by design:

```
.
├── CLAUDE.md                       # Project context for Claude Code sessions
├── README.md                       # This file
├── .claude/
│   ├── agents/                     # Implementation agents (speckit.*, lld-epic-story-validator,
│   │                                #   fwd-cobol-dotnet-consistency-checker, code-quality-analyzer)
│   ├── commands/                   # Slash commands (speckit.*)
│   └── skills/                     # Engine shared skills (portfolio-resolution, migration,
│                                   #   cagen-programs, mflens-mcp, mermaid, mod-implement,
│                                   #   speckit.orchestrate/impact/review, target-stack-{net,java}-conventions)
├── schemas/                        # JSON Schema Draft 2020-12, incl. portfolio-manifest.schema.json
├── scripts/                        # install-portfolio.{sh,ps1}, check-open-core.py, story/spec status, renaming utilities
├── tests/                          # Portfolio-pack contract test
└── mcp/
    ├── mflens-server.json          # MCP resource + tool contract for MFLens
    └── README.md                   # Server/ops connection reference
```

**Packs** — everything client-specific; gitignored here so a client pack can never be committed
to the engine repo:

```
portfolios/
├── _template/                      # annotated starting point for a new pack (tracked)
└── {portfolio}/                    # a pack — usually a symlink into a private repo (ignored)
    ├── skills/                     #   its own skills, plus any its subsets share
    └── ...                         #   a subset declares subset_of and inherits from here
```

---

## MCP Server

`fwd-cobol-dotnet-consistency-checker` pulls COBOL source and static-analysis data from a live
**MFLens** instance over MCP. Before calling any MFLens tool, it reads
`.claude/skills/mflens-mcp/SKILL.md` (deferred-tool discovery, `portfolioId` resolution,
`sourceEvidence` citation). The server/ops reference lives in `mcp/README.md`;
`mcp/mflens-server.json` holds the resource contract.

---
