# Fix: Portfolio Extraction from Branch Names

## Problem

When running speckit commands like `/speckit.plan`, files were created in the wrong directory structure:

**Wrong**: `specs/STORY-ACME-CORE-MU-00-05-002/plan.md`  
**Correct**: `portfolios/ACME-CORE/specs/STORY-ACME-CORE-MU-00-05-002/plan.md`

## Root Cause

The `common.ps1` script's `Get-FeatureDir` function only checked:
1. `$env:PORTFOLIO_NAME` environment variable
2. `.env` file's `PORTFOLIO_NAME` value

It **did NOT extract portfolio from the branch name** itself, even though the branch naming convention includes it: `STORY-{PORTFOLIO}-MU-...`

Meanwhile, `create-new-feature.ps1` had the correct extraction logic but `common.ps1` didn't.

## Solution

Added a new function `Get-PortfolioFromBranch` to `common.ps1` that extracts portfolio from branch names using the same patterns as `create-new-feature.ps1`.

### Extraction Priority Order

1. **Environment variable**: `$env:PORTFOLIO_NAME`
2. **`.env` file**: `PORTFOLIO_NAME=...`
3. **Branch name pattern matching**:
   - `STORY-{PORTFOLIO}-MU-*` → extracts `ACME-CORE` from `STORY-ACME-CORE-MU-00-05-002`
   - `EPIC-{PORTFOLIO}-MU-*` → extracts portfolio from EPIC branches
   - Legacy patterns: `STORY-MU-{PORTFOLIO}-*` and `EPIC-MU-{PORTFOLIO}-*`
4. **File path lookup**: Search for story/epic file in `portfolios/{portfolio}/docs/epics/` and extract portfolio from path

### Supported Branch Patterns

| Branch Pattern | Portfolio Extracted | Example |
|----------------|-------------------|---------|
| `STORY-ACME-CORE-MU-00-05-002` | `ACME-CORE` | Standard story branch |
| `EPIC-UWR-POC-MU-01-02` | `UWR-POC` | Standard EPIC branch |
| `STORY-MU-ACME-CORE-001` | `ACME-CORE` | Legacy pattern (old format) |
| `001-feature-name` | `null` | Fallback to `specs/` root |

## Files Changed

### Replace This File

**File**: `.specify/scripts/powershell/common.ps1`

**Changes**:
1. Added new function `Get-PortfolioFromBranch` (lines 113-189 in fixed version)
2. Updated `Get-FeatureDir` to call `Get-PortfolioFromBranch` (line 195)

### Diff Summary

```diff
function Get-FeatureDir {
    param([string]$RepoRoot, [string]$Branch)

-   # Check for portfolio name in environment variable or .env file
-   $portfolio = $env:PORTFOLIO_NAME
-
-   if (-not $portfolio) {
-       $envFile = Join-Path $RepoRoot ".env"
-       if (Test-Path $envFile) {
-           Get-Content $envFile | ForEach-Object {
-               if ($_ -match '^PORTFOLIO_NAME=(.+)$') {
-                   $portfolio = $matches[1].Trim()
-               }
-           }
-       }
-   }
+   # Extract portfolio from branch name or environment
+   $portfolio = Get-PortfolioFromBranch -Branch $Branch -RepoRoot $RepoRoot

    # If portfolio is defined, use portfolio-based structure
    if ($portfolio) {
        return Join-Path $RepoRoot "portfolios/$portfolio/specs/$Branch"
    }

    # Fallback to non-portfolio structure
    return Join-Path $RepoRoot "specs/$Branch"
}
```

## Testing

### Before Fix

```powershell
# Branch: STORY-ACME-CORE-MU-00-05-002
# Without PORTFOLIO_NAME in .env
.\setup-plan.ps1 -Json
# Output: {"FEATURE_DIR":"C:/repo/specs/STORY-ACME-CORE-MU-00-05-002"}
# WRONG: Missing portfolio folder
```

### After Fix

```powershell
# Branch: STORY-ACME-CORE-MU-00-05-002
# Without PORTFOLIO_NAME in .env
.\setup-plan.ps1 -Json
# Output: {"FEATURE_DIR":"C:/repo/portfolios/ACME-CORE/specs/STORY-ACME-CORE-MU-00-05-002"}
# CORRECT: Portfolio extracted from branch name
```

## Implementation Steps

1. **Backup current file**:
   ```bash
   cp .specify/scripts/powershell/common.ps1 .specify/scripts/powershell/common.ps1.backup
   ```

2. **Replace with fixed version**:
   ```bash
   cp .specify/scripts/powershell/common-FIXED.ps1 .specify/scripts/powershell/common.ps1
   ```

3. **Test with sample branch**:
   ```bash
   git checkout -b STORY-TEST-ABC-MU-00-99-999
   .specify/scripts/powershell/setup-plan.ps1 -Json
   # Should output: portfolios/TEST-ABC/specs/STORY-TEST-ABC-MU-00-99-999/
   git checkout -
   git branch -D STORY-TEST-ABC-MU-00-99-999
   ```

4. **Commit the fix**:
   ```bash
   git add .specify/scripts/powershell/common.ps1
   git commit -m "fix: extract portfolio from branch names in common.ps1

   Added Get-PortfolioFromBranch function to extract portfolio from branch
   name patterns (STORY-{PORTFOLIO}-MU-*, EPIC-{PORTFOLIO}-MU-*) to ensure
   speckit commands create files in correct portfolio-scoped directories.

   Prevents issue where files were created in specs/{story-id}/ instead of
   portfolios/{portfolio}/specs/{story-id}/ when PORTFOLIO_NAME not set in environment.

   Matches extraction logic already present in create-new-feature.ps1."
   ```

## Impact

- ✅ **Fixes**: Speckit commands now create files in correct portfolio-scoped folders
- ✅ **Backward compatible**: Still checks environment and .env first
- ✅ **No breaking changes**: Existing workflows continue to work
- ✅ **Consistent behavior**: Matches create-new-feature.ps1 logic

## Related Files

- `.specify/scripts/powershell/common.ps1` - **Needs update** (this fix)
- `.specify/scripts/powershell/create-new-feature.ps1` - Already has correct logic
- `.specify/scripts/powershell/setup-plan.ps1` - Uses common.ps1 (will automatically benefit)
- `.specify/scripts/powershell/check-prerequisites.ps1` - Uses common.ps1 (will automatically benefit)

## Additional Notes

### Why This Matters

Portfolio-scoped folder structure is essential for multi-portfolio repositories:

```
specs/
├── ACME-CORE/              # National Property Workstation
│   ├── STORY-ACME-CORE-MU-00-01-001/
│   ├── STORY-ACME-CORE-MU-00-01-002/
│   └── ...
├── UWR-POC/               # Underwriting POC
│   ├── STORY-UWR-POC-MU-01-01-001/
│   └── ...
└── REFDB-X12/             # Reference Database
    └── ...
```

Without portfolio extraction, all stories would dump into `specs/` root, causing namespace collisions and organizational chaos.

### Manual Workaround (Temporary)

Until the fix is applied, manually set portfolio before running speckit commands:

```bash
export PORTFOLIO_NAME=ACME-CORE
/speckit.plan
```

Or add to `.env` file:
```
PORTFOLIO_NAME=ACME-CORE
```

But these are workarounds - the branch name **should be the source of truth**.
