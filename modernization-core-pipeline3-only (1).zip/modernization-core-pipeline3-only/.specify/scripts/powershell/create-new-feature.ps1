#!/usr/bin/env pwsh
# Create a new feature
[CmdletBinding(PositionalBinding = $false)]
param(
    [switch]$Json,
    [string]$FeatureName,
    [string]$ShortName,
    [int]$Number = 0,
    [string]$Portfolio,
    [switch]$Help,
    [Parameter(Position = 0, ValueFromRemainingArguments = $true)]
    [string[]]$FeatureDescription
)
$ErrorActionPreference = 'Stop'

# Show help if requested
if ($Help) {
    Write-Host "Usage: ./create-new-feature.ps1 [-Json] [-FeatureName <name>] [-ShortName <name>] [-Number N] [-Portfolio <name>] <feature description>"
    Write-Host ""
    Write-Host "Options:"
    Write-Host "  -FeatureName <name>  Use this exact name as branch and spec folder (no prefix, no slugification)"
    Write-Host "  -Json                Output in JSON format"
    Write-Host "  -ShortName <name>    Provide a custom short name (2-4 words) for the branch (auto-numbered)"
    Write-Host "  -Number N            Specify branch number manually (overrides auto-detection)"
    Write-Host "  -Portfolio <name>    Portfolio name for subfolder (e.g., ACME-CORE). If not provided, extracts from feature description if it starts with STORY-MU-{portfolio}-"
    Write-Host "  -Help                Show this help message"
    Write-Host ""
    Write-Host "Examples:"
    Write-Host "  ./create-new-feature.ps1 -FeatureName 'STORY-ACME-CORE-MU-00-01-004' 'Create DataContract types'"
    Write-Host "  ./create-new-feature.ps1 'Add user authentication system' -ShortName 'user-auth'"
    Write-Host "  ./create-new-feature.ps1 'Implement OAuth2 integration for API' -Portfolio 'ACME-CORE'"
    exit 0
}

# Check if feature description provided
if (-not $FeatureDescription -or $FeatureDescription.Count -eq 0) {
    Write-Error "Usage: ./create-new-feature.ps1 [-Json] [-ShortName <name>] <feature description>"
    exit 1
}

$featureDesc = ($FeatureDescription -join ' ').Trim()

# Validate description is not empty after trimming (e.g., user passed only whitespace)
if ([string]::IsNullOrWhiteSpace($featureDesc)) {
    Write-Error "Error: Feature description cannot be empty or contain only whitespace"
    exit 1
}

# Resolve repository root. Prefer git information when available, but fall back
# to searching for repository markers so the workflow still functions in repositories that
# were initialized with --no-git.
function Find-RepositoryRoot {
    param(
        [string]$StartDir,
        [string[]]$Markers = @('.git', '.specify')
    )
    $current = Resolve-Path $StartDir
    while ($true) {
        foreach ($marker in $Markers) {
            if (Test-Path (Join-Path $current $marker)) {
                return $current
            }
        }
        $parent = Split-Path $current -Parent
        if ($parent -eq $current) {
            # Reached filesystem root without finding markers
            return $null
        }
        $current = $parent
    }
}

function Get-HighestNumberFromSpecs {
    param([string]$SpecsDir)
    
    $highest = 0
    if (Test-Path $SpecsDir) {
        Get-ChildItem -Path $SpecsDir -Directory | ForEach-Object {
            if ($_.Name -match '^(\d+)') {
                $num = [int]$matches[1]
                if ($num -gt $highest) { $highest = $num }
            }
        }
    }
    return $highest
}

function Get-HighestNumberFromBranches {
    param()
    
    $highest = 0
    try {
        $branches = git branch -a 2>$null
        if ($LASTEXITCODE -eq 0) {
            foreach ($branch in $branches) {
                # Clean branch name: remove leading markers and remote prefixes
                $cleanBranch = $branch.Trim() -replace '^\*?\s+', '' -replace '^remotes/[^/]+/', ''
                
                # Extract feature number if branch matches pattern ###-*
                if ($cleanBranch -match '^(\d+)-') {
                    $num = [int]$matches[1]
                    if ($num -gt $highest) { $highest = $num }
                }
            }
        }
    } catch {
        # If git command fails, return 0
        Write-Verbose "Could not check Git branches: $_"
    }
    return $highest
}

function Get-NextBranchNumber {
    param(
        [string]$SpecsDir
    )

    # Fetch all remotes to get latest branch info (suppress errors if no remotes)
    try {
        git fetch --all --prune 2>$null | Out-Null
    } catch {
        # Ignore fetch errors
    }

    # Get highest number from ALL branches (not just matching short name)
    $highestBranch = Get-HighestNumberFromBranches

    # Get highest number from ALL specs (not just matching short name)
    $highestSpec = Get-HighestNumberFromSpecs -SpecsDir $SpecsDir

    # Take the maximum of both
    $maxNum = [Math]::Max($highestBranch, $highestSpec)

    # Return next number
    return $maxNum + 1
}

function ConvertTo-CleanBranchName {
    param([string]$Name)

    return $Name.ToLower() -replace '[^a-z0-9]', '-' -replace '-{2,}', '-' -replace '^-', '' -replace '-$', ''
}

function Get-PortfolioFromDescription {
    param(
        [string]$Description,
        [string]$RepoRoot
    )

    # Priority 1: Check for the story file inside a pack (most accurate)
    # If description looks like a story ID, search for the file
    if ($Description -match '^(STORY|EPIC)-MU-') {
        $packsDir = Join-Path $RepoRoot 'portfolios'
        if (Test-Path $packsDir) {
            # Search for the story file
            $storyFiles = Get-ChildItem -Path $packsDir -Recurse -Filter "$Description.md" -ErrorAction SilentlyContinue
            if ($storyFiles) {
                # Extract portfolio from path: portfolios/{portfolio}/docs/epics/...
                # Use -replace with escaped path separator
                $relativePath = $storyFiles[0].FullName -replace [regex]::Escape($packsDir), ''
                $relativePath = $relativePath.TrimStart('\', '/')

                # Extract first directory component (the portfolio name)
                $parts = $relativePath -split '[\\/]'
                if ($parts.Length -gt 0 -and $parts[0]) {
                    Write-Verbose "Portfolio extracted from file path: $($parts[0])"
                    return $parts[0]
                }
            }
        }
    }

    # Priority 2: Try to extract portfolio from description pattern (fallback)
    # Pattern: STORY-{portfolio}-MU- where portfolio contains a hyphen (e.g., ACME-CORE)
    # This will match ACME-CORE from STORY-ACME-CORE-MU-00-01-007
    if ($Description -match '^STORY-([A-Z]+-[A-Z0-9]+)-MU-') {
        Write-Verbose "Portfolio extracted from STORY-{portfolio}-MU- pattern: $($matches[1])"
        return $matches[1]
    }

    # Try to extract from EPIC-{portfolio}-MU- pattern
    if ($Description -match '^EPIC-([A-Z]+-[A-Z0-9]+)-MU-') {
        Write-Verbose "Portfolio extracted from EPIC-{portfolio}-MU- pattern: $($matches[1])"
        return $matches[1]
    }

    # Legacy pattern support: STORY-MU-{portfolio}- (old format)
    if ($Description -match '^STORY-MU-([A-Z]+-[A-Z0-9]+)-\d+-') {
        Write-Verbose "Portfolio extracted from STORY-MU- (legacy) pattern: $($matches[1])"
        return $matches[1]
    }

    # Legacy pattern support: EPIC-MU-{portfolio}- (old format)
    if ($Description -match '^EPIC-MU-([A-Z]+-[A-Z0-9]+)-\d+-') {
        Write-Verbose "Portfolio extracted from EPIC-MU- (legacy) pattern: $($matches[1])"
        return $matches[1]
    }

    # Try to extract from MU-{portfolio}- pattern at start
    if ($Description -match '^MU-([A-Z]+-[A-Z0-9]+)-') {
        Write-Verbose "Portfolio extracted from MU- pattern: $($matches[1])"
        return $matches[1]
    }

    Write-Verbose "No portfolio detected in description"
    return $null
}
$fallbackRoot = (Find-RepositoryRoot -StartDir $PSScriptRoot)
if (-not $fallbackRoot) {
    Write-Error "Error: Could not determine repository root. Please run this script from within the repository."
    exit 1
}

try {
    $repoRoot = git rev-parse --show-toplevel 2>$null
    if ($LASTEXITCODE -eq 0) {
        $hasGit = $true
    } else {
        throw "Git not available"
    }
} catch {
    $repoRoot = $fallbackRoot
    $hasGit = $false
}

Set-Location $repoRoot

# Determine portfolio for subfolder organization
# Resolution order: explicit -Portfolio param > PORTFOLIO_NAME env var > extraction from FeatureName/description
if (-not $Portfolio -and $env:PORTFOLIO_NAME) {
    $Portfolio = $env:PORTFOLIO_NAME
}
if (-not $Portfolio) {
    # Try to extract from FeatureName first (if provided), then fall back to description
    if ($FeatureName) {
        $Portfolio = Get-PortfolioFromDescription -Description $FeatureName -RepoRoot $repoRoot
    }
    if (-not $Portfolio) {
        $Portfolio = Get-PortfolioFromDescription -Description $featureDesc -RepoRoot $repoRoot
    }
}

if (-not $Portfolio) {
    throw "Portfolio is required. Pass -Portfolio <name>, use a STORY-{PORTFOLIO}-MU-... branch, or set PORTFOLIO_NAME in .env."
}

# Specs live inside the portfolio pack; there is no repo-root specs/.
$specsDir = Join-Path $repoRoot "portfolios/$Portfolio/specs"
New-Item -ItemType Directory -Path $specsDir -Force | Out-Null

# Function to generate branch name with stop word filtering and length filtering
function Get-BranchName {
    param([string]$Description)
    
    # Common stop words to filter out
    $stopWords = @(
        'i', 'a', 'an', 'the', 'to', 'for', 'of', 'in', 'on', 'at', 'by', 'with', 'from',
        'is', 'are', 'was', 'were', 'be', 'been', 'being', 'have', 'has', 'had',
        'do', 'does', 'did', 'will', 'would', 'should', 'could', 'can', 'may', 'might', 'must', 'shall',
        'this', 'that', 'these', 'those', 'my', 'your', 'our', 'their',
        'want', 'need', 'add', 'get', 'set'
    )
    
    # Convert to lowercase and extract words (alphanumeric only)
    $cleanName = $Description.ToLower() -replace '[^a-z0-9\s]', ' '
    $words = $cleanName -split '\s+' | Where-Object { $_ }
    
    # Filter words: remove stop words and words shorter than 3 chars (unless they're uppercase acronyms in original)
    $meaningfulWords = @()
    foreach ($word in $words) {
        # Skip stop words
        if ($stopWords -contains $word) { continue }
        
        # Keep words that are length >= 3 OR appear as uppercase in original (likely acronyms)
        if ($word.Length -ge 3) {
            $meaningfulWords += $word
        } elseif ($Description -match "\b$($word.ToUpper())\b") {
            # Keep short words if they appear as uppercase in original (likely acronyms)
            $meaningfulWords += $word
        }
    }
    
    # If we have meaningful words, use first 3-4 of them
    if ($meaningfulWords.Count -gt 0) {
        $maxWords = if ($meaningfulWords.Count -eq 4) { 4 } else { 3 }
        $result = ($meaningfulWords | Select-Object -First $maxWords) -join '-'
        return $result
    } else {
        # Fallback to original logic if no meaningful words found
        $result = ConvertTo-CleanBranchName -Name $Description
        $fallbackWords = ($result -split '-') | Where-Object { $_ } | Select-Object -First 3
        return [string]::Join('-', $fallbackWords)
    }
}

# Generate branch name
if ($FeatureName) {
    # Use FeatureName verbatim — no prefix, no slugification
    $branchName = $FeatureName
    $featureNum = ''
} else {
    if ($ShortName) {
        # Use provided short name, just clean it up
        $branchSuffix = ConvertTo-CleanBranchName -Name $ShortName
    } else {
        # Generate from description with smart filtering
        $branchSuffix = Get-BranchName -Description $featureDesc
    }

    # Determine branch number
    if ($Number -eq 0) {
        if ($hasGit) {
            # Check existing branches on remotes
            $Number = Get-NextBranchNumber -SpecsDir $specsDir
        } else {
            # Fall back to local directory check
            $Number = (Get-HighestNumberFromSpecs -SpecsDir $specsDir) + 1
        }
    }

    $featureNum = ('{0:000}' -f $Number)
    $branchName = "$featureNum-$branchSuffix"

    # GitHub enforces a 244-byte limit on branch names
    # Validate and truncate if necessary
    $maxBranchLength = 244
    if ($branchName.Length -gt $maxBranchLength) {
        # Calculate how much we need to trim from suffix
        # Account for: feature number (3) + hyphen (1) = 4 chars
        $maxSuffixLength = $maxBranchLength - 4

        # Truncate suffix
        $truncatedSuffix = $branchSuffix.Substring(0, [Math]::Min($branchSuffix.Length, $maxSuffixLength))
        # Remove trailing hyphen if truncation created one
        $truncatedSuffix = $truncatedSuffix -replace '-$', ''

        $originalBranchName = $branchName
        $branchName = "$featureNum-$truncatedSuffix"

        Write-Warning "[specify] Branch name exceeded GitHub's 244-byte limit"
        Write-Warning "[specify] Original: $originalBranchName ($($originalBranchName.Length) bytes)"
        Write-Warning "[specify] Truncated to: $branchName ($($branchName.Length) bytes)"
    }
}

if ($hasGit) {
    $branchCreated = $false
    try {
        git checkout -b $branchName 2>$null | Out-Null
        if ($LASTEXITCODE -eq 0) {
            $branchCreated = $true
        }
    } catch {
        # Exception during git command
    }

    if (-not $branchCreated) {
        # Check if branch already exists
        $existingBranch = git branch --list $branchName 2>$null
        if ($existingBranch) {
            Write-Error "Error: Branch '$branchName' already exists. Please use a different feature name or specify a different number with -Number."
            exit 1
        } else {
            Write-Error "Error: Failed to create git branch '$branchName'. Please check your git configuration and try again."
            exit 1
        }
    }
} else {
    Write-Warning "[specify] Warning: Git repository not detected; skipped branch creation for $branchName"
}

# Create the feature directory inside the portfolio pack
$featureDir = Join-Path $specsDir $branchName
New-Item -ItemType Directory -Path $featureDir -Force | Out-Null

$template = Join-Path $repoRoot '.specify/templates/spec-template.md'
$specFile = Join-Path $featureDir 'spec.md'
if (Test-Path $template) { 
    Copy-Item $template $specFile -Force 
} else { 
    New-Item -ItemType File -Path $specFile | Out-Null 
}

# Set the SPECIFY_FEATURE environment variable for the current session
$env:SPECIFY_FEATURE = $branchName

if ($Json) {
    $obj = [PSCustomObject]@{
        BRANCH_NAME = $branchName
        SPEC_FILE = $specFile
        FEATURE_NUM = $featureNum
        HAS_GIT = $hasGit
        PORTFOLIO = $Portfolio
    }
    $obj | ConvertTo-Json -Compress
} else {
    Write-Output "BRANCH_NAME: $branchName"
    Write-Output "SPEC_FILE: $specFile"
    Write-Output "FEATURE_NUM: $featureNum"
    Write-Output "HAS_GIT: $hasGit"
    if ($Portfolio) {
        Write-Output "PORTFOLIO: $Portfolio"
    }
    Write-Output "SPECIFY_FEATURE environment variable set to: $branchName"
}

