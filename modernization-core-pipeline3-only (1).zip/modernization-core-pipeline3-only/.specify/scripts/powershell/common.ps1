#!/usr/bin/env pwsh
# Common PowerShell functions analogous to common.sh

function Get-RepoRoot {
    try {
        $result = git rev-parse --show-toplevel 2>$null
        if ($LASTEXITCODE -eq 0) {
            return $result
        }
    } catch {
        # Git command failed
    }

    # Fall back to script location for non-git repos
    return (Resolve-Path (Join-Path $PSScriptRoot "../../..")).Path
}

function Get-CurrentBranch {
    # First check if SPECIFY_FEATURE environment variable is set
    if ($env:SPECIFY_FEATURE) {
        return $env:SPECIFY_FEATURE
    }

    # Then check git if available
    try {
        $result = git rev-parse --abbrev-ref HEAD 2>$null
        if ($LASTEXITCODE -eq 0) {
            return $result
        }
    } catch {
        # Git command failed
    }

    # For non-git repos, try to find the latest feature directory
    $repoRoot = Get-RepoRoot

    # Check for portfolio name
    $portfolio = $env:PORTFOLIO_NAME
    if (-not $portfolio) {
        $envFile = Join-Path $repoRoot ".env"
        if (Test-Path $envFile) {
            Get-Content $envFile | ForEach-Object {
                if ($_ -match '^\s*PORTFOLIO_NAME\s*=\s*(.+)\s*$') {
                    $portfolio = $matches[1].Trim()
                }
            }
        }
    }

    # Specs live inside the portfolio pack. Without a portfolio there is no
    # valid location, so return nothing rather than inventing a repo-root specs/.
    if (-not $portfolio) { return "" }
    $specsDir = Join-Path $repoRoot "portfolios/$portfolio/specs"

    if (Test-Path $specsDir) {
        $latestFeature = ""
        $highest = 0

        Get-ChildItem -Path $specsDir -Directory | ForEach-Object {
            if ($_.Name -match '^(\d{3})-') {
                $num = [int]$matches[1]
                if ($num -gt $highest) {
                    $highest = $num
                    $latestFeature = $_.Name
                }
            }
        }

        if ($latestFeature) {
            return $latestFeature
        }
    }

    # Final fallback
    return "main"
}

function Test-HasGit {
    try {
        git rev-parse --show-toplevel 2>$null | Out-Null
        return ($LASTEXITCODE -eq 0)
    } catch {
        return $false
    }
}

function Test-FeatureBranch {
    param(
        [string]$Branch,
        [bool]$HasGit = $true
    )

    # For non-git repos, we can't enforce branch naming but still provide output
    if (-not $HasGit) {
        Write-Warning "[specify] Warning: Git repository not detected; skipped branch validation"
        return $true
    }

    # Accept multiple branch naming conventions:
    # - Stock: 001-feature-name
    # - Story/Epic ID: STORY-*, STORY-MU-*, EPIC-*
    # - Portfolio-prefixed: ACME-REF-*, ACME-*, UWR-*
    # - Custom: any non-main/master branch
    if ($Branch -match '^(main|master)$') {
        Write-Output "ERROR: Cannot run on $Branch. Create or switch to a feature branch first."
        return $false
    }
    return $true
}

function Get-PortfolioFromBranch {
    param(
        [string]$Branch,
        [string]$RepoRoot
    )

    # Priority 1: Check environment variable
    if ($env:PORTFOLIO_NAME) {
        return $env:PORTFOLIO_NAME
    }

    # Priority 2: Check .env file
    $envFile = Join-Path $RepoRoot ".env"
    if (Test-Path $envFile) {
        Get-Content $envFile | ForEach-Object {
            if ($_ -match '^\s*PORTFOLIO_NAME\s*=\s*(.+)\s*$') {
                return $matches[1].Trim()
            }
        }
    }

    # Priority 3: Try to extract portfolio from branch name pattern
    # Pattern: STORY-{portfolio}-MU- where portfolio contains a hyphen (e.g., ACME-CORE)
    # This will match ACME-CORE from STORY-ACME-CORE-MU-00-01-007
    if ($Branch -match '^STORY-([A-Z]+-[A-Z0-9]+)-MU-') {
        Write-Verbose "Portfolio extracted from STORY-{portfolio}-MU- pattern: $($matches[1])"
        return $matches[1]
    }

    # Try to extract from EPIC-{portfolio}-MU- pattern
    if ($Branch -match '^EPIC-([A-Z]+-[A-Z0-9]+)-MU-') {
        Write-Verbose "Portfolio extracted from EPIC-{portfolio}-MU- pattern: $($matches[1])"
        return $matches[1]
    }

    # Legacy pattern support: STORY-MU-{portfolio}- (old format)
    if ($Branch -match '^STORY-MU-([A-Z]+-[A-Z0-9]+)-\d+-') {
        Write-Verbose "Portfolio extracted from STORY-MU- (legacy) pattern: $($matches[1])"
        return $matches[1]
    }

    # Legacy pattern support: EPIC-MU-{portfolio}- (old format)
    if ($Branch -match '^EPIC-MU-([A-Z]+-[A-Z0-9]+)-\d+-') {
        Write-Verbose "Portfolio extracted from EPIC-MU- (legacy) pattern: $($matches[1])"
        return $matches[1]
    }

    # Priority 4: Check for story file in docs/ directory (most accurate for STORY branches)
    if ($Branch -match '^(STORY|EPIC)-') {
        $packsDir = Join-Path $RepoRoot 'portfolios'
        if (Test-Path $packsDir) {
            # Search for the story/epic file
            $storyFiles = Get-ChildItem -Path $packsDir -Recurse -Filter "$Branch.md" -ErrorAction SilentlyContinue
            if ($storyFiles) {
                # Extract portfolio from path: portfolios/{portfolio}/docs/epics/...
                $relativePath = $storyFiles[0].FullName -replace [regex]::Escape($packsDir), ''
                $relativePath = $relativePath.TrimStart('\', '/')

                # Extract first directory component (the portfolio name)
                $parts = $relativePath -split '[\\/]'
                if ($parts.Length -gt 0 -and $parts[0]) {
                    Write-Verbose "Portfolio extracted from file path: $($parts[0])"
                    return $parts[0]
                }
            }
        }
    }

    # No portfolio found
    return $null
}

function Get-FeatureDir {
    param([string]$RepoRoot, [string]$Branch)

    # Extract portfolio from branch name or environment
    $portfolio = Get-PortfolioFromBranch -Branch $Branch -RepoRoot $RepoRoot

    # If portfolio is defined, use portfolio-based structure
    if ($portfolio) {
        return Join-Path $RepoRoot "portfolios/$portfolio/specs/$Branch"
    }

    # No fallback: specs live inside a pack (portfolios/{portfolio}/specs/).
    # Writing to a repo-root specs/ would scatter artifacts outside every pack.
    throw "Cannot resolve portfolio for branch '$Branch'. Use a STORY-{PORTFOLIO}-MU-... branch name or set PORTFOLIO_NAME in .env."
}

function Get-FeaturePathsEnv {
    # Load PORTFOLIO_NAME from .env if not already set in environment
    if (-not $env:PORTFOLIO_NAME) {
        $envRoot = Get-RepoRoot
        $envFile = Join-Path $envRoot ".env"
        if (Test-Path $envFile) {
            Get-Content $envFile | ForEach-Object {
                if ($_ -match '^\s*PORTFOLIO_NAME\s*=\s*(.+)\s*$') {
                    $env:PORTFOLIO_NAME = $matches[1].Trim()
                }
            }
        }
    }

    $repoRoot = Get-RepoRoot
    $currentBranch = Get-CurrentBranch
    $hasGit = Test-HasGit
    $featureDir = Get-FeatureDir -RepoRoot $repoRoot -Branch $currentBranch

    [PSCustomObject]@{
        REPO_ROOT     = $repoRoot
        CURRENT_BRANCH = $currentBranch
        HAS_GIT       = $hasGit
        FEATURE_DIR   = $featureDir
        FEATURE_SPEC  = Join-Path $featureDir 'spec.md'
        IMPL_PLAN     = Join-Path $featureDir 'plan.md'
        TASKS         = Join-Path $featureDir 'tasks.md'
        RESEARCH      = Join-Path $featureDir 'research.md'
        DATA_MODEL    = Join-Path $featureDir 'data-model.md'
        QUICKSTART    = Join-Path $featureDir 'quickstart.md'
        CONTRACTS_DIR = Join-Path $featureDir 'contracts'
    }
}

function Test-FileExists {
    param([string]$Path, [string]$Description)
    if (Test-Path -Path $Path -PathType Leaf) {
        Write-Output "  ✓ $Description"
        return $true
    } else {
        Write-Output "  ✗ $Description"
        return $false
    }
}

function Test-DirHasFiles {
    param([string]$Path, [string]$Description)
    if ((Test-Path -Path $Path -PathType Container) -and (Get-ChildItem -Path $Path -ErrorAction SilentlyContinue | Where-Object { -not $_.PSIsContainer } | Select-Object -First 1)) {
        Write-Output "  ✓ $Description"
        return $true
    } else {
        Write-Output "  ✗ $Description"
        return $false
    }
}

