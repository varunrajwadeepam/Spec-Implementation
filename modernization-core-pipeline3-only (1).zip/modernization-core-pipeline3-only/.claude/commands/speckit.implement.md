---
description: Execute the implementation plan by processing and executing all tasks defined in tasks.md
handoffs:
  - label: Verify Files
    agent: speckit.verify
    prompt: Verify the files I just implemented
    send: true
  - label: Verify API Contract
    agent: speckit.verify
    prompt: Verify API contract for the service I just implemented
    send: true
  - label: Full Code Review
    agent: speckit.review
    prompt: Run a full code review of all changes
    send: true
---

## User Input

```text
$ARGUMENTS
```

You **MUST** consider the user input before proceeding (if not empty).

## Outline

1. Run `.specify/scripts/powershell/check-prerequisites.ps1 -Json -RequireTasks -IncludeTasks` from repo root and parse FEATURE_DIR and AVAILABLE_DOCS list. All paths must be absolute. For single quotes in args like "I'm Groot", use escape syntax: e.g 'I'\''m Groot' (or double-quote if possible: "I'm Groot").

2. **Check analysis gate** (if FEATURE_DIR/analyze-status.json exists):
   - Read `analyze-status.json` from FEATURE_DIR
   - If `status` is `"FAIL"`:
     - Display the blocker list from the file
     - Display critical issue count and migration parity coverage (if applicable)
     - **STOP** and ask: "Analysis gate FAILED with [N] critical issues. Run `/speckit.analyze` to see details and resolve them before implementation. Do you want to proceed anyway? (yes/no)"
     - Wait for user response before continuing
     - If user says "no": halt execution
     - If user says "yes": warn "Proceeding despite analysis failures. Quality issues may result." and continue
   - If `status` is `"PASS"`: display "Analysis gate: PASS" and continue
   - If file doesn't exist: **STOP** and say "No analysis has been run. Run `/speckit.analyze` first — it is a mandatory step before implementation." Do not proceed until analysis is complete.

3. **Check impact analysis gate** (required for migrations and shared code changes):
   - Detect migration: check if `source-audit.md` exists in FEATURE_DIR, or if spec.md contains `[MIGRATION]` tags
   - Detect shared component change: check if plan.md or tasks.md references files in shared/common directories (e.g., `common/`, `shared/`, `lib/`)
   - Detect global-state change: check if tasks.md references the global-state location declared in plan.md, or mentions actions / reducers / selectors / effects / state slices
   - Detect route change: check if tasks.md references route guards, resolvers, or any route-configuration file declared in plan.md
   - Detect dependency update: check if tasks.md references dependency file changes (e.g., `package.json`, `*.csproj`, `pom.xml`, `build.gradle`, `requirements.txt`, `go.mod`)
   - **If ANY of the above detected**:
     - Check if `FEATURE_DIR/impact-analysis.md` exists
     - Check if `FEATURE_DIR/IMPACT-APPROVED.md` exists
     - If impact-analysis.md is MISSING: **STOP** and say "An impact analysis is required before implementation. Run `/speckit.impact` first."
     - If IMPACT-APPROVED.md is MISSING: **STOP** and say "Impact analysis exists but has not been approved. Review the impact analysis and approve it before proceeding."
     - If both exist: display "Impact analysis: APPROVED" and continue

4. **Check checklists status** (if FEATURE_DIR/checklists/ exists):
   - Scan all checklist files in the checklists/ directory
   - For each checklist, count:
     - Total items: All lines matching `- [ ]` or `- [X]` or `- [x]`
     - Completed items: Lines matching `- [X]` or `- [x]`
     - Incomplete items: Lines matching `- [ ]`
   - Create a status table:

     ```text
     | Checklist | Total | Completed | Incomplete | Status |
     |-----------|-------|-----------|------------|--------|
     | ux.md     | 12    | 12        | 0          | ✓ PASS |
     | test.md   | 8     | 5         | 3          | ✗ FAIL |
     | security.md | 6   | 6         | 0          | ✓ PASS |
     ```

   - Calculate overall status:
     - **PASS**: All checklists have 0 incomplete items
     - **FAIL**: One or more checklists have incomplete items

   - **If any checklist is incomplete**:
     - Display the table with incomplete item counts
     - **STOP** and ask: "Some checklists are incomplete. Do you want to proceed with implementation anyway? (yes/no)"
     - Wait for user response before continuing
     - If user says "no" or "wait" or "stop", halt execution
     - If user says "yes" or "proceed" or "continue", proceed to step 5

   - **If all checklists are complete**:
     - Display the table showing all checklists passed
     - Automatically proceed to step 5

5. Load and analyze the implementation context:
   - **REQUIRED**: Read tasks.md for the complete task list and execution plan
   - **REQUIRED**: Read plan.md for tech stack, architecture, and file structure
   - **REQUIRED**: Resolve **implementation root** — the base directory for all generated code:
     - Read plan.md "Project Structure" / "Source Code" section for the declared root path
     - If plan.md specifies `portfolios/{portfolio}/POC/` or similar portfolio-scoped path, use it
     - If plan.md specifies a flat path (e.g., `src/`), prefix with `portfolios/{portfolio}/POC/` where `{portfolio}` is resolved from `.env PORTFOLIO_NAME` or the spec folder path
     - All file paths in tasks.md are relative to this implementation root
     - **This ensures multi-portfolio isolation** — different portfolios write to different output directories
   - **IF EXISTS**: Read data-model.md for entities and relationships
   - **IF EXISTS**: Read contracts/ for API specifications and test requirements
   - **IF EXISTS**: Read research.md for technical decisions and constraints
   - **IF EXISTS**: Read quickstart.md for integration scenarios
   - **IF EXISTS**: Read source-audit.md for source system mapping (migration only)
   - **IF EXISTS**: Load `portfolios/{portfolio}/specs/constitution.md` (resolve portfolio from `PORTFOLIO_NAME` in `.env` or explicit parameter). Use constitution to enforce technology constraints and quality gate thresholds during implementation. If plan.md conflicts with constitution, follow constitution and WARN.

6. **Project Setup Verification**:
   - **REQUIRED**: Create/verify ignore files based on actual project setup:

   **Detection & Creation Logic**:
   - Check if the following command succeeds to determine if the repository is a git repo (create/verify .gitignore if so):

     ```sh
     git rev-parse --git-dir 2>/dev/null
     ```

   - Check if Dockerfile* exists or Docker in plan.md → create/verify .dockerignore
   - Check if .eslintrc* exists → create/verify .eslintignore
   - Check if eslint.config.* exists → ensure the config's `ignores` entries cover required patterns
   - Check if .prettierrc* exists → create/verify .prettierignore
   - Check if .npmrc or package.json exists → create/verify .npmignore (if publishing)
   - Check if terraform files (*.tf) exist → create/verify .terraformignore
   - Check if .helmignore needed (helm charts present) → create/verify .helmignore

   **If ignore file already exists**: Verify it contains essential patterns, append missing critical patterns only
   **If ignore file missing**: Create with full pattern set for detected technology

   **Common Patterns by Technology** (from plan.md tech stack):
   - **Node.js/JavaScript/TypeScript**: `node_modules/`, `dist/`, `build/`, `*.log`, `.env*`
   - **Python**: `__pycache__/`, `*.pyc`, `.venv/`, `venv/`, `dist/`, `*.egg-info/`
   - **Java**: `target/`, `*.class`, `*.jar`, `.gradle/`, `build/`
   - **C#/.NET**: `bin/`, `obj/`, `*.user`, `*.suo`, `packages/`
   - **Go**: `*.exe`, `*.test`, `vendor/`, `*.out`
   - **Ruby**: `.bundle/`, `log/`, `tmp/`, `*.gem`, `vendor/bundle/`
   - **PHP**: `vendor/`, `*.log`, `*.cache`, `*.env`
   - **Rust**: `target/`, `debug/`, `release/`, `*.rs.bk`, `*.rlib`, `*.prof*`, `.idea/`, `*.log`, `.env*`
   - **Kotlin**: `build/`, `out/`, `.gradle/`, `.idea/`, `*.class`, `*.jar`, `*.iml`, `*.log`, `.env*`
   - **C++**: `build/`, `bin/`, `obj/`, `out/`, `*.o`, `*.so`, `*.a`, `*.exe`, `*.dll`, `.idea/`, `*.log`, `.env*`
   - **C**: `build/`, `bin/`, `obj/`, `out/`, `*.o`, `*.a`, `*.so`, `*.exe`, `autom4te.cache/`, `config.status`, `config.log`, `.idea/`, `*.log`, `.env*`
   - **Swift**: `.build/`, `DerivedData/`, `*.swiftpm/`, `Packages/`
   - **R**: `.Rproj.user/`, `.Rhistory`, `.RData`, `.Ruserdata`, `*.Rproj`, `packrat/`, `renv/`
   - **Universal**: `.DS_Store`, `Thumbs.db`, `*.tmp`, `*.swp`, `.vscode/`, `.idea/`

   **Tool-Specific Patterns**:
   - **Docker**: `node_modules/`, `.git/`, `Dockerfile*`, `.dockerignore`, `*.log*`, `.env*`, `coverage/`
   - **ESLint**: `node_modules/`, `dist/`, `build/`, `coverage/`, `*.min.js`
   - **Prettier**: `node_modules/`, `dist/`, `build/`, `coverage/`, `package-lock.json`, `yarn.lock`, `pnpm-lock.yaml`
   - **Terraform**: `.terraform/`, `*.tfstate*`, `*.tfvars`, `.terraform.lock.hcl`
   - **Kubernetes/k8s**: `*.secret.yaml`, `secrets/`, `.kube/`, `kubeconfig*`, `*.key`, `*.crt`

7. Parse tasks.md structure and extract:
   - **Task phases**: Setup, Tests, Core, Integration, Polish (standard) OR Inventory, Interfaces, Leaf, Service, Container, Shell, Cleanup, Quality Gates (migration)
   - **Task dependencies**: Sequential vs parallel execution rules
   - **Task details**: ID, description, file paths, parallel markers [P]
   - **Execution flow**: Order and dependency requirements

8. Execute implementation following the task plan:
   - **Phase-by-phase execution**: Complete each phase before moving to the next
   - **Respect dependencies**: Run sequential tasks in order, parallel tasks [P] can run together
   - **Follow TDD approach**: Execute test tasks before their corresponding implementation tasks
   - **File-based coordination**: Tasks affecting the same files must run sequentially
   - **Validation checkpoints**: Verify each phase completion before proceeding

9. Implementation execution rules:
   - **Story ID traceability** (MANDATORY for all code changes):
     - Extract the Story ID from the current spec directory path (e.g., `portfolios/{portfolio}/specs/STORY-{portfolio}-MU-01-01-001/` → Story ID is `STORY-{portfolio}-MU-01-01-001`)
     - Add a comment header at the top of every file you create or modify, using the language's idiomatic single-line comment syntax: `// Story: {STORY_ID}` (for TypeScript/JavaScript/C#/Java), `# Story: {STORY_ID}` (for Python/Shell/Ruby), `-- Story: {STORY_ID}` (for SQL)
     - For existing files being modified, add the Story ID comment at the beginning of each new method/function/class you add
     - For multiple stories modifying the same file, keep all Story ID comments (one per story) at the top of the file or at the beginning of each method
   - **Setup first**: Initialize project structure, dependencies, configuration
   - **Tests before code**: If you need to write tests for contracts, entities, and integration scenarios
   - **Core development**: Implement models, services, CLI commands, endpoints
   - **Integration work**: Database connections, middleware, logging, external services
   - **Polish and validation**: Unit tests, performance optimization, documentation
   - **Forms / input bindings** — follow the form-binding pattern declared in plan.md (if any). The chosen pattern MUST be applied consistently across the feature: do not mix patterns within the same component / module. If the pattern includes empty-value semantics (does an empty input serialize as `null`, `""`, `undefined`, or get omitted?), apply the documented choice everywhere a form value is read or submitted.
   - **Traceability / automation IDs on UI elements** — if plan.md declares an automation-ID attribute / convention (e.g., `data-testid="..."`), apply it to every interactive element produced by this feature, using the format declared in plan.md.
   - **Style isolation for shared components** (MANDATORY, UI stacks only):
     - Do NOT disable the framework's default style encapsulation on any new or migrated component
     - Do NOT use style-piercing selectors or global / unscoped selectors to override styles of components living in the shared-components location declared in plan.md, or third-party component class names
     - If a style override on a shared component is genuinely needed (e.g., a layout-specific margin), STOP and ask the user for explicit approval. Document: what is being overridden, why, and that the override is scoped
     - Style files SHOULD only style the component's own elements — never reach into child shared components
   - **Error handling** (MANDATORY):
     - Every service method issuing an external call (HTTP, DB, file I/O) MUST have explicit error handling using the idiom declared in plan.md (e.g., `try/catch`, a reactive-stream error operator, `Result<T,E>`) — silent swallowing is prohibited. Pick a strategy per call: "catch and replace with typed fallback" OR "catch and rethrow as formatted error"
     - In reactive pipelines that use flattening operators, place the error handler on the INNER stream — outer placement terminates long-lived streams (search inputs, value-change streams, route params) on the first error
     - Retry behavior is applied ONLY to idempotent reads where source-audit.md Error Handling Inventory shows transient failures; NEVER to non-idempotent operations (POST / PUT / DELETE / other side-effecting verbs)
     - For migrations: every error handling path in the source system MUST be preserved in the target — same user-facing behavior (toast / banner / modal / log line), same fallback values, same retry count. Silently dropping source-system error handling is a Blocker
     - Every long-lived subscription / continuation is bound to a lifecycle scope (using the unsubscribe / cancellation primitive declared in plan.md)
   - **API contract preservation** (MANDATORY for migrations):
     - Every external call MUST produce the **exact same** request/response payload shape as the original — same field names, same types, same formats
     - Numbers MUST stay numbers, booleans MUST stay booleans, `null` MUST stay `null`
     - Do NOT add new fields to existing request payloads. Do NOT remove fields.
     - Empty-input handling: the source system may serialize an empty input as `""`, the target framework may default to `null` or omit the field — match the source behavior byte-for-byte
     - Date / time serialization and collection / array encoding (CSV, repeated keys, JSON array) may differ between source and target — verify formats match (check source-audit.md)
     - For each service method, cross-reference the outbound call against the `source-audit.md` API Calls table to verify field-by-field parity
     - Write tests that verify the exact request/response body shape (field names, types, values)

10. **Lint/build validation after each phase** (MANDATORY):
    After completing each implementation phase, run the project's lint and build commands on all files created or modified in that phase.

    **Detect lint/build commands from plan.md** (look for `lint_cmd`, `build_cmd`, `test_cmd` or derive from tech stack):
    - **TypeScript/JavaScript**: `npx eslint "<files>"` or project-defined lint script
    - **C#/.NET**: `dotnet build --warnaserror`
    - **Java**: `mvn compile` or `./gradlew build`
    - **Python**: `ruff check` or `flake8`
    - **Go**: `go vet ./...`
    - If no lint tool detected, skip this step and note it in progress report.

    - **If errors are found**: Fix them immediately before moving to the next phase
    - **Zero-error policy**: The phase is not complete until lint/build reports zero errors
    - **Do not skip this step** even if the phase has only one file

10b. **On-demand verification** (RECOMMENDED after completing service or component phases):

    After completing a service or complex component, you can invoke `/speckit.verify` for targeted checks:
    - **After implementing a service with external calls**: run `/speckit.verify api contract for [service-file-path]`
    - **After implementing a component**: run `/speckit.verify [file-path]` to check coding standards
    - **After migration phases**: run `/speckit.verify parity for [component-name]` to verify functional parity against source-audit.md

    This is lighter than a full `/speckit.review` and catches issues early before they compound.

11. Progress tracking and error handling:
    - Report progress after each completed task
    - Halt execution if any non-parallel task fails
    - For parallel tasks [P], continue with successful tasks, report failed ones
    - Provide clear error messages with context for debugging
    - Suggest next steps if implementation cannot proceed
    - **IMPORTANT** For completed tasks, make sure to mark the task off as [X] in the tasks file.

12. **Migration Parity Verification (MIGRATION ONLY)**:

    After implementing each migrated component/service, verify behavioral parity:

    a. **Check that all source-system behaviors are preserved**:
       - Compare implemented methods against `source-audit.md` (if present)
       - Verify all entry points, error paths, and data transformations are covered

    b. **Verify integration points remain compatible**:
       - External callers/consumers of the migrated component must still work unchanged
       - Contract shapes (request/response) must match the original

    c. **Interop / bridge registration check** (only if plan.md declares an interop / bridge layer between the source and target stacks):
       - Check whether the new unit is consumed by any source-system caller (search the source-system code paths declared in plan.md for the unit's identifier / selector)
       - If consumed: verify the interop registration exists at the location declared in plan.md, uses the exact identifier convention declared there, and that every public input and output/event of the unit appears in the registration's inputs/outputs lists — missing entries cause silent binding failures
       - If NOT consumed by any source-system caller: skip the registration (don't register unnecessary shims) and document in task notes: "No source-system consumers — bridge registration not needed"

    d. **If mismatches found**: Fix immediately before marking the implementation task as complete.

13. **Final lint/build sweep** (MANDATORY — blocks completion):
    Before declaring implementation complete, run the project's lint and build commands on ALL files that were created or modified across the entire implementation (same tool as step 10, full file set).

    - Collect the full list of changed files from all phases
    - Run a single lint/build pass across all of them
    - **If any errors remain**: fix them before proceeding to step 14
    - **Report the result**: "Lint/Build: X files checked, 0 errors" or list remaining issues
    - This catches cross-file issues (e.g., an import became unused after a later phase refactored something)

14. Completion validation:
    - Verify all required tasks are completed
    - Check that implemented features match the original specification
    - Validate that tests pass and coverage meets the threshold declared in plan.md (or project requirements)
    - Confirm the implementation follows the technical plan
    - Confirm lint/build reports zero errors on all changed files (step 13)
    - **For migrations**: Verify functional parity against source-audit.md — every source feature must have a target equivalent
    - **For migrations**: Verify all integration points remain compatible (step 12)
    - **For migrations**: Verify all cleanup tasks completed (old source files removed where applicable)
    - Report final status with summary of completed work

Note: This command assumes a complete task breakdown exists in tasks.md. If tasks are incomplete or missing, suggest running `/speckit.tasks` first to regenerate the task list.
