---
description: Convert existing tasks into actionable, dependency-ordered GitHub issues for the feature based on available design artifacts.
tools: ['github/github-mcp-server/issue_write']
---

## User Input

```text
$ARGUMENTS
```

You **MUST** consider the user input before proceeding (if not empty).

## Outline

1. Run `.specify/scripts/powershell/check-prerequisites.ps1 -Json -RequireTasks -IncludeTasks` from repo root and parse FEATURE_DIR and AVAILABLE_DOCS list. All paths must be absolute. For single quotes in args like "I'm Groot", use escape syntax: e.g 'I'\''m Groot' (or double-quote if possible: "I'm Groot").
1. From the executed script, extract the path to **tasks**.
1. Get the Git remote by running:

```bash
git config --get remote.origin.url
```

1. **Detect remote type** and route to the appropriate issue creation method:

   **If the remote is a GitHub URL** (contains `github.com`):
   - Use the GitHub MCP server to create issues in the matching GitHub repository.

   **If the remote is an Azure DevOps URL** (contains `dev.azure.com` or `visualstudio.com`):
   - Use the ADO MCP server (`mcp__ado__wit_create_work_item`) to create work items in the matching ADO project.
   - Map task fields: Title → task description, Description → task details + file paths, Type → "Task" or "User Story" based on phase.

   **If the remote is neither GitHub nor Azure DevOps**:
   - STOP and inform the user: "Remote URL is not a supported platform (GitHub or Azure DevOps). Issues cannot be created automatically."

1. For each task in the list, create an issue/work item in the repository that matches the Git remote.

> [!CAUTION]
> UNDER NO CIRCUMSTANCES EVER CREATE ISSUES IN REPOSITORIES THAT DO NOT MATCH THE REMOTE URL
