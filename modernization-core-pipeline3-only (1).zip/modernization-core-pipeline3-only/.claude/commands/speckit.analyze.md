---
description: Perform a non-destructive cross-artifact consistency and quality analysis across spec.md, plan.md, and tasks.md after task generation.
handoffs:
  - label: Start Implementation
    agent: speckit.implement
    prompt: Start the implementation in phases
    send: true
---

## User Input

```text
$ARGUMENTS
```

You **MUST** consider the user input before proceeding (if not empty).

## Goal

Identify inconsistencies, duplications, ambiguities, and underspecified items across the three core artifacts (`spec.md`, `plan.md`, `tasks.md`) before implementation. This command MUST run only after `/speckit.tasks` has successfully produced a complete `tasks.md`.

## Operating Constraints

**STRICTLY READ-ONLY**: Do **not** modify any files. Output a structured analysis report. Offer an optional remediation plan (user must explicitly approve before any follow-up editing commands would be invoked manually).

**Constitution Authority**: The project constitution (`portfolios/{portfolio}/specs/constitution.md`) is **non-negotiable** within this analysis scope. Constitution conflicts are automatically CRITICAL and require adjustment of the spec, plan, or tasks—not dilution, reinterpretation, or silent ignoring of the principle. If a principle itself needs to change, that must occur in a separate, explicit constitution update outside `/speckit.analyze`.

## Execution Steps

### 1. Initialize Analysis Context

Run `.specify/scripts/powershell/check-prerequisites.ps1 -Json -RequireTasks -IncludeTasks` once from repo root and parse JSON for FEATURE_DIR and AVAILABLE_DOCS. Derive absolute paths:

- SPEC = FEATURE_DIR/spec.md
- PLAN = FEATURE_DIR/plan.md
- TASKS = FEATURE_DIR/tasks.md

Abort with an error message if any required file is missing (instruct the user to run missing prerequisite command).
For single quotes in args like "I'm Groot", use escape syntax: e.g 'I'\''m Groot' (or double-quote if possible: "I'm Groot").

### 2. Load Artifacts (Progressive Disclosure)

Load only the minimal necessary context from each artifact:

**From spec.md:**

- Overview/Context
- Functional Requirements
- Non-Functional Requirements
- User Stories
- Edge Cases (if present)

**From plan.md:**

- Architecture/stack choices
- Data Model references
- Phases
- Technical constraints

**From tasks.md:**

- Task IDs
- Descriptions
- Phase grouping
- Parallel markers [P]
- Referenced file paths

**From constitution:**

- Load `portfolios/{portfolio}/specs/constitution.md` for principle validation (resolve portfolio from `PORTFOLIO_NAME` in `.env` or explicit parameter)

### 3. Build Semantic Models

Create internal representations (do not include raw artifacts in output):

- **Requirements inventory**: Each functional + non-functional requirement with a stable key (derive slug based on imperative phrase; e.g., "User can upload file" → `user-can-upload-file`)
- **User story/action inventory**: Discrete user actions with acceptance criteria
- **Task coverage mapping**: Map each task to one or more requirements or stories (inference by keyword / explicit reference patterns like IDs or key phrases)
- **Constitution rule set**: Extract principle names and MUST/SHOULD normative statements

### 4. Detection Passes (Token-Efficient Analysis)

Focus on high-signal findings. Limit to 50 findings total; aggregate remainder in overflow summary.

#### A. Duplication Detection

- Identify near-duplicate requirements
- Mark lower-quality phrasing for consolidation

#### B. Ambiguity Detection

- Flag vague adjectives (fast, scalable, secure, intuitive, robust) lacking measurable criteria
- Flag unresolved placeholders (TODO, TKTK, ???, `<placeholder>`, etc.)

#### C. Underspecification

- Requirements with verbs but missing object or measurable outcome
- User stories missing acceptance criteria alignment
- Tasks referencing files or components not defined in spec/plan

#### D. Constitution Alignment

- Any requirement or plan element conflicting with a MUST principle
- Missing mandated sections or quality gates from constitution

#### E. Coverage Gaps

- Requirements with zero associated tasks
- Tasks with no mapped requirement/story
- Non-functional requirements not reflected in tasks (e.g., performance, security)

#### F. Inconsistency

- Terminology drift (same concept named differently across files)
- Data entities referenced in plan but absent in spec (or vice versa)
- Task ordering contradictions (e.g., integration tasks before foundational setup tasks without dependency note)
- Conflicting requirements (e.g., one requires framework X while another specifies framework Y)

### 5. Severity Assignment

Use this heuristic to prioritize findings:

- **CRITICAL**: Violates constitution MUST, missing core spec artifact, or requirement with zero coverage that blocks baseline functionality
- **HIGH**: Duplicate or conflicting requirement, ambiguous security/performance attribute, untestable acceptance criterion
- **MEDIUM**: Terminology drift, missing non-functional task coverage, underspecified edge case
- **LOW**: Style/wording improvements, minor redundancy not affecting execution order

### 6. Produce Compact Analysis Report

Output a Markdown report (no file writes) with the following structure:

## Specification Analysis Report

| ID | Category | Severity | Location(s) | Summary | Recommendation |
|----|----------|----------|-------------|---------|----------------|
| A1 | Duplication | HIGH | spec.md:L120-134 | Two similar requirements ... | Merge phrasing; keep clearer version |

(Add one row per finding; generate stable IDs prefixed by category initial.)

**Coverage Summary Table:**

| Requirement Key | Has Task? | Task IDs | Notes |
|-----------------|-----------|----------|-------|

**Constitution Alignment Issues:** (if any)

**Unmapped Tasks:** (if any)

**Metrics:**

- Total Requirements
- Total Tasks
- Coverage % (requirements with >=1 task)
- Ambiguity Count
- Duplication Count
- Critical Issues Count

### 7. Migration Parity Validation (MIGRATION ONLY)

**Execute this section ONLY if the feature is a migration** (detected by: `source-audit.md` exists in FEATURE_DIR, or spec.md contains `[MIGRATION]` tags or "Source Parity Matrix" section).

#### A. Load Source Audit

Read `source-audit.md` from FEATURE_DIR. If it doesn't exist, flag as CRITICAL: "Migration detected but no source-audit.md found. Run `/speckit.migrate` to generate source audit (or produce it manually if no such command exists for your source stack)."

#### B. Source → Target Coverage Matrix

For every item in the source audit, verify it has coverage in spec.md and tasks.md:

**Entry Points / Functions Coverage:**

| Source Entry Point | In Spec? | In Tasks? | Task ID | Gap? |
|--------------------|----------|-----------|---------|------|
| [function/method from source] | ✅/❌ | ✅/❌ | TXXX | —/MISSING |

**API/External Calls Coverage:**

| Endpoint/Call | In Spec? | In Tasks? | Task ID | Gap? |
|---------------|----------|-----------|---------|------|
| [endpoint from source-audit] | ✅/❌ | ✅/❌ | TXXX | —/MISSING |

**UI/Presentation Coverage** (if applicable):

| Source UI Element | In Tasks? | Target Equivalent Specified? | Gap? |
|-------------------|-----------|-------------------------------|------|
| [widget/component from source] | ✅/❌ | [target equivalent] | —/MISSING |

**Event/Message Coverage:**

| Event/Message | In Spec? | In Tasks? | Target Pattern Specified? | Gap? |
|---------------|----------|-----------|---------------------------|------|
| [event from source-audit] | ✅/❌ | ✅/❌ | [target pattern] | —/MISSING |

**Service/Dependency Coverage:**

| Service | Target Equivalent Exists? | In Tasks? | Gap? |
|---------|---------------------------|-----------|------|
| [service from source-audit] | ✅/❌ | ✅/❌ | —/MISSING |

#### C. API Contract Preservation Check (BLOCKING)

**Execute this section for EVERY migration with API/external calls in source-audit.md.**

For each endpoint/call documented in source-audit.md:

1. **Verify exact payload shape is documented**: Check that source-audit.md includes the exact field names, types, and formats for the request payload. If types are missing, flag as CRITICAL: "API request payload types not documented — exact types (number vs string, date format, nullability) required"

2. **Verify tasks include contract verification**: For each endpoint, check that tasks.md includes:
   - A task that implements the call matching the exact endpoint
   - A verification step or test task confirming request/response payload field-by-field parity
   - If missing: flag as CRITICAL — "No API contract verification task for endpoint [X]"

3. **Check for common type coercion risks**:
   - Date fields: check if date serialization format is documented in source audit
   - Number fields: check that source audit distinguishes number from string types
   - Null/empty handling: check if nullable vs empty-string behavior is documented
   - Collections / arrays: check that the wire encoding (CSV, repeated keys, JSON array, etc.) is documented
   - If risks not addressed in tasks: flag as HIGH

| Endpoint | Payload Documented? | Types Explicit? | Task Has Verification? | Risk |
|----------|--------------------:|:---------------:|:----------------------:|------|
| [endpoint] | ✅/❌ | ✅/❌ | ✅ T0XX / ❌ | CRITICAL/HIGH/OK |

#### C2. Error Handling Preservation Check (BLOCKING)

**Execute this section for EVERY migration whose source-audit.md contains an "Error Handling Inventory".**

For each entry in the Error Handling Inventory:

1. **Verify target error pattern is documented** in source-audit.md. If missing, flag as HIGH: "Target error pattern not specified for [endpoint] — explicit strategy per call required"

2. **Verify tasks include error-handling implementation**: For each inventory entry, check that tasks.md includes:
   - A task that implements explicit error handling (not silent swallowing; strategy: "catch and replace with typed fallback" OR "catch and rethrow as formatted error")
   - For long-lived streams in reactive stacks: confirms the handler is placed on the inner observable inside flattening operators (not on the outer pipeline)
   - For idempotent reads flagged as flaky: includes retry with explicit count and delay
   - Error-path unit tests asserting the documented user-facing effect
   - If any are missing: flag as CRITICAL — "Error handling task missing for [endpoint] — will drop source-system behavior"

3. **Flag non-idempotent retry**: If tasks.md applies retry to a non-idempotent call (POST/PUT/DELETE), flag as CRITICAL — "Retry on non-idempotent call [endpoint] risks duplicate writes"

4. **Flag silent drops**: If an inventory entry has an existing behavior (toast, banner, fallback) but no corresponding task preserves it, flag as CRITICAL — "Error handler silently dropped for [endpoint]"

| Inventory Entry | Target Pattern Documented? | Task Preserves Behavior? | Retry Idempotent? | Risk |
|-----------------|---------------------------:|:------------------------:|:-----------------:|------|
| [endpoint] | ✅/❌ | ✅ T0XX / ❌ | N/A | CRITICAL/HIGH/OK |

#### D. Severity for Parity Gaps

- **CRITICAL**: API endpoint missing from tasks (functionality will be lost)
- **CRITICAL**: API request payload types not documented in source audit
- **CRITICAL**: No contract verification task for API endpoint
- **CRITICAL**: Error handler from inventory silently dropped
- **CRITICAL**: Retry applied to non-idempotent call
- **CRITICAL**: Event/message handler missing (communication broken)
- **HIGH**: API request type coercion risk not addressed in tasks
- **HIGH**: Target error pattern not specified in source audit
- **HIGH**: UI element not mapped (presentation gap)
- **HIGH**: Reactive/event behavior not mapped (behavior lost)
- **MEDIUM**: Formatting/display pattern not mapped
- **LOW**: Trivial utility not mapped (easy to add later)

#### D. Parity Summary

```
Migration Parity: [N/M] features covered ([X]%)

CRITICAL gaps: [N] — functionality will be lost
HIGH gaps: [N] — significant behavior differences
MEDIUM gaps: [N] — minor display/formatting issues
LOW gaps: [N] — trivial to add later

[If < 100%]: ⚠️ MIGRATION INCOMPLETE — resolve gaps before implementation
[If 100%]: ✅ Full parity achieved
```

#### E. Business Rule Coverage Analysis

**Execute this section ONLY if source-audit.md contains a "Business Rules Extract" section.**

This goes beyond structural parity (Section A-D) to verify that documented business logic has spec coverage and test coverage.

1. **Parse Business Rules Extract** from source-audit.md. Extract each rule with its method and description.

2. **For each documented business rule**, check:
   - **Spec coverage**: Is this rule reflected in spec.md acceptance criteria or functional requirements?
   - **Task coverage**: Is there a task in tasks.md that explicitly implements this rule?
   - **Test coverage**: Is there a task in tasks.md that explicitly tests this rule (or does the implementing task include test criteria)?

3. **Produce Business Rule Coverage Table:**

   | Rule ID | Source Location | Rule Description | In Spec? | In Tasks? | Has Test? | Gap? |
   |---------|-----------------|------------------|----------|-----------|-----------|------|
   | BL-001 | (source-file:line) | (rule description) | ✅ FR-005 | ✅ T012 | ✅ T012 | — |
   | BL-002 | (source-file:line) | (rule description) | ❌ | ❌ | ❌ | CRITICAL |
   | BL-003 | (source-file:line) | (rule description) | ✅ US2-AC3 | ✅ T018 | ❌ | HIGH — no test |

4. **Severity for Business Rule Gaps:**
   - **CRITICAL**: Rule not in spec AND not in tasks — logic WILL be lost
   - **HIGH**: Rule in spec but no explicit task or test — logic may be lost during implementation
   - **MEDIUM**: Rule has task but no test — logic may be correct but unverified
   - **LOW**: Rule has task and test but missing from spec acceptance criteria — covered but not formally specified

5. **Business Rule Coverage Summary:**
   ```
   Business Rule Coverage: [N/M] rules fully covered (X%)
   - Rules with spec + task + test: [N] (fully covered)
   - Rules with task but no test: [N] (HIGH risk — untested)
   - Rules missing from tasks: [N] (CRITICAL — will be lost)
   
   [If any CRITICAL]: ⚠️ BUSINESS LOGIC AT RISK — update spec/tasks before implementation
   [If all covered]: ✅ All business rules have implementation and test coverage
   ```

6. **Check Reactive Chains** (if "Reactive Chains" section exists in source-audit.md):
   - For each documented reactive chain, verify there's a task that implements the full chain
   - Flag any chain where only partial steps are covered by tasks

7. **Check Event Cascades** (if "Event Cascade Map" section exists):
   - For each documented event with multiple listeners, verify ALL listener effects have tasks
   - Flag any listener effect that has no corresponding task

### 8. Write Analysis Status File (GATE ENFORCEMENT)

**ALWAYS write a status file** to `FEATURE_DIR/analyze-status.json` recording the analysis outcome:

```json
{
  "analyzedAt": "[ISO 8601 timestamp]",
  "criticalIssues": [number],
  "highIssues": [number],
  "mediumIssues": [number],
  "lowIssues": [number],
  "totalRequirements": [number],
  "totalTasks": [number],
  "coveragePercent": [number],
  "migrationParityCoverage": [number or null if not migration],
  "businessRuleCoverage": [number or null if no Business Rules Extract],
  "businessRulesTotal": [number or null],
  "businessRulesCriticalGaps": [number or null],
  "status": "PASS" | "FAIL",
  "blockers": ["list of critical issue IDs"]
}
```

**Status rules:**
- **PASS**: Zero CRITICAL issues AND (if migration) parity coverage ≥ 95% AND (if Business Rules Extract exists) business rule coverage ≥ 95%
- **FAIL**: Any CRITICAL issues OR (if migration) parity coverage < 95% OR (if Business Rules Extract exists) business rule coverage < 95%

This file is read by `/speckit.implement` as a **blocking gate**. Implementation will not proceed if status is FAIL.

### 9. Provide Next Actions

At end of report, output a concise Next Actions block:

- If CRITICAL issues exist: **BLOCKING** — Recommend resolving before `/speckit.implement`. List each critical issue with specific remediation.
- If migration parity < 95%: **BLOCKING** — List every unmapped source feature and which artifact (spec.md or tasks.md) needs updating.
- If only LOW/MEDIUM: User may proceed, but provide improvement suggestions
- Provide explicit command suggestions: e.g., "Run /speckit.specify with refinement", "Run /speckit.plan to adjust architecture", "Manually edit tasks.md to add coverage for 'performance-metrics'"
- **Always state**: "Analysis status written to [path]. /speckit.implement will check this gate."

### 10. Offer Remediation

Ask the user: "Would you like me to suggest concrete remediation edits for the top N issues?" (Do NOT apply them automatically.)

## Operating Principles

### Context Efficiency

- **Minimal high-signal tokens**: Focus on actionable findings, not exhaustive documentation
- **Progressive disclosure**: Load artifacts incrementally; don't dump all content into analysis
- **Token-efficient output**: Limit findings table to 50 rows; summarize overflow
- **Deterministic results**: Rerunning without changes should produce consistent IDs and counts

### Analysis Guidelines

- **NEVER modify files** (this is read-only analysis)
- **NEVER hallucinate missing sections** (if absent, report them accurately)
- **Prioritize constitution violations** (these are always CRITICAL)
- **Use examples over exhaustive rules** (cite specific instances, not generic patterns)
- **Report zero issues gracefully** (emit success report with coverage statistics)

## Context

$ARGUMENTS
