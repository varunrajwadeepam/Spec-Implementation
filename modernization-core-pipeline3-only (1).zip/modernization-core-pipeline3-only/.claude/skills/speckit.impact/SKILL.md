# speckit.impact

Analyze the impact of changes to shared code (interfaces, components, services) before implementation begins.

## Usage

```
/speckit.impact
```

Invoke after `/speckit.plan` when the feature modifies shared code or interfaces.

## What it does

Performs comprehensive impact analysis for changes to shared code across 10 dimensions:

1. **Change Summary** - What's being changed and why
2. **Affected Files** - All files being directly modified
3. **Dependency Discovery** - All consumers of changed items (via codebase search)
4. **Breaking Change Analysis** - Contract changes with OLD vs NEW comparison
5. **Migration Path** - Concrete code-level instructions for all consumers
6. **Regression Risk Assessment** - Risk rating per changed item with justification
7. **Test Coverage Plan** - Existing tests, new tests required, QA scenarios
8. **Deployment Impact** - Build, deployment sequence, rollback plan
9. **Constitutional Compliance** - Verify change aligns with Constitution principles
10. **Sign-off Requirements** - Reviewer approval needed before implementation

**Pass threshold**: All HIGH-severity breaking changes have migration paths defined

## Outputs

Generates `impact-analysis.md` in the feature directory with:
- Executive summary with risk level (HIGH/MEDIUM/LOW)
- Current state vs target state comparison
- Complete consumer inventory (via grep/glob searches)
- Breaking change catalog with severity ratings
- Migration instructions for each consumer
- Regression risk assessment
- Test coverage requirements
- Rollback plan
- Approval status

**Risk levels**:
- **HIGH**: Widely used interface/component on critical path → Second reviewer + QA sign-off required
- **MEDIUM**: Used in several places, non-critical path → Standard review sufficient
- **LOW**: Single consumer or internal-only change → Standard review sufficient

## When to use

**MANDATORY** (per Constitution XIII):
- ✅ Modifying a shared interface, abstract base, or contract type
- ✅ Changing a component / module used across multiple features
- ✅ Updating a shared service, helper, pipe/filter, directive, middleware, or interceptor
- ✅ Modifying global-state structure (store shape, action payloads, reducers, selectors, effects)
- ✅ Changing routes, guards, resolvers
- ✅ Updating third-party dependencies (any breaking version bump)
- ✅ Any change affecting a cross-system integration point or an interop / bridge layer between two stacks
- ✅ Any change crossing a deployment boundary (separately released artifact / service / library)

**OPTIONAL**:
- ❌ New features with no shared code impact
- ❌ Isolated component changes (single consumer)
- ❌ Test-only changes
- ❌ Documentation updates

## Example workflow

```bash
# 1. Specify feature
/speckit.specify STORY-{portfolio}-MU-XX-YY-ZZZ "feature description"

# 2. Clarify ambiguities
/speckit.clarify

# 3. Create technical plan (plan.md declares the stack)
/speckit.plan

# 4. Impact analysis (you are here) — MANDATORY if shared code changed
/speckit.impact

# 5. Generate tasks (only after impact approved)
/speckit.tasks

# 6. Implement
/speckit.implement
```

## What gets analyzed

**Shared Code Types** (substitute the equivalent in your stack — declared in plan.md):
- Shared interfaces / abstract base types
- Published service contracts (WSDL, OpenAPI, gRPC, GraphQL, message schema)
- Serialized data contracts / DTOs / schemas
- Shared UI components / modules (used in multiple features)
- Shared services (injected / consumed across modules)
- Pipes / filters / directives / guards / resolvers / middleware / interceptors
- Global-state structure (store shape, action / event payloads)
- Cross-system integration points and interop / bridge layer items (units exposed across two stacks)
- Third-party dependencies in the project's package manifest

**Analysis Methods**:
1. **Grep / Glob search**: Find all imports, usages, references — using patterns appropriate to the source tree declared in plan.md
2. **Wire-contract analysis**: Identify external clients consuming a published service contract (SOAP/REST/gRPC)
3. **Test discovery**: Find tests covering changed code
4. **Architecture review**: Verify Clean Architecture layer compliance
5. **Constitution check**: Ensure change aligns with principles (loaded from `portfolios/{portfolio}/specs/constitution.md`)

## Breaking Change Severity

- **🔴 Compile-time / static-analysis**: Compiler / type-checker / linter error; build fails without consumer updates
- **🟠 Runtime**: Builds but throws at runtime
- **🟡 Behavioral**: Builds and runs but produces different output / behavior

## Analysis Principles

1. **Evidence-Based** - All consumers found via actual codebase search (grep / glob)
2. **Complete** - Every consumer must have a migration path defined
3. **Actionable** - Migration instructions are code-level, not conceptual
4. **Risk-Proportional** - Risk ratings justify why HIGH / MEDIUM / LOW
5. **Reviewable** - Document includes search commands used (reproducible)
6. **Stack-Agnostic** - Concrete identifiers, paths, and tool names come from plan.md, not from any hard-coded stack

## Output Structure

```markdown
# Impact Analysis: [Feature Name]

## Executive Summary
- Change type, breaking change (Y/N), risk level, recommendation

## Current State Analysis
- What exists now, how it works, who uses it

## Proposed Change
- What changes, what doesn't change

## Dependency Analysis
- All consumers (via grep / glob), grouped by type

## Breaking Change Analysis (if any)
- BC-001: [Description] — Severity, OLD vs NEW, consumers affected

## Migration Path
- Code-level instructions for each consumer

## Risk Assessment
- Risk level per changed item, justification, overall risk

## Test Coverage Plan
- Existing tests, new tests, QA scenarios

## Deployment Impact
- Build impact, deployment sequence, rollback plan

## Constitutional Compliance
- Verify alignment with Constitution principles

## Approval
- Sign-off section (HIGH risk → second reviewer + QA)
```

## Notes

- Impact analysis is **preventative** — catches issues before implementation begins
- For HIGH-risk changes, second-reviewer approval is required before `/speckit.tasks`
- All grep / glob commands must be documented for reproducibility
- Migration paths must be concrete code examples (not "update consumers")
- For published service contracts (WSDL / OpenAPI / gRPC / GraphQL / message schema), analyze wire-format compatibility — additive changes are usually safe, removing / renaming is breaking
- Constitution XIII requires impact analysis for shared code — non-compliance blocks PR
