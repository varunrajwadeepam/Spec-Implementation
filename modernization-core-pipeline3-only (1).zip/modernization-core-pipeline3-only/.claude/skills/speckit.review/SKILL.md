# speckit.review

Review completed implementation for quality, correctness, and compliance.

## Usage

```
/speckit.review
```

Invoke after `/speckit.implement` completes to perform comprehensive quality review.

## What it does

Performs automated quality review of the completed implementation across 7 dimensions:

1. **Specification Compliance** (25 pts) - All user stories and functional requirements implemented
2. **Test Coverage** (20 pts) - Unit tests for all public methods with ≥80% coverage
3. **Code Quality** (20 pts) - Clean, readable code with documentation
4. **Architecture & Design** (15 pts) - Clean Architecture and design patterns
5. **Constitution Compliance** (10 pts) - All 7 Constitution principles verified
6. **Error Handling** (5 pts) - Proper exception handling and logging
7. **Performance** (5 pts) - Performance targets met, efficient algorithms

**Pass threshold**: ≥70/100

## Outputs

Generates `review-report.md` in the feature directory with:
- Overall score and approval status
- Dimension-by-dimension scoring
- Strengths (what's done well)
- Issues by severity (Critical/Major/Minor/Info)
- Actionable recommendations
- Constitution compliance table
- Test coverage summary
- Files reviewed

**Approval statuses**:
- **90-100 pts**: APPROVED - Ready for pull request
- **70-89 pts**: APPROVED WITH RECOMMENDATIONS - Can proceed with minor fixes
- **< 70 pts**: CHANGES REQUIRED - Fix critical/major issues before PR

## When to use

- ✅ After `/speckit.implement` completes all tasks
- ✅ Before creating pull request
- ✅ After major refactoring or changes
- ✅ When implementation quality verification needed

## Example workflow

```bash
# 1. Specify feature
/speckit.specify STORY-{portfolio}-MU-XX-YY-ZZZ "feature description"

# 2. Clarify ambiguities
/speckit.clarify

# 3. Create technical plan
/speckit.plan

# 4. Implement
/speckit.implement

# 5. Review (you are here)
/speckit.review

# 6. Create PR if approved
git push origin {story-id}
```

## What gets reviewed

**Design Documents**:
- spec.md - Feature specification
- plan.md - Technical implementation plan  
- tasks.md - Task breakdown
- research.md - Design decisions
- data-model.md - Entity definitions
- contracts/ - Interface contracts
- source-audit.md - Source system mapping (migrations only)

**Implementation Files**:
- All files referenced in tasks.md
- Test files for coverage analysis
- Build output for warnings/errors

**Quality Checks**:
- User stories vs implemented features
- Functional requirements coverage
- Test coverage and quality
- Code quality (naming, documentation, complexity)
- Architecture patterns
- Constitution principles (from `portfolios/{portfolio}/specs/constitution.md`)
- Source traceability (if migration)
- Error handling
- Performance benchmarks

## Review Principles

1. **Objective** - Measurable criteria, not subjective preferences
2. **Constructive** - Issues framed as improvement opportunities
3. **Evidence-Based** - Every finding references specific code
4. **Actionable** - Recommendations are specific and implementable
5. **Proportional** - Severity matches actual impact

## Issue Severity

- **Critical**: Blocks deployment, violates Constitution, security vulnerability, data loss risk
- **Major**: Functional defect, missing key feature, poor performance, inadequate tests
- **Minor**: Code smell, missing documentation, style violation
- **Info**: Observation, suggestion for future enhancement

## Notes

- Automated review complements (doesn't replace) human code review
- Focus is on implemented code vs specification, not future enhancements
- For migrations, source-system parity is mandatory - missing features are Critical
- Constitution principle violations result in automatic score penalties
