# speckit.orchestrate Quick Reference

## Single Command Usage

```bash
/speckit.orchestrate STORY-ACME-CORE-MU-01-01-001
```

That's it! The skill will:

1. **Auto-detect portfolio** from story ID → `ACME-CORE`
2. **Create folder** → `portfolios/ACME-CORE/specs/STORY-ACME-CORE-MU-01-01-001/`
3. **Run workflow** → specify → clarify → plan → tasks → analyze → implement → review

## How Portfolio Detection Works

| Story ID | Extracted Portfolio |
|----------|-------------------|
| `STORY-ACME-CORE-MU-01-01-001` | `ACME-CORE` |
| `STORY-UWR-POC-MU-02-03-004` | `UWR-POC` |
| `STORY-REFDB-X12-MU-01-01-001` | `REFDB-X12` |

**Pattern**: `STORY-{PORTFOLIO}-MU-{wave}-{mu}-{story}`

The regex captures everything between `STORY-` and `-MU-`, supporting:
- Single segment: `NPW`, `UWR`, `REFDB`
- Hyphenated: `ACME-CORE`, `UWR-POC`, `REFDB-X12`

## Override Portfolio (Optional)

```bash
/speckit.orchestrate STORY-ACME-CORE-MU-01-01-001 portfolio=CUSTOM-NAME
```

## What Gets Created

```
portfolios/ACME-CORE/specs/STORY-ACME-CORE-MU-01-01-001/
├── spec.md              ← Feature specification (from story doc)
├── plan.md              ← Technical implementation plan
├── tasks.md             ← Dependency-ordered task list
├── research.md          ← Design decisions and ADRs
├── data-model.md        ← Entity and database schema
├── review-report.md     ← Quality review (≥70/100 to pass)
├── checklists/
│   └── requirements.md
└── contracts/
    └── *.md             ← Interface contracts
```

## Workflow Steps

| Step | Skill | Output | Purpose |
|------|-------|--------|---------|
| 1 | `/speckit.specify` | `spec.md` | Generate feature specification from story |
| 2 | `/speckit.clarify` | Updated `spec.md` | Identify and resolve ambiguities |
| 3 | `/speckit.plan` | `plan.md`, `research.md` | Create technical implementation plan |
| 4 | `/speckit.tasks` | `tasks.md` | Generate dependency-ordered task list |
| 5 | `/speckit.analyze` | Analysis notes | Non-destructive cross-artifact consistency and quality analysis across spec.md, plan.md, tasks.md |
| 6 | `/speckit.implement` | Code files | Execute all tasks from tasks.md |
| 7 | `/speckit.review` | `review-report.md` | Quality validation (7 dimensions) |

## Prerequisites

- ✅ Story exists in `portfolios/{portfolio}/docs/epics/{MU-ID}/{EPIC-ID}/{story-id}.md`
- ✅ Git branch matches story ID (recommended): `git checkout -b STORY-ACME-CORE-MU-01-01-001`
- ✅ `.env` contains `PORTFOLIO_NAME={portfolio}` (fallback if extraction fails)

## Common Use Cases

### Standard workflow (most common)
```bash
git checkout -b STORY-ACME-CORE-MU-01-01-001
/speckit.orchestrate STORY-ACME-CORE-MU-01-01-001
# Review generates report, fix any issues if score < 70
git add . && git commit -m "feat(ACME-CORE): implement feature X"
```

### Resume after interruption
```bash
cd portfolios/ACME-CORE/specs/STORY-ACME-CORE-MU-01-01-001
/speckit.tasks      # Re-run from specific step
/speckit.implement
```

### Re-run quality review only
```bash
cd portfolios/ACME-CORE/specs/STORY-ACME-CORE-MU-01-01-001
/speckit.review
```

## Troubleshooting

| Issue | Cause | Fix |
|-------|-------|-----|
| "Cannot detect portfolio" | Story ID format wrong | Use format: `STORY-{PORTFOLIO}-MU-{wave}-{mu}-{story}` |
| "Story not found" | Story doesn't exist | This repo no longer generates EPICs/stories — obtain the story file from the portfolio pack's `docs/epics/{MU-ID}/` first |
| Files in wrong location | Didn't use orchestrate skill | Use `/speckit.orchestrate`, not individual skills |
| Review score < 70 | Quality issues | Read `review-report.md`, fix issues, re-run `/speckit.review` |

## Related Skills

- `/speckit.*` - Individual workflow steps (for manual control)

## Technical Implementation

When invoked, Claude executes:

```bash
# 1. Extract portfolio from story ID
PORTFOLIO=$(echo "STORY-ACME-CORE-MU-01-01-001" | sed -E 's/^STORY-([^-]+-[^-]+)-MU-.*/\1/')

# 2. Create portfolio-scoped directory
mkdir -p "specs/$PORTFOLIO/STORY-ACME-CORE-MU-01-01-001"

# 3. Change to that directory
cd "specs/$PORTFOLIO/STORY-ACME-CORE-MU-01-01-001"

# 4. Run speckit workflow from that location
# (speckit skills create files relative to current directory)
```

This ensures all speckit-generated files land in `portfolios/{portfolio}/specs/{story-id}/`.
