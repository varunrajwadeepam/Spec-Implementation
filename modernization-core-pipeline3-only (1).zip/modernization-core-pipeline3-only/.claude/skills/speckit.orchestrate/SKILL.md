# speckit.orchestrate

Portfolio-aware orchestration of the complete speckit implementation workflow.

## Usage

```bash
# Automatic portfolio detection from story ID
/speckit.orchestrate STORY-ACME-CORE-MU-01-01-001

# Explicit portfolio (REQUIRED when story ID doesn't embed portfolio)
/speckit.orchestrate STORY-MU-ACMEREF-SUBSET-01-02-001 portfolio=ACME-REF-subset
```

## What it does

Orchestrates the complete implementation workflow with automatic portfolio-scoped folder creation:

1. **Detect Portfolio** - Extract from story ID pattern `STORY-{PORTFOLIO}-...` or read from `.env`
2. **Setup Directories** - Create `portfolios/{portfolio}/specs/{story-id}/` (spec artifacts) and ensure `portfolios/{portfolio}/POC/` exists (implementation output)
3. **Run Workflow** - Execute speckit pipeline in correct location:
   - `/speckit.specify` - Generate spec.md from story document
   - `/speckit.clarify` - Identify and resolve ambiguities  
   - `/speckit.plan` - Create technical implementation plan
   - `/speckit.tasks` - Generate dependency-ordered tasks
   - `/speckit.analyze` - Non-destructive cross-artifact consistency and quality analysis across spec.md, plan.md, and tasks.md
   - `/speckit.implement` - Execute all tasks
   - `/speckit.review` - Quality validation

## Portfolio Detection

Portfolio is resolved **once** at the start, in this precedence order:

1. **Explicit parameter**: `portfolio=ACME-REF-subset` in command (highest priority)
2. **Story ID pattern**: If ID matches `STORY-{PORTFOLIO}-MU-{d}-{d}-{d}`, extract portfolio segment
3. **Environment file**: Read `PORTFOLIO_NAME` from project-root `.env`
4. **Error if none found**: Stop and ask the user

Once resolved, the portfolio value is used for all path lookups in this run.

### Story ID Pattern Matching

| Story ID Pattern | Extracted Portfolio |
|------------------|-------------------|
| `STORY-ACME-CORE-MU-01-01-001` | `ACME-CORE` |
| `STORY-UWR-POC-MU-02-03-004` | `UWR-POC` |
| `STORY-REFDB-X12-MU-01-01-001` | `REFDB-X12` |

Pattern (case-insensitive): `STORY-{PORTFOLIO}-MU-{digits}-{digits}-{digits}`

**Important**: Some portfolios use Story IDs that do NOT embed the portfolio name (e.g., `STORY-MU-ACMEREF-SUBSET-01-02-001`). For these, the explicit `portfolio=` parameter or `.env` is required — pattern extraction will not work.

## Folder Structure Created

All artifacts are created in `portfolios/{portfolio}/specs/{story-id}/`:

```
portfolios/{portfolio}/specs/{story-id}/
├── spec.md              # Feature specification
├── plan.md              # Technical implementation plan
├── tasks.md             # Dependency-ordered task list
├── research.md          # Design decisions and ADRs
├── data-model.md        # Entity and database schema
├── review-report.md     # Quality review results
├── checklists/
│   └── requirements.md  # Requirements checklist
└── contracts/
    └── *.md             # Interface contracts
```

## Prerequisites

- Story must exist in `portfolios/{portfolio}/docs/epics/{MU-ID}/{EPIC-ID}/{story-id}.md`
- Portfolio must be resolvable (explicit parameter, Story ID pattern, or `.env`)
- **Do NOT pre-create the story branch.** `/speckit.specify` (step 0e) checks out the base branch (the portfolio integration branch, e.g., `ACME-CORE`) and then cuts the new story branch from it. Pre-creating the branch yourself causes the orchestrator to abort with "branch already exists".
- The working tree MUST be clean before invoking (no uncommitted edits, no untracked files). The sync step refuses to run on a dirty tree and will not auto-stash.

## Implementation Steps

When this skill is invoked, Claude will:

1. **Resolve portfolio** using the precedence order in "Portfolio Detection" above
2. **Validate portfolio** — confirm `portfolios/{portfolio}/docs/epics/` exists
3. **Resolve the base branch** (the portfolio integration branch — typically `ACME-CORE`, `UWR-POC`, etc., or `main` if none). Order of precedence:
   1. Explicit `base=<branch>` argument on the command.
   2. `SPECKIT_BASE_BRANCH=<branch>` in `.env`.
   3. The portfolio's integration branch if it matches the portfolio name (e.g., `ACME-CORE` for portfolio `ACME-CORE`).
   4. Default `main`.
4. **Verify clean working tree.** `git status --porcelain` MUST be empty. If dirty, abort.
5. **Check out the base branch** (`git checkout <base>` + `git pull origin <base> --ff-only`) so the new story branch is cut from the right place. This step is delegated to `/speckit.specify` step 0e but the orchestrator confirms `HEAD` is on the base branch before delegating.
6. **Create directory**: `mkdir -p portfolios/{portfolio}/specs/{story-id}`
7. **Change working directory**: `cd portfolios/{portfolio}/specs/{story-id}`
8. **Run speckit workflow** from that directory:
   - `/speckit.specify` will create the story branch from the base (step 0e + step 2d of the speckit.specify agent).
   - Each speckit skill runs in the portfolio-scoped folder.
   - Files are created in the correct location automatically.
   - Working directory context ensures proper scoping.

## Example Execution

```bash
# User runs (portfolio embedded in story ID):
/speckit.orchestrate STORY-ACME-CORE-MU-01-01-001

# User runs (portfolio explicit — required when ID doesn't embed it):
/speckit.orchestrate STORY-MU-ACMEREF-SUBSET-01-02-001 portfolio=ACME-REF-subset

# Claude executes:
# 1. Resolve portfolio (explicit > story ID > .env > error)
# 2. Resolve base branch (base= arg > SPECKIT_BASE_BRANCH > portfolio integration branch > main)
# 3. Verify clean tree; abort if dirty
# 4. git checkout <base> && git pull origin <base> --ff-only
# 5. mkdir -p portfolios/{portfolio}/specs/{story-id}
# 6. cd portfolios/{portfolio}/specs/{story-id}
# 7. /speckit.specify (creates and checks out the story branch)
# 8. /speckit.clarify
# 9. /speckit.plan
# 10. /speckit.tasks
# 11. /speckit.analyze
# 12. /speckit.implement
# 13. /speckit.review
```

### Branch behavior

The new story branch (`STORY-ACME-CORE-MU-01-01-001` in the example above) is created by `/speckit.specify`, not by `/speckit.orchestrate` directly. The orchestrator's responsibility is to put `HEAD` on the correct base before delegating. If the user is already on a different story branch when invoking `/speckit.orchestrate` (a common mid-stream case), the orchestrator switches to the base branch first so the new story branch does not inherit the prior story's commits.

## Quality Gates

- **Spec clarity**: No ambiguities or underspecified areas (clarify step resolves)
- **Plan completeness**: All design decisions documented with ADRs
- **Task actionability**: All tasks have clear acceptance criteria
- **Implementation quality**: ≥70/100 on review score
- **Constitution compliance**: All 7 principles verified

## Error Handling

| Error | Cause | Resolution |
|-------|-------|------------|
| "Cannot detect portfolio" | Story ID doesn't match pattern and no .env | Add `portfolio=` parameter or fix story ID format |
| "Story not found" | Story doesn't exist in docs/ | This repo no longer generates EPICs/stories — obtain the story file from the portfolio pack's `docs/epics/{MU-ID}/` first |
| "Working tree has uncommitted changes" | Dirty tree at invocation time | Commit or stash before re-running; the orchestrator never auto-stashes |
| "Cannot resolve base branch" | No `base=` arg, no `.env`, and no integration branch matching the portfolio | Pass `base=<branch>` explicitly, or set `SPECKIT_BASE_BRANCH` in `.env` |
| "Base branch has diverged from origin" | Local base branch ahead of remote (non-fast-forward) | Reconcile manually (rebase, reset, or merge) before re-running |
| "Branch already exists" | Story branch was pre-created or a prior run partially completed | Delete the partial branch (`git branch -D <story-id>`) or use the existing branch directly without re-running orchestrate |
| "Review score < 70" | Implementation quality issues | Fix issues in review-report.md and re-run /speckit.review |

## Related Skills

- Individual `/speckit.*` skills for manual workflow steps

## Notes

- Working directory changes are scoped to the skill execution
- After skill completes, working directory returns to project root
- Portfolio detection is deterministic and reproducible
- Folder structure is created automatically - no manual setup needed
- Built-in speckit skills work correctly when run from portfolio-scoped folder
