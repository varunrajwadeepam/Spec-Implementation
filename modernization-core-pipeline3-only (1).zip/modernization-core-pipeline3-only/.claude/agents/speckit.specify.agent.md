---
description: Create or update the feature specification from a natural language feature description.
handoffs: 
  - label: Build Technical Plan
    agent: speckit.plan
    prompt: Create a plan for the spec. I am building with...
  - label: Clarify Spec Requirements
    agent: speckit.clarify
    prompt: Clarify specification requirements
    send: true
---

## User Input

```text
$ARGUMENTS
```

You **MUST** consider the user input before proceeding (if not empty).

## Outline

The text the user typed after `/speckit.specify` in the triggering message **is** the feature description. Assume you always have it available in this conversation even if `$ARGUMENTS` appears literally below. Do not ask the user to repeat it unless they provided an empty command.

Given that feature description, do this:

0. **Sync the local working tree with the remote** (MUST run before any other step):

   a. **Verify the working tree is clean.** Run `git status --porcelain`. If the output is non-empty, **abort immediately** and tell the user:

      > Working tree has uncommitted changes. Commit or stash them before re-running `/speckit.specify`, so that the sync step cannot silently move or overwrite work. Listed below are the dirty paths:
      >
      > `<paste the `git status --porcelain` output>`

      Do NOT proceed to step 0b on a dirty tree. Do NOT auto-stash. Do NOT run any other step.

   b. **Fetch the latest remote state**:

      ```bash
      git fetch --all --prune
      ```

   c. **Fast-forward the current branch from its tracking branch**:

      - Determine the current branch: `git branch --show-current`
      - Check that the current branch has an upstream tracking branch: `git rev-parse --abbrev-ref --symbolic-full-name @{u}` (if this fails with `no upstream configured`, skip the pull — there is no remote state to fast-forward from — and continue to step 1).
      - If an upstream exists, pull from origin (fast-forward only):

        ```bash
        git pull origin --ff-only
        ```

      - If `git pull origin --ff-only` fails with a non-fast-forward error (local has diverged from remote), **abort** and tell the user:

        > Local branch `<branch>` has diverged from `origin/<branch>`. The sync step refuses to merge or rebase automatically — resolve the divergence manually (`git rebase`, `git reset --hard origin/<branch>`, or your own choice) before re-running `/speckit.specify`.

      - Do NOT touch `main` or any other branch. Do NOT rebase. Do NOT force-push. The sync step only pulls the current branch from its own remote tracking branch.

   d. **Confirm sync result** to the user in one short line, e.g.:

      > Sync: fetched from origin; `<branch>` fast-forwarded `<N>` commits (or `already up-to-date`).

   e. **Switch to the base branch before the new story branch is cut.** The new story branch MUST be cut from the project's *base branch* (typically the portfolio integration branch — e.g., `ACME-CORE`), NOT from whatever story branch happens to be checked out. Without this step, a new story branch silently inherits unrelated commits from the prior story.

      - Resolve the base branch in this order:
        1. Explicit `base=<branch-name>` argument on the user command (e.g., `/speckit.specify STORY-... base=ACME-CORE`).
        2. `SPECKIT_BASE_BRANCH=<branch-name>` line in the repo-root `.env` file.
        3. The most recent ancestor branch in the project's recent `git log` (e.g., the portfolio integration branch).
        4. Default to `main` if none of the above resolve.
      - If `git branch --show-current` does NOT already equal the resolved base branch:
        - Verify the working tree is still clean (`git status --porcelain` empty). If dirty, abort per step 0a's rule.
        - `git checkout <base-branch>` then `git pull origin <base-branch> --ff-only` (only if the base branch has an upstream).
      - Confirm to the user in one short line:

        > Base branch: `<base-branch>` (checked out + fast-forwarded). New story branch will be cut from here.

      - If the resolution chose a base branch that doesn't exist locally or on the remote, **abort** and ask the user to clarify which base branch to use.

   Only after step 0 completes successfully may you proceed to step 1.

1. **Extract the feature name from user input**:
   - The user MUST provide a feature name in one of these formats:
     - Story ID: `STORY-{PORTFOLIO}-MU-XX-YY-ZZZ` (e.g., `STORY-ACME-CORE-MU-00-01-004`, `STORY-MU-ACMEREF-SUBSET-01-02-001`)
     - Custom code: `CODE-NNN-feature-name` (e.g., `AGY-001-agency-shell`, `BKG-003-booking-calendar`)
   - This name is used as-is for BOTH the branch name and the spec folder name
   - If the user did not provide a name in one of these formats, ask them to provide one before proceeding
   - Do NOT auto-generate or auto-increment numbers — the name comes from the user
   - When a story ID is provided, read the story file from `portfolios/{portfolio}/docs/epics/` to extract the full feature description (resolve `{portfolio}` per §2c below)

2. **Create the branch and spec folder**:

   a. First, fetch all remote branches to ensure we have the latest information:

      ```bash
      git fetch --all --prune
      ```

   b. Check that no branch or spec folder with this name already exists:
      - Remote branches: `git ls-remote --heads origin | grep -E 'refs/heads/<feature-name>$'`
      - Local branches: `git branch | grep -E '^[* ]*<feature-name>$'`
      - Specs directories: Check for directory `specs/<feature-name>`

   c. **Resolve portfolio** (single resolution — used for all downstream path lookups):
      - **Explicit parameter**: If user passed `portfolio=<value>` in the command, use that value.
      - **Story ID extraction**: If feature name matches `STORY-{PORTFOLIO}-MU-*` or `EPIC-{PORTFOLIO}-MU-*`, extract the portfolio segment (e.g., `ACME-CORE` from `STORY-ACME-CORE-MU-00-01-004`).
      - **Environment file**: Read `PORTFOLIO_NAME` from project-root `.env`.
      - **Error if none found**: Stop and ask the user to provide `portfolio=<name>`.
      - Portfolio pattern (case-insensitive): `[A-Za-z]+-[A-Za-z0-9-]+` (e.g., `ACME-CORE`, `UWR-POC`, `ACME-REF-subset`)

   d. Run the script `.specify/scripts/powershell/create-new-feature.ps1 -Json -ShortName "<feature-name>" -Portfolio "<portfolio>" "<description>"`:
      - With portfolio: `.specify/scripts/powershell/create-new-feature.ps1 -Json -ShortName "STORY-MU-ACMEREF-SUBSET-01-02-001" -Portfolio "ACME-REF-subset" "Implement Program Code Catalog Lookup"`
      - Without portfolio (uses .env): `.specify/scripts/powershell/create-new-feature.ps1 -Json -ShortName "AGY-001-agency-shell" "Migrate agency shell component"`

   **IMPORTANT**:
   - The feature name provided by the user is the EXACT branch name and spec folder name — no modification
   - If a branch or spec folder already exists with that name, inform the user and ask how to proceed
   - You must only ever run this script once per feature
   - **The new branch is cut from whatever branch is currently checked out.** Step 0e is responsible for putting `HEAD` on the correct base branch before this script runs. If step 0e was skipped or resolved to the wrong branch, the new story branch will inherit the wrong history. Before invoking the script, verify that `git branch --show-current` returns the resolved base branch.
   - The JSON is provided in the terminal as output - always refer to it to get the actual content you're looking for
   - The JSON output will contain BRANCH_NAME and SPEC_FILE paths
   - For single quotes in args like "I'm Groot", use escape syntax: e.g 'I'\''m Groot' (or double-quote if possible: "I'm Groot")

3. Load `.specify/templates/spec-template.md` to understand required sections.
   - **IF EXISTS**: Load `portfolios/{portfolio}/specs/constitution.md` (resolve portfolio per §2c). Extract active principles and technology constraints. Use these to constrain requirement generation — do not propose approaches that violate MUST principles. If the file does not exist, proceed without constitution constraints.

4. Follow this execution flow:

    1. Parse user description from Input
       If empty: ERROR "No feature description provided"
    2. Extract key concepts from description
       Identify: actors, actions, data, constraints
    3. For unclear aspects:
       - Make informed guesses based on context and industry standards
       - Only mark with [NEEDS CLARIFICATION: specific question] if:
         - The choice significantly impacts feature scope or user experience
         - Multiple reasonable interpretations exist with different implications
         - No reasonable default exists
       - **LIMIT: Maximum 3 [NEEDS CLARIFICATION] markers total**
       - Prioritize clarifications by impact: scope > security/privacy > user experience > technical details
    4. Fill User Scenarios & Testing section
       If no clear user flow: ERROR "Cannot determine user scenarios"
    5. Generate Functional Requirements
       Each requirement must be testable
       Use reasonable defaults for unspecified details (document assumptions in Assumptions section)
    6. Define Success Criteria
       Create measurable, technology-agnostic outcomes
       Include both quantitative metrics (time, performance, volume) and qualitative measures (user satisfaction, task completion)
       Each criterion must be verifiable without implementation details
    7. Identify Key Entities (if data involved)
    8. Return: SUCCESS (spec ready for planning)

5. Write the specification to SPEC_FILE using the template structure, replacing placeholders with concrete details derived from the feature description (arguments) while preserving section order and headings.

6. **Specification Quality Validation**: After writing the initial spec, validate it against quality criteria:

   a. **Create Spec Quality Checklist**: Generate a checklist file at `FEATURE_DIR/checklists/requirements.md` using the checklist template structure with these validation items:

      ```markdown
      # Specification Quality Checklist: [FEATURE NAME]
      
      **Purpose**: Validate specification completeness and quality before proceeding to planning
      **Created**: [DATE]
      **Feature**: [Link to spec.md]
      
      ## Content Quality
      
      - [ ] No implementation details (languages, frameworks, APIs)
      - [ ] Focused on user value and business needs
      - [ ] Written for non-technical stakeholders
      - [ ] All mandatory sections completed
      
      ## Requirement Completeness
      
      - [ ] No [NEEDS CLARIFICATION] markers remain
      - [ ] Requirements are testable and unambiguous
      - [ ] Success criteria are measurable
      - [ ] Success criteria are technology-agnostic (no implementation details)
      - [ ] All acceptance scenarios are defined
      - [ ] Edge cases are identified
      - [ ] Scope is clearly bounded
      - [ ] Dependencies and assumptions identified
      
      ## Feature Readiness
      
      - [ ] All functional requirements have clear acceptance criteria
      - [ ] User scenarios cover primary flows
      - [ ] Feature meets measurable outcomes defined in Success Criteria
      - [ ] No implementation details leak into specification
      
      ## Notes
      
      - Items marked incomplete require spec updates before `/speckit.clarify` or `/speckit.plan`
      ```

   b. **Run Validation Check**: Review the spec against each checklist item:
      - For each item, determine if it passes or fails
      - Document specific issues found (quote relevant spec sections)

   c. **Handle Validation Results**:

      - **If all items pass**: Mark checklist complete and proceed to step 6

      - **If items fail (excluding [NEEDS CLARIFICATION])**:
        1. List the failing items and specific issues
        2. Update the spec to address each issue
        3. Re-run validation until all items pass (max 3 iterations)
        4. If still failing after 3 iterations, document remaining issues in checklist notes and warn user

      - **If [NEEDS CLARIFICATION] markers remain**:
        1. Extract all [NEEDS CLARIFICATION: ...] markers from the spec
        2. **LIMIT CHECK**: If more than 3 markers exist, keep only the 3 most critical (by scope/security/UX impact) and make informed guesses for the rest
        3. For each clarification needed (max 3), present options to user in this format:

           ```markdown
           ## Question [N]: [Topic]
           
           **Context**: [Quote relevant spec section]
           
           **What we need to know**: [Specific question from NEEDS CLARIFICATION marker]
           
           **Suggested Answers**:
           
           | Option | Answer | Implications |
           |--------|--------|--------------|
           | A      | [First suggested answer] | [What this means for the feature] |
           | B      | [Second suggested answer] | [What this means for the feature] |
           | C      | [Third suggested answer] | [What this means for the feature] |
           | Custom | Provide your own answer | [Explain how to provide custom input] |
           
           **Your choice**: _[Wait for user response]_
           ```

        4. **CRITICAL - Table Formatting**: Ensure markdown tables are properly formatted:
           - Use consistent spacing with pipes aligned
           - Each cell should have spaces around content: `| Content |` not `|Content|`
           - Header separator must have at least 3 dashes: `|--------|`
           - Test that the table renders correctly in markdown preview
        5. Number questions sequentially (Q1, Q2, Q3 - max 3 total)
        6. Present all questions together before waiting for responses
        7. Wait for user to respond with their choices for all questions (e.g., "Q1: A, Q2: Custom - [details], Q3: B")
        8. Update the spec by replacing each [NEEDS CLARIFICATION] marker with the user's selected or provided answer
        9. Re-run validation after all clarifications are resolved

   d. **Update Checklist**: After each validation iteration, update the checklist file with current pass/fail status

7. Report completion with branch name, spec file path, checklist results, and readiness for the next phase (`/speckit.clarify` or `/speckit.plan`).

**NOTE:** The script creates and checks out the new branch and initializes the spec file before writing.

## General Guidelines

## Quick Guidelines

- Focus on **WHAT** users need and **WHY**.
- Avoid HOW to implement (no tech stack, APIs, code structure).
- Written for business stakeholders, not developers.
- DO NOT create any checklists that are embedded in the spec. That will be a separate command.

### Section Requirements

- **Mandatory sections**: Must be completed for every feature
- **Optional sections**: Include only when relevant to the feature
- When a section doesn't apply, remove it entirely (don't leave as "N/A")

### For AI Generation

When creating this spec from a user prompt:

1. **Make informed guesses**: Use context, industry standards, and common patterns to fill gaps
2. **Document assumptions**: Record reasonable defaults in the Assumptions section
3. **Limit clarifications**: Maximum 3 [NEEDS CLARIFICATION] markers - use only for critical decisions that:
   - Significantly impact feature scope or user experience
   - Have multiple reasonable interpretations with different implications
   - Lack any reasonable default
4. **Prioritize clarifications**: scope > security/privacy > user experience > technical details
5. **Think like a tester**: Every vague requirement should fail the "testable and unambiguous" checklist item
6. **Common areas needing clarification** (only if no reasonable default exists):
   - Feature scope and boundaries (include/exclude specific use cases)
   - User types and permissions (if multiple conflicting interpretations possible)
   - Security/compliance requirements (when legally/financially significant)

**Examples of reasonable defaults** (don't ask about these):

- Data retention: Industry-standard practices for the domain
- Performance targets: Standard web/mobile app expectations unless specified
- Error handling: User-friendly messages with appropriate fallbacks
- Authentication method: Standard session-based or OAuth2 for web apps
- Integration patterns: Use project-appropriate patterns (REST/GraphQL for web services, function calls for libraries, CLI args for tools, etc.)

### Success Criteria Guidelines

Success criteria must be:

1. **Measurable**: Include specific metrics (time, percentage, count, rate)
2. **Technology-agnostic**: No mention of frameworks, languages, databases, or tools
3. **User-focused**: Describe outcomes from user/business perspective, not system internals
4. **Verifiable**: Can be tested/validated without knowing implementation details

**Good examples**:

- "Users can complete checkout in under 3 minutes"
- "System supports 10,000 concurrent users"
- "95% of searches return results in under 1 second"
- "Task completion rate improves by 40%"

**Bad examples** (implementation-focused):

- "API response time is under 200ms" (too technical, use "Users see results instantly")
- "Database can handle 1000 TPS" (implementation detail, use user-facing metric)
- "React components render efficiently" (framework-specific)
- "Redis cache hit rate above 80%" (technology-specific)
