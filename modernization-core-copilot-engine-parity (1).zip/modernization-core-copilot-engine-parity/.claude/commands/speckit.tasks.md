---
description: Generate an actionable, dependency-ordered tasks.md for the feature based on available design artifacts.
handoffs: 
  - label: Create Checklist
    agent: speckit.checklist
    prompt: Create a quality checklist for this feature
  - label: Analyze For Consistency
    agent: speckit.analyze
    prompt: Run a project analysis for consistency
    send: true
---

## User Input

```text
$ARGUMENTS
```

You **MUST** consider the user input before proceeding (if not empty).

## Outline

**Before step 1 — load portfolio context (MANDATORY).** Read
`.claude/skills/portfolio-resolution/SKILL.md` in full and follow it exactly. It
resolves the portfolio name, loads and validates `portfolios/{portfolio}/portfolio.yaml`,
locates skills pack-first (pack `skills/` → `subset_of` ancestors → `.claude/skills/`),
and defines the mandatory load order for the pack's **client**, **domain**, and
**target-stack-conventions** skills plus the authoritative
`portfolios/{portfolio}/{target_stack.definition}`.

Do not paraphrase or re-implement those rules here — that file is the single source
of truth, and skipping it is how this phase ends up generating output with no client
or domain knowledge loaded at all, which produces confidently wrong results rather
than an error.

1. **Setup**: Run `.specify/scripts/bash/check-prerequisites.sh --json` from repo root and parse FEATURE_DIR and AVAILABLE_DOCS list. All paths must be absolute.

2. **Load design documents**: Read from FEATURE_DIR:
   - **Required**: plan.md (tech stack, libraries, structure), spec.md (user stories with priorities)
   - **Optional**: data-model.md (entities), contracts/ (interface contracts), research.md (decisions), quickstart.md (test scenarios)
   - **IF EXISTS**: Load `portfolios/{portfolio}/specs/constitution.md` (resolve portfolio from `PORTFOLIO_NAME` in `.env` or explicit parameter). Use constitution to validate that generated tasks use mandated technology stack and quality gate thresholds. If plan.md conflicts with constitution, follow constitution and WARN.
   - Note: Not all projects have all documents. Generate tasks based on what's available.

3. **Execute task generation workflow**:
   - Load plan.md and extract tech stack, libraries, project structure
   - **Resolve implementation root**: Read plan.md "Project Structure" section. All file paths in generated tasks MUST be relative to the declared implementation root (typically `portfolios/{portfolio}/POC/`). If plan.md uses a flat path like `src/`, prefix it with `portfolios/{portfolio}/POC/` where `{portfolio}` comes from the portfolio resolved during `/speckit.specify` or `.env`. This ensures multi-portfolio isolation.
   - Load spec.md and extract user stories with their priorities (P1, P2, P3, etc.)
   - If data-model.md exists: Extract entities and map to user stories
   - If contracts/ exists: Map interface contracts to user stories
   - If research.md exists: Extract decisions for setup tasks
   - Generate tasks organized by user story (see Task Generation Rules below)
   - Generate dependency graph showing user story completion order
   - Create parallel execution examples per user story
   - Validate task completeness (each user story has all needed tasks, independently testable)

4. **Generate tasks.md**: Use `.specify/templates/tasks-template.md` as structure, fill with:
   - Correct feature name from plan.md
   - Phase 1: Setup tasks (project initialization)
   - Phase 2: Foundational tasks (blocking prerequisites for all user stories)
   - Phase 3+: One phase per user story (in priority order from spec.md)
   - Each phase includes: story goal, independent test criteria, tests (if requested), implementation tasks
   - Final Phase: Polish & cross-cutting concerns
   - All tasks must follow the strict checklist format (see Task Generation Rules below)
   - Clear file paths for each task
   - Dependencies section showing story completion order
   - Parallel execution examples per story
   - Implementation strategy section (MVP first, incremental delivery)

5. **Report**: Output path to generated tasks.md and summary:
   - Total task count
   - Task count per user story
   - Parallel opportunities identified
   - Independent test criteria for each story
   - Suggested MVP scope (typically just User Story 1)
   - Format validation: Confirm ALL tasks follow the checklist format (checkbox, ID, labels, file paths)

Context for task generation: $ARGUMENTS

The tasks.md should be immediately executable - each task must be specific enough that an LLM can complete it without additional context.

## Task Generation Rules

**CRITICAL**: Tasks MUST be organized by user story to enable independent implementation and testing.

**Tests are OPTIONAL**: Only generate test tasks if explicitly requested in the feature specification or if user requests TDD approach.

### Checklist Format (REQUIRED)

Every task MUST strictly follow this format:

```text
- [ ] [TaskID] [P?] [Story?] Description with file path
```

**Format Components**:

1. **Checkbox**: ALWAYS start with `- [ ]` (markdown checkbox)
2. **Task ID**: Sequential number (T001, T002, T003...) in execution order
3. **[P] marker**: Include ONLY if task is parallelizable (different files, no dependencies on incomplete tasks)
4. **[Story] label**: REQUIRED for user story phase tasks only
   - Format: [US1], [US2], [US3], etc. (maps to user stories from spec.md)
   - Setup phase: NO story label
   - Foundational phase: NO story label  
   - User Story phases: MUST have story label
   - Polish phase: NO story label
5. **Description**: Clear action with exact file path

**Examples**:

- ✅ CORRECT: `- [ ] T001 Create project structure per implementation plan`
- ✅ CORRECT: `- [ ] T005 [P] Implement authentication middleware in src/middleware/auth.py`
- ✅ CORRECT: `- [ ] T012 [P] [US1] Create User model in src/models/user.py`
- ✅ CORRECT: `- [ ] T014 [US1] Implement UserService in src/services/user_service.py`
- ❌ WRONG: `- [ ] Create User model` (missing ID and Story label)
- ❌ WRONG: `T001 [US1] Create model` (missing checkbox)
- ❌ WRONG: `- [ ] [US1] Create User model` (missing Task ID)
- ❌ WRONG: `- [ ] T001 [US1] Create model` (missing file path)

### Task Organization

1. **From User Stories (spec.md)** - PRIMARY ORGANIZATION:
   - Each user story (P1, P2, P3...) gets its own phase
   - Map all related components to their story:
     - Models needed for that story
     - Services needed for that story
     - Interfaces/UI needed for that story
     - If tests requested: Tests specific to that story
   - Mark story dependencies (most stories should be independent)

2. **From Contracts**:
   - Map each interface contract → to the user story it serves
   - If tests requested: Each interface contract → contract test task [P] before implementation in that story's phase

3. **From Data Model**:
   - Map each entity to the user story(ies) that need it
   - If entity serves multiple stories: Put in earliest story or Setup phase
   - Relationships → service layer tasks in appropriate story phase

4. **From Setup/Infrastructure**:
   - Shared infrastructure → Setup phase (Phase 1)
   - Foundational/blocking tasks → Foundational phase (Phase 2)
   - Story-specific setup → within that story's phase

### Phase Structure

**Detect migration**: Check if spec.md contains `[MIGRATION]` tags, a "Source Parity Matrix" section, or if `source-audit.md` exists in FEATURE_DIR. Also check if spec title or user stories reference "migrate", "migration", "rewrite", "port", "convert from", or similar terms.

**If migration detected**: Verify `source-audit.md` exists in FEATURE_DIR. If missing, warn: "Migration detected but no source-audit.md found (`/speckit.migrate`, the intended generator, is follow-up work and does not exist yet in this engine). Proceeding on the portfolio pack's other source evidence (`inputs/static-analysis/`, `knowledge-store/`, MFLens) may result in missing features." Continue with available information but flag that parity verification in later phases will be limited.

#### Standard Feature Phase Structure (non-migration)

- **Phase 1**: Setup (project initialization)
- **Phase 2**: Foundational (blocking prerequisites - MUST complete before user stories)
- **Phase 3+**: User Stories in priority order (P1, P2, P3...)
  - Within each story: Tests (if requested) → Models → Services → Endpoints → Integration
  - Each phase should be a complete, independently testable increment
- **Final Phase**: Polish & Cross-Cutting Concerns

#### Migration Phase Structure (Bottom-Up Order)

**REQUIRED when the feature is a migration.** This replaces the standard User Story phases with migration-layer phases that enforce dependency-first ordering (dependencies before dependents).

- **Phase 1: Inventory & Setup**
  - T001 Research existing target-system components for reuse (MANDATORY)
    - Search the target codebase for existing equivalents
    - Document findings: what was searched, what was found, reuse decision
  - T002 Create project/directory structure under `portfolios/{portfolio}/POC/`
  - T003 [P] Create data model types/interfaces from data-model.md
  - T004 [P] Create enum/constant files from source-audit.md

- **Phase 2: Interface & Contract Extraction**
  - Extract all API request/response schemas from source-audit.md
  - Place shared interfaces/contracts in the appropriate shared location
  - Each interface task must reference the source-audit.md entry it maps from

- **Phase 3: Foundation/Leaf Migration**
  - Migrate components/services with NO internal dependencies first
  - Each task MUST include:
    - Implementation file(s) in `portfolios/{portfolio}/POC/`
    - Unit tests
  - Mark each task with the source file it replaces

- **Phase 4: Service/Business Logic Migration**
  - Migrate services and business logic
  - Each service task MUST include:
    - All methods from source-audit.md Service Inventory
    - Error handling for every external call, using the idiom declared in plan.md — silent swallowing prohibited
      - Strategy per call is explicit: "catch and replace with typed fallback" OR "catch and rethrow as formatted error" — choice recorded in the task description
      - Retry is applied only to idempotent reads where source-audit.md Error Handling Inventory shows flakiness or manual retry behavior; NEVER on non-idempotent writes
      - Every error handler from source-audit.md Error Handling Inventory is preserved (same user-facing effect — toast/banner/modal/log/fallback); any new error handler added where the source had none is explicit, not accidental
    - Unit tests for all public methods covering success and error paths; error tests assert the documented user-facing effect

- **Phase 5: Integration/Container Migration**
  - Migrate higher-level components that compose foundational ones
  - MUST only start after ALL foundation components from Phase 3 are complete

- **Phase 6: Cleanup & Removal**
  - Generate explicit cleanup tasks with exact file paths for source files being replaced
  - Each cleanup task MUST reference the specific file to delete/modify
  - Run verification searches after cleanup to confirm zero dangling references

- **Phase 7: Behavior Test Matrix (MANDATORY when Business Rules Extract exists)**

  **Execute this phase ONLY if source-audit.md contains a "Business Rules Extract" section.**

  Generate a dedicated task that creates unit tests derived directly from the documented business rules.

  - `- [ ] TXXX Generate behavior-driven test cases from Business Rules Extract`

  **For each rule in Business Rules Extract**, generate a test case:

  | Rule ID | Source Method | Rule | Test Case | Expected Behavior |
  |---------|-------------|------|-----------|-------------------|

  **Rules for test generation:**
  - Each business rule MUST have at least one corresponding unit test
  - Test names SHOULD reference the original source method for traceability
  - Tests MUST verify the exact condition, not just that the method exists

  Insert these test tasks WITHIN the relevant component/service phase (Phase 3-5), immediately after the implementation task. Do NOT defer all tests to a separate phase.

- **Phase 8: Quality Gates (NON-NEGOTIABLE)**
  - `- [ ] TXXX Run lint on all new/modified files`
  - `- [ ] TXXX Run full test suite`
  - `- [ ] TXXX Run production build`
  - `- [ ] TXXX Verify functional parity against source-audit.md`
  - `- [ ] TXXX Verify business logic parity: all rules from Business Rules Extract implemented and tested`
  - `- [ ] TXXX Verify API contract preservation: for each external call, compare request/response payload field-by-field against source-audit.md`
  - `- [ ] TXXX Verify error handling parity: for each entry in source-audit.md Error Handling Inventory, confirm the target preserves the documented behavior`
  - These tasks MUST NOT be marked complete until gates have actually been executed and passed
  - Prefer the exact lint / test / build commands declared in plan.md when generating these gate tasks

  **API Contract Verification sub-tasks** (insert within Phase 4 — Service/Business Logic Migration, after each service is implemented):
  ```
  - [ ] TXXX [USn] Verify API contract for [ServiceName]: cross-reference each outbound call against source-audit.md
    - Compare request payload: field names, types (numbers stay numbers, NOT strings), date formats, null handling
    - Compare response contract: field names, types match the API response exactly
    - Write contract / wire-level tests verifying the exact request body shape (using the test client declared in plan.md)
    - Check empty-input handling: the source may send `""`, the target framework may send `null` or omit the field — match the source behavior
    - Check date / time serialization matches the source format byte-for-byte
    - Check collection / array encoding matches the source format
  ```

### Auto-Inserted Tasks (REQUIRED for ALL features, not just migrations)

The following tasks MUST be automatically inserted regardless of feature type:

**Component Research Task** (insert at start of first implementation phase):
```
- [ ] TXXX Research existing components for reuse before creating new ones
  - Search the target codebase for existing equivalents
  - Document: what was searched, what was found, why new component warranted (or which existing component reused)
```

**Quality Gate Tasks** (Post-Implementation Gates — insert as final phase):
```
- [ ] TXXX Run lint on all new/modified files
- [ ] TXXX Run full test suite with zero failures
- [ ] TXXX Run production build successfully
```
