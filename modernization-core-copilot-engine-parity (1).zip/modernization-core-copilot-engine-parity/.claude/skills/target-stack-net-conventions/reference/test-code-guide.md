# Test Code Guide — TDD Patterns and Conventions (.NET route)

> Supporting reference for the `target-stack-net-conventions` skill. Applies only to packs
> whose manifest declares `target_stack.id: net`. The framework and naming rules here are the
> worked-example form of `[TEST-01]`–`[TEST-07]` and `[COV-*]` in that skill's `SKILL.md` — the
> rule IDs are authoritative on any conflict. There is no Java equivalent yet; a `java`-route
> pack needs the same patterns expressed with JUnit 5 / Mockito / AssertJ.

**Version:** 1.0  
**Last Updated:** 2026-05-27

## Purpose

This guide defines test code patterns, conventions, and examples for implementing user stories using Test-Driven Development (TDD). All test code in this Migration Unit must follow these patterns for consistency, COBOL traceability, and maintainability.

---

## TDD Workflow

**Always follow this sequence:**

1. **RED:** Write failing tests first
2. **GREEN:** Implement code to make tests pass
3. **REFACTOR:** Clean up code while keeping tests green

**Never write implementation code before tests.**

---

## Test Types

### 1. Unit Tests

**Purpose:** Test business logic, calculations, transformations, and entity behavior in isolation

**Location:** `tests/{MU-Name}.Domain.Tests/Entities/` or `tests/{MU-Name}.Application.Tests/Services/`

**Naming Convention:** `{EntityName}Tests.cs` or `{ServiceName}Tests.cs`

**Example:**

```csharp
using System;
using NUnit.Framework;
using FluentAssertions;
using {MU-Name}.Domain.Entities;

namespace {MU-Name}.Domain.Tests.Entities
{
    /// <summary>
    /// Tests for Policy entity
    /// </summary>
    /// <remarks>
    /// COBOL Reference: {PROGRAM} - Paragraph {PARAGRAPH} (lines {START}-{END})
    /// </remarks>
    [TestFixture]
    [Category("Unit")]
    public class PolicyTests
    {
        [Test]
        public void Policy_WithValidData_MapsCorrectly()
        {
            // Arrange - Test data matching COBOL host variables
            var policyNumber = "POL001234567890";
            var applicantId = 12345;

            // Act
            var policy = new Policy
            {
                PolicyNumber = policyNumber,
                ApplicantId = applicantId
            };

            // Assert - Validate field mapping matches COBOL structure
            policy.PolicyNumber.Should().Be(policyNumber);
            policy.ApplicantId.Should().Be(applicantId);
        }

        [Test]
        public void Policy_PolicyNumber_MaxLength15()
        {
            // COBOL: HV-POL-NBR PIC X(15)
            var policy = new Policy { PolicyNumber = "123456789012345" };
            policy.PolicyNumber.Length.Should().BeLessOrEqualTo(15);
        }
    }
}
```

**Key Patterns:**
- **XML Comments:** Always include `<summary>` and `<remarks>` with COBOL reference
- **Category Attribute:** `[Category("Unit")]` for test filtering
- **Test Method Names:** `{ClassName}_{Scenario}_{ExpectedResult}` format
- **Arrange/Act/Assert:** Clear sections with inline comments
- **COBOL Comments:** Reference host variables, PIC clauses, field lengths
- **FluentAssertions:** Use `.Should()` syntax for readable assertions

---

### 2. Integration Tests

**Purpose:** Test data access (repositories), database queries, and EF6 behavior against DB2

**Location:** `tests/{MU-Name}.DataAccess.Tests/Repositories/`

**Naming Convention:** `{RepositoryName}Tests.cs`

**Example:**

```csharp
using System;
using NUnit.Framework;
using FluentAssertions;
using {MU-Name}.DataAccess;
using {MU-Name}.DataAccess.Repositories;
using {MU-Name}.Domain.Entities;

namespace {MU-Name}.DataAccess.Tests.Repositories
{
    /// <summary>
    /// Integration tests for PolicyRepository
    /// </summary>
    /// <remarks>
    /// COBOL Reference: {PROGRAM} - Paragraph {PARAGRAPH} (lines {START}-{END})
    /// Validates .NET behavior matches COBOL SELECT INTO logic
    /// </remarks>
    [TestFixture]
    [Category("Integration")]
    public class PolicyRepositoryTests
    {
        private {MU-Name}DbContext _context;
        private IPolicyRepository _repository;

        [SetUp]
        public void SetUp()
        {
            // Initialize DbContext and repository before each test
            _context = new {MU-Name}DbContext();
            _repository = new PolicyRepository(_context);
        }

        [TearDown]
        public void TearDown()
        {
            // Dispose DbContext after each test to release connections
            _context?.Dispose();
        }

        [Test]
        public void GetByPolicyNumber_PolicyExists_ReturnsPolicy()
        {
            // COBOL Validation: Compare with COBOL output for known policy number
            // Arrange
            var policyNumber = "POL001234567890"; // Known test policy

            // Act
            var policy = _repository.GetByPolicyNumber(policyNumber);

            // Assert
            policy.Should().NotBeNull("COBOL returns policy record for valid policy number");
            policy.PolicyNumber.Should().Be(policyNumber);
            policy.ApplicantId.Should().BeGreaterThan(0, "COBOL populates HV-POL-APPLICANT-ID");
        }

        [Test]
        public void GetByPolicyNumber_PolicyNotFound_ReturnsNull()
        {
            // COBOL Validation: SQLCODE=100 scenario (lines {START}-{END})
            // Arrange
            var invalidPolicyNumber = "INVALID000000000";

            // Act
            var policy = _repository.GetByPolicyNumber(invalidPolicyNumber);

            // Assert
            policy.Should().BeNull("COBOL returns SQLCODE=100 when policy not found");
        }
    }
}
```

**Key Patterns:**
- **SetUp/TearDown:** Always initialize/dispose DbContext in SetUp/TearDown
- **COBOL Validation Comments:** Start assertions with `// COBOL Validation: ...`
- **Known Test Data:** Use known policy numbers, applicant IDs from test database
- **SQLCODE Scenarios:** Test both success (data found) and SQLCODE=100 (not found)
- **Assertion Messages:** Include COBOL context in FluentAssertions `because` parameter

---

### 3. Performance Tests

**Purpose:** Validate query execution time meets NFRs (typically <50ms, <100ms, <200ms)

**Location:** Same as integration tests (`tests/{MU-Name}.DataAccess.Tests/Repositories/`)

**Example:**

```csharp
[Test]
public void GetByPolicyNumber_Performance_CompletesInUnder50ms()
{
    // COBOL: Indexed PK lookup should be fast
    var policyNumber = "POL001234567890";

    var stopwatch = System.Diagnostics.Stopwatch.StartNew();
    var policy = _repository.GetByPolicyNumber(policyNumber);
    stopwatch.Stop();

    policy.Should().NotBeNull();
    stopwatch.ElapsedMilliseconds.Should().BeLessThan(50, "Indexed query performance requirement");
}
```

**Key Patterns:**
- **Stopwatch:** Use `System.Diagnostics.Stopwatch` to measure execution time
- **Thresholds:** Assert against NFR thresholds (50ms, 100ms, 200ms)
- **Index Comments:** Comment on required indexes (e.g., `// Requires IX_POLICY_NBR index`)

---

### 4. Contract Tests (WCF)

**Purpose:** Validate WSDL contracts, SOAP request/response, and service operation behavior

**Location:** `tests/{MU-Name}.Services.Tests/Contracts/`

**Example:**

```csharp
using System;
using NUnit.Framework;
using FluentAssertions;
using {MU-Name}.Services;
using {MU-Name}.Services.Contracts;

namespace {MU-Name}.Services.Tests.Contracts
{
    /// <summary>
    /// Contract tests for UnderwritingService WSDL
    /// </summary>
    /// <remarks>
    /// COBOL Reference: {PROGRAM} - Entry paragraph (lines {START}-{END})
    /// </remarks>
    [TestFixture]
    [Category("Contract")]
    public class UnderwritingServiceContractTests
    {
        [Test]
        public void AssessRisk_WithValidRequest_ReturnsValidResponse()
        {
            // COBOL Validation: Compare SOAP response with COBOL COMMAREA output
            // Arrange
            var service = new UnderwritingService();
            var request = new AssessRiskRequest
            {
                PolicyNumber = "POL001234567890"
            };

            // Act
            var response = service.AssessRisk(request);

            // Assert
            response.Should().NotBeNull("COBOL returns valid COMMAREA structure");
            response.ResponseCode.Should().Be("0000", "COBOL success response code");
        }
    }
}
```

**Key Patterns:**
- **WSDL Validation:** Ensure request/response match WSDL schema
- **SOAP Envelope:** Test SOAP envelope structure if needed
- **COBOL COMMAREA:** Compare response structure with COBOL copybook

---

## COBOL Traceability Requirements

**Every test class, test method, and assertion MUST include COBOL traceability:**

### 1. Class-Level XML Comments

```csharp
/// <summary>
/// Tests for Policy entity
/// </summary>
/// <remarks>
/// COBOL Reference: UWRDATA - Paragraph 2000-GET-POLICY (lines 184-203)
/// </remarks>
```

### 2. Test Method Comments

```csharp
[Test]
public void GetByPolicyNumber_PolicyExists_ReturnsPolicy()
{
    // COBOL Validation: Compare with COBOL output for known policy number
    ...
}
```

### 3. Assertion Messages

```csharp
policy.Should().NotBeNull("COBOL returns policy record for valid policy number");
policy.ApplicantId.Should().BeGreaterThan(0, "COBOL populates HV-POL-APPLICANT-ID");
```

### 4. Inline COBOL Comments

```csharp
// COBOL: HV-POL-NBR PIC X(15)
policy.PolicyNumber.Length.Should().BeLessOrEqualTo(15);

// COBOL: SQLCODE=100 scenario (lines 210-215)
policy.Should().BeNull("COBOL returns SQLCODE=100 when policy not found");
```

---

## Naming Conventions

### Test Class Names

Format: `{ClassName}Tests.cs`

Examples:
- `PolicyTests.cs`
- `PolicyRepositoryTests.cs`
- `UnderwritingDataServiceTests.cs`

### Test Method Names

Format: `{MethodName}_{Scenario}_{ExpectedResult}`

Examples:
- `GetByPolicyNumber_PolicyExists_ReturnsPolicy`
- `GetByPolicyNumber_PolicyNotFound_ReturnsNull`
- `CalculateRiskScore_Score0_ReturnsPenalty40`

### Test Data Variable Names

Use descriptive names matching COBOL context:

```csharp
var policyNumber = "POL001234567890";          // ✅ Clear
var applicantId = 12345;                       // ✅ Clear
var cutoffDate = DateTime.Now.AddYears(-5);   // ✅ Clear

var x = "POL001234567890";                     // ❌ Unclear
var id = 12345;                                // ❌ Ambiguous
```

---

## Test Frameworks and Libraries

**Required NuGet Packages:**

- **NUnit 3.13.3** — Test framework
- **FluentAssertions 6.11.0** — Assertion library
- **Moq 4.18.4** — Mocking framework
- **NUnit3TestAdapter 4.5.0** — Visual Studio integration

**Example `packages.config`:**

```xml
<packages>
  <package id="NUnit" version="3.13.3" targetFramework="net48" />
  <package id="FluentAssertions" version="6.11.0" targetFramework="net48" />
  <package id="Moq" version="4.18.4" targetFramework="net48" />
  <package id="NUnit3TestAdapter" version="4.5.0" targetFramework="net48" />
</packages>
```

---

## Test Data Management

### 1. Use Known Test Data

Always use known, pre-seeded test data:

```csharp
// ✅ Known test policy (pre-seeded in test database)
var policyNumber = "POL001234567890";

// ❌ Random or unknown data
var policyNumber = Guid.NewGuid().ToString();
```

### 2. Document Test Data

Include test data sources in comments:

```csharp
// Arrange - Known test policy from test database (POLICY table)
var policyNumber = "POL001234567890";
```

### 3. Test Data Reset

For integration tests, consider using `TransactionScope` to rollback changes:

```csharp
[Test]
public void CreatePolicy_ValidPolicy_SavesSuccessfully()
{
    using (var scope = new TransactionScope())
    {
        // Arrange
        var policy = new Policy { PolicyNumber = "TEST00000000001" };

        // Act
        _repository.Add(policy);
        _context.SaveChanges();

        // Assert
        var saved = _repository.GetByPolicyNumber("TEST00000000001");
        saved.Should().NotBeNull();

        // Rollback (scope not completed)
    }
}
```

---

## Assertion Patterns

### Use FluentAssertions `.Should()` Syntax

```csharp
// ✅ Fluent syntax (readable, chainable)
policy.Should().NotBeNull();
policy.PolicyNumber.Should().Be("POL001234567890");
policy.ApplicantId.Should().BeGreaterThan(0);

// ❌ Classic Assert syntax (avoid)
Assert.IsNotNull(policy);
Assert.AreEqual("POL001234567890", policy.PolicyNumber);
Assert.IsTrue(policy.ApplicantId > 0);
```

### Include COBOL Context in Messages

```csharp
// ✅ COBOL context in assertion message
policy.Should().NotBeNull("COBOL returns policy record for valid policy number");
policy.ApplicantId.Should().BeGreaterThan(0, "COBOL populates HV-POL-APPLICANT-ID");

// ❌ Generic message (less helpful)
policy.Should().NotBeNull("policy should not be null");
```

---

## Common Patterns

### 1. Testing Default Values

```csharp
[Test]
public void CreditProfile_WorstCaseDefaults_Score0_DTI99()
{
    // COBOL Business Rule: UWRDATA-BR005 (lines 285-290)
    // When credit profile not found, default to worst case
    var profile = new CreditProfile
    {
        CreditScore = 0,
        DebtToIncome = 99.00m
    };

    profile.CreditScore.Should().Be(0, "Worst-case credit score default");
    profile.DebtToIncome.Should().Be(99.00m, "Worst-case DTI default");
}
```

### 2. Testing SQLCODE=100 (Not Found)

```csharp
[Test]
public void GetByPolicyNumber_PolicyNotFound_ReturnsNull()
{
    // COBOL Validation: SQLCODE=100 scenario (lines 210-215)
    // Arrange
    var invalidPolicyNumber = "INVALID000000000";

    // Act
    var policy = _repository.GetByPolicyNumber(invalidPolicyNumber);

    // Assert
    policy.Should().BeNull("COBOL returns SQLCODE=100 when policy not found");
}
```

### 3. Testing Aggregate Queries

```csharp
[Test]
public void GetClaimCount_PolicyWithClaims_ReturnsCount()
{
    // COBOL Validation: Compare with COBOL cursor loop claim count (WS-CLAIM-COUNT)
    // Arrange
    var policyNumber = "POL001234567890";
    var cutoffDate = DateTime.Now.AddYears(-5);

    // Act
    var count = _repository.GetClaimCountByPolicy(policyNumber, cutoffDate);

    // Assert
    count.Should().BeGreaterOrEqualTo(0, "COBOL accumulates WS-CLAIM-COUNT");
    // Verify against known COBOL output for this policy
}
```

### 4. Testing ORDER BY DESC (Most Recent)

```csharp
[Test]
public void GetMostRecentByApplicant_ProfileExists_ReturnsMostRecent()
{
    // COBOL Validation: ORDER BY CRD_REPORT_DATE DESC FETCH FIRST 1 ROW
    // Arrange
    var applicantId = 12345;

    // Act
    var profile = _repository.GetMostRecentByApplicant(applicantId);

    // Assert
    profile.Should().NotBeNull("COBOL returns most recent credit profile");
    profile.ReportDate.Should().BeOnOrBefore(DateTime.Now, "Report date must be historical");
}
```

---

## Test Organization

### Folder Structure

```
tests/
  {MU-Name}.Domain.Tests/
    Entities/
      PolicyTests.cs
      ApplicantTests.cs
      CreditProfileTests.cs
    ValueObjects/
      RiskScoreTests.cs
  
  {MU-Name}.DataAccess.Tests/
    Repositories/
      PolicyRepositoryTests.cs
      ApplicantRepositoryTests.cs
      CreditProfileRepositoryTests.cs
  
  {MU-Name}.Application.Tests/
    Services/
      UnderwritingDataServiceTests.cs
      RiskScoringEngineTests.cs
  
  {MU-Name}.Services.Tests/
    Contracts/
      UnderwritingServiceContractTests.cs
```

---

## Run Tests

### From Visual Studio

- **Run All Tests:** Test Explorer → Run All
- **Run Category:** Test Explorer → Group By → Category → Run "Integration" or "Unit"

### From Command Line (NUnit Console Runner)

```bash
# Run all tests
nunit3-console.exe tests/{MU-Name}.Domain.Tests/bin/Debug/{MU-Name}.Domain.Tests.dll

# Run unit tests only
nunit3-console.exe tests/{MU-Name}.Domain.Tests/bin/Debug/{MU-Name}.Domain.Tests.dll --where "cat == Unit"

# Run integration tests only
nunit3-console.exe tests/{MU-Name}.DataAccess.Tests/bin/Debug/{MU-Name}.DataAccess.Tests.dll --where "cat == Integration"
```

---

## Example: Complete Test Class

```csharp
using System;
using NUnit.Framework;
using FluentAssertions;
using UnderwritingAssessment.DataAccess;
using UnderwritingAssessment.DataAccess.Repositories;
using UnderwritingAssessment.Domain.Entities;

namespace UnderwritingAssessment.DataAccess.Tests.Repositories
{
    /// <summary>
    /// Integration tests for PolicyRepository
    /// </summary>
    /// <remarks>
    /// COBOL Reference: UWRDATA - Paragraph 2000-GET-POLICY (lines 184-203)
    /// Validates .NET behavior matches COBOL SELECT INTO logic
    /// </remarks>
    [TestFixture]
    [Category("Integration")]
    public class PolicyRepositoryTests
    {
        private UnderwritingDbContext _context;
        private IPolicyRepository _repository;

        [SetUp]
        public void SetUp()
        {
            // Initialize DbContext and repository before each test
            _context = new UnderwritingDbContext();
            _repository = new PolicyRepository(_context);
        }

        [TearDown]
        public void TearDown()
        {
            // Dispose DbContext after each test to release connections
            _context?.Dispose();
        }

        [Test]
        public void GetByPolicyNumber_PolicyExists_ReturnsPolicy()
        {
            // COBOL Validation: Compare with COBOL output for known policy number
            // Arrange
            var policyNumber = "POL001234567890"; // Known test policy

            // Act
            var policy = _repository.GetByPolicyNumber(policyNumber);

            // Assert
            policy.Should().NotBeNull("COBOL returns policy record for valid policy number");
            policy.PolicyNumber.Should().Be(policyNumber);
            policy.ApplicantId.Should().BeGreaterThan(0, "COBOL populates HV-POL-APPLICANT-ID");
            policy.ProductCode.Should().NotBeNullOrEmpty("COBOL populates HV-POL-PRODUCT-CODE");
        }

        [Test]
        public void GetByPolicyNumber_PolicyNotFound_ReturnsNull()
        {
            // COBOL Validation: SQLCODE=100 scenario (lines 210-215)
            // Arrange
            var invalidPolicyNumber = "INVALID000000000";

            // Act
            var policy = _repository.GetByPolicyNumber(invalidPolicyNumber);

            // Assert
            policy.Should().BeNull("COBOL returns SQLCODE=100 when policy not found");
        }

        [Test]
        public void GetByPolicyNumber_Performance_CompletesInUnder50ms()
        {
            // COBOL: Indexed PK lookup should be fast
            var policyNumber = "POL001234567890";

            var stopwatch = System.Diagnostics.Stopwatch.StartNew();
            var policy = _repository.GetByPolicyNumber(policyNumber);
            stopwatch.Stop();

            policy.Should().NotBeNull();
            stopwatch.ElapsedMilliseconds.Should().BeLessThan(50, "Indexed query performance requirement");
        }
    }
}
```

---

## Summary

**Key Takeaways:**

1. **TDD Always:** Tests first, implementation second, refactor third
2. **COBOL Traceability:** Every test references COBOL program, paragraph, lines
3. **Naming Conventions:** Clear, descriptive names following `{Class}_{Scenario}_{Expected}` pattern
4. **FluentAssertions:** Use `.Should()` syntax with COBOL context in messages
5. **SetUp/TearDown:** Initialize/dispose DbContext in integration tests
6. **Known Test Data:** Use pre-seeded test data, not random values
7. **Performance Testing:** Always validate query execution time against NFRs

**Follow this guide for all test code in this Migration Unit.**
