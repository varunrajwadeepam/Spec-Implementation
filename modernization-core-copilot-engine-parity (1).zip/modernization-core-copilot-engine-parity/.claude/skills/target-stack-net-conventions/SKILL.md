---
name: target-stack-net-conventions
description: Implementation conventions for the .NET target stack (.NET Framework 4.8 / WCF SOAP / Entity Framework 6 / Unity / NLog / NUnit / IIS / DB2 LUW). Single source of truth for the stack-convention rules applied while implementing a story. Load whenever a speckit implementation agent runs on a portfolio whose declared stack (portfolios/{portfolio}/inputs/target-stack-net.md) is .NET/WCF.
---

# .NET Target-Stack Conventions

Conventions for implementing Migration Units on the .NET Framework 4.8 / WCF / DB2 LUW stack. The implementation agent (speckit `plan`/`implement`) reads this file and applies the relevant sections when writing or reviewing code for a story. Rule IDs (e.g. `[EF6-02]`) are stable — cite them in generated artifacts.

**Precedence:** the portfolio's `portfolios/{portfolio}/inputs/target-stack-net.md` is authoritative for technology and version choices. The version pins below are validated defaults for .NET 4.8 + DB2 LUW 11.x — if the portfolio's target-stack file disagrees, the portfolio file wins.

---

## Service Contracts — WCF / WSDL (applied during implementation)

WCF SOAP services use `BasicHttpBinding` with SOAP 1.1. The WSDL contract defines the service interface, operations, message schemas, and SOAP bindings.

| WCF Concept | WSDL 1.1 Element |
|-------------|-----------------|
| Service Contract (`[ServiceContract]`) | `<wsdl:portType>` |
| Operation Contract (`[OperationContract]`) | `<wsdl:operation>` within portType |
| Data Contract (`[DataContract]`) | `<xsd:complexType>` in types section |
| Message parameters | `<wsdl:message>` with parts referencing XSD types |
| SOAP Binding | `<wsdl:binding>` with `<soap:binding>` transport |
| Service Endpoint | `<wsdl:service>` with `<soap:address>` location |

**[WSDL-01]** All WSDL documents must use WSDL 1.1 format (most compatible with .NET Framework 4.8 WCF).

**[WSDL-02]** SOAP binding must use `BasicHttpBinding` style: document/literal wrapped.

**[WSDL-03]** All message schemas must be defined using XSD (XML Schema Definition) in the `<wsdl:types>` section.

**[WSDL-04]** Request and response messages must include all fields from the COMMAREA interface contract (see the portfolio's client-specific skill).

**[WSDL-05]** Fault messages must be defined for each error category (validation errors, DB2 errors, business logic errors) using `<wsdl:fault>`.

**[WSDL-06]** All XSD types must include annotations with field-level descriptions explaining business meaning and validation rules.

**[WSDL-07]** Service endpoint URL should use placeholder `http://localhost:8080/{ServiceName}.svc` (will be replaced at deployment).

---

## Data Access — Entity Framework 6 (applied during implementation)

**[EF6-01]** Use Code First approach with existing database — entities map to existing DB2 tables, not code-generated tables.

**[EF6-02]** One DbContext per bounded context (not per service). All services within an MU share the same DbContext.

**[EF6-03]** Use Repository Pattern for data access — no direct DbContext access from service layer.

**[EF6-04]** Connection string uses `IBM.Data.DB2` ADO.NET provider.

**[EF6-05]** Connection pooling: min 5, max 100 connections.

**[EF6-06]** Query timeout: 30 seconds default (configurable per repository method).

## DB2 LUW Naming Conventions (applied during implementation)

**[DB2-01]** Schema naming: `{MAINFRAME_SCHEMA}_LUW` (e.g., `UWR` → `UWR_LUW`).

> ⚠️ **Cross-stack inconsistency to verify:** the Java stack convention preserves the mainframe schema name unchanged (no `_LUW` suffix, per `TSA-db2-migration.md`). Confirm the portfolio's TSA DB2 migration decision before applying [DB2-01] — the TSA artifact wins over this default.

**[DB2-02]** Table names preserved from mainframe (e.g., `POLICY`, `APPLICANT`).

**[DB2-03]** Column names preserved from mainframe (e.g., `POLICY_NBR`, `APPLICANT_ID`).

**[DB2-04]** Primary keys must be defined in EF6 entity using `[Key]` attribute or Fluent API.

**[DB2-05]** Foreign keys must be defined using navigation properties and Fluent API relationships.

## Data Access Patterns (applied during implementation)

**[DATA-01]** Read-heavy operations: use `.AsNoTracking()` for performance.

**[DATA-02]** Single-row lookups: use `.FirstOrDefault()` or `.SingleOrDefault()`.

**[DATA-03]** Multi-row queries: use `.Where()` with indexed columns.

**[DATA-04]** Cursor-based operations (e.g., CLAIM_HISTORY): use `.Take(n)` to limit rows fetched.

**[DATA-05]** No writes in POC scope — all operations are read-only (SELECT only).

---

## Project Structure (applied during implementation)

**[PROJ-01]** Use Visual Studio solution (.sln) with multiple projects per MU (layered architecture).

**[PROJ-02]** Project naming convention: `{MU-Name}.{Layer}`

Example (illustrative underwriting MU — derive real names from the portfolio's artifacts):
- `UnderwritingRiskAssessment.Services` (WCF services)
- `UnderwritingRiskAssessment.Application` (business logic)
- `UnderwritingRiskAssessment.DataAccess` (repositories, DbContext)
- `UnderwritingRiskAssessment.Domain` (entities, interfaces)
- `UnderwritingRiskAssessment.Infrastructure` (logging, DI, utilities)

**[PROJ-03]** All projects target .NET Framework 4.8 (not .NET Core, not .NET Standard).

**[PROJ-04]** Use NuGet for all external dependencies (no DLL references).

## NuGet Package Versions (applied during implementation)

**[PKG-01]** Entity Framework: `EntityFramework 6.4.4`

**[PKG-02]** IBM DB2 Provider: `IBM.Data.DB2` version `11.5.8000.0` or later (compatible with DB2 LUW 11.x and .NET Framework 4.8)

**Note:** Do NOT use `IBM.Data.DB2.Core` — it is a .NET Core package and is incompatible with .NET Framework 4.8.

**[PKG-03]** Unity Container: `Unity 5.11.10`

**[PKG-04]** NLog: `NLog 5.2.8` and `NLog.Config 4.7.15`

**[PKG-05]** Testing: `NUnit 3.14.0`, `Moq 4.20.70`, `FluentAssertions 6.12.0`

**[PKG-06]** WCF dependencies are built-in to .NET Framework 4.8 (no NuGet packages needed for `System.ServiceModel`).

**Note:** The pinned versions above are validated for .NET Framework 4.8 and DB2 LUW 11.x. Implementation teams should verify these versions are still current at deployment time.

## WCF Configuration (applied during implementation)

**[WCF-01]** Use `BasicHttpBinding` for all WCF services (SOAP 1.1).

**[WCF-02]** Service endpoint pattern: `http://{hostname}:8080/{ServiceName}.svc`

**[WCF-03]** Configure message size limits (maxReceivedMessageSize: 2MB, maxBufferSize: 2MB).

**[WCF-04]** Enable detailed error messages in development (includeExceptionDetailInFaults: true).

**[WCF-05]** Use Unity `ServiceHostFactory` for dependency injection.

## IIS Hosting (applied during implementation)

**[IIS-01]** IIS Application Pool: .NET CLR v4.0, Integrated pipeline mode.

**[IIS-02]** Application Pool Identity: Custom service account (not ApplicationPoolIdentity).

**[IIS-03]** Enable Windows Authentication (disable Anonymous Authentication in production).

**[IIS-04]** Connection string stored in Web.config (encrypted using `aspnet_regiis` in production).

## CA:Gen Runtime Utilities — shared static library (applied during implementation)

Applies only when `codegen: cagen`. Realises the reusable decision **ADR-CAGEN-TIR-UTILS** (see the `cagen-programs` skill) for the .NET stack. Governs `TIR*` runtime modules (disposition `shared-static-util`), not business programs.

**[UTIL-01]** CA:Gen `TIR*` runtime utilities (date/numeric/view conversion) are realised as `static` methods on a `static` class in a **dedicated shared library project** — `{Solution}.Common` (or `CaGen.Runtime`) — referenced by every MU project and **not** duplicated per MU. Implement from the documented behavior in the `cagen-programs` `reference/tir-runtime-modules.md`.

**[UTIL-02]** These utilities are **NOT registered in Unity** and **not injected** — the **one sanctioned exception to [WCF-05]**. Callers invoke the static method directly (e.g. `CaGenDateUtil.ToDb2Date(view)`). A stateless deterministic converter is not a component and has no lifecycle.

**[UTIL-03]** Never define an interface + Moq mock for a `TIR*` utility and never register one in the container. Unit-test the static method directly with NUnit against its documented cases (no Moq double); downstream tests call the **real** utility — it is pure and fast.

**[UTIL-04]** Implement inverse conversions together for round-trip consistency (e.g. `TIRD2VW`/`TIRVW2D`); the `{Solution}.Common` library is a cross-MU dependency, built once and reused by fan-in.

---

## Testing Framework (applied during implementation)

For the full TDD workflow, COBOL-to-test traceability rules, and worked NUnit
patterns, read [reference/test-code-guide.md](reference/test-code-guide.md) next
to this file. Read it on demand rather than by default — it is ~700 lines.

**[TEST-01]** Use NUnit 3.x for all test projects (not MSTest, not xUnit).

**[TEST-02]** Use Moq 4.x for mocking dependencies (interfaces, DbContext).

**[TEST-03]** Use FluentAssertions 6.x for readable assertions.

**[TEST-04]** Use NUnit3TestAdapter for Visual Studio Test Explorer integration.

## Test Project Structure (applied during implementation)

**[TEST-05]** Three test projects per MU:
- `{MU-Name}.Tests.Unit` — Unit tests (fast, isolated)
- `{MU-Name}.Tests.Integration` — Integration tests (DB2, slow)
- `{MU-Name}.Tests.Contract` — WSDL contract tests

**[TEST-06]** Test class naming: `{ClassUnderTest}Tests.cs`

**[TEST-07]** Test method naming: `{MethodUnderTest}_{Scenario}_{ExpectedBehavior}`

## Code Coverage (applied during implementation)

**[COV-01]** Minimum 80% code coverage enforced by SonarQube.

**[COV-02]** Exclude from coverage: DTOs, entities, enums, auto-generated code.

**[COV-03]** 100% coverage required for: business logic (scoring, validation), formatters.

**[COV-04]** Integration tests contribute to coverage (not just unit tests).

## Test Data Management (applied during implementation)

*(Test-data rule IDs are scoped to this section — distinct from the Data Access Patterns `[DATA-*]` rules above.)*

**[DATA-01]** Use dedicated test database (DB2 LUW test instance).

**[DATA-02]** Test data setup: SQL scripts in `tests/TestData/` folder.

**[DATA-03]** Each test class has `[SetUp]` and `[TearDown]` for test data lifecycle.

**[DATA-04]** Use test data builders for complex object creation (e.g., PolicyBuilder).
