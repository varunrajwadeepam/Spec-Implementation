---
name: insurance-underwriting-domain
description: A pure domain knowledge skill covering how insurance underwriting works as a business discipline — policy lifecycle flows, risk assessment principles, industry standards (ACORD, NAIC, ISO), regulatory obligations, product types (Auto, Home, Life, Health, Commercial), and the roles of carriers, agents, brokers, and reinsurers. Technology agnostic — describes what underwriting firms do and why, not how any specific system implements it. Intended as the foundational domain reference for business analysts, solution architects, SMEs, and project teams working on insurance modernization programs including mainframe migration, process improvement, vendor evaluation, and capability assessments. Use together with the portfolio's client-specific modernization skill when available (the portfolio's client_skill) — the client-specific skill takes precedence for any client-specific decision.
---

IMPORTANT: This skill is technology-agnostic domain knowledge. When a client-specific skill (the portfolio's `client_skill`) is also loaded, the client-specific skill takes precedence. Use this skill to understand the underlying business logic, industry context, and standard terminology behind any client-specific decision.

# Insurance Underwriting Domain Knowledge

This skill makes Claude a knowledgeable domain expert on how insurance underwriting works as a business. It covers the full underwriting lifecycle, product-specific considerations, regulatory environment, key participants, and standard industry data models. Applicable to any P&C or Life carrier, MGA, or program administrator operating in the US market.

---

## Part 1: The Insurance Value Chain

### 1.1 Key Participants

| Participant | Role |
|-------------|------|
| **Carrier / Insurer** | Bears the risk; issues the policy; pays claims |
| **Agent (Captive)** | Represents a single carrier; sells only that carrier's products |
| **Agent (Independent) / Broker** | Represents the insured; shops multiple carriers; owes duty to client |
| **Managing General Agent (MGA)** | Authorized to underwrite and bind on behalf of a carrier within delegated authority |
| **Reinsurer** | Assumes a portion of the carrier's risk in exchange for a premium cession |
| **Program Administrator** | Manages a book of specialty or affinity business under a carrier's paper |
| **Wholesale Broker / Surplus Lines** | Places non-standard or hard-to-place risks with E&S carriers |

### 1.2 The Insurance Value Chain

```
[Client / Insured]
  | Application (direct, agent, broker, web portal)
[Distribution Channel]
  | Submission
[Underwriting Platform]
  | Eligibility Check → Data Acquisition → Risk Scoring → Decision
  ↓
[Decision: APPROVE / REFER / DECLINE]
  ↓ (if APPROVE)
[Policy Issuance]
  | Policy document, coverage schedule, premium notice
  ↓
[Billing & Collections]
  | Premium installments, commission payment to agent
  ↓
[Policy Administration]
  | Endorsements, renewals, cancellations, reinstatements
  ↓
[Claims Management]
  | First Notice of Loss → Investigation → Adjudication → Settlement
  ↓
[Reinsurance Reporting]
  | Cession statements, loss bordereau, premium bordereau
  ↓
[Regulatory & Actuarial Reporting]
  | NAIC filings, state statutory reporting, loss development triangles
```

---

## Part 2: Policy Lifecycle

### 2.1 Application & Submission

- Submission arrives from agent, broker, or direct channel (web, phone, API)
- ACORD application forms are the industry standard (ACORD 125 for Commercial, ACORD 80 for Homeowners, etc.)
- Submission includes: applicant identity, risk location, coverage requested, prior loss history, prior carrier information
- Admitted vs. E&S distinction: admitted carriers must file rates/forms with the state; E&S (surplus lines) carriers have more pricing flexibility

### 2.2 Underwriting Decision Types

| Decision | Meaning |
|----------|---------|
| **Auto-Approve (Straight-Through)** | Application meets all eligibility and scoring criteria; policy bound without human review |
| **Refer** | Application meets basic eligibility but has exceptions or complexity requiring a human underwriter |
| **Decline** | Application fails eligibility or exceeds maximum risk appetite; no offer made |
| **Counter-offer** | Carrier willing to insure but at different terms (higher deductible, exclusions, sub-limits) |
| **Hold / Pend** | More information required (inspection, MVR, loss runs) before decision |

### 2.3 Policy Issuance

- Policy number assigned (often includes state code, line of business code, sequence number)
- Policy documents generated: declarations page, coverage form, endorsements, exclusions
- Effective date and expiration date recorded
- Premium calculated and premium notice issued
- Agent / broker commission recorded and scheduled

### 2.4 Mid-Term Changes (Endorsements)

Common mid-term endorsements:
- Add/remove a vehicle or driver (Auto)
- Change coverage limits or deductibles
- Add a lienholder or mortgagee
- Change named insured
- Add a scheduled item (inland marine, jewelry floater)

Each endorsement triggers a premium adjustment (return premium or additional premium) and re-rates the policy.

### 2.5 Renewal

- Renewal offer generated 45–60 days before expiration (state-specific notice requirements)
- Risk re-underwritten at renewal: new loss runs, new credit score pull (where permitted), updated valuation
- Non-renewal requires advance notice (typically 30–60 days, state-specific)
- Renewal may be subject to rate change (filed rate change + individual risk adjustment)

### 2.6 Cancellation & Reinstatement

- **Flat cancellation**: cancelled from inception — as if policy never existed
- **Short-rate cancellation**: insured cancels mid-term; carrier retains a penalty percentage
- **Pro-rata cancellation**: carrier cancels; insured receives full pro-rata refund
- Reinstatement: lapsed policy re-activated, usually with a statement of no loss and payment of back premium

---

## Part 3: Risk Assessment & Underwriting Principles

### 3.1 Core Underwriting Principles

| Principle | Description |
|-----------|-------------|
| **Insurable interest** | The insured must have a financial stake in the risk being insured |
| **Utmost good faith (Uberrimae fidei)** | Both parties must disclose all material facts |
| **Indemnity** | Insurance restores the insured to pre-loss financial position — no profit |
| **Subrogation** | After paying a claim, the carrier steps into the insured's shoes to recover from liable third parties |
| **Contribution** | When multiple policies cover the same loss, each pays proportionately |

### 3.2 Risk Factors by Line of Business

**Personal Auto:**
- Driver factors: age, gender (where permitted), years licensed, violations, at-fault accidents, DUI/DWI
- Vehicle factors: make, model, year, VIN, use (pleasure vs. commute vs. commercial), annual mileage
- Territory: garaging zip code, urban vs. rural, theft rates
- Credit-based insurance score (CBIS) — where permitted by state law

**Homeowners:**
- Property: age of home, construction type (frame, masonry, mixed), square footage, roof age and material
- Location: proximity to fire station, flood zone (FEMA designation), coastal/wind zone, crime index
- Coverage: dwelling limit vs. replacement cost value (RCV), personal property limit, liability limit
- Loss history: CLUE report (Comprehensive Loss Underwriting Exchange) — prior claims on the property

**Life:**
- Medical underwriting: health history, build (height/weight), tobacco use, family history
- Financial underwriting: income, net worth, existing coverage, insurable interest for third-party ownership
- Aviation, avocation, foreign travel exclusions or flat extras
- Simplified issue (no exam) vs. fully underwritten

**Health (Group and Individual):**
- ACA-compliant individual market: guaranteed issue, no medical underwriting
- Group: experience-rated (large groups) or community-rated (small groups)
- Stop-loss (aggregate and specific) for self-insured employers

**Commercial Lines:**
- General Liability: SIC code, payroll, revenue, prior losses, operations description
- Commercial Property: replacement cost valuation (RCV), coinsurance clause, business income period
- Workers' Compensation: class codes by job type, experience modification factor (EMod)
- Commercial Auto: fleet size, driver list, vehicle schedule, radius of operations
- Professional Liability / E&O: revenue, years in business, prior claims, retroactive date

### 3.3 Credit-Based Insurance Scoring

Used in personal lines (Auto, Homeowners) where permitted by state:
- Based on credit bureau data (Equifax, Experian, TransUnion) — not the same as a loan credit score
- Factors: payment history, outstanding balances, length of credit history, new credit inquiries
- States that prohibit or restrict: CA, HI, MD, MA, MI, OR (restrictions vary)
- Must be disclosed to the applicant if it adversely affects the rate

### 3.4 Loss History Sources

| Source | Description |
|--------|-------------|
| **CLUE (LexisNexis)** | Comprehensive Loss Underwriting Exchange — claims history for personal auto and property |
| **MVR** | Motor Vehicle Report — driving record including violations and accidents |
| **ISO / Verisk** | Industry loss data, actuarial services, catastrophe models |
| **A-PLUS (Verisk)** | Commercial lines loss history database |
| **Credit Bureau** | CBIS where permitted |

---

## Part 4: Products

### 4.1 Personal Lines

| Product | Key Coverage | Typical Policy Term |
|---------|-------------|-------------------|
| Personal Auto | Liability, collision, comprehensive, UM/UIM, PIP/MedPay | 6 or 12 months |
| Homeowners (HO-3) | Dwelling, other structures, personal property, ALE, liability | 12 months |
| Renters (HO-4) | Personal property, liability, ALE | 12 months |
| Condo (HO-6) | Interior dwelling, personal property, liability | 12 months |
| Umbrella | Excess liability over auto and home | 12 months |
| Life (Term) | Death benefit for a defined term | 10/20/30 years |
| Life (Whole / UL) | Permanent death benefit + cash value accumulation | Permanent |

### 4.2 Commercial Lines

| Product | Common Triggers / Exposures |
|---------|----------------------------|
| BOP (Business Owner's Policy) | Small commercial bundled GL + property |
| Commercial General Liability | Bodily injury and property damage to third parties |
| Commercial Property | Building and business personal property |
| Workers' Compensation | Statutory benefits for work-related injuries |
| Commercial Auto | Owned, hired, and non-owned vehicles |
| Professional Liability (E&O) | Claims arising from professional services |
| D&O | Claims against directors and officers |
| Cyber Liability | Data breach, ransomware, business interruption |

---

## Part 5: Regulatory Environment

### 5.1 US Insurance Regulation Structure

- Insurance is regulated at the state level — no federal insurance regulator for most lines
- Each state has an Insurance Department that licenses carriers, agents, and brokers
- Rates and policy forms must be filed and approved in most states before use (file-and-use vs. prior-approval)

### 5.2 Key Regulatory Bodies and Standards

| Body | Role |
|------|------|
| **NAIC** | Model laws, regulatory data standards, financial solvency monitoring |
| **ISO / Verisk** | Develops standard policy forms, rates, and actuarial tools licensed by carriers |
| **ACORD** | Industry standards body for data exchange, application forms, and XML messaging |
| **State DOIs** | Licensing, rate/form approval, market conduct exams, consumer complaints |
| **FINRA / SEC** | Variable life and annuity products (securities component) |

### 5.3 Key NAIC Data Calls

| Filing | Frequency | Content |
|--------|-----------|---------|
| Annual Statement (Yellow Book) | Annual | Full statutory financial statements |
| Quarterly Statement | Quarterly | Abbreviated statutory financials |
| Market Conduct Annual Statement (MCAS) | Annual | Claims, underwriting, producer data |
| Call for Experience | Annual | Premium and loss data by state and line |

### 5.4 ACORD Standards

- **ACORD XML** — industry standard for electronic data exchange between carriers, MGAs, agents, and vendors
- Key ACORD transactions: AL3 (personal auto), ACORD 125 (commercial application), ACORD 80 (homeowners)
- ACORD SEMCI: single-entry, multiple-company interface for comparative raters

---

## Part 6: Core Data Model Concepts

### 6.1 Core Entities

| Entity | Description |
|--------|-------------|
| **Policy** | The insurance contract — policy number, effective/expiration dates, coverage terms |
| **Insured / Named Insured** | The party whose risk is insured |
| **Risk / Location** | The physical object or activity being insured (vehicle, property, business) |
| **Coverage** | A specific protection (liability, collision, dwelling) within a policy |
| **Premium** | The price of coverage — written, earned, unearned |
| **Endorsement** | A mid-term change to a policy |
| **Claim** | A demand for payment under the policy |
| **Loss** | The actual loss event — may generate one or more claims |
| **Reserve** | Carrier's estimate of future claim payments — case reserve + IBNR |
| **Agent / Producer** | The distribution entity that sold the policy |
| **Commission** | Producer compensation — flat percentage or tiered schedule |

### 6.2 Premium Concepts

| Concept | Definition |
|---------|-----------|
| **Written Premium** | Total premium bound at policy inception or endorsement |
| **Earned Premium** | Portion of written premium for coverage period already elapsed |
| **Unearned Premium Reserve (UPR)** | Written minus earned — liability for unexpired coverage |
| **In-Force Premium** | Total premium on all active policies at a point in time |
| **Net Premium** | Gross premium minus reinsurance ceded premium |

### 6.3 Loss & Reserve Concepts

| Concept | Definition |
|---------|-----------|
| **IBNR** | Incurred But Not Reported — actuarial estimate of unfiled claims |
| **Loss Development** | How losses grow over time from initial report to final settlement |
| **Loss Ratio** | Incurred losses ÷ earned premium — primary profitability metric |
| **Combined Ratio** | Loss ratio + expense ratio — below 100% = underwriting profit |
| **LAE** | Loss Adjustment Expense — cost of investigating and settling claims |

---

## Part 7: External Integration Points

| System / Party | Integration Type | Data Exchanged |
|----------------|-----------------|---------------|
| **LexisNexis / CLUE** | API / batch | Prior loss history for property and auto |
| **MVR providers** (Aamva, state DMVs) | API / batch | Driving record, violations, accidents |
| **Credit bureaus** (Equifax, Experian, TransUnion) | API | Credit-based insurance score |
| **ISO / Verisk** | API / file | Property valuations, actuarial data, catastrophe models |
| **ACORD XML exchange** | XML API | Agency-carrier data interchange, policy transactions |
| **State DOI e-filing portals** | File / API | Rate and form filings, market conduct data |
| **Reinsurers** | File / API | Bordereau, cession statements, loss advice |
| **Print / fulfillment vendors** | File | Policy documents, billing notices |
| **Payment processors** | API | Premium collection, return premium disbursement |

---

## Part 8: Glossary

| Term | Definition |
|------|-----------|
| **ALE** | Additional Living Expenses — temporary housing costs after a covered property loss |
| **Binder** | Temporary evidence of insurance before the policy is issued |
| **CBIS** | Credit-Based Insurance Score |
| **CLUE** | Comprehensive Loss Underwriting Exchange — prior claims database |
| **Coinsurance** | Clause requiring insured to carry coverage to a minimum % of value |
| **Combined Ratio** | Loss ratio + expense ratio; below 100% = underwriting profit |
| **Dec Page** | Declarations page — summary of insured, risk, coverage, premium, dates |
| **EMod** | Experience Modification Factor — workers' comp rating adjustment |
| **E&S** | Excess and Surplus Lines — non-admitted market for non-standard risks |
| **FNOL** | First Notice of Loss — initial claim report |
| **HO-3** | Standard homeowners policy form |
| **IBNR** | Incurred But Not Reported claims reserve |
| **ISO** | Insurance Services Office (now Verisk) — standard forms and rates |
| **Lapse** | Policy termination due to non-payment of premium |
| **Loss Run** | Report of prior claims on a risk |
| **MGA** | Managing General Agent |
| **MVR** | Motor Vehicle Report |
| **NAIC** | National Association of Insurance Commissioners |
| **PIP** | Personal Injury Protection — no-fault medical coverage |
| **Pro-Rata** | Proportional premium return or cancellation |
| **RCV** | Replacement Cost Value |
| **Reinstatement** | Restoring a lapsed policy |
| **Subrogation** | Carrier's right to recover from a liable third party after paying a claim |
| **UM/UIM** | Uninsured/Underinsured Motorist coverage |
| **UPR** | Unearned Premium Reserve |
| **Verisk** | Parent of ISO, AIR Worldwide, LexisNexis Risk Solutions |
