---
name: mermaid
description: Mermaid diagramming rules — load before writing any mermaid fenced block. Covers flowchart TD/LR, C4Context, erDiagram, and sequenceDiagram types. Defines rules M-01 to M-21 preventing parse failures (no \n in labels, no em dashes, alphanumeric IDs only), pre-write checklist, reference patterns, and failure-mode table. Mandatory for all agents that emit mermaid code blocks.
---

# Mermaid Diagramming Rules

This skill is **mandatory** for any agent or task that produces a Mermaid code block.
Load it before writing any `mermaid` fenced block. These rules apply regardless of diagram type.

---

## Supported diagram types in this project

- `flowchart TD` / `flowchart LR` — primary type for data flows, call graphs, migration wave sequences
- `C4Context` — system context diagrams showing people, systems, and external dependencies
- `erDiagram` — entity-relationship diagrams (database schemas only)
- `sequenceDiagram` — cross-service interaction sequences

Do not use `graph TD` — use `flowchart TD` instead (same syntax, better parser support).

---

## Flowchart rules

### Node labels

**[M-01] Never use `\n` inside node labels.** It is not valid Mermaid syntax and breaks rendering in all preview tools (VS Code, GitHub, gitlab, claude.ai).

```
❌  DRIVER["ESDRV212\nBatch Dispatcher\n(COBOL)"]
✅  DRIVER["`ESDRV212
Batch Dispatcher
(COBOL)`"]
```

**[M-02] Use backtick labels for any node that needs multiple lines or special characters.**
Wrap the entire label in backtick pairs inside the bracket:

```
NODE["`Line one
Line two
Line three`"]
```

Backtick labels support:
- Line breaks (actual newlines inside the backticks)
- `@` symbols (safe in backtick labels)
- Parentheses, colons, slashes

**[M-03] Do not use em dashes (`—`) inside node labels or subgraph titles.**
Em dashes cause parse failures in most Mermaid renderers. Use ` - ` (space-hyphen-space) instead.

```
❌  subgraph ACL_01["ACL-01 Seam (R-07 — mechanism UNKNOWN)"]
✅  subgraph ACL_01["ACL-01 Seam (R-07 - mechanism UNKNOWN)"]
```

**[M-04] Keep node IDs alphanumeric and underscore-only.** No hyphens, spaces, or dots in the ID itself (hyphens in the display label are fine).

```
❌  MU-02["Payment Processing"]
✅  MU02["Payment Processing"]
```

**[M-05] Do not use `<br>` or `<br/>` inside standard `["..."]` labels.** They render as literal text. Use backtick labels (M-02) for multi-line instead.

---

### Edge labels

**[M-06] Never use `\n` inside edge labels.** Keep edge labels to a single line. Move secondary detail to a `%%` comment or prose below the diagram.

```
❌  A -- "CALL ESCAL070 USING BILL-NEW-DATA\n(line 6535)" --> B
✅  A -- "CALL ESCAL070 (line 6535)" --> B
```

**[M-07] Keep edge labels short — under 60 characters.** Long edge labels overlap adjacent nodes and cause mis-renders. Put detail in the prose section below the diagram, not on the arrow.

**[M-08] Do not use em dashes (`—`) in edge labels.** Same issue as M-03 — use ` - ` instead.

---

### Subgraphs

**[M-09] Subgraph IDs must be alphanumeric + underscore only.** The display title (in quotes) can contain spaces, parentheses, and hyphens.

```
✅  subgraph SHR_MU00["SHR-MU-00 acme-ref-domain-model"]
```

**[M-10] Do not nest more than 2 subgraph levels.** Three or more levels cause layout failures in most renderers.

**[M-11] `direction` inside a subgraph is only valid in Mermaid v10.3+.** If the target render environment is unknown, omit `direction` inside subgraphs and rely on the top-level direction only.

---

### Style directives

**[M-12] `style` directives must reference node IDs (not subgraph IDs).** Styling a subgraph ID directly has no effect in most renderers.

```
✅  style SVC130 fill:#ffe1e1,stroke:#cc0000
❌  style MU02 fill:#ffe1e1   %% subgraph ID — no effect
```

**[M-13] Use only hex color values in `style` directives.** Named colors (`red`, `yellow`) are not reliably supported.

---

## Pre-write checklist

Before writing any `mermaid` block, verify every item:

**For all diagram types:**
- [ ] No `\n` escape sequences anywhere in the block (node labels, edge labels, subgraph titles)
- [ ] No em dash `—` anywhere in the block
- [ ] All node / element IDs are alphanumeric + underscore only

**For `flowchart`:**
- [ ] All multi-line labels use backtick syntax
- [ ] All edge labels are under 60 characters and single-line
- [ ] `subgraph` IDs are alphanumeric + underscore only (display titles can have spaces/hyphens)
- [ ] `style` directives reference node IDs only, with hex colors
- [ ] No more than 2 subgraph nesting levels

**For `C4Context`:**
- [ ] Opening keyword is exactly `C4Context` (not `c4context`, not `C4 Context`)
- [ ] Every `Person`, `System`, `SystemDb` element has all three arguments: id, label, description
- [ ] Every `Enterprise_Boundary` / `System_Boundary` has a matching closing `}`
- [ ] All relationships use `Rel(from, to, "label")` — no `-->` arrows
- [ ] External actors/systems use the `_Ext` variant (`Person_Ext`, `System_Ext`, `SystemDb_Ext`)

---

## Reference: corrected multi-line node pattern

```mermaid
flowchart TD
    subgraph SVC_LAYER["esrdpps-payment-processing (ESRD-PPS-MU-02)"]
        direction TB
        SVC070["`Escal070CalculationService
@Service - CY2007
cyclomatic 141`"]
        SVC130["`Escal130CalculationService
@Service - CY2013
cyclomatic 572 - HIGH-RISK
IMPLEMENT LAST`"]
    end

    CALLER -- "CALL ESCAL070 (line 6535)" --> SVC070
    CALLER -- "CALL ESCAL130 (line 6425)" --> SVC130

    style SVC130 fill:#ffe1e1,stroke:#cc0000
```

---

## Reference: erDiagram pattern

```mermaid
erDiagram
    POLICY {
        varchar policy_nbr PK
        varchar product_code
        date effective_date
    }
    APPLICANT {
        varchar applicant_id PK
        varchar policy_nbr FK
    }
    POLICY ||--o{ APPLICANT : "has"
```

Rules specific to `erDiagram`:
- Entity names must be single words (no spaces, no hyphens)
- Field types are free-form strings — use the actual DB2 type (varchar, decimal, date, integer)
- PK / FK suffixes are supported in Mermaid v10+
- Relationship labels must be in double quotes

---

## C4Context rules

Use `C4Context` for system context diagrams — the outermost view showing actors, the system under migration, and external dependencies. Do not use it for internal component or data-flow detail; use `flowchart` for those.

**[M-14] The opening keyword is `C4Context` — no spaces, capital C and second capital C.**

```
❌  ```c4context
❌  ```C4 Context
✅  ```mermaid
    C4Context
```

**[M-15] Use only the six supported element types.** Other keywords are silently ignored or cause parse errors.

| Keyword | Use for |
|---|---|
| `Person(id, "label", "descr")` | Human actor (staff, customer, claimant) |
| `Person_Ext(id, "label", "descr")` | External human actor (third-party user) |
| `System(id, "label", "descr")` | System being documented (in-scope) |
| `System_Ext(id, "label", "descr")` | External system / dependency |
| `SystemDb(id, "label", "descr")` | Database system |
| `SystemDb_Ext(id, "label", "descr")` | External database |

**[M-16] Element IDs follow the same rule as flowchart node IDs — alphanumeric and underscore only.** No hyphens.

```
❌  System(esrd-pps, "ESRD-PPS", "Payment pricer")
✅  System(esrd_pps, "ESRD-PPS", "Payment pricer")
```

**[M-17] All three arguments are required: `id`, `"label"`, `"description"`.** Omitting the description argument causes a parse error in Mermaid v10+.

```
❌  System(esrd_pps, "ESRD-PPS")
✅  System(esrd_pps, "ESRD-PPS", "Calculates ESRD prospective payment amounts")
```

**[M-18] Relationships use `Rel(from, to, "label")` — not arrows.** Do not use `-->` syntax inside a `C4Context` block.

```
❌  esrd_pps --> mainframe
✅  Rel(esrd_pps, mainframe, "reads claim data")
```

Optionally add a technology hint as a fourth argument: `Rel(a, b, "label", "REST/JSON")`.

**[M-19] Boundaries use `Enterprise_Boundary`, `System_Boundary`, or `Container_Boundary` with an id and label.** Close every boundary with its matching closing brace. Unclosed boundaries are the most common C4Context parse failure.

```
Enterprise_Boundary(b_epam, "EPAM Migration Scope") {
    System(esrd_pps, "ESRD-PPS", "Payment pricer")
}
```

**[M-20] `title` and `UpdateLayoutConfig` are optional but must appear at the top of the block if used**, before any element definitions.

```mermaid
C4Context
    title System context - ESRD-PPS Payment Pricer
    ...elements...
```

**[M-21] Do not mix C4Context keywords with flowchart syntax in the same block.** They are separate diagram types and cannot be combined.

---

## Reference: C4Context pattern

```mermaid
C4Context
    title System context - ESRD-PPS Payment Pricer (MU-02)

    Person(claims_staff, "Claims Staff", "Submits and reviews ESRD claims")

    Enterprise_Boundary(b_internal, "EPAM Migration Scope") {
        System(esrd_pps, "ESRD-PPS Payment Pricer", "Calculates prospective payment amounts for ESRD claims (Java 21 / Spring Boot 3.4)")
    }

    System_Ext(mainframe, "Mainframe COBOL Estate", "Hosts ESDRV212 batch dispatcher during Waves 1-3")
    SystemDb_Ext(db2, "DB2 / ACMEREF Schema", "Reference tables: wage rate, composite index, bundled index (owned by MU-01)")
    System_Ext(cms, "CMS Pricer Feed", "External rate and policy update feed")

    Rel(claims_staff, esrd_pps, "submits claim for pricing")
    Rel(esrd_pps, mainframe, "called by ESDRV212 via ACL-01 (Waves 1-3)")
    Rel(esrd_pps, db2, "reads wage index and rate tables", "JDBC / DB2 JCC")
    Rel(cms, esrd_pps, "provides rate updates")
```

Rules demonstrated above:
- `C4Context` keyword at top of block, after ` ```mermaid `
- `title` line before element definitions
- `Enterprise_Boundary` wraps in-scope systems
- All IDs use underscores (`claims_staff`, not `claims-staff`)
- All elements have three arguments (id, label, description)
- All relationships use `Rel()`, not `-->`
- External systems and DBs use `_Ext` variants

---

## Common failure modes (do not repeat)

| Symptom | Root cause | Fix |
|---|---|---|
| Diagram renders as raw text | Fenced block language tag missing or misspelled | Use ` ```mermaid ` exactly |
| Node shows literal `\n` | `\n` in `["..."]` label | Switch to backtick multiline label |
| Parse error at `—` | Em dash in label or title | Replace with ` - ` |
| Subgraph renders but is empty | `direction` keyword used in Mermaid < v10.3 | Remove `direction` inside subgraphs |
| Edge label overlaps node | Label too long or contains newline | Shorten to < 60 chars, single line |
| `style` directive has no effect | Applied to subgraph ID | Apply to node IDs only |
| Node ID parse error | Hyphen in node ID (e.g. `MU-02`) | Use underscore: `MU02` or `MU_02` |
| C4Context blank render | Opening keyword written as `c4context` or `C4 Context` | Use `C4Context` exactly |
| C4Context parse error | Missing third argument on `Person()` or `System()` | All three args required: id, label, description |
| C4Context boundary not closed | `Enterprise_Boundary` or `System_Boundary` missing closing `}` | Every boundary block must close |
| C4Context arrows not shown | Used `-->` instead of `Rel()` inside C4Context | Replace arrows with `Rel(from, to, "label")` |
| C4Context element not rendered | Hyphen in element ID | Use underscore only in IDs |
