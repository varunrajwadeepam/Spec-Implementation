# CA:Gen TIR Runtime Modules — Reference

> Supporting reference for the `cagen-programs` skill. Loaded on demand when an agent needs
> the behavior of a specific `TIR*` module; it is not part of the skill's default context.
> Applies only to estates whose pack manifest declares `codegen: cagen`.

## Overview

This document describes the CA:Gen runtime modules present in any CA:Gen-generated mainframe estate. These modules provide date conversion, numeric conversion, and date calculation services that support generated COBOL applications.

**Note:** Most TIR modules do not have available COBOL source code. The business logic and COBOL examples provided are reconstructed based on documented behavior and typical implementation patterns.

---

## Table of Contents

1. [TIRD2VW - Date to View](#tird2vw---date-to-view)
2. [TIRDAT2 - Date Functions](#tirdat2---date-functions)
3. [TIRFNUM - Text to Numeric Conversion](#tirfnum---text-to-numeric-conversion)
4. [TIRFNUMD - Date to Number](#tirfnumd---date-to-number)
5. [TIRVPAD - PAD Support](#tirvpad---pad-support)
6. [TIRVW2D - View to Date](#tirvw2d---view-to-date)
7. [TIRFDNUM - Number Processing](#tirfdnum---number-processing)

---

## TIRD2VW - Date to View

### Purpose

Converts dates with value `00010101` (as read from DB2) into `00000000`. A conversion routine that converts a 10-character standard date format into the 8-character CA Gen date format by removing separators.

### Program Definition

| Item | Description |
|------|-------------|
| **Program Name** | TIRD2VW |
| **Product** | CA Gen Runtime |
| **Type** | Date Conversion Runtime Module |
| **Purpose** | Convert external/standard date representation into CA Gen view date format |
| **Input Format** | Standard date (typically YYYY-MM-DD) or DB2 date value |
| **Output Format** | CA Gen date view (YYYYMMDD) |
| **Special Processing** | Converts DB2 minimum date 0001-01-01 to CA Gen zero date 00000000 |
| **Called By** | Generated action diagrams and runtime date functions |

### Business Rules

#### Rule 1 – Standard Date Conversion

```
IF input date = YYYY-MM-DD
THEN Remove separators
     Return YYYYMMDD
```

**Example:**
```
2025-06-15  →  20250615
```

#### Rule 2 – DB2 Null/Minimum Date Handling

```
IF input date = 0001-01-01
THEN Return 00000000
```

This special handling is specifically documented by Broadcom.

#### Rule 3 – Valid Date Preservation

```
IF date is valid
THEN Preserve year
     Preserve month
     Preserve day
     Remove formatting characters only
```

### Input Examples

| Example | Input |
|---------|-------|
| Normal Date | `2024-12-31` |
| Leap Year | `2024-02-29` |
| DB2 Minimum Date | `0001-01-01` |

### Output Examples

| Input | Output |
|-------|--------|
| `2024-12-31` | `20241231` |
| `2024-02-29` | `20240229` |
| `0001-01-01` | `00000000` |

### Processing Flow

```
Application
    |
    V
TIRD2VW
    |
    +--> Validate Date
    |
    +--> Is 0001-01-01 ?
    |         +---+---+
    |         |       |
    |        YES      NO
    |         |       |
    |         V       V
    |    00000000  Remove '-'
    |         |       |
    |         +---+---+
    |             V
    |         YYYYMMDD
    V
Continue
```

### Parameter Layout

```cobol
01 DATE-CONVERSION-AREA.
   05 INPUT-DATE     PIC X(10).
   05 OUTPUT-DATE    PIC X(08).
   05 RETURN-CODE    PIC S9(4) COMP.
```

**Example Values:**
```cobol
INPUT-DATE  = '2025-05-31'
OUTPUT-DATE = '20250531'
RETURN-CODE = 0
```

### COBOL Code (Reconstructed)

```cobol
IDENTIFICATION DIVISION.
PROGRAM-ID. TIRD2VW.

DATA DIVISION.
WORKING-STORAGE SECTION.
01 WS-WORK-DATE.
   05 WS-YEAR    PIC X(4).
   05 WS-MONTH   PIC X(2).
   05 WS-DAY     PIC X(2).

LINKAGE SECTION.
01 LK-DATE-AREA.
   05 LK-IN-DATE     PIC X(10).
   05 LK-OUT-DATE    PIC X(08).

PROCEDURE DIVISION USING LK-DATE-AREA.
    IF LK-IN-DATE = '0001-01-01'
       MOVE '00000000'
         TO LK-OUT-DATE
    ELSE
       MOVE LK-IN-DATE(1:4) TO WS-YEAR
       MOVE LK-IN-DATE(6:2) TO WS-MONTH
       MOVE LK-IN-DATE(9:2) TO WS-DAY
       
       STRING
          WS-YEAR
          WS-MONTH
          WS-DAY
          DELIMITED BY SIZE
          INTO LK-OUT-DATE
       END-STRING
    END-IF
    
    GOBACK.
```

---

## TIRDAT2 - Date Functions

### Purpose

Supports date functions and converts a number of days from December 31, 0000 into a date in YYYYMMDD format.

### Program Definition

| Item | Description |
|------|-------------|
| **Program Name** | TIRDAT2 |
| **Product** | CA Gen Runtime |
| **Type** | Date Service Runtime Module |
| **Purpose** | Support CA Gen date functions |
| **Primary Function** | Convert day count to CA Gen date |
| **Input** | Number of days since 1-JAN-0001 |
| **Output** | Date in YYYYMMDD format |
| **Called By** | Generated Action Diagrams and runtime date services |
| **Related Modules** | TIRDAT, TIRDAT2I, TIRFNUMD, TIRFDNUM |

### Business Rules

#### Rule 1 – Day Count to Date Conversion

```
IF input = number of days since 1-JAN-0001
THEN Calculate corresponding calendar date
     Return YYYYMMDD
```

#### Rule 2 – Leap Year Processing

```
IF calculated date crosses leap years
THEN Apply leap-year rules
     Return valid Gregorian date
```

#### Rule 3 – Date Function Support

```
IF generated Action Diagram uses a CA Gen date function
THEN Invoke TIRDAT2 services
     Perform date calculations
     Return resulting date
```

### Input Examples

TIRDAT2 typically works with an internal date serial number.

| Example | Input | Meaning |
|---------|-------|---------|
| Example 1 | `1` | 1-JAN-0001 |
| Example 2 | `730120` | 730120 days since 1-JAN-0001 |
| Example 3 | `739402` | Internal CA Gen date count |

### Output Examples

| Input | Output |
|-------|--------|
| `1` | `00010101` |
| `739402` | `20240531` |
| `739768` | `20250531` |

### Processing Flow

```
Application
    |
    V
TIRDAT2
    |
    +--> Receive Day Count
    |
    +--> Calculate Year
    |
    +--> Calculate Month
    |
    +--> Calculate Day
    |
    +--> Format YYYYMMDD
    |
    V
Return Date
```

### Parameter Layout

```cobol
01 DATE-CONVERSION-AREA.
   05 INPUT-DAY-COUNT     PIC S9(9) COMP.
   05 OUTPUT-DATE         PIC X(08).
   05 RETURN-CODE         PIC S9(4) COMP.
```

**Example Values:**
```cobol
INPUT-DAY-COUNT = 739768
OUTPUT-DATE     = '20250531'
RETURN-CODE     = 0
```

### COBOL Code (Reconstructed)

```cobol
IDENTIFICATION DIVISION.
PROGRAM-ID. TIRDAT2.

DATA DIVISION.
WORKING-STORAGE SECTION.
01 WS-DAY-COUNT       PIC S9(9) COMP.
01 WS-DATE            PIC X(08).

LINKAGE SECTION.
01 LK-PARAMETERS.
   05 LK-DAYS         PIC S9(9) COMP.
   05 LK-DATE         PIC X(08).

PROCEDURE DIVISION USING LK-PARAMETERS.
* Convert day count to Gregorian date
* (Illustrative only)
    
    MOVE LK-DAYS
      TO WS-DAY-COUNT
    
    MOVE '20250531'
      TO LK-DATE
    
    GOBACK.
```

### Good to Know

- **TIRDAT2** - Support IEF date functions. Converts number of days from December 31, 0000 to a date in YYYYMMDD format.
- **TIRDAT2x** is a user exit that allows modification of values returned from date/time services because TIRDAT itself is not directly modifiable

---

## TIRFNUM - Text to Numeric Conversion

### Purpose

Converts a character string into its integer numeric representation.

### Program Definition

| Item | Description |
|------|-------------|
| **Program Name** | TIRFNUM |
| **Product** | CA Gen Runtime |
| **Type** | Supplied Runtime Function |
| **Toolset Function** | Numtext |
| **Purpose** | Convert text to a numeric value |
| **Input** | Character string or character view |
| **Output** | Integer numeric value |
| **Called By** | Generated Action Diagrams |
| **Related Function** | TIRFCHR (Textnum) |

### Business Rules

#### Rule 1 – Character to Numeric Conversion

```
IF input contains valid numeric characters
THEN Convert text to integer numeric value
     Return integer result
```

**Example:**
```
'12345'  →  12345
```

#### Rule 2 – Decimal Point Processing

```
IF input contains decimal point
THEN Remove decimal point
     Return integer representation
```

**Example:**
```
'123.45'  →  12345
```

#### Rule 3 – Sign Processing

```
IF input begins with + or -
THEN Accept sign as valid input
     Convert to integer representation
     Return numeric result
```

Plus sign, minus sign, and decimal point are the only special characters allowed.

**Example:**
```
'-123.45'  →  12345
```

#### Rule 4 – Invalid Characters

```
IF input contains nonnumeric characters
THEN Return conversion error
```

**Example:**
```
'12AB34'  →  ERROR
```

### Input Examples

| Example | Input |
|---------|-------|
| Example 1 | `'12345'` |
| Example 2 | `'123.45'` |
| Example 3 | `'-9876'` |
| Example 4 | `'+100.25'` |

### Output Examples

| Type | Input | Output |
|------|-------|--------|
| Integer Text | `'12345'` | `12345` |
| Decimal Text | `'123.45'` | `12345` |
| Negative Text | `'-9876'` | `9876` |
| Signed Decimal | `'+100.25'` | `10025` |

### Processing Flow

```
Application
    |
    V
TIRFNUM
    |
    +--> Read Character String
    |
    +--> Validate Characters
    |
    +--> Remove + / - Sign
    |
    +--> Remove Decimal Point
    |
    +--> Convert To Integer
    |
    V
Numeric Result
```

### Parameter Layout

```cobol
01 NUMTEXT-AREA.
   05 INPUT-TEXT        PIC X(30).
   05 OUTPUT-NUMBER     PIC S9(18) COMP.
   05 RETURN-CODE       PIC S9(4) COMP.
```

**Example Values:**
```cobol
INPUT-TEXT    = '123.45'
OUTPUT-NUMBER = 12345
RETURN-CODE   = 0
```

### COBOL Code (Reconstructed)

```cobol
IDENTIFICATION DIVISION.
PROGRAM-ID. TIRFNUM.

DATA DIVISION.
WORKING-STORAGE SECTION.
01 WS-TEXT-IN          PIC X(30).
01 WS-DIGITS           PIC X(30).
01 WS-I                PIC 9(04).

LINKAGE SECTION.
01 LK-PARAMETERS.
   05 LK-TEXT          PIC X(30).
   05 LK-NUMBER        PIC S9(18) COMP.

PROCEDURE DIVISION USING LK-PARAMETERS.
    
    MOVE SPACES TO WS-DIGITS
    MOVE 1 TO WS-I
    
    PERFORM VARYING WS-I FROM 1 BY 1
            UNTIL WS-I > LENGTH OF LK-TEXT
       EVALUATE LK-TEXT(WS-I:1)
          WHEN '0' THRU '9'
             STRING
                WS-DIGITS DELIMITED BY SPACE
                LK-TEXT(WS-I:1)
                DELIMITED BY SIZE
                INTO WS-DIGITS
          WHEN '+'
             CONTINUE
          WHEN '-'
             CONTINUE
          WHEN '.'
             CONTINUE
          WHEN OTHER
             GOBACK
       END-EVALUATE
    END-PERFORM
    
    MOVE FUNCTION NUMVAL(WS-DIGITS)
      TO LK-NUMBER
    
    GOBACK.
```

### Good to Know

- **TIRFNUM** = Numtext runtime function
- Input is a character string or character view
- Allowed special characters are `+`, `-`, and `.`
- Output is an integer numeric value that contains neither sign nor decimal point

---

## TIRFNUMD - Date to Number

### Purpose

TIRFNUMD is a date to number function. TIRFNUMD is called every time a CA Gen action diagram uses the DATENUM function. DATENUM converts a numeric value into a valid date.

There is some naming confusion in the documentation because the CA Gen function name is DATENUM, but the runtime module name is TIRFNUMD. The practical behavior is that TIRFNUMD supports conversion between a CA Gen date value and its numeric YYYYMMDD representation.

### Program Definition

| Item | Description |
|------|-------------|
| **Program Name** | TIRFNUMD |
| **Product** | CA Gen Runtime |
| **Type** | Supplied Runtime Function |
| **Toolset Function** | DATENUM |
| **Purpose** | Convert between CA Gen date values and numeric date representation |
| **Input** | Date or numeric date value |
| **Output** | Numeric YYYYMMDD representation or valid date value |
| **Called By** | Generated Action Diagrams |
| **Related Function** | TIRFDNUM (NUMDATE) |

### Business Rules

#### Rule 1 – Numeric Date to CA Gen Date

```
IF input is numeric YYYYMMDD
THEN Convert numeric value
     Return valid CA Gen date
```

**Example:**
```
20250531  →  31-MAY-2025 (internal date representation)
```

#### Rule 2 – Initialize DB2 Date Fields

A documented use of DATENUM is initializing a DB2 DATE column.

```
IF input = 00010101
THEN Return date value 0001-01-01
```

**Example:**
```
datenum(00010101)  →  0001-01-01
```

#### Rule 3 – Validate Date Components

```
IF YYYYMMDD represents a valid date
THEN Return converted date
ELSE Return error condition
```

### Input Examples

| Example | Input | Note |
|---------|-------|------|
| Example 1 | `20250531` | Normal date |
| Example 2 | `19991231` | End of year |
| Example 3 | `00010101` | DB2 initialization |
| Example 4 | `20240229` | Leap year |

### Output Examples

| Type | Input | Output |
|------|-------|--------|
| Normal Date | `20250531` | `2025-05-31` |
| End of Year | `19991231` | `1999-12-31` |
| DB2 Initialization Date | `00010101` | `0001-01-01` |
| Leap Year | `20240229` | `2024-02-29` |

### Processing Flow

```
Application
    |
    V
TIRFNUMD
    |
    +--> Read Numeric Date
    |
    +--> Validate YYYYMMDD
    |
    +--> Convert To Date
    |
    +--> Return Date Value
    |
    V
Continue Processing
```

### Parameter Layout

```cobol
01 DATENUM-AREA.
   05 INPUT-NUMBER      PIC S9(8).
   05 OUTPUT-DATE       PIC S9(8).
   05 RETURN-CODE       PIC S9(4) COMP.
```

**Example Values:**
```cobol
INPUT-NUMBER = 20250531
OUTPUT-DATE  = 20250531
RETURN-CODE  = 0
```

### COBOL Code (Reconstructed)

```cobol
IDENTIFICATION DIVISION.
PROGRAM-ID. TIRFNUMD.

DATA DIVISION.
WORKING-STORAGE SECTION.
01 WS-YEAR             PIC 9(4).
01 WS-MONTH            PIC 9(2).
01 WS-DAY              PIC 9(2).

LINKAGE SECTION.
01 LK-PARAMETERS.
   05 LK-NUMERIC-DATE  PIC 9(8).
   05 LK-DATE-VALUE    PIC 9(8).

PROCEDURE DIVISION USING LK-PARAMETERS.
    
    MOVE LK-NUMERIC-DATE(1:4)
      TO WS-YEAR
    MOVE LK-NUMERIC-DATE(5:2)
      TO WS-MONTH
    MOVE LK-NUMERIC-DATE(7:2)
      TO WS-DAY
    
    IF WS-MONTH < 1 OR > 12
       GOBACK
    END-IF
    
    MOVE LK-NUMERIC-DATE
      TO LK-DATE-VALUE
    
    GOBACK.
```

### Good to Know

- **TIRFNUMD** is the runtime module invoked for the DATENUM function
- **DATENUM** converts a numeric value into a valid date
- A documented example is `datenum(00010101)` to initialize a DB2 date field to `0001-01-01`

---

## TIRVPAD - PAD Support

### Purpose

TIRVPAD is associated with Procedure Action Diagram (PAD) validation/processing support within the CA Gen runtime environment.

### Program Definition

| Item | Description |
|------|-------------|
| **Program Name** | TIRVPAD |
| **Product** | CA Gen Runtime |
| **Type** | Runtime PAD Support Module |
| **Purpose** | Supports execution/validation of generated Procedure Action Diagram logic |
| **Used By** | Generated CA Gen applications |
| **Runtime Area** | Action Diagram (PAD) processing |
| **Input** | Generated PAD execution context |
| **Output** | Processed action results and status |

CA Gen applications are generated from Procedure Action Diagrams (PADs), which are transformed into COBOL, C, Java, or C# code during generation. The runtime environment executes logic that originated from PAD statements.

### Business Rules

#### Rule 1 – Process PAD Logic

```
IF Action Diagram statement is encountered
THEN Evaluate statement
     Execute business logic
     Update views
     Return processing status
```

#### Rule 2 – Conditional Logic

```
IF PAD condition evaluates TRUE
THEN execute corresponding action
ELSE execute alternate path
```

#### Rule 3 – Error Detection

```
IF PAD processing detects runtime error
THEN Return error status
     Invoke runtime error handling
     Preserve transaction integrity
```

### Input Examples

Runtime modules typically receive control blocks rather than business records.

**Example 1:**
```
ACTION-TYPE   = MOVE
SOURCE-FIELD  = CUSTOMER-NAME
TARGET-FIELD  = WS-CUSTOMER-NAME
```

**Example 2:**
```
ACTION-TYPE   = IF
CONDITION     = CUSTOMER-STATUS = 'A'
```

**Example 3:**
```
ACTION-TYPE   = CALL
TARGET        = CUSTOMER-INQUIRY
```

### Output Examples

#### Successful Processing

**Input:**
```
CUSTOMER-STATUS = 'A'
```

**Output:**
```
CONDITION TRUE
ACTION EXECUTED
RETURN-CODE = 0
```

#### Conditional Failure

**Input:**
```
CUSTOMER-STATUS = 'I'
```

**Output:**
```
CONDITION FALSE
ALTERNATE PATH TAKEN
RETURN-CODE = 0
```

#### Runtime Error

**Input:**
```
INVALID VIEW REFERENCE
```

**Output:**
```
RUNTIME ERROR
MESSAGE GENERATED
RETURN-CODE = 8
```

### Processing Flow

```
Generated Application
    |
    V
TIRVPAD
    |
    +--> Read PAD Context
    |
    +--> Evaluate Statement
    |
    +--> Update Views
    |
    +--> Return Status
    |
    V
Continue Execution
```

### COBOL Code (Reconstructed)

```cobol
IDENTIFICATION DIVISION.
PROGRAM-ID. TIRVPAD.

DATA DIVISION.
WORKING-STORAGE SECTION.
01 WS-RETURN-CODE      PIC S9(4) COMP VALUE 0.

LINKAGE SECTION.
01 LK-PAD-CONTEXT.
   05 LK-ACTION-TYPE   PIC X(08).
   05 LK-CONDITION     PIC X(50).

PROCEDURE DIVISION USING LK-PAD-CONTEXT.
    
    EVALUATE LK-ACTION-TYPE
       WHEN 'MOVE'
          CONTINUE
       WHEN 'IF'
          CONTINUE
       WHEN 'CALL'
          CONTINUE
       WHEN OTHER
          MOVE 8 TO WS-RETURN-CODE
    END-EVALUATE
    
    GOBACK.
```

### Good to Know

- CA Gen applications are built from Procedure Action Diagrams (PADs)
- Runtime execution ultimately processes logic generated from PAD statements
- Runtime components handle error management, tracing, message processing, and execution services

---

## TIRVW2D - View to Date

### Purpose

TIRVW2D converts date to view format. TIRVW2D converts a CA Gen 8-character date to a 10-character standard date including hyphens (`-`). Basically, it is the inverse of TIRD2VW.

### Program Definition

| Item | Description |
|------|-------------|
| **Program Name** | TIRVW2D |
| **Product** | CA Gen Runtime |
| **Type** | Date Conversion Runtime Module |
| **Purpose** | Convert CA Gen internal date format to standard display date format |
| **Input Format** | CA Gen date view (YYYYMMDD) |
| **Output Format** | Standard date (YYYY-MM-DD) |
| **Called By** | Generated Action Diagrams and runtime date functions |

### Business Rules

#### Rule 1 – Convert CA Gen Date to Standard Date

```
IF input date = YYYYMMDD
THEN Insert '-' after year
     Insert '-' after month
     Return YYYY-MM-DD
```

**Example:**
```
20250615  →  2025-06-15
```

#### Rule 2 – Convert Null CA Gen Date

```
IF input date = 00000000
THEN Return 0001-01-01
     OR environment-specific null-date representation
```

**Note:** Broadcom publicly documents the special conversion performed by TIRD2VW (`0001-01-01` → `00000000`) but does not explicitly document the reverse mapping performed by TIRVW2D. The behavior shown above is inferred from the paired conversion architecture and may vary by implementation.

#### Rule 3 – Preserve Date Components

```
IF date is valid
THEN Preserve:
     - Year
     - Month
     - Day
```

### Input Examples

| Example | Input |
|---------|-------|
| Example 1 | `20250531` |
| Example 2 | `19991231` |
| Example 3 | `00000000` |

### Output Examples

| Type | Input | Output |
|------|-------|--------|
| Normal Date | `20250531` | `2025-05-31` |
| End-of-Year Date | `19991231` | `1999-12-31` |
| Null Date | `00000000` | `0001-01-01` or `0000-00-00` |

### Processing Flow

```
Application
    |
    V
TIRVW2D
    |
    +--> Read YYYYMMDD
    |
    +--> Extract Year
    |
    +--> Extract Month
    |
    +--> Extract Day
    |
    +--> Insert '-'
    |
    V
YYYY-MM-DD
```

### Parameter Layout

```cobol
01 DATE-CONVERSION-AREA.
   05 INPUT-DATE      PIC X(08).
   05 OUTPUT-DATE     PIC X(10).
   05 RETURN-CODE     PIC S9(4) COMP.
```

**Example Values:**
```cobol
INPUT-DATE   = '20250531'
OUTPUT-DATE  = '2025-05-31'
RETURN-CODE  = 0
```

### COBOL Code (Reconstructed)

```cobol
IDENTIFICATION DIVISION.
PROGRAM-ID. TIRVW2D.

DATA DIVISION.
LINKAGE SECTION.
01 LK-DATE-AREA.
   05 LK-IN-DATE      PIC X(08).
   05 LK-OUT-DATE     PIC X(10).

PROCEDURE DIVISION USING LK-DATE-AREA.
    
    STRING
       LK-IN-DATE(1:4)
       '-'
       LK-IN-DATE(5:2)
       '-'
       LK-IN-DATE(7:2)
       DELIMITED BY SIZE
       INTO LK-OUT-DATE
    END-STRING
    
    GOBACK.
```

### Good to Know

- **TIRVW2D** - Converts date to view format
- TIRVW2D converts CA Gen 8-char date to 10-char standard date including `-`

---

## TIRFDNUM - Number Processing

### Purpose

TIRFDNUM validates, generates, or formats business identification numbers (account numbers, customer numbers, reference numbers, document numbers, etc.).

**Note:** TIRFDNUM is not a known standard CA Gen runtime component. Without the generated COBOL, CA Gen encyclopedia definition, action diagram, or copybooks, its actual functionality cannot be determined with certainty. The information below is based on common naming conventions and typical implementation patterns.

### Program Definition

| Attribute | Description |
|-----------|-------------|
| **Module Name** | TIRFDNUM |
| **Technology** | CA Gen |
| **Language** | Generated COBOL |
| **Module Type** | Called Procedure Step |
| **Execution Mode** | Batch or Online |
| **Functional Area** | Number Processing |
| **Purpose** | Validate, generate, or format business numbers |

### Functional Description

TIRFDNUM receives a request containing a business identifier or number-related information, validates the format and business rules, optionally generates a new number, and returns the resulting value and status information.

**Common functions:**
- Account number generation
- Customer number assignment
- Document number creation
- Reference number validation
- Check-digit calculation
- Number formatting and normalization

### Business Rules

- Number must not be blank
- Number length must match business rules
- Number must contain valid characters
- Check digit must be valid
- Number range must be authorized
- Generated numbers must be unique
- Sequence numbers must be increased
- Prefix values depend on business type
- Leading zeros must be preserved
- Generated values must pass validation checks
- Hyphens are removed before validation
- Returned number follows enterprise format
- Country-specific formats are supported

### Example Import View

**Layout:**
```cobol
01 IMPORT-VIEW.
   05 REQUEST-TYPE          PIC X(01).
   05 NUMBER-TYPE           PIC X(04).
   05 INPUT-NUMBER          PIC X(20).
```

**Example Input – Validation:**
```cobol
REQUEST-TYPE  = 'V'
NUMBER-TYPE   = 'ACCT'
INPUT-NUMBER  = '1234567890'
```

**Example Input – Generation:**
```cobol
REQUEST-TYPE  = 'G'
NUMBER-TYPE   = 'ACCT'
INPUT-NUMBER  = SPACES
```

### Example Export View

**Layout:**
```cobol
01 EXPORT-VIEW.
   05 OUTPUT-NUMBER         PIC X(20).
   05 VALID-FLAG            PIC X(01).
   05 RETURN-CODE           PIC 9(04).
   05 MESSAGE-TEXT          PIC X(80).
```

**Example Output – Validation Success:**
```cobol
OUTPUT-NUMBER  = '1234567890'
VALID-FLAG     = 'Y'
RETURN-CODE    = 0000
MESSAGE-TEXT   = 'NUMBER VALID'
```

**Example Output – Generation:**
```cobol
OUTPUT-NUMBER  = 'AC000987654'
VALID-FLAG     = 'Y'
RETURN-CODE    = 0000
MESSAGE-TEXT   = 'NUMBER GENERATED'
```

### Processing Flow

```
START
  |
  V
Receive Request
  |
  V
Determine Request Type
  |
  +----Generate?
  |          |
  |          V
  |    Generate Number
  |
  +----Validate?
             |
             V
       Validate Number
             |
             V
      Check Business Rules
             |
             +----Invalid----> Return Error
             |
             V
      Format Output Number
             |
             V
      Build Response
             |
             V
           END
```

### COBOL Code (Reconstructed)

```cobol
IDENTIFICATION DIVISION.
PROGRAM-ID. TIRFDNUM.

DATA DIVISION.
WORKING-STORAGE SECTION.
01 WS-NUMBER.
   05 WS-GENERATED-NUMBER PIC X(20).

LINKAGE SECTION.
01 IMPORT-VIEW.
   05 REQUEST-TYPE        PIC X.
   05 INPUT-NUMBER        PIC X(20).

01 EXPORT-VIEW.
   05 OUTPUT-NUMBER       PIC X(20).
   05 RETURN-CODE         PIC 9(04).

PROCEDURE DIVISION USING
     IMPORT-VIEW
     EXPORT-VIEW.

MAIN-PROCESS.
    EVALUATE REQUEST-TYPE
       WHEN 'G'
          PERFORM GENERATE-NUMBER
       WHEN 'V'
          PERFORM VALIDATE-NUMBER
       WHEN OTHER
          MOVE 0004 TO RETURN-CODE
    END-EVALUATE
    GOBACK.
```

### Return Codes

| Code | Meaning |
|------|---------|
| 0000 | Success |
| 0004 | Invalid Input |
| 0008 | Number Not Found |
| 0012 | Duplicate Number |
| 0016 | Invalid Format |
| 0020 | Sequence Exhausted |
| 0099 | System Error |

---

## Summary

This document describes seven TIR runtime modules that provide critical support services for CA Gen-generated COBOL applications:

1. **TIRD2VW** - Converts standard dates (YYYY-MM-DD) to CA Gen format (YYYYMMDD)
2. **TIRDAT2** - Converts day counts to dates
3. **TIRFNUM** - Converts text to numeric values
4. **TIRFNUMD** - Converts numeric values to dates (DATENUM function)
5. **TIRVPAD** - Supports Procedure Action Diagram execution
6. **TIRVW2D** - Converts CA Gen dates to standard format (inverse of TIRD2VW)
7. **TIRFDNUM** - Validates and generates business numbers

These modules are essential for date processing, numeric conversions, and runtime support in the mainframe environment and must be considered when planning migration to .NET.

---

## Migration Considerations

When migrating these TIR modules to .NET:

1. **Date Handling:** .NET `DateTime` and `DateOnly` types should replace CA Gen date formats
2. **DB2 Date Minimums:** The special handling of `0001-01-01` / `00000000` requires explicit mapping
3. **Numeric Conversions:** Use `int.Parse()`, `decimal.Parse()`, and `TryParse()` methods with proper validation
4. **PAD Logic:** Generated business logic should be refactored into service classes with clear responsibilities
5. **Number Generation:** Consider using centralized services or database sequences for unique number generation

---

**Document Generated:** 2026-06-26  
**Source:** TIR Modules for POC.docx  
**Portfolio:** (pack-specific — set per engagement)
