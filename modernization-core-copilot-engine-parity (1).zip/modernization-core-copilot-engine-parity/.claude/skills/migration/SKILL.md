---
name: migration
description: Target-architecture conventions for implementing mainframe-to-.NET (or mainframe-to-Java) modernization stories at insurance carriers — COBOL/CICS/VSAM/MQ pattern mapping, WCF/Spring Boot service layering, error handling, coexistence/back-sync strategy, and the mandatory .NET/Java engineering standards (financial arithmetic, sagas, batch, resilience, correlation IDs, logging, security). Load this when implementing or reviewing a migration story's code. For domain knowledge — business capability models, underwriting lifecycle flows, industry standards, regulatory details, and operational processes — always load and reference the insurance-underwriting-domain skill in conjunction with this one.
---

IMPORTANT: This skill works in conjunction with `insurance-underwriting-domain`.

Before performing any task that requires understanding of:
- Business capability definitions or capability taxonomy
- Policy lifecycle processes (application, eligibility, risk scoring, issuance, claims, billing)
- Industry standards (ACORD, NAIC, ISO)
- Regulatory obligations or participant roles
- Reference data, corporate actions, or reporting obligations

→ Read and apply the `insurance-underwriting-domain` skill. Do not duplicate that knowledge here. This skill focuses exclusively on target-architecture conventions applied while implementing a migration story.

> **Note on scope:** this skill originally also covered AS-IS program-classification and Migration-Unit/wave-planning methodology. Those sections were removed when the AS-IS and LLD generation pipelines were retired — this repo now runs implementation only (speckit-based), consuming EPICs/stories that already exist under `portfolios/{portfolio}/docs/epics/`. What remains below is the target-architecture reference implementation agents still need while writing code for a story.

---

# Part 1: Target Architecture Patterns (.NET)

> **Scope note:** this part covers architecture patterns (what maps to what, and why). Concrete .NET implementation conventions — EF6/DB2 rules, NuGet version pins, WCF/IIS configuration, test frameworks, coverage gates — live in `.claude/skills/target-stack-net-conventions/SKILL.md`, which is authoritative for those rules; if this part and that skill disagree, the conventions skill wins.

## 1.1 COBOL Program → .NET WCF Service Mapping

| COBOL / Mainframe Pattern | Target .NET 4.8 Pattern | Notes |
|--------------------------|------------------------|-------|
| CICS COMMAREA-based entry point | WCF `[ServiceContract]` with `[DataContract]` request/response | Preserve field-level contract; map COMMAREA layout to `[DataContract]` class |
| COBOL CALL to shared subroutine | .NET class library method call | Extract to `{Project}.Application` or `{Project}.Domain` layer |
| EXEC SQL SELECT INTO | EF6 `context.Set<T>().Where(...).FirstOrDefault()` or raw `IBM.Data.DB2` SQL | Use EF6 for standard CRUD; raw ADO.NET for complex cursors |
| EXEC SQL cursor FETCH loop | EF6 `context.Set<T>().Where(...).ToList()` or streaming ADO.NET `DataReader` | Bound row count to avoid latency SLA breach |
| VSAM KSDS read/write | DB2 LUW table with primary key; EF6 repository | Create table with equivalent key structure |
| IBM MQ MQPUT / MQGET | IBM MQ retained on-prem; `IBM.XMS` .NET client | No replacement messaging platform in target stack — confirm with architect |
| JCL batch job | Windows Service with `System.Timers.Timer` or Task Scheduler | `InstanceContextMode` not applicable; use dedicated host process |
| SYSOUT report | File output (CSV, PDF) from .NET; base64 in SOAP response for on-demand reports | Reporting strategy TBD per engagement |
| CICS TSQ temporary storage | In-process `Dictionary<string, T>` or call-scoped state in WCF `OperationContext` | Not durable — do not use for cross-call state |

## 1.2 Data Migration: DB2 z/OS → DB2 LUW

All mainframe DB2 stores migrate to IBM DB2 LUW (Linux, Unix, Windows). Key considerations:

| Topic | Mainframe DB2 | DB2 LUW | Action Required |
|-------|--------------|---------|----------------|
| SQL dialect | DB2 for z/OS | DB2 LUW | Review z/OS-specific SQL extensions (e.g. `REXX`, `FETCH FIRST n ROWS`) — validate compatibility |
| Data types | `CHAR`, `DECIMAL`, `DATE` (z/OS format) | `CHAR`, `DECIMAL`, `DATE` (LUW format) | Date format migration: z/OS `YYMMDD` → LUW `YYYY-MM-DD` |
| Index strategy | z/OS index structures | LUW B-tree indexes | Re-evaluate index definitions; performance profile differs |
| Stored procedures | COBOL or PL/I stored procs | DB2 LUW SQL PL or .NET CLR | Migrate logic to .NET application layer where possible |
| Connection | DRDA / DB2 Connect | `IBM.Data.DB2` ADO.NET provider | Connection string: `Database=;Server=host:50000;UID=;PWD=;Pooling=true;Min Pool Size=5;Max Pool Size=100` |
| VSAM → DB2 LUW | VSAM KSDS / RRDS / ESDS | DB2 LUW tables | Design schema transformation; sequential files may stay as flat files |

## 1.3 WCF Service Architecture Layers

Every migrated online transaction program maps to a WCF service following this layered structure:

```
{MU-Name}.Services/           ← WCF [ServiceContract] + [DataContract]; SOAP endpoint
{MU-Name}.Application/        ← Command handlers; business logic orchestration; transaction boundaries
{MU-Name}.DataAccess/         ← Repository pattern; EF6 DbContext (Db2Context); IBM.Data.DB2
{MU-Name}.Domain/             ← POCO entities; domain rules
{MU-Name}.Infrastructure/     ← Logging (NLog), configuration (Web.config), cross-cutting concerns
```

**Binding:** `BasicHttpBinding` (SOAP 1.1/1.2, maximum interoperability, contract-first)
**Instance mode:** `InstanceContextMode.PerCall` (stateless; new instance per request)
**Transaction scope:** One `DbContext` per WCF call; `SaveChanges()` in command handler; no distributed transactions

## 1.4 Error Handling Contract

| Mainframe Pattern | .NET WCF Target |
|-------------------|----------------|
| COBOL `RETURN-CODE` / `SQLCODE` | SOAP Fault (`<soap:Fault>`) with structured `<detail>` element |
| ABEND / system failure | `IErrorHandler` implementation; log to NLog; return `FaultException<T>` |
| DB2 SQLCODE errors | Caught at repository layer; wrapped in domain exception; propagated as SOAP Fault |
| Partial success / warning codes | Include in `[DataContract]` response as `WarningCode` + `WarningMessage` fields |

## 1.5 Coexistence Data Strategy

During the coexistence period (mainframe + migrated .NET services running simultaneously), data consistency across DB2 z/OS and DB2 LUW must be explicitly managed.

**Settled approach (confirm with the client's architecture team before implementation):**

1. **"DB2 LUW-first writes"**: Migrated .NET services write to DB2 LUW as the primary transactional store.
2. **"DB2 z/OS back-sync"**: Where remaining mainframe programs still read from DB2 z/OS, the migrated service is responsible for back-syncing via a defined sync mechanism — confirm approach (MQ-based CDC, ETL bridge, or dual-write) with the client's DB migration team before the MU enters parallel run.
3. **"MU team owns back-sync"**: Back-sync is not the DB migration team's responsibility — the MU delivery team must implement it consistently across all data-writing services in the MU.

**Design implications:**
- Every service that writes transactional data must implement the agreed back-sync pattern from day one — not retrofitted later
- Sync mechanism, event format, and retry/dead-letter strategy must be standardised across MUs (not per-service ad hoc)
- The portfolio's Interim/Target State Architecture (if the pack carries one) should document this pattern's "Data synchronisation" field explicitly
- If DB2 LUW write succeeds but DB2 z/OS back-sync fails, the service must handle this as a compensating operation — do not silently ignore the failure

**COPYBOOK data contracts — shared library, not one-to-one mapping:**

COPYBOOKs are the mainframe's shared data contracts — they define record structures used across multiple programs. The migration risk is not that they are complex to convert, but that different WCF service teams independently interpret the same COPYBOOK and produce inconsistent .NET `[DataContract]` classes, creating silent data mismatches across service boundaries.

**Do NOT** attempt a strict structural one-to-one mapping of COPYBOOK layouts to .NET classes. COPYBOOKs carry mainframe-specific baggage that should not be replicated in .NET:
- Cryptic 2–4 character field names (IBM naming conventions from the 1970s)
- `FILLER` areas (padding bytes with no business meaning)
- `REDEFINES` clauses (union types — same memory interpreted as different structures)
- `OCCURS DEPENDING ON` (variable-length arrays driven by a count field)

**Do:** Identify COPYBOOKs that are cross-service data contracts (policy record, claim record, premium record) and define them **once** in the shared .NET class library before any downstream WCF service references them. Rename fields to business-meaningful names; eliminate `FILLER`; flatten `REDEFINES` into explicit typed properties.

The shared library is the single source of truth for cross-service data structure references. Local COPYBOOKs used only within a single program's scope do not need to be in the shared library.

## 1.6 .NET Framework Standards — Mandatory Patterns

These patterns apply to ALL migrated .NET 4.8 WCF services and Windows Services across every MU. They address common COBOL-to-.NET translation risks and must be treated as non-negotiable engineering standards.

### 1.6.1 Financial Arithmetic — `decimal` Mandatory

**Rule:** `double` and `float` MUST NOT be used for any financial value in migrated services. Use C# `decimal` for all prices, premium amounts, fees, commissions, reserve amounts, and rate factors.

```csharp
// WRONG — never use for financial values
double premiumAmount = 1234.56;
float totalPremium = (float)(premiumAmount * 1.1);

// CORRECT
decimal premiumAmount = 1234.56m;
decimal totalPremium = premiumAmount * 1.1m;
// Always specify rounding explicitly for financial calculations:
decimal rounded = Math.Round(totalPremium, 2, MidpointRounding.AwayFromZero);
```

**Why this matters for COBOL migration:** COBOL uses `PIC 9(7)V9(2)` packed decimal (COMP-3) for all financial arithmetic — exact binary-coded decimal with no floating-point rounding error. C# `double` / `float` introduce IEEE 754 rounding errors that accumulate across a policy lifecycle (e.g. premium × rate factor × quantity across millions of policies). C# `decimal` is the exact equivalent. Map every COBOL `PIC 9` financial field to `decimal` in the `[DataContract]` class.

### 1.6.2 Distributed Transactions — Saga Pattern

**Why it matters:** CICS provides an implicit unit-of-work (UoW) — all DB2 writes within a CICS transaction are rolled back atomically on failure. When the business logic is decomposed across multiple WCF services (e.g. underwriting decision → policy issuance → billing setup), this guarantee disappears. Distributed 2PC across WCF services is not supported in the target stack.

**Preferred pattern — MQ choreography-based saga** for flows that involve multi-step state changes crossing service boundaries (e.g. application submission → risk scoring → policy issuance):
- On a successful step → publish a domain event to IBM MQ (guaranteed delivery)
- On failure → publish to a retry queue; after max retries → dead-letter queue (DLQ)
- On DLQ entry → trigger compensating operations to reverse completed steps
- Each step must have an explicitly defined compensating operation documented in the MU's Target State Architecture

**Orchestration-based saga** (use only for complex multi-step flows requiring central coordination):
- A dedicated orchestrator Windows Service drives the sequence
- Each participant WCF service exposes command endpoints
- The orchestrator handles retries and compensating calls

**When `TransactionScope` is acceptable:** within a single WCF service operating against its own DB2 LUW schema — standard ADO.NET / EF6 `DbContext.SaveChanges()` within a `TransactionScope` is fine. The saga constraint applies only when a logical business transaction spans multiple services.

> **Every saga step that writes data must have a defined compensating operation. Document this before implementation begins.**

### 1.6.3 Batch Processing — Windows Service Patterns

Windows Services are the mandated target for all migrated JCL/COBOL batch programs. Key patterns:

**Chunk-oriented processing** (maps to COBOL READ / PERFORM / WRITE loops):
```csharp
// Reader → Processor → Writer pattern
foreach (var batch in reader.ReadInChunks(chunkSize: 500))
{
    var results = processor.Process(batch);
    writer.Write(results);
    // Commit after each chunk — enables restart from last committed chunk
    dbContext.SaveChanges();
}
```

**Restartability / checkpointing:** COBOL Batch can restart from the last checkpoint after failure. Every migrated batch Windows Service must implement restartable processing — persist a checkpoint (last processed key or batch sequence number) to DB2 LUW after each committed chunk. On restart, resume from the checkpoint rather than reprocessing from the beginning.

**Partitioned processing for high-volume batch:** For high-volume batch jobs (e.g. large renewal or billing runs), partition the dataset by date range, product line, or account range and process partitions in parallel using `Task.WhenAll()` with a bounded degree of parallelism (`SemaphoreSlim`). Do not process all records sequentially when volume requires parallel throughput.

**Job parameter design:** Match COBOL JCL PARM conventions — batch Windows Services must accept processing date, run mode (full/delta), and dry-run flag as command-line or configuration parameters. Do not hardcode these values.

### 1.6.4 Resilience Patterns — Polly

Use **Polly** (the standard .NET resilience library) for all inter-service and database resilience. Do not implement custom retry loops.

| Pattern | Usage | Configuration |
|---------|-------|---------------|
| Retry | Idempotent operations against downstream WCF services or DB2 | Max 3 retries; exponential backoff (100ms, 500ms, 2000ms); do NOT retry non-idempotent writes |
| Circuit Breaker | Downstream WCF service calls | Open after 5 consecutive failures; half-open after 30s; log state transitions to NLog |
| Timeout | All downstream service calls and DB2 queries | Timeout must be ≤ upstream SLA; online service calls ≤ SLA threshold; confirm per MU |
| Bulkhead | Thread pool isolation per downstream dependency | Prevent a slow downstream from exhausting the shared thread pool |

**MQ failure handling — dead-letter pattern:**

Every IBM MQ consumer in a migrated service must implement explicit dead-letter handling:
1. Process message → on failure: publish to retry queue (retry after delay)
2. Retry queue → on failure after max retries: publish to dead-letter queue (DLQ)
3. DLQ → trigger an NLog alert (and any APM alert wired to log ingestion)
4. DLQ → manual review or replay procedure documented in the MU runbook

Silent message discard is not acceptable for insurance business events (policy issuance, claims, billing). DLQ alert thresholds must be defined per MU in the Target State Architecture.

### 1.6.5 Correlation ID — End-to-End Trace Propagation

**Mandatory for all migrated services:** every transaction in the policy/underwriting lifecycle (application submission through policy issuance and billing setup) must carry a single correlation ID from entry point across all downstream services, IBM MQ messages, DB2 writes, and log entries.

**Canonical correlation ID:** Use the **Policy Number** (for post-bind flows) or **Application ID** (for pre-bind flows) as the primary correlation ID. Where neither exists yet (e.g. first-call intake), generate a GUID at the first service boundary and replace it with the Application ID once assigned.

**Propagation rules:**
- **WCF SOAP messages:** Propagate as a custom SOAP header (`<CorrelationId>`). The WCF service must extract it in the `IDispatchMessageInspector` and attach it to the call context before any processing.
- **IBM MQ messages:** Include `correlationId` as an MQ message property (not in the payload body). Consumers must extract it and attach it to the log context before any processing.
- **DB2 writes:** Include a `correlation_id` column in all transactional tables (application, policy, billing, claims) — mandatory for regulatory audit trail and reconciliation.
- **Logging:** Every log statement at INFO level or above must include the correlation ID in the NLog `MappedDiagnosticsContext` (MDC). Set `MappedDiagnosticsLogicalContext.Set("correlationId", id)` at service entry; clear at exit.

Whatever APM/tracing tool is deployed will automatically correlate spans if the correlation ID is consistently propagated — do not rely on auto-instrumentation alone without explicit header propagation.

### 1.6.6 Testing Strategy for Migrated Services

**Shadow mode / parallel-run (preferred mechanism):**

Deploy the migrated .NET service alongside the legacy mainframe program; route requests to BOTH systems simultaneously. Compare outputs — DB2 LUW writes vs. DB2 z/OS writes, MQ events vs. mainframe file outputs — using a reconciliation harness. The mainframe remains the authoritative system until exit criteria are met. This is the safest parallel-run pattern for high-priority programs.

**Test data strategy:**
- Production-masked data is required for performance and integration testing — do not rely on synthetic data for volume tests
- COBOL test output (SYSOUT, DB2 snapshots) becomes the golden reference for .NET output comparison
- Record/replay: capture a representative set of mainframe inputs and expected outputs before decommissioning any program; use as regression suite for the .NET equivalent

**Performance regression testing:**
- Every batch MU with a defined throughput NFR (e.g. policies per hour) must have a benchmark harness before going live
- Baseline: run the same input volume through the mainframe batch and the .NET Windows Service; compare throughput and elapsed time
- Acceptance criterion: .NET service must achieve ≥ mainframe throughput at equivalent infrastructure cost, or have an approved investment plan to close the gap

**Unit test coverage minimum:** 80% line coverage for all new .NET service code. COBOL has no existing unit tests — the migration is the opportunity to introduce a test baseline.

### 1.6.7 Contract-First (WSDL-First) Design Principle

**Rule:** every migrated WCF service must define its WSDL / `[ServiceContract]` + `[DataContract]` **before** implementation begins. The contract is the design artefact — not a generated by-product of the code.

**Why this matters for mainframe migration:** COBOL programs have no formal service contracts. They expose behaviour through CICS transaction IDs, CALL linkages, and shared COPYBOOK structures — all undocumented and implementation-coupled. The migration is the one opportunity to make these contracts explicit and stable. If implementation starts before the contract is agreed, services end up tightly coupled in a different language — the same problem in C# instead of COBOL.

**What Contract-First means in practice:**

1. **Define the `[ServiceContract]` and `[DataContract]` first** — agree it with all consuming teams before writing a line of service implementation. For MQ contracts, define the message schema in the shared library before producers or consumers are built.

2. **Contract is the source of truth** — code is generated from or validated against the agreed WSDL, not the other way around. Use `svcutil.exe` or Visual Studio's "Add Service Reference" tooling to generate client proxies from the agreed contract.

3. **Versioning from day one** — every WCF service must include a `serviceVersion` field in the `[DataContract]` response from its first deployment. Breaking changes require a new endpoint suffix (e.g. `/v2/`). Non-breaking additions (new optional fields marked `[DataMember(IsRequired=false)]`) do not require a new endpoint but must be documented in the changelog.

4. **Consumer-driven contract validation** — consuming services must validate their expectations against the provider's WSDL as part of CI. A WSDL changed by one team must not silently break another team's generated proxy.

5. **Applied to COBOL migration:**
   - Each CICS transaction being replaced → define `[ServiceContract]` before building the WCF service implementation
   - Each COPYBOOK shared across services → define the `[DataContract]` in the shared library before any service references it (see §1.5)
   - Each IBM MQ queue being replaced or retained → define the message schema (format, field names, encoding) before building the Windows Service consumer
   - Each JCL file handoff → define the file contract (format, delimiter, encoding, field order) before building the file reader/writer

### 1.6.8 Database Schema Versioning — DbUp

**Mandated approach:** All DB2 LUW schema changes (DDL) across all MU schemas must be managed using **DbUp** (or the portfolio-approved equivalent). No manual DDL runs against any DB2 LUW environment (dev, sit, uat, preprod, prod).

**Why this matters:** without schema versioning, teams accumulate DDL drift between environments. During the coexistence period when multiple MU teams are writing to DB2 LUW simultaneously, uncontrolled schema changes will cause production incidents. DbUp provides an auditable, repeatable DDL migration history co-versioned with the application.

**Required practices:**
- DbUp migration scripts (`/db/scripts/`) are checked in to the same repository as the service code — schema version is tied to application version
- Each script has a unique name (e.g. `0001_create_policy_table.sql`); script names are never reused or modified after merge to main
- DbUp runs as a pre-deployment step (console executable or in-process on startup) before the service starts — schema is always applied before traffic
- **Rollback scripts are mandatory** for every migration that modifies existing data structures (column type changes, renames, drops). Additive-only changes (new tables, new nullable columns, new indexes) do not require rollback scripts but must be reviewed by the DBA team before release
- **Non-destructive changes only in production:** column drops and renames require a multi-release deprecation cycle — old column retained as nullable until all services referencing it have been updated and re-deployed
- All DDL scripts must be reviewed by the DBA team before merge to main

### 1.6.9 Structured JSON Logging Standards

**Mandatory for all migrated services** — required for centralized log ingestion and cross-service log correlation.

All log output must be structured JSON (not plain-text). Configure NLog with a `JsonLayout` target. Plain-text logs will not be parsable for alerting, metric extraction, or correlation.

**Mandatory JSON log fields:**

| Field | Value | Notes |
|-------|-------|-------|
| `timestamp` | ISO-8601 UTC [e.g. `2026-03-04T14:30:00.123Z`] | |
| `level` | ERROR / WARN / INFO / DEBUG | |
| `service` | Service name (e.g. `underwriting-decision-service`) | |
| `correlationId` | Application ID, Policy Number, or GUID (via MDC — see §1.6.5) | **present in all INFO+ entries** |
| `traceId` | APM trace ID if injected by agent | |
| `message` | Human-readable description | |

**Log level semantics:**

| Level | Meaning |
|-------|---------|
| `ERROR` | Unexpected failure requiring immediate investigation; triggers an alert |
| `WARN` | Expected, handled failure; retry activated, fallback used — no immediate action required |
| `INFO` | Business-significant events: application received, underwriting decision made, policy issued, claim opened, batch job started/finished |
| `DEBUG` | Diagnostic only; enabled via configuration flag; never enable in production |

**What MUST NOT appear in production logs (PII / Sensitive Data):**
- Full Social Security Numbers (mask to last 4 digits if needed for debugging)
- Full date of birth
- Full account or payment card numbers
- Health or medical information (for life/health lines)
- Authentication tokens, API keys, or secrets of any kind

### 1.6.10 Service Security — WCF Transport Security

**Mandated approach:** All WCF service-to-service communication must use **transport-level security (HTTPS + mutual TLS)**. Clear-text HTTP between services is not permitted in SIT, UAT, or production environments.

**Implementation:**
- Bind all IIS-hosted WCF services to HTTPS using certificates managed by the portfolio's PKI / certificate management team
- For service-to-service calls within the data centre, use `BasicHttpBinding` over HTTPS with client certificates where required by the portfolio's security standard
- Service accounts must be validated against Active Directory; use Windows Integrated Authentication (`SecurityMode.TransportWithMessageCredential`) for internal service-to-service flows where ADFS/Windows Auth is available
- Do NOT configure transport security in `Web.config` in a way that conflicts with IIS HTTPS bindings — validate with the platform team before deploying

**Secrets management:** All service credentials, DB2 connection passwords, MQ credentials, and API keys must be retrieved from the portfolio's approved secrets manager at runtime. Do not hardcode secrets in `Web.config`, `App.config`, or environment variables. Use the vendor-provided SDK or the approved secrets retrieval pattern established by the portfolio's security team.

**Authorization:** Every WCF service must validate the caller's identity before processing. Do not implement implicit trust within the on-prem network. Minimum: validate the service account identity; preferred: validate against an authorization list configured per service endpoint.

**Development environments:** Local development (outside SIT/UAT) may use `SecurityMode.None` or self-signed certificates — do NOT add configuration that disables security to SIT, UAT, or production `Web.config` transforms.

## 1.7 Service Design — Right-Sizing, Not Nano-Services

### 1.7.1 Communication Type Selection

Every service-to-service interaction requires a conscious choice. DO NOT default to WCF SOAP synchronous calls because it is familiar or because the COBOL program was a CICS transaction. Evaluate each flow against the criteria below.

| Interaction Type | Use When | Insurance Examples |
|-----------------|----------|--------------------|
| **IBM MQ (async, durable)** | High message volume; fire-and-forget acceptable; multiple consumers; temporal decoupling needed; audit trail required | Policy state changes, claim status updates, billing cycle events, regulatory filing triggers |
| **WCF SOAP (synchronous)** | Caller needs an immediate result; low-to-moderate volume; human-initiated or UI-triggered; confirmed outcome required before proceeding | Real-time underwriting decisions, single-record lookups, policy issuance confirmation, payment acknowledgement |
| **Named Pipes / net.pipe** | High-frequency internal same-machine service-to-service; lowest latency requirement; no cross-machine boundary | In-process orchestration between co-located services on the same IIS host |

**Critical rule — async-first for batch and event-driven flows:**

The upstream COBOL programs (premium calculation, policy issuance, claims adjudication) are inherently batch and event-driven — COBOL programs in the mainframe communicate via MQ queues and file handoffs, not synchronous calls. The .NET target architecture should replicate this asynchronous nature using IBM MQ, not re-wire it as synchronous WCF chains.

- A WCF call chain of depth > 2 in a latency-sensitive path is a design smell — consider replacing with MQ-driven choreography
- Synchronous WCF is appropriate for **inbound** requests (from a workstation, agent portal, or external ACORD partner) — not for internal domain orchestration
- Every IBM MQ topic/queue replaces a mainframe MQ queue or file handoff; document this lineage explicitly in the MU's integration inventory
- MQ consumers must define dead-letter queues (DLQ) and poison-message handling — these are not optional (see §1.6.4)

**When NOT to use IBM MQ:**
- When the caller requires a synchronous response with confirmed outcome before proceeding (e.g. underwriting decision with policy number — use WCF SOAP)
- When exactly one service handles the request and temporal decoupling adds complexity with no benefit
- When message volume is negligible (< 10/min) and operational overhead of an MQ queue is not justified

### 1.7.2 Service Granularity — Right-Sizing, Not Nano-Services

**Anti-pattern to avoid: one WCF service per COBOL program.**

The mainframe may have hundreds of programs. A one-to-one mapping would produce hundreds of nano-services — each with its own deployment pipeline, IIS application pool, health check scheme, and operational overhead; distributed tracing becomes unmanageable, and team cognitive load explodes.

**Right-sizing principles:**

1. **Bounded context, not COBOL program.** A service boundary aligns with a business capability (see `insurance-underwriting-domain` taxonomy). Multiple COBOL programs implementing the same capability belong in the same WCF service project.

2. **A service must own its data.** If two candidate services share a DB2 LUW table or schema — they are not two services; they are one. Shared schema until the schema can be clearly separated.

3. **Single team, full ownership.** A service should be small enough that one team (3–8 engineers) can understand, own, and deploy it end-to-end. If more than one team is needed to deploy a change, split.

4. **The chatty service anti-pattern.** If Service A makes > 3 synchronous WCF calls to Service B to complete a single business transaction (e.g. underwriting decision), they should likely be merged or interactions should be MQ-driven.

5. **Don't sub-divide below the capability catalog.** The `insurance-underwriting-domain` capability catalog represents the target service granularity. Splitting a capability service further requires explicit justification: team size, independent scaling requirement, or conflicting deployment cadence.

**Service decomposition checklist (use before defining a new service boundary):**
- [ ] Does it align with a single bounded context from the `insurance-underwriting-domain` taxonomy?
- [ ] Does it own its own DB2 LUW schema (no shared tables with another service)?
- [ ] Does it have a clear, bounded `[ServiceContract]` surface (not a dump of all COBOL programs from an old system)?
- [ ] Can one team (3–8 engineers) understand, own, and deploy it end-to-end?
- [ ] Will the communication overhead (WCF roundtrips, MQ messages) be tolerable at target volume?

If any checkbox fails, revisit the boundary before proceeding.

---

# Part 2: Java 21 / Spring Boot 3.4 Target Stack (Side-by-Side)

> This part is the Java equivalent of Part 1. Use when targeting Java 21 + Spring Boot 3.4 instead of .NET 4.8 + WCF. Load `portfolios/{portfolio}/inputs/target-stack-java.md` for authoritative Java version pins. Concrete Java implementation conventions — JPA/DB2 rules, Maven structure, dependency pins, CXF/Spring IoC configuration, test frameworks, coverage gates — live in `.claude/skills/target-stack-java-conventions/SKILL.md`, which is authoritative for those rules.

## 2.1 COBOL Program → Java / Spring Boot Mapping

| COBOL / Mainframe Pattern | Target Java 21 / Spring Boot 3.4 Pattern | Notes |
|---|---|---|
| CICS COMMAREA-based entry point | Apache CXF `@WebService` JAX-WS endpoint (document/literal wrapped SOAP) | Same WSDL 1.1 contract as .NET — the story's API contract is reused |
| COBOL CALL to shared subroutine | Java class in `{mu}-application` module, annotated `@Service` | No WCF equivalent — Spring `@Service` is sufficient |
| EXEC SQL SELECT INTO | Spring Data JPA `findById()` / derived query method on `JpaRepository<T,ID>` | Use `Optional<T>` return type |
| EXEC SQL cursor FETCH loop | `findTop{N}By...OrderBy...()` or `@Query` + `Pageable` | `PageRequest.of(0, 1000)` for row cap (R-01) |
| VSAM KSDS read/write | DB2 LUW table; Spring Data JPA `JpaRepository` | `@Table(name=..., schema=...)` in JPA entity |
| IBM MQ MQPUT / MQGET | IBM MQ retained on-prem; `com.ibm.mq:com.ibm.mq.allclient` Spring Integration | Same as .NET — no replacement platform |
| SYSOUT report | File output (CSV, PDF) from Java; base64 in SOAP response | Same reporting strategy as .NET |
| CICS TSQ temporary storage | In-scope state passed as method parameters | No JVM equivalent needed — pure in-process |
| Working storage (WS-THRESHOLDS) | `@ConfigurationProperties(prefix="scoring")` record/class in `{mu}-infrastructure` | Reads from `application.yml` — same R-06 mitigation as .NET Web.config |

## 2.2 Java Architecture Layers

Every migrated online transaction program maps to a Spring Boot service following this layered structure:

```
{mu}-services/       ← @SpringBootApplication + @WebService CXF endpoint (SOAP, JAX-WS)
{mu}-application/    ← @Service command/handler; orchestration; input validation (E001–E004)
{mu}-data-access/    ← @Repository Spring Data JPA interfaces; JPA @Entity; UnderwritingDbConfig
{mu}-domain/         ← Pure Java POJOs, enums, scoring results, interfaces (zero Spring)
{mu}-infrastructure/ ← @ConfigurationProperties ThresholdSettings; MDC helpers; Logback config
```

**Transaction scope:** `@Transactional` on service layer; Hibernate session per request; no distributed transactions.

## 2.3 Java Persistence Mapping

| Mainframe Pattern | Java / Spring Data JPA Target |
|---|---|
| EXEC SQL SELECT WHERE pk = :v | `findById(id)` → `Optional<T>` |
| EXEC SQL SELECT WHERE fk = :v ORDER BY date DESC FETCH FIRST 1 ROW | `findFirstByFkOrderByDateDesc(fk)` → `Optional<T>` |
| DECLARE cursor FETCH loop (CLAIM_HISTORY) | `@Query("SELECT c FROM ... WHERE ... ORDER BY date DESC") List<T> find(..., Pageable p)` with `PageRequest.of(0,1000)` |
| VSAM KSDS primary key | `@Id @Column(name="COLUMN_NAME")` in JPA entity |
| DB2 z/OS schema | `@Table(name="TABLE", schema="UWR")` — schema name preserved from TSA-db2-migration.md |
| EXEC SQL stored proc | Native `@Query(nativeQuery=true)` or JdbcTemplate for complex DB2-specific syntax |
| Connection string | `spring.datasource.url=jdbc:db2://host:50000/DB` in `application.yml` |
| Connection pooling (DRDA) | HikariCP: `minimumIdle: 5`, `maximumPoolSize: 100` |

## 2.4 Java vs .NET Side-by-Side Reference

| Concern | .NET 4.8 | Java 21 / Spring Boot 3.4 |
|---|---|---|
| SOAP framework | WCF `[ServiceContract]` / `BasicHttpBinding` | Apache CXF `@WebService` / JAX-WS |
| Hosting | IIS Application Pool | Embedded Tomcat 10.x |
| DI container | Unity Container | Spring IoC (`@Service`, `@Bean`) |
| Config file | `Web.config` appSettings | `application.yml` |
| ORM | Entity Framework 6 | Spring Data JPA + Hibernate 6 |
| DB connection | `IBM.Data.DB2` ADO.NET + EF6 | HikariCP + DB2 JDBC Type 4 |
| Logging | NLog | SLF4J + Logback |
| Service activation | `ServiceHostFactory` + Unity.Wcf | CXF `EndpointImpl` + `@SpringBootApplication` |
| Project format | `.sln` / `.csproj` / NuGet | Maven multi-module `pom.xml` |
| Test framework | NUnit 3 + Moq + FluentAssertions | JUnit 5 + Mockito 5 + AssertJ 3 |
| Coverage | coverlet + SonarQube | JaCoCo 0.8 + SonarQube |
| Target stack file | `portfolios/{portfolio}/inputs/target-stack-net.md` | `portfolios/{portfolio}/inputs/target-stack-java.md` |
| Output file suffix | `data-flows.md` | `data-flows-java.md` |
