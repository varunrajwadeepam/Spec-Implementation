---
name: mflens-mcp
description: How to discover and call the MFLens MCP server — deferred-tool discovery via ToolSearch, numeric portfolioId resolution, sourceEvidence citation format, tool selection by need, and fallback when MFLens is unreachable. ALWAYS load (Read) before making any MFLens MCP call. This is the single agent-facing copy of the MFLens usage contract; the server/ops reference is mcp/README.md.
---

# MFLens MCP — Retrieving COBOL Program Detail Without Source Files

This pipeline runs **without local COBOL source files**. `portfolios/{portfolio}/inputs/source/` is not
available and must not be relied upon. All program detail — functional requirements, call
edges, paragraph code, exit-states, data access, business rules, and even verbatim source
excerpts — is retrieved from the **MFLens MCP server**, which serves the results of static
code analysis already performed on the estate.

> **Canonical reference:** `mcp/README.md` is the source of truth for the MFLens server
> contract — the full tool list, `portfolioId` resolution, per-agent tool mapping, and
> fallback. Keep this skill aligned with it. This skill is the single agent-facing copy of
> that contract; agents must Read this skill instead of embedding their own copy.

## Discovering and calling MFLens

1. MFLens tools are **deferred MCP tools**. Discover them at runtime with `ToolSearch` using
   the query `MFlens`, then load the ones you need with `select:<tool_name>` before calling.
2. **Resolve the portfolio ID first.** MFLens tools take a numeric `portfolioId` (e.g. `182`),
   not the portfolio name (e.g. `ACME-CORE-subset`). Resolve it once at the start of the run by
   calling `search_program` (or `search_component`) with any known in-scope program name; the
   result includes the portfolio's numeric ID and PDS location. Reuse that `portfolioId` for
   all subsequent MFLens calls.
3. Cite MFLens as the evidence source in outputs — e.g. `sourceEvidence: "MFLens:<program>"` —
   instead of a source file path such as `PROGRAM.cbl:142`.
4. **Fallback:** if MFLens is unreachable or returns nothing for a program, fall back to
   `portfolios/{portfolio}/knowledge-store/programs-enriched.json` and the
   `portfolios/{portfolio}/inputs/static-analysis/` CSVs, and lower the confidence accordingly.

## MFLens tools by need

`ToolSearch` query `MFlens`, then `select:` the ones you use:

| Need | MFLens tools |
|------|--------------|
| Functional requirements / program purpose | `get_program_prd`, `get_program_summary`, `get_program_export` |
| Call edges & call chains | `get_portfolio_call_chain`, `get_portfolio_call_chain_statistics`, `find_portfolio_call_paths`, `get_program_deep_call_chain` |
| CICS usage | `get_cics_usage` |
| MQ usage | `get_mq_usage_program`, `get_mq_usage_portfolio` |
| DB2 / SQL tables & statements | `get_portfolio_sql_tables`, `get_program_sql_statements`, `get_sql_table_structure`, `get_sql_table_usage` |
| Program outputs & data lineage | `get_program_outputs`, `get_lineage_summary`, `get_field_lineage`, `trace_field_lineage`, `trace_output_structure` |
| Paragraphs, control flow & verbatim code | `get_program_paragraphs`, `get_program_paragraph_details`, `get_control_flow_graph`, `get_program_source_code`, `get_program_dead_paragraphs` |
| Data structures (PIC clauses, layouts) | `list_data_structures`, `get_data_structure_details` |
| Blast-radius / migration impact | `analyze_migration_impact`, `recommend_modernization_start` |
| Capabilities & classification | `get_business_capabilities`, `get_programs_by_capabilities`, `update_program_classification` |
| JCL jobs & datasets | `list_portfolio_jcl_jobs`, `get_jcl_job_execution_details`, `get_jcl_job_io`, `get_jcl_bottom_up_file_analysis` |
| Code / component search | `search_code`, `search_code_portfolio`, `search_program`, `search_component` |
| Portfolio discovery & health | `get_portfolio_overview`, `get_portfolio_assets`, `get_portfolio_files` |
| COBOL → ISO conversion guidance | `cobol_ibm_to_iso` |
