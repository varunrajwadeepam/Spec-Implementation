---
name: portfolio-resolution
description: Shared portfolio and skill resolution procedure for the implementation pipeline's agents (speckit.*, fwd-cobol-dotnet-consistency-checker, code-quality-analyzer, lld-epic-story-validator). Manifest-driven — every portfolio is a self-contained pack under portfolios/{portfolio}/ with a portfolio.yaml manifest that declares its skills, target stack, and codegen provenance. Defines portfolio-name resolution, manifest loading, pack-first skill path resolution, and the mandatory skill load order. Single source of truth — agents must NOT embed their own copy of these rules (same pattern as mflens-mcp).
---

# Portfolio & Skill Resolution — Shared Procedure (Manifest-Driven)

Every implementation-pipeline agent resolves its portfolio and skills by following this file. Do not paraphrase or copy these rules into agent definitions — Read this file at the start of every run and follow it exactly.

A portfolio is a **self-contained pack**: `portfolios/{portfolio}/` carries its manifest, skills, inputs, and all generated outputs. There is **no hardcoded registry, no prefix inference, and no subset special-case** — the manifest is the only source of truth. Adding a portfolio requires zero changes to agents, this skill, or CLAUDE.md.

## 1. Resolve the portfolio name

1. Check the arguments for `portfolio=<name>` (e.g. `portfolio=ACME-CORE`).
2. If not provided, read `PORTFOLIO_NAME` from the project-root `.env` file.
3. If neither is present → **STOP** with: `ERROR: no portfolio specified. Pass portfolio=<name> or set PORTFOLIO_NAME in .env`

## 2. Load the pack manifest

Read `portfolios/{portfolio}/portfolio.yaml`.

- File missing → **STOP** with: `ERROR: portfolios/{portfolio}/portfolio.yaml not found. The portfolio pack is not installed — run scripts/install-portfolio.sh <path-to-pack> (or .ps1), or check the portfolio name.`
- The manifest schema is `schemas/portfolio-manifest.schema.json`. If a required field (`portfolio`, `client_skill`, `domain_skill`, `target_stack`, `codegen`) is absent → **STOP** and report the missing field.
- `manifest.portfolio` must equal the resolved portfolio name; mismatch → **STOP**.

All pack-relative paths below are relative to `portfolios/{portfolio}/`:

| Content | Path |
|---|---|
| MFLens CSV exports | `portfolios/{portfolio}/inputs/static-analysis/` |
| COBOL source | `portfolios/{portfolio}/inputs/source/` |
| Target-stack definition | `portfolios/{portfolio}/{target_stack.definition}` |
| Knowledge-store JSON artifacts (if present — carried over from a prior AS-IS/LLD run or supplied by the pack) | `portfolios/{portfolio}/knowledge-store/` |
| CSA / TSA / LLD / diagrams / SAD (read-only reference, if present) | `portfolios/{portfolio}/architecture/` |
| EPICs & stories — the required input to the implementation pipeline | `portfolios/{portfolio}/docs/epics/` |
| Generated implementation | `portfolios/{portfolio}/POC/` |
| Speckit artifacts | `portfolios/{portfolio}/specs/` |
| Reports / logs | `portfolios/{portfolio}/reports/`, `portfolios/{portfolio}/logs/` |

Agents create output subdirectories automatically if they do not exist.

## 3. Resolve the skills

From the manifest, with explicit arguments always winning:

1. `client_skill` — argument `client_skill=<name>` if passed, else `manifest.client_skill`.
2. `domain_skill` — argument `domain_skill=<name>` if passed, else (LLD-phase agents only) `domainSkill` from `portfolios/{portfolio}/knowledge-store/target-state.json` when present, else `manifest.domain_skill`.
3. `stack_skill` — `manifest.target_stack.conventions_skill` (LLD/to-be agents only; see §5).
4. `extra_skills` — `manifest.extra_skills` (may be empty).

## 4. Locate a skill on disk (pack-first, then up the subset chain)

For **every** skill name resolved above, find its `SKILL.md` by checking in order — **first hit wins**:

1. `portfolios/{portfolio}/skills/{name}/SKILL.md` — the pack's own skill (also how a pack overrides an inherited or engine skill of the same name)
2. **Each ancestor pack's `skills/`, walking the `subset_of` chain** — for a pack with `subset_of: PARENT`, check `portfolios/PARENT/skills/{name}/SKILL.md`, then `PARENT`'s own `subset_of`, and so on
3. `.claude/skills/{name}/SKILL.md` — engine shared skills (migration, cagen-programs, mermaid, target-stack-* conventions, …)

`subset_of` is **load-bearing**, not documentation: it is what lets a parent hold the skills for its whole set — its own plus those its subsets share — so sibling subsets need no `skills/` directory and no shared-skills side-channel exists. A subset pack that needs a skill nobody else uses still ships it in its own `skills/` (step 1).

Walking the chain:

- Follow `subset_of` at most until it is `null`. Each hop must name an installed pack; a `subset_of` pointing at a pack that is not installed is a hard error — **STOP** and report it, because the subset cannot resolve its inherited skills.
- A cycle in the chain (a pack reachable from itself) is a hard error — **STOP**.

This is what makes packs a plugin surface: a pack (or its parent) ships its own client, domain, **and stack-conventions** skills without any engine change.

## 5. Skill load order (mandatory)

Load each skill by Reading its resolved `SKILL.md` in full, in this order:

1. `{client_skill}` — client landscape and governance
2. `{domain_skill}` — technology-agnostic domain knowledge
3. Each of `{extra_skills}`, in manifest order
4. `.claude/skills/migration/SKILL.md` — migration methodology
5. `cagen-programs` — **only when `manifest.codegen: cagen`**. On `handwritten` estates skip it, and skip all prefix-based (IQP*/MQP*/DDP*/TIR*) reasoning — classify from static-analysis evidence instead.
6. `{target_stack.conventions_skill}` — **implementation-time agents only** (the `speckit.*` plan/implement chain, `fwd-cobol-dotnet-consistency-checker`, `code-quality-analyzer`) — load it whenever the task involves writing or reviewing target-stack code
7. `.claude/skills/mermaid/SKILL.md` — **only if the agent emits Mermaid diagrams**; must be loaded before writing any mermaid block

Additionally, Read `.claude/skills/mflens-mcp/SKILL.md` before calling any MFLens MCP tool (it is its own single source of truth). If `manifest.mflens.portfolio_id` is set, use it as the `portfolioId`; otherwise resolve per that skill.

## 6. Target-stack conventions skill selection

Implementation-time agents pick the conventions skill from `manifest.target_stack.id`:

- `net` → `target-stack-net-conventions` (.NET 4.8 / WCF / EF6 / IIS)
- `java` → `target-stack-java-conventions` (Java 21 / Spring Boot / CXF / JPA)
- any other id → **STOP** and report that no conventions skill is declared for this stack; the pack must either use a supported route id or contribute its own conventions skill via `extra_skills`.

The definition file `portfolios/{portfolio}/{target_stack.definition}` is authoritative over the conventions skill's version pins on any conflict.

## 7. Failure behavior

- A resolved skill name whose `SKILL.md` is not found in any of the three locations (§4) is a hard error — **STOP** and report the name and the three paths checked; do not continue with partial context.
- Never fall back to a different portfolio's skills or manifest. Loading the wrong domain knowledge produces confidently wrong output, which is worse than stopping.
