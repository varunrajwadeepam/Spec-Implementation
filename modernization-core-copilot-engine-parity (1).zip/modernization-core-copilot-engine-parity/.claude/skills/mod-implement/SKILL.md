---
name: mod-implement
description: Portfolio-aware alias for the full speckit implementation workflow for one story, equivalent to speckit.orchestrate. Resolves the portfolio, creates the story's spec folder under portfolios/{portfolio}/specs/{story-id}/, and runs specify through review.
argument-hint: "STORY-ACME-CORE-MU-01-01-001 [portfolio=ACME-CORE]"
---

# mod-implement

Portfolio-aware implementation workflow that runs the complete speckit pipeline (specify → plan → tasks → implement → review) with correct folder structure.

## Usage

```bash
/mod-implement STORY-ACME-CORE-MU-01-01-001
```

## What it does

Orchestrates the complete implementation workflow for a user story with portfolio-scoped folder structure:

1. **Setup** - Resolves portfolio from `.env` or story ID, creates `portfolios/{portfolio}/specs/{story-id}/`
2. **Specify** - Reads story from `portfolios/{portfolio}/docs/epics/` and generates `spec.md`
3. **Clarify** - Identifies ambiguities and updates spec
4. **Plan** - Creates technical implementation plan with architecture decisions
5. **Tasks** - Generates dependency-ordered task list
6. **Analyze** - Cross-artifact consistency check
7. **Implement** - Executes all tasks
8. **Review** - Quality validation across 7 dimensions

## Folder Structure

All artifacts are created in `portfolios/{portfolio}/specs/{story-id}/`:

```
portfolios/ACME-CORE/specs/STORY-ACME-CORE-MU-01-01-001/
├── spec.md              # Feature specification
├── plan.md              # Technical implementation plan
├── tasks.md             # Dependency-ordered task list
├── research.md          # Design decisions and ADRs
├── data-model.md        # Entity and database schema
├── review-report.md     # Quality review results
├── checklists/
│   └── requirements.md  # Requirements checklist
└── contracts/
    └── *.md             # Interface contracts
```

## Prerequisites

- Story must exist in `portfolios/{portfolio}/docs/epics/{MU-ID}/{EPIC-ID}/{story-id}.md`
- `.env` must contain `PORTFOLIO_NAME={portfolio}` OR story ID must include portfolio prefix
- Git branch should match story ID

## Portfolio Resolution

> **Authority.** The resolution rules below are a summary for the reader. The
> executable contract is `.claude/skills/portfolio-resolution/SKILL.md` — read it
> in full and follow it exactly, including the pack-first skill search and the
> mandatory client → domain → extras → migration → stack load order. Where this
> summary and that file disagree, that file wins.

Portfolio is resolved in this order:

1. Explicit argument: `/mod-implement STORY-ACME-CORE-MU-01-01-001 portfolio=ACME-CORE`
2. From `.env` file: `PORTFOLIO_NAME=ACME-CORE`
3. From story ID pattern: `STORY-{portfolio}-...` extracts `{portfolio}`
4. Error if none of the above

## Quality Gates

- **Spec clarity**: No ambiguities or underspecified areas
- **Plan completeness**: All design decisions documented
- **Task actionability**: All tasks have clear acceptance criteria
- **Implementation quality**: ≥70/100 on review score
- **Constitution compliance**: All 7 principles verified

## Example Workflow

```bash
# 1. Create and checkout story branch
git checkout -b STORY-ACME-CORE-MU-01-01-001

# 2. Run complete implementation workflow
/mod-implement STORY-ACME-CORE-MU-01-01-001

# 3. Review generates report - fix any issues if score < 70

# 4. Create PR when approved
git add .
git commit -m "feat(ACME-CORE): implement DateConverter service"
git push origin STORY-ACME-CORE-MU-01-01-001
```

## When to Use

✅ **Use this skill when:**
- Starting implementation of a user story
- Story document exists in `portfolios/{portfolio}/docs/epics/`
- You want the complete workflow (spec → plan → implement → review)
- You want portfolio-scoped folder structure enforced

❌ **Don't use when:**
- Story doesn't exist yet — this repo no longer generates EPICs/stories (the AS-IS/LLD pipelines were removed); obtain the story from the portfolio pack's `docs/epics/` first
- You only need part of the workflow (use individual `/speckit.*` skills)
- You're working on a feature not tied to a story

## Related Skills

- `/speckit.*` - Individual workflow steps (specify, plan, tasks, implement, review)

## Notes

- Creates portfolio-scoped folders automatically
- Skips steps if artifacts already exist and are up-to-date
- Review step can be re-run independently with `/speckit.review`
- Failed review (score < 70) blocks PR creation
