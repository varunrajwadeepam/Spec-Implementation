---
name: target-stack-java-conventions
description: Implementation conventions for the Java target stack (Java 21 / Spring Boot 3.4 / Apache CXF / JPA-Hibernate 6 / Spring Data / JUnit 5 / JaCoCo / DB2 LUW). Single source of truth for the stack-convention rules applied while implementing a story. Load whenever a speckit implementation agent runs on a portfolio whose declared stack (portfolios/{portfolio}/inputs/target-stack-java.md) is Java/Spring Boot.
---

# Java Target-Stack Conventions

Conventions for implementing Migration Units on the Java 21 / Spring Boot 3.4 / DB2 LUW stack. The implementation agent (speckit `plan`/`implement`) reads this file and applies the relevant sections when writing or reviewing code for a story. Rule IDs (e.g. `[JPA-02]`) are stable — cite them in generated artifacts.

**Precedence:** the portfolio's `portfolios/{portfolio}/inputs/target-stack-java.md` is authoritative for technology and version choices. The version pins below are validated defaults — if the portfolio's target-stack file disagrees, the portfolio file wins.

**Naming:** all `uwr-*` module names, `com.insurance.uwr` group IDs, and SCORECALC/UWRFMT examples in this file and the Java agents are **illustrative** (drawn from an underwriting MU). Derive the actual `{mu-prefix}`, artifactIds, and packages from the MU being processed — never emit the literal `uwr-*` names for a non-UWR portfolio.

---

## REST API Contracts — OpenAPI (applied during implementation)

Spring Boot REST controllers use `@RestController` with standard HTTP methods. The OpenAPI contract defines the API surface, request/response schemas, and error responses.

| COBOL/Legacy Concept | Spring Boot / OpenAPI Element |
|---|---|
| Program entry point | `@PostMapping` or `@GetMapping` on `@RestController` |
| COMMAREA input fields | Request body schema (`application/json`) |
| COMMAREA output fields | Response body schema (`application/json`) |
| Error codes (E001–E004) | `400 Bad Request` with `ErrorResponse` schema |
| DB2 errors (D001–D009) | `503 Service Unavailable` with `ErrorResponse` schema |
| Formatter errors (F001–F002) | `500 Internal Server Error` with `ErrorResponse` schema |
| Service interface | `@RestController` class with `@RequestMapping` base path |

**[REST-01]** All OpenAPI documents must use OpenAPI 3.1.0 format, serialized as YAML.

**[REST-02]** All endpoints must use `application/json` for both request and response content types.

**[REST-03]** All schema types must be defined in the `components/schemas` section and referenced via `$ref`. Do not inline complex types in path definitions.

**[REST-04]** Request and response schemas must include all fields from the COMMAREA interface contract (see the portfolio's client-specific skill). Field-level descriptions must reference the originating COBOL COMMAREA field name and length.

**[REST-05]** All error categories must be represented as distinct HTTP status codes with a shared `ErrorResponse` schema:
- `400` — Input validation errors (E001–E004)
- `503` — DB2 / downstream system errors (D001–D009)
- `500` — Formatter / internal processing errors (F001–F002)

**[REST-06]** All schema fields must include `description`, `example`, and applicable `maxLength` / `pattern` constraints sourced from the COMMAREA definition.

**[REST-07]** Enum-constrained fields (e.g., `riskTier`, `actionCode`, `productCode`) must use the `enum` keyword with all valid values listed.

**[REST-08]** Base path must use placeholder `http://localhost:8080` with a versioned path prefix `/api/v1` (will be replaced at deployment).

**[REST-09]** Each endpoint must declare an `operationId` in camelCase matching the Java method name that will implement it.

**[REST-10]** Security schemes must be declared in `components/securitySchemes` even if set to a placeholder (`bearerAuth` with `http` / `bearer` type). Apply at the global level with per-operation override capability.

---

## Data Access — JPA / Hibernate 6 (applied during implementation)

**[JPA-01]** Use JPA with Hibernate 6 via Spring Data JPA. Do NOT use EF6, EF Core, or any .NET ORM.

**[JPA-02]** Entity classes are annotated with `@Entity` and `@Table(name="TABLE_NAME", schema="UWR")`. Schema is preserved from mainframe (not appended with `_LUW` — follow TSA-db2-migration.md).

**[JPA-03]** Use `@Column(name="COLUMN_NAME")` to map to mainframe column names exactly. Property names follow Java camelCase convention.

**[JPA-04]** One `EntityManagerFactory` per bounded context. All repositories in an MU share the same factory, configured via `@Configuration` class.

**[JPA-05]** Use Spring Data JPA `JpaRepository<T, ID>` interfaces for repository pattern. No manual DAO implementations needed for standard CRUD.

**[JPA-06]** For custom queries use JPQL `@Query` or Spring Data derived query method names. Use native `@Query(nativeQuery=true)` only for DB2-specific syntax that JPQL cannot express.

**[JPA-07]** `ddl-auto: none` — never generate DDL. Map to existing DB2 tables.

## DB2 LUW Naming Conventions (applied during implementation)

**[DB2-01]** Schema: follow `TSA-db2-migration.md` exactly (typically the mainframe schema name, e.g. `UWR`).

> ⚠️ **Cross-stack inconsistency to verify:** the .NET stack convention defaults to a `{MAINFRAME_SCHEMA}_LUW` suffix. Confirm the portfolio's TSA DB2 migration decision — the TSA artifact wins over either default.

**[DB2-02]** Table names preserved from mainframe (e.g., `POLICY`, `APPLICANT`).

**[DB2-03]** Column names preserved from mainframe in `@Column(name=...)`.

**[DB2-04]** Use `@Id` for primary key. Composite keys use `@IdClass` or `@EmbeddedId`.

**[DB2-05]** Foreign key relationships use `@ManyToOne` / `@OneToMany` with `@JoinColumn`.

## Data Access Patterns (applied during implementation)

**[DATA-01]** Read-heavy lookups: use `findById()` or derived query methods. Spring Data JPA does not track changes unless `@Transactional` is present.

**[DATA-02]** Cursor-equivalent queries: use `Pageable` or `findTop{N}By...OrderBy...` to limit rows.

**[DATA-03]** Projection queries: use Spring Data Projections (interfaces) when only a subset of columns is needed.

**[DATA-04]** Connection pooling via HikariCP (Spring Boot default): `minimumIdle: 5`, `maximumPoolSize: 100`.

**[DATA-05]** No writes in POC scope — all operations are read-only (SELECT only).

---

## Maven Multi-Module Structure (applied during implementation)

**[PROJ-01]** One Maven parent POM per MU. All child modules inherit the parent.

**[PROJ-02]** Module naming convention: `{mu-prefix}-{layer}`

Example for an illustrative MU-UWR-01 (derive real names from the portfolio's artifacts):
- `uwr-domain` (POJOs, interfaces, enums — no Spring)
- `uwr-data-access` (JPA entities, Spring Data repositories)
- `uwr-application` (command/handler/service — Spring `@Service`)
- `uwr-infrastructure` (config properties, MDC helpers)
- `uwr-services` (Spring Boot app, CXF endpoint — `@SpringBootApplication`)

**[PROJ-03]** All modules target Java 21. Use `<java.version>21</java.version>` in parent.

**[PROJ-04]** The domain module has **no Spring dependencies** — pure Java, zero framework coupling.

**[PROJ-05]** The services module is the only deployable module (fat JAR). All others are `<packaging>jar</packaging>` libraries.

## Dependency Versions — pinned (applied during implementation)

**[DEP-01]** Spring Boot: `3.4.2` (BOM via `spring-boot-starter-parent`)

**[DEP-02]** Apache CXF: `4.1.0` (`cxf-spring-boot-starter-jaxws`)

**[DEP-03]** IBM DB2 JDBC: `com.ibm.db2:jcc:11.5.8.0`

**[DEP-04]** Testing: `spring-boot-starter-test` (provides JUnit 5.10, Mockito 5.x, AssertJ 3.x via BOM)

**[DEP-05]** JaCoCo: `0.8.12` (coverage)

**[DEP-06]** Do NOT use `spring-boot-starter-web` for SOAP — use `cxf-spring-boot-starter-jaxws` instead. They conflict if both are present unless excluded carefully.

## Apache CXF JAX-WS Configuration (applied during implementation)

**[CXF-01]** Declare the CXF endpoint bean in a `@Configuration` class. Do NOT use `cxf-servlet.xml` or Spring XML config.

**[CXF-02]** Endpoint URL pattern: `/services/{ServiceName}` (e.g., `/services/UnderwritingRiskAssessmentService`)

**[CXF-03]** Service implementation class is annotated `@WebService(endpointInterface = "...")` and injected with all dependencies via constructor injection.

**[CXF-04]** SOAP fault detail: use `@WebFault(name="ServiceFault")` on a checked exception class.

**[CXF-05]** Correlation ID: implement `AbstractPhaseInterceptor<Message>` for MDC propagation (replaces .NET `CorrelationIdBehaviorAttribute`).

## Spring IoC (applied during implementation)

**[DI-01]** All services registered as Spring beans via annotations: `@Service`, `@Repository`, `@Component`.

**[DI-02]** Constructor injection only (no `@Autowired` on fields). Enables immutability and testability.

**[DI-03]** `ThresholdSettings` bound via `@ConfigurationProperties(prefix="scoring")`. Register with `@EnableConfigurationProperties(ThresholdSettings.class)` in the main application class.

**[DI-04]** No XML configuration files — annotation-driven only.

## CA:Gen Runtime Utilities — shared static library (applied during implementation)

Applies only when `codegen: cagen`. Realises the reusable decision **ADR-CAGEN-TIR-UTILS** (see the `cagen-programs` skill) for the Java stack. Governs `TIR*` runtime modules (disposition `shared-static-util`), not business programs.

**[UTIL-01]** CA:Gen `TIR*` runtime utilities (date/numeric/view conversion) are realised as **stateless `static` methods** on a `final` utility class with a private constructor, in a **dedicated shared module** — `cagen-runtime` (or `{solution}-commons`) shared across every MU, **not** duplicated per MU. Implement from the documented behavior in the `cagen-programs` `reference/tir-runtime-modules.md`.

**[UTIL-02]** These utilities are **NOT Spring beans** — no `@Component`/`@Service`/`@Repository`, not field- or constructor-injected. Callers invoke the static method directly (e.g. `CaGenDateUtil.toDb2Date(view)`). This is the **one sanctioned exception to [DI-01]**: a stateless deterministic converter is not a component.

**[UTIL-03]** Never define an interface + mock for a `TIR*` utility and never register one in DI. Unit-test the static method directly with JUnit against its documented cases (no Mockito double); downstream tests call the **real** utility — it is pure and fast.

**[UTIL-04]** The `cagen-runtime` module has **no Spring dependency** (same rule as the domain module, [PROJ-04]). Implement inverse conversions together for round-trip consistency (e.g. `TIRD2VW`/`TIRVW2D`); the library is a cross-MU dependency, built once and reused by fan-in.

---

## Testing Framework (applied during implementation)

**[TEST-01]** Use JUnit 5 (Jupiter) for all tests — NOT JUnit 4, TestNG, or Spock.

**[TEST-02]** Use Mockito 5.x for mocking. Activate via `@ExtendWith(MockitoExtension.class)` — NOT `@RunWith(MockitoJUnitRunner.class)` (JUnit 4 style).

**[TEST-03]** Use AssertJ 3.x for assertions — NOT Hamcrest or JUnit built-in assertions.

**[TEST-04]** Use `spring-boot-starter-test` as the test BOM — it pins JUnit 5, Mockito, and AssertJ to compatible versions.

**[TEST-05]** Unit tests: zero Spring context — `@ExtendWith(MockitoExtension.class)` only.

**[TEST-06]** Integration tests: `@SpringBootTest` or `@DataJpaTest` with `@Transactional` for DB isolation.

## Test Structure (applied during implementation)

**[TEST-07]** Tests live in `src/test/java/...` within each Maven module (Maven convention). No separate test modules needed — Maven Surefire runs `src/test/java` automatically.

**[TEST-08]** Package mirrors production: `com.insurance.uwr.application.handler.AssessRiskHandlerTest` tests `AssessRiskHandler`.

**[TEST-09]** Test class naming: `{ClassUnderTest}Test` (not `Tests`, not `Spec`).

**[TEST-10]** Test method naming: `methodName_scenario_expectedResult` — mirrors .NET convention.

## Code Coverage (applied during implementation)

**[COV-01]** 80% minimum line coverage enforced by JaCoCo Maven plugin (`check` goal) — fails build if below threshold.

**[COV-02]** Exclude from coverage: `@SpringBootApplication` class, entity POJOs without logic, `@ConfigurationProperties` DTOs.

**[COV-03]** 90%+ target for command handlers and scoring services (critical business logic).
