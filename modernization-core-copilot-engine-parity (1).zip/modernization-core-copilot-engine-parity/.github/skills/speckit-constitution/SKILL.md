---
name: "speckit-constitution"
description: "Create or update the project constitution from interactive or provided principle inputs, ensuring all dependent templates stay in sync."
compatibility: "Requires the portfolio-pack project structure (.specify/, portfolios/{portfolio}/portfolio.yaml)"
metadata:
  author: "mainframe-modernization-core"
  source: ".claude/commands/speckit.constitution.md"
---

<!-- GENERATED FILE -- DO NOT EDIT.
     Source:     .claude/commands/speckit.constitution.md
     Generator:  scripts/gen-copilot.sh
     Regenerate: scripts/gen-copilot.sh
     Hand edits here are rejected by the copilot-surface CI job. -->

> **Copilot naming note.** This skill is `/speckit-constitution` here. The canonical definitions in `.claude/` use dotted names (`/speckit.constitution`); any `/speckit-<x>` reference below maps to `.claude/commands/speckit.<x>.md` or `.claude/skills/speckit.<x>/`. Use the form exposed by your agent.


## User Input

```text
$ARGUMENTS
```

You **MUST** consider the user input before proceeding (if not empty).

## Outline

You are updating the project constitution at `portfolios/{portfolio}/specs/constitution.md` (portfolio-scoped). This file is a TEMPLATE containing placeholder tokens in square brackets (e.g. `[PROJECT_NAME]`, `[PRINCIPLE_1_NAME]`). Your job is to (a) resolve the portfolio, (b) collect/derive concrete values, (c) fill the template precisely, and (d) propagate any amendments across dependent artifacts.

**Portfolio Resolution** (same precedence as other speckit commands):
1. Explicit parameter: `portfolio=ACME-REF-subset`
2. Environment variable: `PORTFOLIO_NAME` from project-root `.env`
3. Error if neither found — stop and ask the user.

**Note**: If `portfolios/{portfolio}/specs/constitution.md` does not exist yet, copy from `.specify/templates/constitution-template.md` and create the directory if needed.

Follow this execution flow:

1. Resolve portfolio (see above), then load the existing constitution at `portfolios/{portfolio}/specs/constitution.md`.
   - Identify every placeholder token of the form `[ALL_CAPS_IDENTIFIER]`.
   **IMPORTANT**: The user might require less or more principles than the ones used in the template. If a number is specified, respect that - follow the general template. You will update the doc accordingly.

2. Collect/derive values for placeholders:
   - If user input (conversation) supplies a value, use it.
   - Otherwise infer from existing repo context (README, docs, prior constitution versions if embedded).
   - For governance dates: `RATIFICATION_DATE` is the original adoption date (if unknown ask or mark TODO), `LAST_AMENDED_DATE` is today if changes are made, otherwise keep previous.
   - `CONSTITUTION_VERSION` must increment according to semantic versioning rules:
     - MAJOR: Backward incompatible governance/principle removals or redefinitions.
     - MINOR: New principle/section added or materially expanded guidance.
     - PATCH: Clarifications, wording, typo fixes, non-semantic refinements.
   - If version bump type ambiguous, propose reasoning before finalizing.

3. Draft the updated constitution content:
   - Replace every placeholder with concrete text (no bracketed tokens left except intentionally retained template slots that the project has chosen not to define yet—explicitly justify any left).
   - Preserve heading hierarchy and comments can be removed once replaced unless they still add clarifying guidance.
   - Ensure each Principle section: succinct name line, paragraph (or bullet list) capturing non‑negotiable rules, explicit rationale if not obvious.
   - Ensure Governance section lists amendment procedure, versioning policy, and compliance review expectations.

4. Consistency propagation checklist (convert prior checklist into active validations):
   - Read `.specify/templates/plan-template.md` and ensure any "Constitution Check" or rules align with updated principles.
   - Read `.specify/templates/spec-template.md` for scope/requirements alignment—update if constitution adds/removes mandatory sections or constraints.
   - Read `.specify/templates/tasks-template.md` and ensure task categorization reflects new or removed principle-driven task types (e.g., observability, versioning, testing discipline).
   - Read each command file in `.claude/commands/speckit.*.md` — the canonical definitions — to verify no outdated references remain when generic guidance is required. Do NOT edit the generated Copilot mirror under `.github/skills/*/SKILL.md`; regenerate it instead (`scripts/gen-copilot.sh`).
   - Read any runtime guidance docs (e.g., `README.md`, `docs/quickstart.md`, or agent-specific guidance files if present). Update references to principles changed.

5. Produce a Sync Impact Report (prepend as an HTML comment at top of the constitution file after update):
   - Version change: old → new
   - List of modified principles (old title → new title if renamed)
   - Added sections
   - Removed sections
   - Templates requiring updates (✅ updated / ⚠ pending) with file paths
   - Follow-up TODOs if any placeholders intentionally deferred.

6. Validation before final output:
   - No remaining unexplained bracket tokens.
   - Version line matches report.
   - Dates ISO format YYYY-MM-DD.
   - Principles are declarative, testable, and free of vague language ("should" → replace with MUST/SHOULD rationale where appropriate).

7. Write the completed constitution back to `portfolios/{portfolio}/specs/constitution.md` (overwrite).

8. Output a final summary to the user with:
   - New version and bump rationale.
   - Any files flagged for manual follow-up.
   - Suggested commit message (e.g., `docs: amend constitution to vX.Y.Z (principle additions + governance update)`).

Formatting & Style Requirements:

- Use Markdown headings exactly as in the template (do not demote/promote levels).
- Wrap long rationale lines to keep readability (<100 chars ideally) but do not hard enforce with awkward breaks.
- Keep a single blank line between sections.
- Avoid trailing whitespace.

If the user supplies partial updates (e.g., only one principle revision), still perform validation and version decision steps.

If critical info missing (e.g., ratification date truly unknown), insert `TODO(<FIELD_NAME>): explanation` and include in the Sync Impact Report under deferred items.

Do not create a new template; always operate on the existing `portfolios/{portfolio}/specs/constitution.md` file.

## Next steps

When this skill completes, the natural continuations are:

- **Build Specification** — run `/speckit-specify` with: "Implement the feature specification based on the updated constitution. I want to build..."
