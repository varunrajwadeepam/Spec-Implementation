---
name: "speckit-orchestrate"
description: "Portfolio-aware orchestration of the complete speckit implementation workflow (specify, clarify, plan, tasks, analyze, implement, review) for one story. Resolves the portfolio from the story ID, resolves and checks out the base branch, creates portfolios/{portfolio}/specs/{story-id}/, then runs every phase in order. Use this as the single entry point for implementing a story end to end."
argument-hint: "STORY-ACME-CORE-MU-01-01-001 [portfolio=ACME-CORE] [base=ACME-CORE]"
compatibility: "Requires the portfolio-pack project structure (.specify/, portfolios/{portfolio}/portfolio.yaml)"
metadata:
  author: "mainframe-modernization-core"
  source: ".claude/skills/speckit.orchestrate/SKILL.md"
---

<!-- GENERATED FILE -- DO NOT EDIT.
     Source:     .claude/skills/speckit.orchestrate/SKILL.md
     Generator:  scripts/gen-copilot.sh
     Regenerate: scripts/gen-copilot.sh
     Hand edits here are rejected by the copilot-surface CI job. -->

> **Copilot naming note.** This skill is `/speckit-orchestrate` here. The canonical definitions in `.claude/` use dotted names (`/speckit.orchestrate`); any `/speckit-<x>` reference below maps to `.claude/commands/speckit.<x>.md` or `.claude/skills/speckit.<x>/`. Use the form exposed by your agent.


# speckit-orchestrate

Portfolio-aware orchestration of the complete speckit implementation workflow.

## Usage

```bash
# Automatic portfolio detection from story ID
/speckit-orchestrate STORY-ACME-CORE-MU-01-01-001

# Explicit portfolio (REQUIRED when story ID doesn't embed portfolio)
/speckit-orchestrate STORY-MU-ACMEREF-SUBSET-01-02-001 portfolio=ACME-REF-subset
```

## What it does

Orchestrates the complete implementation workflow with automatic portfolio-scoped folder creation:

1. **Detect Portfolio** - Extract from story ID pattern `STORY-{PORTFOLIO}-...` or read from `.env`
2. **Setup Directories** - Create `portfolios/{portfolio}/specs/{story-id}/` (spec artifacts) and ensure `portfolios/{portfolio}/POC/` exists (implementation output)
3. **Run Workflow** - Execute speckit pipeline in correct location:
   - `/speckit-specify` - Generate spec.md from story document
   - `/speckit-clarify` - Identify and resolve ambiguities  
   - `/speckit-plan` - Create technical implementation plan
   - `/speckit-tasks` - Generate dependency-ordered tasks
   - `/speckit-analyze` - Non-destructive cross-artifact consistency and quality analysis across spec.md, plan.md, and tasks.md
   - `/speckit-implement` - Execute all tasks
   - `/speckit-review` - Quality validation

## Workflow Steps

| Step | Skill | Output | Purpose |
|------|-------|--------|---------|
| 1 | `/speckit-specify` | `spec.md` | Generate feature specification from the story |
| 2 | `/speckit-clarify` | Updated `spec.md` | Identify and resolve ambiguities (≤5 questions) |
| 3 | `/speckit-plan` | `plan.md`, `research.md` | Create the technical implementation plan |
| 4 | `/speckit-tasks` | `tasks.md` | Generate the dependency-ordered task list |
| 5 | `/speckit-analyze` | `analyze-status.json` | Non-destructive cross-artifact consistency and quality analysis across spec.md, plan.md, tasks.md |
| 6 | `/speckit-implement` | Code files | Execute all tasks from tasks.md |
| 7 | `/speckit-review` | `review-report.md` | Quality validation (7 scored dimensions, ≥70/100) |

## Portfolio Detection

> **Authority.** The resolution rules below are a summary for the reader. The
> executable contract is `.claude/skills/portfolio-resolution/SKILL.md` — read it
> in full and follow it exactly, including the pack-first skill search and the
> mandatory client → domain → extras → migration → stack load order. Where this
> summary and that file disagree, that file wins.

Portfolio is resolved **once** at the start, in this precedence order:

1. **Explicit parameter**: `portfolio=ACME-REF-subset` in command (highest priority)
2. **Story ID pattern**: If ID matches `STORY-{PORTFOLIO}-MU-{d}-{d}-{d}`, extract portfolio segment
3. **Environment file**: Read `PORTFOLIO_NAME` from project-root `.env`
4. **Error if none found**: Stop and ask the user

Once resolved, the portfolio value is used for all path lookups in this run.

### Story ID Matching

Matching is done against the **installed packs** — every directory under
`portfolios/` that has a `portfolio.yaml` — not against a name-shape regex. The
story ID has its `STORY-`/`EPIC-` (and legacy `MU-`) prefix stripped, and the
longest installed pack name that prefixes the remainder wins:

| Story ID | Installed pack | Resolves to |
|---|---|---|
| `STORY-ACME-CORE-MU-01-01-001` | `ACME-CORE` | `ACME-CORE` |
| `STORY-TRDOC421-MU-01-01-001` | `TRDOC421` | `TRDOC421` |
| `STORY-MEETING-ROOM-BOOKING-MU-01-01-001` | `MEETING-ROOM-BOOKING` | `MEETING-ROOM-BOOKING` |
| `STORY-ACME-REF-subset-MU-01-02-001` | `ACME-REF-subset` | `ACME-REF-subset` |

This is why matching is pack-driven: the previous regex
(`^STORY-([A-Z]+-[A-Z0-9]+)-MU-`) required exactly two uppercase hyphen-separated
segments, so it matched none of the one-segment, three-segment, or mixed-case
packs above.

**When the ID names no pack at all** (e.g. `STORY-MU-ACMEREF-SUBSET-01-02-001`,
where `ACMEREF` ≠ `ACME-REF`, or a custom-code feature like
`MRBS-001-meeting-room-booking`), resolution falls back to an existing
`portfolios/*/specs/{id}/` folder, then to locating `{id}.md` inside a pack's
`docs/epics/`. If none of those resolve, pass `portfolio=<name>` explicitly or set
`PORTFOLIO_NAME` in `.env`.

## Folder Structure Created

All artifacts are created in `portfolios/{portfolio}/specs/{story-id}/`:

```
portfolios/{portfolio}/specs/{story-id}/
├── spec.md              # Feature specification
├── plan.md              # Technical implementation plan
├── tasks.md             # Dependency-ordered task list
├── research.md          # Design decisions and ADRs
├── data-model.md        # Entity and database schema
├── review-report.md     # Quality review results
├── checklists/
│   └── requirements.md  # Requirements checklist
└── contracts/
    └── *.md             # Interface contracts
```

## Prerequisites

- Story must exist in `portfolios/{portfolio}/docs/epics/{MU-ID}/{EPIC-ID}/{story-id}.md`
- Portfolio must be resolvable (explicit parameter, Story ID pattern, or `.env`)
- **Do NOT pre-create the story branch.** `/speckit-specify` (step 0e) checks out the base branch (the portfolio integration branch, e.g., `ACME-CORE`) and then cuts the new story branch from it. Pre-creating the branch yourself causes the orchestrator to abort with "branch already exists".
- The working tree MUST be clean before invoking (no uncommitted edits, no untracked files). The sync step refuses to run on a dirty tree and will not auto-stash.

## Implementation Steps

When this skill is invoked, Claude will:

1. **Resolve portfolio** using the precedence order in "Portfolio Detection" above
2. **Validate portfolio** — confirm `portfolios/{portfolio}/docs/epics/` exists
3. **Resolve the base branch** (the portfolio integration branch — typically `ACME-CORE`, `UWR-POC`, etc., or `main` if none). Order of precedence:
   1. Explicit `base=<branch>` argument on the command.
   2. `SPECKIT_BASE_BRANCH=<branch>` in `.env`.
   3. The portfolio's integration branch if it matches the portfolio name (e.g., `ACME-CORE` for portfolio `ACME-CORE`).
   4. Default `main`.
4. **Verify clean working tree.** `git status --porcelain` MUST be empty. If dirty, abort.
5. **Check out the base branch** (`git checkout <base>` + `git pull origin <base> --ff-only`) so the new story branch is cut from the right place. This step is delegated to `/speckit-specify` step 0e but the orchestrator confirms `HEAD` is on the base branch before delegating.
6. **Create directory**: `mkdir -p portfolios/{portfolio}/specs/{story-id}`
7. **Change working directory**: `cd portfolios/{portfolio}/specs/{story-id}`
8. **Run speckit workflow** from that directory:
   - `/speckit-specify` will create the story branch from the base (its step 0e resolves and checks out the base; its step 2d creates the branch).
   - Each speckit skill runs in the portfolio-scoped folder.
   - Files are created in the correct location automatically.
   - Working directory context ensures proper scoping.

## Example Execution

```bash
# User runs (portfolio embedded in story ID):
/speckit-orchestrate STORY-ACME-CORE-MU-01-01-001

# User runs (portfolio explicit — required when ID doesn't embed it):
/speckit-orchestrate STORY-MU-ACMEREF-SUBSET-01-02-001 portfolio=ACME-REF-subset

# Claude executes:
# 1. Resolve portfolio (explicit > story ID > .env > error)
# 2. Resolve base branch (base= arg > SPECKIT_BASE_BRANCH > portfolio integration branch > main)
# 3. Verify clean tree; abort if dirty
# 4. git checkout <base> && git pull origin <base> --ff-only
# 5. mkdir -p portfolios/{portfolio}/specs/{story-id}
# 6. cd portfolios/{portfolio}/specs/{story-id}
# 7. /speckit-specify (creates and checks out the story branch)
# 8. /speckit-clarify
# 9. /speckit-plan
# 10. /speckit-tasks
# 11. /speckit-analyze
# 12. /speckit-implement
# 13. /speckit-review
```

### Branch behavior

The new story branch (`STORY-ACME-CORE-MU-01-01-001` in the example above) is created by `/speckit-specify`, not by `/speckit-orchestrate` directly. The orchestrator's responsibility is to put `HEAD` on the correct base before delegating. If the user is already on a different story branch when invoking `/speckit-orchestrate` (a common mid-stream case), the orchestrator switches to the base branch first so the new story branch does not inherit the prior story's commits.

## Common Use Cases

### Standard workflow (most common)

```bash
# Do NOT pre-create the story branch — /speckit-specify step 0e cuts it from the base.
/speckit-orchestrate STORY-ACME-CORE-MU-01-01-001
# Review writes review-report.md; fix any issues if the score is < 70
git add . && git commit -m "feat(ACME-CORE): implement feature X"
```

### Resume after interruption

Every phase is individually resumable, because state lives on disk (the spec
folder, `analyze-status.json`, `IMPACT-APPROVED.md`) and in the branch name —
not in conversation context. Re-run from whichever phase was interrupted:

```bash
/speckit-tasks
/speckit-implement
```

### Re-run quality review only

```bash
/speckit-review
```

## Quality Gates

- **Spec clarity**: No ambiguities or underspecified areas (clarify step resolves)
- **Plan completeness**: All design decisions documented with ADRs
- **Task actionability**: All tasks have clear acceptance criteria
- **Implementation quality**: ≥70/100 on review score
- **Constitution compliance**: All 7 principles verified

## Error Handling

| Error | Cause | Resolution |
|-------|-------|------------|
| "Cannot detect portfolio" | Story ID doesn't match pattern and no .env | Add `portfolio=` parameter or fix story ID format |
| "Story not found" | Story doesn't exist in docs/ | This repo no longer generates EPICs/stories — obtain the story file from the portfolio pack's `docs/epics/{MU-ID}/` first |
| "Working tree has uncommitted changes" | Dirty tree at invocation time | Commit or stash before re-running; the orchestrator never auto-stashes |
| "Cannot resolve base branch" | No `base=` arg, no `.env`, and no integration branch matching the portfolio | Pass `base=<branch>` explicitly, or set `SPECKIT_BASE_BRANCH` in `.env` |
| "Base branch has diverged from origin" | Local base branch ahead of remote (non-fast-forward) | Reconcile manually (rebase, reset, or merge) before re-running |
| "Branch already exists" | Story branch was pre-created or a prior run partially completed | Delete the partial branch (`git branch -D <story-id>`) or use the existing branch directly without re-running orchestrate |
| "Review score < 70" | Implementation quality issues | Fix issues in review-report.md and re-run /speckit-review |
| Files landed outside the pack | Individual skills were run without a resolvable portfolio | Artifacts belong in `portfolios/{portfolio}/specs/{story-id}/`. Re-run via `/speckit-orchestrate`, or pass `portfolio=<name>` to the individual skill |

## Related Skills

- Individual `/speckit.*` skills for manual workflow steps

## Notes

- Working directory changes are scoped to the skill execution
- After skill completes, working directory returns to project root
- Portfolio detection is deterministic and reproducible
- Folder structure is created automatically - no manual setup needed
- Built-in speckit skills work correctly when run from portfolio-scoped folder
