# Copilot instructions — Mainframe Modernization Engine

This repository is an agentic implementation pipeline (spec → clarify → plan → tasks →
analyze → implement → review) that turns approved migration stories into target-stack code.
It is authored for Claude Code and mirrored for GitHub Copilot; **both tools run the same
pipeline from the same canonical definitions.**

## Read `CLAUDE.md` first

`CLAUDE.md` at the repository root is the full project guide — architecture, the portfolio-pack
plugin contract, how to run the pipeline, quality gates. It applies to you exactly as it applies
to Claude Code. Read it before doing anything else in this repo.

## Where things live for Copilot

| What | Copilot reads it from | Canonical source |
|---|---|---|
| Pipeline commands (`/speckit-specify`, `/speckit-plan`, …) | `.github/skills/speckit-*/SKILL.md` — **generated, do not edit** | `.claude/commands/speckit.*.md` |
| Orchestrator (`/speckit-orchestrate`), review (`/speckit-review`) | `.github/skills/speckit-*/SKILL.md` — generated | `.claude/skills/speckit.*/SKILL.md` |
| Engine skills (`portfolio-resolution`, `migration`, `mermaid`, `cagen-programs`, `target-stack-*-conventions`, …) | `.claude/skills/*/SKILL.md` — read natively | same |
| Agents (`code-quality-analyzer`, `fwd-cobol-dotnet-consistency-checker`, `lld-epic-story-validator`, `lld-to-story`) | `.claude/agents/*.md` — read natively | same |
| Helper scripts | `.specify/scripts/bash/*.sh` | same |

**Naming.** Canonical names are dotted (`/speckit.specify`, as upstream spec-kit's templates are);
Copilot Agent Skills cannot contain dots, so the generated skills are hyphenated
(`/speckit-specify`). `CLAUDE.md` and the skill bodies refer to the dotted form — map
`speckit.<x>` → `/speckit-<x>` when invoking. Everything else (`/mod-implement`,
`portfolio-resolution`, …) is the same name in both tools.

**To change a pipeline command**, edit its source under `.claude/` and run
`scripts/gen-copilot.sh`; CI rejects hand edits to `.github/skills/`.

## Running the pipeline here

```
/speckit-orchestrate STORY-ACME-CORE-MU-01-01-001
```

Before any phase, load portfolio context by following `.claude/skills/portfolio-resolution/SKILL.md`
exactly — it resolves the pack manifest and the client, domain, and target-stack skills the
phase must have loaded. The phase skills say this at their top; do not skip it.

Helper scripts emit JSON on stdout and diagnostics on stderr; a failure is
`{"ERROR": "..."}` plus a non-zero exit. Run them from the repository root.
