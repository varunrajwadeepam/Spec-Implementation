---

### 1. ARCHITECTURE.md
Analyse the POC project codebase thoroughly — read all `pom.xml` files, all Spring Boot / Jakarta EE application configurations, all REST controllers and service layer classes, all domain entities and JPA repositories, all configuration files (application.properties, application.yml, persistence.xml, web.xml), and the Maven module structure.  
Then produce a comprehensive ARCHITECTURE.md file that includes:
- What the application does and its core business purpose
- ASCII art diagrams for:
    1. High-level architecture (REST client → application server → database),
    2. Maven module dependency graph (one node per Maven module, edges showing module dependencies),
    3. Request flow through the layers (REST controller → service → repository → database),
    4. Business domain data model (all JPA entities and their relationships with @OneToMany, @ManyToOne, etc.),
    5. Deployment architecture (application server, REST endpoints, database connection pooling),
    6. Maven project structure (one box per Maven module, annotated with layer responsibilities)
- A technology summary table (layer, technology, version) derived from `pom.xml` dependency versions

---

### 2. USE_CASES.md
Read all service layer source files, all REST controller classes, all domain entity definitions, and all custom exception and response status definitions.  
Derive every distinct use case the system supports and produce a USE_CASES.md with:
- An overview of the main business flow and any state management / validation rules
- Use cases grouped by domain (discover groupings from package structure and service classes)
- For each use case: actor, REST endpoint entry point (HTTP method + path), description of what the caller does, request inputs (path params, query params, request body), response outputs (HTTP status codes, response DTOs), and key exception types from the code
- A use case count summary table
- A request-flow diagram showing how REST operations move from controllers → services → repositories

---

### 3. ARCHITECTURE.pdf and USE_CASES.pdf
Convert ARCHITECTURE.md to a formatted PDF (ARCHITECTURE.pdf) and USE_CASES.md to a formatted PDF (USE_CASES.pdf).  
Use a monospaced font for the ASCII diagrams to preserve alignment.  
Apply clean styling with a title, section headers, and tables.

---

### 4. CYCLOMATIC_COMPLEXITY.pdf / cc-data.json
Compute the cyclomatic complexity for every Java file across all production Maven modules (exclude test modules and test source sets).  
For each method, count the number of decision points (`if`, `else if`, `for`, `foreach`, `while`, `do`, `switch case`, `catch`, `&&`, `||`, `?` ternary, `Optional.orElse`, stream terminal operations with predicates) and add 1.  
Produce:
- A `cc-data.json` with per-file and per-method scores
- A CYCLOMATIC_COMPLEXITY.pdf report with: summary statistics table (total methods, mean CC, median CC, high-risk methods ≥ 10), a ranked list of the top 20 most complex methods, a histogram of CC score distribution, and per-module detail tables

---

### 5. CODE_QUALITY_ANALYSIS.pdf
Perform a full static code quality analysis of the POC codebase. Read all Java source files across all production Maven modules.  
Assess and report on:
- Code duplication patterns (copy-paste across similar service classes, DTOs, or repository implementations)
- Method length and class size distributions
- Coupling and cohesion (Maven module-level fan-in / fan-out, interface-to-implementation ratios, Spring bean dependency graphs)
- Naming conventions and consistency (Java camelCase / PascalCase standards, package naming conventions)
- Error handling patterns (exception hierarchy usage, `@ControllerAdvice` coverage, custom exception types, HTTP status code mappings)
- Cyclomatic complexity hotspots
- Dead code or unreachable paths (unused service methods, unreferenced DTOs, unused repository queries)
- Spring/Jakarta EE best practices (proper use of `@Transactional`, `@Service` vs `@Component`, constructor injection vs field injection)

Produce a CODE_QUALITY_ANALYSIS.pdf with findings, severity ratings, and recommendations.

---

### 6. NFR_ANALYSIS.pdf
Analyse the POC project against Non-Functional Requirements. Read all `pom.xml` files, all Spring Boot / Jakarta EE configuration files (application.properties, application.yml, persistence.xml, server.xml), logging configuration (logback.xml, log4j2.xml), and all source code.  
Assess the following NFR categories with evidence and recommendations:
- Performance (JPA query patterns, N+1 query detection, database connection pooling configuration, lazy vs. eager loading, REST response payload size, use of caching annotations)
- Scalability (stateless vs. stateful REST design, Spring bean scope configuration, database transaction isolation levels, horizontal scaling readiness)
- Security (Spring Security configuration, input validation coverage (Bean Validation / JSR-380), SQL injection risk via JPA/JDBC, authentication/authorization patterns, PII data handling, logging of sensitive fields)
- Maintainability (Maven module structure, test coverage (JUnit/TestNG), JavaDoc coverage, externalized configuration management via Spring profiles)
- Reliability (exception handling coverage, global exception handler (`@ControllerAdvice`) behavior, correlation ID propagation, transaction management with `@Transactional`)
- Portability (Spring Boot vs. Jakarta EE lock-in, database driver coupling, application server-specific dependencies, cloud-native readiness)
- Build & Deployment (Maven build repeatability, dependency convergence, multi-module build order, Docker/Kubernetes readiness, Spring Boot Actuator health checks)

Produce a NFR_ANALYSIS.pdf with a summary scorecard and detailed findings per category.

---

### 7. FULL_STACK_ANALYSIS.pdf
Combine all findings from the architecture review, use case catalogue, cyclomatic complexity analysis, code quality analysis, and NFR analysis into a single comprehensive FULL_STACK_ANALYSIS.pdf.  
Include an executive summary, a risk register (high/medium/low), prioritised recommendations, and a full appendix of all diagrams and data tables.
