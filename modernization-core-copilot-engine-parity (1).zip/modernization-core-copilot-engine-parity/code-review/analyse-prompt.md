---

### 1. ARCHITECTURE.md
Analyse the POC project codebase thoroughly – read all pom.xml files, the Angular source in POC-client/src, the REST controllers in POC-online, the action blocks and entities in POC-core, and the config in POC-web-config.  
Then produce a comprehensive ARCHITECTURE.md file that includes:
- What the application does and its core business purpose
- ASCII art diagrams for:
    1. High-level architecture (browser → server → DB),
    2. Maven module dependency graph,
    3. Request flow through the layers,
    4. Business domain data model,
    5. Deployment architecture,
    6. Angular frontend module structure
- A technology summary table (layer, technology, version)

---

### 2. USE_CASES.md
Read all action block source files in POC-core, the REST controllers in POC-online, and the exit-states definitions.  
Derive every distinct use case the system supports and produce a USE_CASES.md with:
- An overview of the approval chain and immutability rules
- Use cases grouped by domain (Agreement Management, Agreement Period Management, Loss Period Management, Loss Period Bill Management, etc.)
- For each use case: actor, entry point, description of what the user does, inputs, outputs, and key exit state codes from the code
- A use case count summary table
- A navigation flow diagram showing how screens connect

---

### 3. ARCHITECTURE.pdf and USE_CASES.pdf
Convert ARCHITECTURE.md to a formatted PDF (ARCHITECTURE.pdf) and USE_CASES.md to a formatted PDF (USE_CASES.pdf).  
Use a monospaced font for the ASCII diagrams to preserve alignment.  
Apply clean styling with a title, section headers, and tables.

---

### 4. CYCLOMATIC_COMPLEXITY.pdf / cc-data.json
Compute the cyclomatic complexity for every Java file in POC-core and POC-online.  
For each method, count the number of decision points (if, else if, for, while, do, switch case, catch, &&, ||, ternary) and add 1.  
Produce:
- A cc-data.json with per-file and per-method scores
- A CYCLOMATIC_COMPLEXITY.pdf report with: summary statistics table (total methods, mean CC, median CC, high-risk methods), a ranked list of the top 20 most complex methods, a histogram of CC score distribution, and per-file detail tables

---

### 5. CODE_QUALITY_ANALYSIS.pdf
Perform a full static code quality analysis of the POC codebase. Read all Java source in POC-core, POC-online, and POC-web-config.  
Assess and report on:
- Code duplication patterns (copy-paste across action blocks)
- Method length and class size distributions
- Coupling and cohesion (fan-in / fan-out between modules)
- Naming conventions and consistency
- Error handling patterns (exit state usage)
- Cyclomatic complexity hotsPOCs
- Dead code or unreachable paths

Produce a CODE_QUALITY_ANALYSIS.pdf with findings, severity ratings, and recommendations.

---

### 6. NFR_ANALYSIS.pdf
Analyse the POC project against Non-Functional Requirements. Read all pom.xml files, the Liberty server config, the Angular build config, and the source code.  
Assess the following NFR categories with evidence and recommendations:
- Performance (DB access patterns, connection pooling, caching, Angular bundle size)
- Scalability (Stateless vs stateful design, session management)
- Security (Authentication/authorisation, input validation, SQL injection risk)
- Maintainability (Module structure, test coverage, documentation)
- Reliability (Error handling, exit state coverage, transaction management)
- Portability (Jakarta EE standard compliance, Liberty-specific lock-in)
- Build & Deployment (Maven build repeatability, frontend/backend coupling)

Produce a NFR_ANALYSIS.pdf with a summary scorecard and detailed findings per category.

---

### 7. FULL_STACK_ANALYSIS.pdf
Combine all findings from the architecture review, use case catalogue, cyclomatic complexity analysis, code quality analysis, and NFR analysis into a single comprehensive FULL_STACK_ANALYSIS.pdf.  
Include an executive summary, a risk register (high/medium/low), prioritised recommendations, and a full appendix of all diagrams and data tables.
