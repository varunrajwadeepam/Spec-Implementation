---

### 1. ARCHITECTURE.md
Analyse the POC project codebase thoroughly — read all `.csproj` files, `packages.config` files, the solution `.sln` file, all WCF service contracts and implementations, all application handlers and services, all domain models and business logic, all EF6 repositories and entity mappings, and all infrastructure configuration files (Web.config, NLog.config, transform configs).  
Then produce a comprehensive ARCHITECTURE.md file that includes:
- What the application does and its core business purpose
- ASCII art diagrams for:
    1. High-level architecture (SOAP client → IIS / WCF → database),
    2. .NET project reference dependency graph (one node per `.csproj`, edges showing project references),
    3. Request flow through the layers (WCF contract → handler → services → repositories → database),
    4. Business domain data model (all domain entities and their relationships),
    5. Deployment architecture (IIS application pool, WCF `.svc` endpoint, database connection),
    6. Solution project structure (one box per `.csproj`, annotated with layer responsibilities)
- A technology summary table (layer, technology, version) derived from `packages.config` and `.csproj` files

---

### 2. USE_CASES.md
Read all handler and service source files in the application layer, the WCF service contract interfaces and implementations, and all domain exception, status code, and result type definitions.  
Derive every distinct use case the system supports and produce a USE_CASES.md with:
- An overview of the main business flow and any immutability / error-state rules
- Use cases grouped by domain (discover groupings from the code)
- For each use case: actor, WCF operation entry point, description of what the caller does, request inputs, response outputs, and key status/action/exception codes from the code
- A use case count summary table
- A request-flow diagram showing how operations move from WCF → handlers → services → repositories

---

### 3. ARCHITECTURE.pdf and USE_CASES.pdf
Convert ARCHITECTURE.md to a formatted PDF (ARCHITECTURE.pdf) and USE_CASES.md to a formatted PDF (USE_CASES.pdf).  
Use a monospaced font for the ASCII diagrams to preserve alignment.  
Apply clean styling with a title, section headers, and tables.

---

### 4. CYCLOMATIC_COMPLEXITY.pdf / cc-data.json
Compute the cyclomatic complexity for every C# file across all production projects (exclude test projects).  
For each method, count the number of decision points (`if`, `else if`, `for`, `foreach`, `while`, `do`, `switch case`, `catch`, `&&`, `||`, `?` ternary, `??` null-coalescing, `?.` null-conditional) and add 1.  
Produce:
- A `cc-data.json` with per-file and per-method scores
- A CYCLOMATIC_COMPLEXITY.pdf report with: summary statistics table (total methods, mean CC, median CC, high-risk methods ≥ 10), a ranked list of the top 20 most complex methods, a histogram of CC score distribution, and per-file detail tables

---

### 5. CODE_QUALITY_ANALYSIS.pdf
Perform a full static code quality analysis of the POC codebase. Read all C# source files across all production projects.  
Assess and report on:
- Code duplication patterns (copy-paste across similar classes such as result types or repository implementations)
- Method length and class size distributions
- Coupling and cohesion (project-level fan-in / fan-out, interface-to-implementation ratios)
- Naming conventions and consistency (C# PascalCase / camelCase standards, prefix conventions)
- Error handling patterns (exception hierarchy usage, `FaultException<T>` coverage, domain status/action code usage)
- Cyclomatic complexity hotspots
- Dead code or unreachable paths (unused interfaces, unreferenced DTOs)

Produce a CODE_QUALITY_ANALYSIS.pdf with findings, severity ratings, and recommendations.

---

### 6. NFR_ANALYSIS.pdf
Analyse the POC project against Non-Functional Requirements. Read all `.csproj` and `packages.config` files, all Web.config variants (base, Debug, Release transforms), logging config, test run settings, and all source code.  
Assess the following NFR categories with evidence and recommendations:
- Performance (EF6 query patterns, database connection management, lazy vs. eager loading, SOAP payload size)
- Scalability (stateless vs. stateful WCF design, IoC container lifetime scoping, IIS application pool configuration)
- Security (WCF transport / message security, input validation coverage, SQL injection risk via EF6, PII data handling, logging of sensitive fields)
- Maintainability (project structure, test coverage, inline documentation, externalised configuration management)
- Reliability (exception handling coverage, error handler behaviour, correlation ID propagation, transaction management in EF6)
- Portability (.NET Framework 4.8 / WCF lock-in vs. .NET 6+ migration path, database driver coupling, IIS-specific hosting)
- Build & Deployment (MSBuild repeatability, `packages.config` vs. PackageReference, smoke-test scripts, deployment transform configs)

Produce a NFR_ANALYSIS.pdf with a summary scorecard and detailed findings per category.

---

### 7. FULL_STACK_ANALYSIS.pdf
Combine all findings from the architecture review, use case catalogue, cyclomatic complexity analysis, code quality analysis, and NFR analysis into a single comprehensive FULL_STACK_ANALYSIS.pdf.  
Include an executive summary, a risk register (high/medium/low), prioritised recommendations, and a full appendix of all diagrams and data tables.
