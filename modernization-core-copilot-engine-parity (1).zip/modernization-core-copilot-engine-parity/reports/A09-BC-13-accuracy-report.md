# A09 TSA Accuracy Report — BC-13

**Portfolio:** RevDB-subset2  
**BC:** BC-13 (Revenue Reference Data Lookup (Pool Codes))  
**Target stack:** java  
**Programs:** 9  
**MUs:** 1  
**Generated:** 2026-07-28 09:29  

## Verdict

PASS — TSA complete and consistent with bounded-contexts.json

## Summary

| Check | Errors | Warnings |
|-------|--------|----------|
| ✅ REQUIRED-FILES | 0 | 0 |
| ✅ PROGRAM-COVERAGE | 0 | 0 |
| ✅ WAVE-ORDER | 0 | 0 |
| ✅ MU-COVERAGE | 0 | 0 |
| ✅ ADRS | 0 | 0 |
| ✅ RISKS | 0 | 0 |
| ✅ STACK-VIOLATION | 0 | 0 |
| ✅ FRONTMATTER | 0 | 0 |
| **Total** | 0 | 0 |
