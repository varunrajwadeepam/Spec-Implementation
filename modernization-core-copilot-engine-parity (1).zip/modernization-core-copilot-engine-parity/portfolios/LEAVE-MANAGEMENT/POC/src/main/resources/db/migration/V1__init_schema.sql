CREATE TABLE employee (
    id            BIGSERIAL PRIMARY KEY,
    name          VARCHAR(255) NOT NULL,
    leave_balance INTEGER      NOT NULL DEFAULT 17
);

CREATE TABLE leave_request (
    id           BIGSERIAL PRIMARY KEY,
    employee_id  BIGINT       NOT NULL REFERENCES employee (id),
    days         INTEGER      NOT NULL,
    reason       VARCHAR(500) NOT NULL,
    requested_at TIMESTAMP    NOT NULL DEFAULT now()
);

CREATE INDEX idx_leave_request_employee_id ON leave_request (employee_id);
