package com.leavemanagement.web;

import com.leavemanagement.application.EmployeeService;
import com.leavemanagement.domain.Employee;
import com.leavemanagement.web.dto.BalanceResponse;
import com.leavemanagement.web.dto.EmployeeRegisterRequest;
import com.leavemanagement.web.dto.EmployeeResponse;
import jakarta.validation.Valid;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/employees")
public class EmployeeController {

    private final EmployeeService employeeService;

    public EmployeeController(EmployeeService employeeService) {
        this.employeeService = employeeService;
    }

    @PostMapping
    public ResponseEntity<EmployeeResponse> register(@Valid @RequestBody EmployeeRegisterRequest request) {
        Employee employee = employeeService.registerEmployee(request.name());
        return ResponseEntity.status(HttpStatus.CREATED).body(EmployeeResponse.from(employee));
    }

    @GetMapping("/{employeeId}/balance")
    public ResponseEntity<BalanceResponse> getBalance(@PathVariable Long employeeId) {
        Employee employee = employeeService.getEmployee(employeeId);
        return ResponseEntity.ok(BalanceResponse.from(employee));
    }
}
