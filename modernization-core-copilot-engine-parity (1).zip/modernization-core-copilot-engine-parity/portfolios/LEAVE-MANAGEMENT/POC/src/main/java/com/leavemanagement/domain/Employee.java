package com.leavemanagement.domain;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name = "employee")
public class Employee {

    /** BR-01: every new employee starts with this many leave days. */
    public static final int DEFAULT_LEAVE_BALANCE = 17;

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "name", nullable = false)
    private String name;

    @Column(name = "leave_balance", nullable = false)
    private int leaveBalance;

    protected Employee() {
        // JPA
    }

    public Employee(String name) {
        this.name = name;
        this.leaveBalance = DEFAULT_LEAVE_BALANCE;
    }

    public Long getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public int getLeaveBalance() {
        return leaveBalance;
    }

    public void deduct(int days) {
        if (days > leaveBalance) {
            throw new IllegalStateException("Insufficient balance");
        }
        this.leaveBalance -= days;
    }
}
