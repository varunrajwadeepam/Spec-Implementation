package com.leavemanagement.web.dto;

import com.leavemanagement.domain.LeaveRequest;
import java.time.Instant;

public record LeaveHistoryItem(Long id, int days, String reason, Instant requestedAt) {

    public static LeaveHistoryItem from(LeaveRequest leaveRequest) {
        return new LeaveHistoryItem(
                leaveRequest.getId(), leaveRequest.getDays(), leaveRequest.getReason(), leaveRequest.getRequestedAt());
    }
}
