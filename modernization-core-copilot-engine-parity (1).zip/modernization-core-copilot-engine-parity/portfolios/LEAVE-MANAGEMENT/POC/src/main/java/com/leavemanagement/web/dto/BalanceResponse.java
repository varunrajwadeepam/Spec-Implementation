package com.leavemanagement.web.dto;

import com.leavemanagement.domain.Employee;

public record BalanceResponse(Long employeeId, int leaveBalance) {

    public static BalanceResponse from(Employee employee) {
        return new BalanceResponse(employee.getId(), employee.getLeaveBalance());
    }
}
