package com.leavemanagement.domain;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import java.time.Instant;

/** Append-only audit record of an approved leave request; never updated or deleted. */
@Entity
@Table(name = "leave_request")
public class LeaveRequest {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "employee_id", nullable = false)
    private Long employeeId;

    @Column(name = "days", nullable = false)
    private int days;

    @Column(name = "reason", nullable = false)
    private String reason;

    @Column(name = "requested_at", nullable = false)
    private Instant requestedAt;

    protected LeaveRequest() {
        // JPA
    }

    public LeaveRequest(Long employeeId, int days, String reason) {
        this.employeeId = employeeId;
        this.days = days;
        this.reason = reason;
        this.requestedAt = Instant.now();
    }

    public Long getId() {
        return id;
    }

    public Long getEmployeeId() {
        return employeeId;
    }

    public int getDays() {
        return days;
    }

    public String getReason() {
        return reason;
    }

    public Instant getRequestedAt() {
        return requestedAt;
    }
}
