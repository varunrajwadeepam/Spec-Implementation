package com.leavemanagement.web.dto;

import jakarta.validation.constraints.NotBlank;

public record EmployeeRegisterRequest(@NotBlank String name) {
}
