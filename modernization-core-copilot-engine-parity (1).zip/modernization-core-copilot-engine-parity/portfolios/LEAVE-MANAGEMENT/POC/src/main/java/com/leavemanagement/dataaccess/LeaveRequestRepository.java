package com.leavemanagement.dataaccess;

import com.leavemanagement.domain.LeaveRequest;
import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;

public interface LeaveRequestRepository extends JpaRepository<LeaveRequest, Long> {

    List<LeaveRequest> findByEmployeeIdOrderByRequestedAtAsc(Long employeeId);
}
