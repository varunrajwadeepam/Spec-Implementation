package com.leavemanagement.web.dto;

import com.leavemanagement.domain.Employee;

public record LeaveActionResponse(Long employeeId, int leaveBalance, String reason) {

    public static LeaveActionResponse of(Employee employee, String reason) {
        return new LeaveActionResponse(employee.getId(), employee.getLeaveBalance(), reason);
    }
}
