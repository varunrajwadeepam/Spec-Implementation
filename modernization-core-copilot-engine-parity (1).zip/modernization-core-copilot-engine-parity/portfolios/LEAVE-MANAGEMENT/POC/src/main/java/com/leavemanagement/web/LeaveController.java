package com.leavemanagement.web;

import com.leavemanagement.application.LeaveService;
import com.leavemanagement.domain.Employee;
import com.leavemanagement.domain.LeaveRequest;
import com.leavemanagement.web.dto.LeaveActionResponse;
import com.leavemanagement.web.dto.LeaveHistoryItem;
import com.leavemanagement.web.dto.LeaveRequestBody;
import jakarta.validation.Valid;
import java.util.List;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/employees/{employeeId}/leaves")
public class LeaveController {

    private final LeaveService leaveService;

    public LeaveController(LeaveService leaveService) {
        this.leaveService = leaveService;
    }

    @PostMapping
    public ResponseEntity<LeaveActionResponse> requestLeave(
            @PathVariable Long employeeId, @Valid @RequestBody LeaveRequestBody request) {
        Employee employee = leaveService.requestLeave(employeeId, request.days(), request.reason());
        return ResponseEntity.status(HttpStatus.CREATED)
                .body(LeaveActionResponse.of(employee, request.reason()));
    }

    @GetMapping
    public ResponseEntity<List<LeaveHistoryItem>> listLeaves(@PathVariable Long employeeId) {
        List<LeaveRequest> leaves = leaveService.listLeaves(employeeId);
        return ResponseEntity.ok(leaves.stream().map(LeaveHistoryItem::from).toList());
    }
}
