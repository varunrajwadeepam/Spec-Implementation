package com.leavemanagement.web.dto;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Positive;

public record LeaveRequestBody(@NotNull @Positive Integer days, @NotBlank String reason) {
}
