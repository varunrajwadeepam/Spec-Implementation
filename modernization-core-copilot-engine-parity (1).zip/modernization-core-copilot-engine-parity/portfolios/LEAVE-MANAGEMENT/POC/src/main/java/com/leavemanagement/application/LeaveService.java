package com.leavemanagement.application;

import com.leavemanagement.dataaccess.EmployeeRepository;
import com.leavemanagement.dataaccess.LeaveRequestRepository;
import com.leavemanagement.domain.Employee;
import com.leavemanagement.domain.LeaveRequest;
import java.util.List;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
public class LeaveService {

    private final EmployeeRepository employeeRepository;
    private final LeaveRequestRepository leaveRequestRepository;

    public LeaveService(EmployeeRepository employeeRepository, LeaveRequestRepository leaveRequestRepository) {
        this.employeeRepository = employeeRepository;
        this.leaveRequestRepository = leaveRequestRepository;
    }

    @Transactional
    public Employee requestLeave(Long employeeId, int days, String reason) {
        Employee employee = employeeRepository.findByIdForUpdate(employeeId)
                .orElseThrow(() -> new NotFoundException("Unknown employeeId: " + employeeId));

        if (days > employee.getLeaveBalance()) {
            throw new InsufficientBalanceException(
                    "Requested " + days + " days exceeds balance of " + employee.getLeaveBalance());
        }

        employee.deduct(days);
        employeeRepository.save(employee);
        leaveRequestRepository.save(new LeaveRequest(employeeId, days, reason));
        return employee;
    }

    @Transactional(readOnly = true)
    public List<LeaveRequest> listLeaves(Long employeeId) {
        if (!employeeRepository.existsById(employeeId)) {
            throw new NotFoundException("Unknown employeeId: " + employeeId);
        }
        return leaveRequestRepository.findByEmployeeIdOrderByRequestedAtAsc(employeeId);
    }
}
