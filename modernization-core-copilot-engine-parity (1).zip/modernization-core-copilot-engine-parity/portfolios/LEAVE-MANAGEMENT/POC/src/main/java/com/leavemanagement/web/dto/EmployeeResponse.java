package com.leavemanagement.web.dto;

import com.leavemanagement.domain.Employee;

public record EmployeeResponse(Long employeeId, String name, int leaveBalance) {

    public static EmployeeResponse from(Employee employee) {
        return new EmployeeResponse(employee.getId(), employee.getName(), employee.getLeaveBalance());
    }
}
