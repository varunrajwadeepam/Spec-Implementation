package com.leavemanagement.application;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import com.leavemanagement.dataaccess.EmployeeRepository;
import com.leavemanagement.domain.Employee;
import java.util.Optional;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

@ExtendWith(MockitoExtension.class)
class EmployeeServiceTest {

    @Mock
    private EmployeeRepository employeeRepository;

    @InjectMocks
    private EmployeeService employeeService;

    @Test
    void registerEmployee_validName_returnsEmployeeWithDefaultBalance() {
        when(employeeRepository.save(any(Employee.class))).thenAnswer(invocation -> invocation.getArgument(0));

        Employee result = employeeService.registerEmployee("Ada Lovelace");

        assertThat(result.getName()).isEqualTo("Ada Lovelace");
        assertThat(result.getLeaveBalance()).isEqualTo(Employee.DEFAULT_LEAVE_BALANCE);
        verify(employeeRepository).save(any(Employee.class));
    }

    @Test
    void getEmployee_existingId_returnsEmployee() {
        Employee employee = new Employee("Ada Lovelace");
        when(employeeRepository.findById(1L)).thenReturn(Optional.of(employee));

        Employee result = employeeService.getEmployee(1L);

        assertThat(result).isSameAs(employee);
    }

    @Test
    void getEmployee_unknownId_throwsNotFoundException() {
        when(employeeRepository.findById(99L)).thenReturn(Optional.empty());

        assertThatThrownBy(() -> employeeService.getEmployee(99L)).isInstanceOf(NotFoundException.class);
    }
}
