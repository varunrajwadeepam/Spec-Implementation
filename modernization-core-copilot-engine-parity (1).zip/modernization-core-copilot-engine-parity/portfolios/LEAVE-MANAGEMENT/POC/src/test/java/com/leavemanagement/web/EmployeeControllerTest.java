package com.leavemanagement.web;

import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.leavemanagement.application.EmployeeService;
import com.leavemanagement.application.NotFoundException;
import com.leavemanagement.domain.Employee;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.web.servlet.MockMvc;

@WebMvcTest(EmployeeController.class)
class EmployeeControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @Autowired
    private ObjectMapper objectMapper;

    @MockBean
    private EmployeeService employeeService;

    @Test
    void register_validName_returns201() throws Exception {
        Employee employee = newEmployee(1L, "Ada Lovelace");
        when(employeeService.registerEmployee(anyString())).thenReturn(employee);

        mockMvc.perform(post("/api/employees")
                        .contentType("application/json")
                        .content(objectMapper.writeValueAsString(new NameRequest("Ada Lovelace"))))
                .andExpect(status().isCreated())
                .andExpect(jsonPath("$.employeeId").value(1))
                .andExpect(jsonPath("$.leaveBalance").value(17));
    }

    @Test
    void register_blankName_returns400() throws Exception {
        mockMvc.perform(post("/api/employees")
                        .contentType("application/json")
                        .content(objectMapper.writeValueAsString(new NameRequest(""))))
                .andExpect(status().isBadRequest());
    }

    @Test
    void getBalance_existingEmployee_returns200() throws Exception {
        Employee employee = newEmployee(1L, "Ada Lovelace");
        when(employeeService.getEmployee(1L)).thenReturn(employee);

        mockMvc.perform(get("/api/employees/1/balance"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.leaveBalance").value(17));
    }

    @Test
    void getBalance_unknownEmployee_returns404() throws Exception {
        when(employeeService.getEmployee(99L)).thenThrow(new NotFoundException("Unknown employeeId: 99"));

        mockMvc.perform(get("/api/employees/99/balance")).andExpect(status().isNotFound());
    }

    private static Employee newEmployee(Long id, String name) throws Exception {
        Employee employee = new Employee(name);
        java.lang.reflect.Field idField = Employee.class.getDeclaredField("id");
        idField.setAccessible(true);
        idField.set(employee, id);
        return employee;
    }

    private record NameRequest(String name) {
    }
}
