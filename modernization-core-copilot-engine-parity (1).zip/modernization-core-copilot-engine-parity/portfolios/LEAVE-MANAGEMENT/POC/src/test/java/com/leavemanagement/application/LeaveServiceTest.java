package com.leavemanagement.application;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import com.leavemanagement.dataaccess.EmployeeRepository;
import com.leavemanagement.dataaccess.LeaveRequestRepository;
import com.leavemanagement.domain.Employee;
import com.leavemanagement.domain.LeaveRequest;
import java.util.List;
import java.util.Optional;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

@ExtendWith(MockitoExtension.class)
class LeaveServiceTest {

    @Mock
    private EmployeeRepository employeeRepository;

    @Mock
    private LeaveRequestRepository leaveRequestRepository;

    @InjectMocks
    private LeaveService leaveService;

    @Test
    void requestLeave_withinBalance_deductsAndPersistsAuditRow() {
        Employee employee = new Employee("Ada Lovelace");
        when(employeeRepository.findByIdForUpdate(1L)).thenReturn(Optional.of(employee));

        Employee result = leaveService.requestLeave(1L, 3, "Family trip");

        assertThat(result.getLeaveBalance()).isEqualTo(Employee.DEFAULT_LEAVE_BALANCE - 3);
        verify(employeeRepository).save(employee);
        verify(leaveRequestRepository).save(any(LeaveRequest.class));
    }

    @Test
    void requestLeave_exceedsBalance_throwsInsufficientBalanceAndDoesNotPersist() {
        Employee employee = new Employee("Ada Lovelace");
        for (int i = 0; i < 15; i++) {
            employee.deduct(1);
        }
        when(employeeRepository.findByIdForUpdate(1L)).thenReturn(Optional.of(employee));

        assertThatThrownBy(() -> leaveService.requestLeave(1L, 3, "Too many days"))
                .isInstanceOf(InsufficientBalanceException.class);

        assertThat(employee.getLeaveBalance()).isEqualTo(2);
        verify(employeeRepository, never()).save(any(Employee.class));
        verify(leaveRequestRepository, never()).save(any(LeaveRequest.class));
    }

    @Test
    void requestLeave_unknownEmployee_throwsNotFoundException() {
        when(employeeRepository.findByIdForUpdate(99L)).thenReturn(Optional.empty());

        assertThatThrownBy(() -> leaveService.requestLeave(99L, 1, "reason"))
                .isInstanceOf(NotFoundException.class);
        verify(leaveRequestRepository, never()).save(any(LeaveRequest.class));
    }

    @Test
    void listLeaves_existingEmployee_returnsHistory() {
        when(employeeRepository.existsById(1L)).thenReturn(true);
        LeaveRequest leaveRequest = new LeaveRequest(1L, 3, "Family trip");
        when(leaveRequestRepository.findByEmployeeIdOrderByRequestedAtAsc(1L)).thenReturn(List.of(leaveRequest));

        List<LeaveRequest> result = leaveService.listLeaves(1L);

        assertThat(result).containsExactly(leaveRequest);
    }

    @Test
    void listLeaves_unknownEmployee_throwsNotFoundException() {
        when(employeeRepository.existsById(99L)).thenReturn(false);

        assertThatThrownBy(() -> leaveService.listLeaves(99L)).isInstanceOf(NotFoundException.class);
    }
}
