package com.leavemanagement.web;

import static org.mockito.ArgumentMatchers.anyInt;
import static org.mockito.ArgumentMatchers.anyLong;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.leavemanagement.application.InsufficientBalanceException;
import com.leavemanagement.application.LeaveService;
import com.leavemanagement.application.NotFoundException;
import com.leavemanagement.domain.Employee;
import com.leavemanagement.domain.LeaveRequest;
import java.lang.reflect.Field;
import java.util.List;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.web.servlet.MockMvc;

@WebMvcTest(LeaveController.class)
class LeaveControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @Autowired
    private ObjectMapper objectMapper;

    @MockBean
    private LeaveService leaveService;

    @Test
    void requestLeave_withinBalance_returns201() throws Exception {
        Employee employee = withId(new Employee("Ada Lovelace"), 1L);
        employee.deduct(3);
        when(leaveService.requestLeave(anyLong(), anyInt(), anyString())).thenReturn(employee);

        mockMvc.perform(post("/api/employees/1/leaves")
                        .contentType("application/json")
                        .content(objectMapper.writeValueAsString(new LeaveBody(3, "Family trip"))))
                .andExpect(status().isCreated())
                .andExpect(jsonPath("$.leaveBalance").value(14));
    }

    @Test
    void requestLeave_invalidDays_returns400() throws Exception {
        mockMvc.perform(post("/api/employees/1/leaves")
                        .contentType("application/json")
                        .content(objectMapper.writeValueAsString(new LeaveBody(0, "Family trip"))))
                .andExpect(status().isBadRequest());
    }

    @Test
    void requestLeave_blankReason_returns400() throws Exception {
        mockMvc.perform(post("/api/employees/1/leaves")
                        .contentType("application/json")
                        .content(objectMapper.writeValueAsString(new LeaveBody(1, ""))))
                .andExpect(status().isBadRequest());
    }

    @Test
    void requestLeave_unknownEmployee_returns404() throws Exception {
        when(leaveService.requestLeave(anyLong(), anyInt(), anyString()))
                .thenThrow(new NotFoundException("Unknown employeeId: 99"));

        mockMvc.perform(post("/api/employees/99/leaves")
                        .contentType("application/json")
                        .content(objectMapper.writeValueAsString(new LeaveBody(1, "reason"))))
                .andExpect(status().isNotFound());
    }

    @Test
    void requestLeave_insufficientBalance_returns409() throws Exception {
        when(leaveService.requestLeave(anyLong(), anyInt(), anyString()))
                .thenThrow(new InsufficientBalanceException("Requested 3 days exceeds balance of 2"));

        mockMvc.perform(post("/api/employees/1/leaves")
                        .contentType("application/json")
                        .content(objectMapper.writeValueAsString(new LeaveBody(3, "reason"))))
                .andExpect(status().isConflict());
    }

    @Test
    void listLeaves_existingEmployee_returns200() throws Exception {
        when(leaveService.listLeaves(1L)).thenReturn(List.of(new LeaveRequest(1L, 3, "Family trip")));

        mockMvc.perform(get("/api/employees/1/leaves"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$[0].days").value(3));
    }

    @Test
    void listLeaves_unknownEmployee_returns404() throws Exception {
        when(leaveService.listLeaves(99L)).thenThrow(new NotFoundException("Unknown employeeId: 99"));

        mockMvc.perform(get("/api/employees/99/leaves")).andExpect(status().isNotFound());
    }

    private static Employee withId(Employee employee, Long id) throws Exception {
        Field idField = Employee.class.getDeclaredField("id");
        idField.setAccessible(true);
        idField.set(employee, id);
        return employee;
    }

    private record LeaveBody(Integer days, String reason) {
    }
}
