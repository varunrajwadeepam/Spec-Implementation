# STORY-LEAVE-MANAGEMENT-MU-01-01-001: Employee self-service leave tracking (register, balance inquiry, request leave)

**Type:** Technical
**Satisfies FRs:** N/A
**Points:** 5

## Card

As an employee, I want to register myself, check my remaining leave balance, and submit a leave
request against that balance, so that I can manage my own vacation days without any manager
approval step.

## Conversation

Single standalone Spring Boot service `leave-management` (Java 21 / Spring Boot 3.4 / PostgreSQL /
Flyway), layered the same way as the `MEETING-ROOM-BOOKING` reference pack (`domain` /
`application` / `dataaccess` / `web`). No messaging, batch, or external integrations.

- **Web layer:** `EmployeeController` (`POST /api/employees`, `GET /api/employees/{id}/balance`),
  `LeaveController` (`POST /api/employees/{id}/leaves`, `GET /api/employees/{id}/leaves`), one
  shared `GlobalExceptionHandler` (`@RestControllerAdvice` + RFC 7807 `ProblemDetail`).
- **Application layer:** `EmployeeService` (`registerEmployee`, `getEmployee`), `LeaveService`
  (`requestLeave`) — both stateless `@Service` beans.
- **Data access layer:** `EmployeeRepository` only; there is no separate `Leave` entity — a leave
  request mutates `Employee.leaveBalance` and appends an audit row to `leave_request`.
- **Domain layer:** `Employee` entity (`id`, `name`, `leaveBalance`); `LeaveRequest` is a
  JPA-mapped audit entity, append-only, never updated or deleted.

**Data model:** `employee(id PK, name, leave_balance)`, `leave_request(id PK, employee_id FK,
days, reason, requested_at)`, indexed on `leave_request.employee_id`. `Employee.leaveBalance` is
the denormalized source of truth for "days left" (not derived by summing `leave_request` at read
time), so the balance check stays a single indexed-row read.

**Transactions:** `registerEmployee` — single `@Transactional` `INSERT`. `getEmployee` /
balance inquiry — `@Transactional(readOnly = true)` single `SELECT`. `requestLeave` — one
`@Transactional` method spanning pessimistic-lock read (`SELECT ... FOR UPDATE` on the employee
row, same pattern as the reference pack's `RoomRepository.findByIdForUpdate`), balance check,
`UPDATE employee`, `INSERT leave_request` — all four commit or roll back together.

**API contracts** (base path `/api`, JSON, no auth):

| Method | Path | Request | Success | Failure |
|---|---|---|---|---|
| `POST` | `/api/employees` | `{ "name": "Ada Lovelace" }` | `201 { "employeeId", "name", "leaveBalance": 17 }` | `400` invalid name |
| `GET` | `/api/employees/{employeeId}/balance` | - | `200 { "employeeId", "leaveBalance" }` | `404` unknown employee |
| `POST` | `/api/employees/{employeeId}/leaves` | `{ "days": 3, "reason": "..." }` | `201 { "employeeId", "leaveBalance", "reason" }` | `404` unknown, `400` invalid days, `409` insufficient balance |
| `GET` | `/api/employees/{employeeId}/leaves` | - | `200 [ { "id", "days", "reason", "requestedAt" } ]` | `404` unknown employee |

DTOs mirror the reference pattern's `RoomRequest`/`RoomResponse`: Java `record`s with
`jakarta.validation` annotations (`@NotBlank`, `@NotNull`, `@Positive`) and a static `from(entity)`
factory per response record.

### Non-functional notes

- **Error handling:** `MethodArgumentNotValidException` → 400, `IllegalArgumentException` → 400,
  `NotFoundException` → 404, `InsufficientBalanceException` → 409, catch-all `Exception` → 500
  with a generic body (no stack trace leaked).
- **Retry:** no server-side idempotency key on `POST /leaves` in v1 (accepted risk — a client
  retry after a timeout could double-deduct if the original request committed); no async/queue
  retries exist anywhere in this system.
- **Caching:** none — balance reads are cheap single-row indexed PK lookups; do not add a cache.
- **Security:** no authentication/authorization in v1 (any holder of an `employeeId` can act on
  it) — still validate all input via `jakarta.validation` and use parameterized JPA queries only.
- **Logging:** INFO on both state-changing calls with `employeeId` + outcome
  (`success`/`insufficient_balance`/`not_found`), WARN on `NotFoundException` /
  `InsufficientBalanceException`, ERROR + stack trace on the catch-all 500 handler.
- **Performance:** pessimistic lock on `employee.id` serializes concurrent requests for the *same*
  employee only; different employees never block each other. No pagination on the leave-history
  endpoint in v1 (small per-employee row counts assumed).

## Confirmation

- Given a request with a non-blank `name`, when `POST /api/employees` is called, then a `201` is
  returned with a generated `employeeId` and `leaveBalance` of exactly `17` (BR-01).
- Given a request with a blank `name`, when `POST /api/employees` is called, then a `400` is
  returned and no employee row is created (VR-01).
- Given an existing employee with balance `17`, when `GET /api/employees/{id}/balance` is called,
  then a `200` is returned with `leaveBalance: 17`.
- Given an unknown `employeeId`, when `GET /api/employees/{id}/balance` is called, then a `404` is
  returned (VR-04).
- Given an employee with balance `17`, when a leave request for `3` days with a non-blank reason
  is submitted, then a `201` is returned with `leaveBalance: 14`, the change is persisted
  atomically with a matching `leave_request` audit row, and no manager-approval step blocks it
  (BR-02, BR-03).
- Given an employee with balance `2`, when a leave request for `3` days is submitted, then a `409`
  is returned, the balance is left unchanged at `2`, and no `leave_request` row is written (BR-02).
- Given a leave request with `days: 0` or a negative value, when `POST /api/employees/{id}/leaves`
  is called, then a `400` is returned (VR-02).
- Given a leave request with a blank `reason`, when `POST /api/employees/{id}/leaves` is called,
  then a `400` is returned (VR-03).
- Given an unknown `employeeId`, when `POST /api/employees/{id}/leaves` is called, then a `404` is
  returned and no balance mutation occurs (VR-04).
- Given two concurrent leave requests against the same employee that together exceed the balance,
  when both are submitted at once, then the pessimistic row lock serializes them so at most one
  succeeds and the balance never goes negative (BR-02).

### Definition of Done

- [ ] Implementation complete
- [ ] Unit tests written and passing
- [ ] Code coverage meets target-stack threshold
- [ ] Integration tests passing (if applicable)
