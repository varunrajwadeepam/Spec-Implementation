# Feature Specification: Employee self-service leave tracking (register, balance inquiry, request leave)

**Feature Branch**: `STORY-LEAVE-MANAGEMENT-MU-01-01-001`
**Created**: 2026-09-16
**Status**: Draft
**Input**: Story `portfolios/LEAVE-MANAGEMENT/docs/epics/MU-01-01/EPIC-MU-01-01-01/STORY-LEAVE-MANAGEMENT-MU-01-01-001.md`

## User Scenarios & Testing *(mandatory)*

### User Story 1 - Register as an employee (Priority: P1)

As a new employee, I want to register with just my name so that I receive an employee ID and a
starting leave balance without any manager or admin action.

**Why this priority**: Nothing else in the system works without an employee record — this is the
entry point for every other capability.

**Independent Test**: Can be fully tested by calling `POST /api/employees` with a name and
verifying a `201` with a generated `employeeId` and `leaveBalance` of `17`.

**Acceptance Scenarios**:

1. **Given** a request with a non-blank `name`, **When** `POST /api/employees` is called, **Then**
   a `201` is returned with a generated `employeeId` and `leaveBalance` of exactly `17`.
2. **Given** a request with a blank `name`, **When** `POST /api/employees` is called, **Then** a
   `400` is returned and no employee row is created.

---

### User Story 2 - Check my remaining leave balance (Priority: P1)

As an employee, I want to look up my remaining leave balance by my employee ID so that I know how
many days I have left before requesting leave.

**Why this priority**: Balance visibility is required before a leave request can be made
meaningfully, and is independently valuable (read-only, no side effects).

**Independent Test**: Can be fully tested by registering an employee, then calling
`GET /api/employees/{id}/balance` and verifying the returned balance matches the persisted value.

**Acceptance Scenarios**:

1. **Given** an existing employee with balance `17`, **When**
   `GET /api/employees/{id}/balance` is called, **Then** a `200` is returned with
   `leaveBalance: 17`.
2. **Given** an unknown `employeeId`, **When** `GET /api/employees/{id}/balance` is called,
   **Then** a `404` is returned.

---

### User Story 3 - Submit a leave request against my balance (Priority: P1)

As an employee, I want to submit a leave request for a number of days and a reason, and have it
auto-approved against my balance immediately, so that I can manage my own vacation days without
any manager approval step.

**Why this priority**: This is the core value-delivering transaction of the system; balance
inquiry alone has no purpose without it.

**Independent Test**: Can be fully tested by registering an employee, submitting a leave request
within balance, and verifying the balance is deducted, a `201` is returned, and a matching audit
row exists.

**Acceptance Scenarios**:

1. **Given** an employee with balance `17`, **When** a leave request for `3` days with a
   non-blank reason is submitted, **Then** a `201` is returned with `leaveBalance: 14`, the change
   is persisted atomically with a matching `leave_request` audit row, and no manager-approval step
   blocks it.
2. **Given** an employee with balance `2`, **When** a leave request for `3` days is submitted,
   **Then** a `409` is returned, the balance is left unchanged at `2`, and no `leave_request` row
   is written.
3. **Given** a leave request with `days: 0` or a negative value, **When**
   `POST /api/employees/{id}/leaves` is called, **Then** a `400` is returned.
4. **Given** a leave request with a blank `reason`, **When**
   `POST /api/employees/{id}/leaves` is called, **Then** a `400` is returned.
5. **Given** an unknown `employeeId`, **When** `POST /api/employees/{id}/leaves` is called,
   **Then** a `404` is returned and no balance mutation occurs.
6. **Given** two concurrent leave requests against the same employee that together exceed the
   balance, **When** both are submitted at once, **Then** the pessimistic row lock serializes them
   so at most one succeeds and the balance never goes negative.

---

### User Story 4 - View my leave request history (Priority: P2)

As an employee, I want to list my past leave requests so that I can see what I've taken.

**Why this priority**: Useful but not required for the core register/balance/request loop to
deliver value; smallest independent slice.

**Independent Test**: Can be fully tested by submitting one or more leave requests, then calling
`GET /api/employees/{id}/leaves` and verifying all rows are returned in a stable order.

**Acceptance Scenarios**:

1. **Given** an employee with existing leave requests, **When**
   `GET /api/employees/{id}/leaves` is called, **Then** a `200` is returned with each request's
   `id`, `days`, `reason`, and `requestedAt`.
2. **Given** an unknown `employeeId`, **When** `GET /api/employees/{id}/leaves` is called,
   **Then** a `404` is returned.

### Edge Cases

- Concurrent leave requests on the same employee must not allow the balance to go negative
  (handled via pessimistic row locking).
- A leave request exactly equal to the remaining balance succeeds and leaves the balance at `0`.
- Unexpected/unclassified errors return `500` with a generic body — no stack trace leaked.

## Requirements *(mandatory)*

### Functional Requirements

- **FR-001**: System MUST allow anyone to register as an employee by providing a non-blank
  `name`, returning a generated `employeeId` and a default `leaveBalance` of `17` (BR-01).
- **FR-002**: System MUST reject registration with a blank `name` with `400` and create no row
  (VR-01).
- **FR-003**: System MUST allow lookup of an employee's current leave balance by `employeeId`
  (`200`), or `404` if the employee does not exist (VR-04).
- **FR-004**: System MUST allow an employee to submit a leave request (`days`, `reason`) that is
  auto-approved and deducted from the balance in the same call if sufficient balance exists
  (BR-02, BR-03), returning `201` with the updated balance.
- **FR-005**: System MUST reject a leave request that exceeds the current balance with `409` and
  leave the balance and audit trail unchanged (BR-02).
- **FR-006**: System MUST reject a leave request with `days <= 0` with `400` (VR-02).
- **FR-007**: System MUST reject a leave request with a blank `reason` with `400` (VR-03).
- **FR-008**: System MUST reject any operation referencing an unknown `employeeId` with `404`
  (VR-04).
- **FR-009**: System MUST persist every successful leave request as an append-only audit row in
  `leave_request`, atomically with the balance deduction.
- **FR-010**: System MUST list an employee's leave request history ordered by request time,
  returning `404` for an unknown `employeeId`.
- **FR-011**: System MUST serialize concurrent leave requests against the same employee (row-level
  locking) so the balance never goes negative.
- **FR-012**: System MUST NOT require authentication/authorization in this version — any caller
  holding an `employeeId` may act on it (accepted risk, documented, not a gap).

### Key Entities

- **Employee**: `id` (generated), `name`, `leaveBalance` (denormalized running balance, starts at
  17).
- **LeaveRequest**: `id` (generated), `employeeId` (FK), `days`, `reason`, `requestedAt` —
  append-only audit record, never updated or deleted.

## Success Criteria *(mandatory)*

### Measurable Outcomes

- **SC-001**: An employee can register, check balance, and submit a leave request end-to-end in
  three sequential API calls with no manual/manager intervention.
- **SC-002**: 100% of leave requests that would drive the balance negative are rejected with no
  balance mutation (verified by concurrent-request test).
- **SC-003**: 100% of requests against an unknown `employeeId` return `404` with no side effects.
- **SC-004**: Balance and audit-trail writes are atomic — no state exists where a balance is
  deducted without a corresponding audit row, or vice versa.

## Assumptions

- No authentication/authorization, leave-type distinctions, accrual/carry-forward, or manager
  approval workflow are in scope (explicitly out of scope per the source story/LLD).
- One leave "day" is a whole day; no half-day granularity.
- Per-employee leave-request history is small; no pagination required in v1.
