# Tasks: Employee self-service leave tracking

**Input**: [plan.md](./plan.md), [spec.md](./spec.md)
**Output root**: `portfolios/LEAVE-MANAGEMENT/POC/`

## Phase 1 — Project scaffolding

- [X] T001 Create Maven project (`pom.xml`) — Spring Boot 3.4 parent, `spring-boot-starter-web`,
  `spring-boot-starter-data-jpa`, `spring-boot-starter-validation`, `flyway-core`,
  `flyway-database-postgresql`, `postgresql` driver, `spring-boot-starter-test`, JaCoCo plugin
  (80% line coverage gate)
- [X] T002 `application.yml` (Postgres datasource, Flyway enabled, JPA `ddl-auto: validate`)
- [X] T003 `docker-compose.yml` (Postgres 16), `Dockerfile`
- [X] T004 `V1__init_schema.sql` Flyway migration (`employee`, `leave_request`,
  `idx_leave_request_employee_id`)

## Phase 2 — Domain layer

- [X] T005 [P] `Employee` entity (`id`, `name`, `leaveBalance`, `DEFAULT_LEAVE_BALANCE = 17`
  constant)
- [X] T006 [P] `LeaveRequest` entity (append-only, `id`, `employeeId`, `days`, `reason`,
  `requestedAt`)

## Phase 3 — Data access layer

- [X] T007 `EmployeeRepository` (`JpaRepository<Employee, Long>` + pessimistic-lock
  `findByIdForUpdate`)
- [X] T008 `LeaveRequestRepository` (`JpaRepository<LeaveRequest, Long>` +
  `findByEmployeeIdOrderByRequestedAtAsc`)

## Phase 4 — Application layer

- [X] T009 `NotFoundException`, `InsufficientBalanceException`
- [X] T010 `EmployeeService.registerEmployee` (FR-001, FR-002, BR-01, VR-01)
- [X] T011 `EmployeeService.getEmployee` (FR-003, VR-04)
- [X] T012 `LeaveService.requestLeave` — pessimistic lock, balance check, atomic update + audit
  insert (FR-004, FR-005, FR-009, FR-011, BR-02, BR-03)
- [X] T013 `LeaveService.listLeaves` (FR-010)

## Phase 5 — Web layer

- [X] T014 [P] Request/response DTOs (`EmployeeRegisterRequest`, `EmployeeResponse`,
  `BalanceResponse`, `LeaveRequestBody`, `LeaveResponse`) with `jakarta.validation` annotations
  (VR-01..VR-03)
- [X] T015 `EmployeeController` (`POST /api/employees`, `GET /api/employees/{id}/balance`)
- [X] T016 `LeaveController` (`POST /api/employees/{id}/leaves`,
  `GET /api/employees/{id}/leaves`)
- [X] T017 `GlobalExceptionHandler` (`@RestControllerAdvice`, RFC 7807 `ProblemDetail` mapping
  per LLD "Error & Exception Handling Strategy")

## Phase 6 — Tests

- [X] T018 [P] `EmployeeServiceTest` (unit, Mockito) — register happy/blank-name,
  get happy/not-found
- [X] T019 [P] `LeaveServiceTest` (unit, Mockito) — request happy path, insufficient balance,
  not-found, zero/negative days, blank reason, listLeaves happy/not-found
- [X] T020 [P] `EmployeeControllerTest` (`@WebMvcTest`) — 201/400 on register, 200/404 on balance
- [X] T021 [P] `LeaveControllerTest` (`@WebMvcTest`) — 201/400/404/409 on leave request,
  200/404 on history

## Phase 7 — Verification

- [X] T022 Run `mvn test` and confirm all tests pass
- [X] T023 Run `mvn verify` (JaCoCo coverage gate) and confirm ≥80% line coverage

## Dependencies

- T001-T004 before all others.
- T005-T006 (domain) before T007-T008 (data access) before T009-T013 (application) before
  T014-T017 (web).
- T018-T021 can start once their corresponding production class exists; T022-T023 last.

## Parallel Example

```
T005, T006 in parallel (independent entity classes)
T014 in parallel with T015/T016 authoring (DTOs are consumed by controllers but are independently writable)
T018, T019, T020, T021 in parallel (independent test classes)
```
