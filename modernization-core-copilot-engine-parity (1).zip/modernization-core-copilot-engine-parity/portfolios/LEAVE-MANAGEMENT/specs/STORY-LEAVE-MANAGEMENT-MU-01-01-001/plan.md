# Implementation Plan: Employee self-service leave tracking

**Branch**: `STORY-LEAVE-MANAGEMENT-MU-01-01-001` | **Spec**: [spec.md](./spec.md)
**Input**: Feature specification + `portfolios/LEAVE-MANAGEMENT/architecture/lld/LLD.md`

## Summary

Standalone Spring Boot 3.4 / Java 21 REST service, single Maven module, PostgreSQL + Flyway,
layered `domain` / `application` / `dataaccess` / `web` packages (mirrors the
`MEETING-ROOM-BOOKING` reference pattern). No messaging, no batch, no external integrations, no
authentication. Implements employee registration, balance inquiry, leave request (auto-approved,
pessimistic-locked), and leave history listing.

## Technical Context

- **Language/Runtime**: Java 21
- **Framework**: Spring Boot 3.4 (`spring-boot-starter-web`, `spring-boot-starter-data-jpa`,
  `spring-boot-starter-validation`)
- **Database**: PostgreSQL 16, schema-managed by Flyway (`V1__init_schema.sql`)
- **Testing**: JUnit 5, Mockito 5, AssertJ, `spring-boot-starter-test`; JaCoCo for coverage
  ([TEST-01]..[TEST-10], [COV-01]..[COV-03] per `target-stack-java-conventions`)
- **Packaging**: single Maven module, fat JAR (`spring-boot-maven-plugin`)
- **Local infra**: `docker-compose.yml` for Postgres, matching reference pack

## Constitution / Conventions Check

- `target_stack.id: java` → `target-stack-java-conventions` skill loaded. This is a handwritten,
  non-CA:Gen, non-mainframe-migration greenfield service (`codegen: handwritten`), so CXF/SOAP,
  DB2, and multi-module MU-prefix rules in that skill do not apply — the story's own architecture
  (plain REST controllers, single module, PostgreSQL) is authoritative, consistent with the sibling
  `MEETING-ROOM-BOOKING` reference pack.
- Applicable conventions: JUnit 5 / Mockito / AssertJ testing stack, JaCoCo 80% minimum line
  coverage with 90%+ target on service classes, constructor injection only, package-mirrors-test
  structure, `{ClassUnderTest}Test` naming.
- `client_skill` / `domain_skill` for this portfolio are stubs (no client-specific constraints
  beyond the LLD) — proceeding on the LLD + story as the authoritative design source.

## Project Structure

```
portfolios/LEAVE-MANAGEMENT/POC/
├── pom.xml
├── docker-compose.yml
├── Dockerfile
└── src/
    ├── main/
    │   ├── java/com/leavemanagement/
    │   │   ├── LeaveManagementApplication.java
    │   │   ├── domain/
    │   │   │   ├── Employee.java
    │   │   │   └── LeaveRequest.java
    │   │   ├── dataaccess/
    │   │   │   ├── EmployeeRepository.java
    │   │   │   └── LeaveRequestRepository.java
    │   │   ├── application/
    │   │   │   ├── EmployeeService.java
    │   │   │   ├── LeaveService.java
    │   │   │   ├── NotFoundException.java
    │   │   │   └── InsufficientBalanceException.java
    │   │   └── web/
    │   │       ├── EmployeeController.java
    │   │       ├── LeaveController.java
    │   │       ├── GlobalExceptionHandler.java
    │   │       └── dto/
    │   │           ├── EmployeeRegisterRequest.java
    │   │           ├── EmployeeResponse.java
    │   │           ├── BalanceResponse.java
    │   │           ├── LeaveRequestBody.java
    │   │           └── LeaveResponse.java
    │   └── resources/
    │       ├── application.yml
    │       └── db/migration/V1__init_schema.sql
    └── test/java/com/leavemanagement/
        ├── application/{EmployeeServiceTest,LeaveServiceTest}.java
        └── web/{EmployeeControllerTest,LeaveControllerTest}.java
```

## Design Decisions (ADRs)

- **ADR-01 — No separate `Leave` entity.** A leave request mutates `Employee.leaveBalance`
  (denormalized counter) and appends a `leave_request` audit row in the same transaction;
  `leave_request` is never read back to compute balance. Rationale: keeps the balance check a
  single indexed-row read (LLD "Data Model").
- **ADR-02 — Pessimistic locking over optimistic.** `requestLeave` uses
  `SELECT ... FOR UPDATE` (`@Lock(PESSIMISTIC_WRITE)` in Spring Data) on the employee row rather
  than `@Version` optimistic locking, because a losing concurrent request must be rejected with a
  business `409`, not retried — an optimistic-lock exception would require an extra retry loop for
  no behavioral benefit here.
- **ADR-03 — RFC 7807 `ProblemDetail` via one `@RestControllerAdvice`.** Matches the reference
  pack and keeps exception-to-status mapping in a single place (`GlobalExceptionHandler`).
- **ADR-04 — Constant for default balance.** `Employee.DEFAULT_LEAVE_BALANCE = 17` as a named
  constant (BR-01), not a magic number.

## Data Model

See LLD `architecture/lld/LLD.md` → "Database Schema Mapping" for the authoritative DDL; carried
into `V1__init_schema.sql` unchanged.

## API Contracts

See LLD → "API Contracts" table (also mirrored in spec.md User Stories). No OpenAPI YAML is
generated for this greenfield handwritten service — DTOs are the executable contract, per the
`MEETING-ROOM-BOOKING` sibling precedent.

## Complexity Tracking

No constitution violations or unjustified complexity — single module, no distributed transactions,
no additional infra beyond Postgres.
