# LLD - Leave Management System

**Portfolio:** LEAVE-MANAGEMENT
**Status:** Draft - input to `lld-to-story`
**Reference implementation pattern:** `portfolios/MEETING-ROOM-BOOKING/POC` (Java 21 / Spring Boot 3.4 / PostgreSQL / Flyway, layered `domain` / `application` / `dataaccess` / `web`)

---

## Capability Overview

A minimal, single-service leave (vacation) tracking system for employees. It exposes three capabilities:

1. **Employee registration** - anyone can register with just a name and receive a generated employee ID. No authentication, no manager hierarchy, no approval workflow.
2. **Leave balance inquiry** - any caller holding an employee ID can look up that employee's remaining leave days. Every new employee starts with a fixed balance of **17 days**.
3. **Leave request** - an employee (identified by employee ID) can submit a leave request with a reason and a number of days. If sufficient balance exists, the days are deducted immediately (no manager approval step in this simple system) and the updated balance is returned.

Out of scope (explicitly, to keep this a "very simple" system per the brief): authentication/authorization, manager approval chains, leave types (sick/casual/earned), carry-forward/accrual rules, public holidays, half-day leave, leave cancellation, and multi-tenant/company hierarchy. These are candidate future EPICs, not part of this LLD.

---

## Service Decomposition

Single standalone Spring Boot service, `leave-management`, following the same layering as the meeting-room-booking reference:

```mermaid
flowchart TD
    subgraph WEB["web layer"]
        EC["EmployeeController"]
        LC["LeaveController"]
        GEH["GlobalExceptionHandler"]
    end
    subgraph APP["application layer"]
        ES["EmployeeService"]
        LS["LeaveService"]
    end
    subgraph DATA["dataaccess layer"]
        ER["EmployeeRepository"]
    end
    subgraph DOM["domain layer"]
        EMP["Employee entity"]
    end

    EC --> ES
    LC --> LS
    ES --> ER
    LS --> ER
    ER --> EMP
```

There is no separate `Leave` entity in this simple version - a leave request is a mutation of the `Employee.leaveBalance` column, recorded as an audit row in a `leave_request` table for traceability (see Data Model). `LeaveService` and `EmployeeService` are both stateless `@Service` beans; no messaging, no batch, no external integrations.

---

## Sequence Diagrams

### Register employee

```mermaid
sequenceDiagram
    participant Client
    participant EmployeeController
    participant EmployeeService
    participant EmployeeRepository
    participant DB as PostgreSQL

    Client->>EmployeeController: POST /api/employees {name}
    EmployeeController->>EmployeeService: registerEmployee(name)
    EmployeeService->>EmployeeRepository: save(new Employee(name, 17))
    EmployeeRepository->>DB: INSERT INTO employee
    DB-->>EmployeeRepository: generated id
    EmployeeRepository-->>EmployeeService: Employee
    EmployeeService-->>EmployeeController: Employee
    EmployeeController-->>Client: 201 {employeeId, name, leaveBalance:17}
```

### Check leave balance

```mermaid
sequenceDiagram
    participant Client
    participant LeaveController
    participant EmployeeService
    participant EmployeeRepository
    participant DB as PostgreSQL

    Client->>LeaveController: GET /api/employees/{id}/balance
    LeaveController->>EmployeeService: getEmployee(id)
    EmployeeService->>EmployeeRepository: findById(id)
    EmployeeRepository->>DB: SELECT * FROM employee WHERE id=?
    DB-->>EmployeeRepository: row or empty
    EmployeeRepository-->>EmployeeService: Optional Employee
    alt found
        EmployeeService-->>LeaveController: Employee
        LeaveController-->>Client: 200 {employeeId, leaveBalance}
    else not found
        EmployeeService-->>LeaveController: NotFoundException
        LeaveController-->>Client: 404 ProblemDetail
    end
```

### Request leave

```mermaid
sequenceDiagram
    participant Client
    participant LeaveController
    participant LeaveService
    participant EmployeeRepository
    participant DB as PostgreSQL

    Client->>LeaveController: POST /api/employees/{id}/leaves {days, reason}
    LeaveController->>LeaveService: requestLeave(id, days, reason)
    LeaveService->>EmployeeRepository: findByIdForUpdate(id)
    EmployeeRepository->>DB: SELECT ... FOR UPDATE
    DB-->>EmployeeRepository: Employee row
    alt balance >= days
        LeaveService->>EmployeeRepository: save(employee with reduced balance)
        LeaveService->>EmployeeRepository: insert leave_request audit row
        EmployeeRepository->>DB: UPDATE employee, INSERT leave_request
        LeaveService-->>LeaveController: updated Employee
        LeaveController-->>Client: 201 {employeeId, leaveBalance, reason}
    else balance < days
        LeaveService-->>LeaveController: InsufficientBalanceException
        LeaveController-->>Client: 409 ProblemDetail
    end
```

---

## API Contracts

Base path: `/api`. JSON over HTTP, no auth (see Security Design for why).

| Method | Path | Request Body | Success | Failure |
|---|---|---|---|---|
| `POST` | `/api/employees` | `{ "name": "Ada Lovelace" }` | `201 { "employeeId": 1, "name": "Ada Lovelace", "leaveBalance": 17 }` | `400` invalid name |
| `GET` | `/api/employees/{employeeId}/balance` | - | `200 { "employeeId": 1, "leaveBalance": 14 }` | `404` unknown employee |
| `POST` | `/api/employees/{employeeId}/leaves` | `{ "days": 3, "reason": "Family trip" }` | `201 { "employeeId": 1, "leaveBalance": 14, "reason": "Family trip" }` | `404` unknown employee, `400` invalid days, `409` insufficient balance |
| `GET` | `/api/employees/{employeeId}/leaves` | - | `200 [ { "id": 5, "days": 3, "reason": "Family trip", "requestedAt": "2026-09-10T09:00:00Z" } ]` | `404` unknown employee |

DTOs mirror the reference pattern (`RoomRequest`/`RoomResponse`): Java `record`s with `jakarta.validation` annotations (`@NotBlank`, `@NotNull`, `@Positive`), and a static `from(entity)` factory on each response record.

---

## Data Model

```mermaid
erDiagram
    EMPLOYEE {
        bigint id PK
        varchar name
        integer leave_balance
    }
    LEAVE_REQUEST {
        bigint id PK
        bigint employee_id FK
        integer days
        varchar reason
        timestamptz requested_at
    }
    EMPLOYEE ||--o{ LEAVE_REQUEST : "requests"
```

- `Employee.leaveBalance` is the current source of truth for "days left" (denormalized counter, not derived from summing `leave_request` at read time, to keep the balance check a single indexed row read).
- `LEAVE_REQUEST` is an append-only audit/history table; it is never updated or deleted in this simple version.

---

## Business Rules and Validation Rules (Goes in PRD)

1. **BR-01 - Default balance.** Every new employee starts with a leave balance of exactly **17 days**. This value is a named constant, not a magic number, so it is one-line-changeable if the business rule changes later.
2. **BR-02 - Balance cannot go negative.** A leave request for more days than the current balance is rejected outright (no partial approval, no negative balance, no borrowing against future accrual).
3. **BR-03 - No approval workflow.** Any request within balance is auto-approved and the balance is deducted synchronously in the same call - there is no pending/approved/rejected state machine in this version.
4. **VR-01 - `name`** must be non-blank on registration.
5. **VR-02 - `days`** on a leave request must be a positive integer (`> 0`); zero-day or negative-day requests are rejected with `400`.
6. **VR-03 - `reason`** must be non-blank on a leave request.
7. **VR-04 - `employeeId`** in any inquiry or request must reference an existing employee, else `404`.

---

## Error & Exception Handling Strategy

Follows the reference pattern's `@RestControllerAdvice` + `ProblemDetail` (RFC 7807) approach - one `GlobalExceptionHandler` translating domain exceptions to HTTP status:

| Exception | HTTP Status | Trigger |
|---|---|---|
| `MethodArgumentNotValidException` | 400 | Bean validation failure (blank name/reason, missing/non-positive days) |
| `IllegalArgumentException` | 400 | Programmatic invariant violation not covered by bean validation |
| `NotFoundException` | 404 | Unknown `employeeId` |
| `InsufficientBalanceException` | 409 | Leave request days exceed current balance |
| `Exception` (catch-all) | 500 | Unexpected error; body carries only a generic message, no stack trace, to avoid leaking internals |

No retries are attempted inside the exception handler itself - see Retry Logic below for where retry belongs.

---

## Retry Logic

This is a synchronous, single-database, no-external-integration system, so retry logic is minimal and confined to the data layer:

- **Optimistic concern:** none by default - the balance-deduction path uses a pessimistic row lock (`SELECT ... FOR UPDATE`, same pattern as the reference system's `RoomRepository.findByIdForUpdate`), so there is no lost-update race to retry around.
- **Transient DB errors** (connection drop, deadlock victim): the client (caller of the REST API) is responsible for retrying `POST /api/employees/{id}/leaves` with the same idempotency expectations as any non-idempotent POST - i.e., a naive retry on `POST` can double-deduct if the first attempt actually committed. Given the "very simple" scope, no server-side idempotency key is implemented in v1; this is called out as a risk below.
- **No message queues, no async jobs, no scheduled retries** exist in this system.

---

## Database Schema Mapping

PostgreSQL, migrated with Flyway (`V1__init_schema.sql`), same tooling as the reference pack:

```sql
CREATE TABLE employee (
    id            BIGSERIAL PRIMARY KEY,
    name          VARCHAR(255) NOT NULL,
    leave_balance INTEGER      NOT NULL DEFAULT 17
);

CREATE TABLE leave_request (
    id           BIGSERIAL PRIMARY KEY,
    employee_id  BIGINT       NOT NULL REFERENCES employee (id),
    days         INTEGER      NOT NULL,
    reason       VARCHAR(500) NOT NULL,
    requested_at TIMESTAMPTZ  NOT NULL DEFAULT now()
);

CREATE INDEX idx_leave_request_employee_id ON leave_request (employee_id);
```

Entity mapping mirrors the reference (`@Entity`/`@Table`/`@Column`, `IDENTITY` generation strategy, protected no-arg constructor for JPA, public constructor for domain use).

---

## Transaction Boundaries

- `EmployeeService.registerEmployee` - single `@Transactional` method, one `INSERT`.
- `EmployeeService.getEmployee` / balance inquiry - `@Transactional(readOnly = true)`, single `SELECT`.
- `LeaveService.requestLeave` - single `@Transactional` method spanning: pessimistic-lock read of the `employee` row, balance check, `UPDATE employee`, `INSERT leave_request`. Committing or rolling back all four together is what prevents a balance decrement without a matching audit row (or vice versa).

No cross-service or distributed transactions exist - everything is one service, one database.

---

## Caching Strategy

None in v1. Balance reads are cheap, single-row, indexed-PK lookups against Postgres; introducing a cache (e.g., per-employee balance in Redis) would add invalidation complexity disproportionate to the "very simple" scope and risks serving a stale balance right after a leave request. If read volume later justifies it, a short-TTL cache keyed by `employeeId` invalidated on write would be the natural next step - not implemented now.

---

## Integration Design

None. This is a standalone service with no upstream/downstream systems, no message brokers, no external APIs. It does not integrate with the mainframe estate, MFLens, or any other portfolio pack - it is a net-new greenfield application, not a modernization of existing COBOL.

---

## Batch Design

None. All operations are synchronous request/response. There is no accrual job, no year-end balance reset/carry-forward batch, and no scheduled reconciliation in this version (candidate for a future EPIC once BR-01's "reset each year" behavior, if any, is specified).

---

## Security Design

Deliberately minimal, matching the "very simple" brief:

- **No authentication.** Anyone who knows (or is given) an `employeeId` can query its balance or file a leave request on its behalf. This is an explicit, accepted risk for v1 (see Risks) - there is no session, no API key, no OAuth.
- **No authorization/role model.** There is no "manager" or "admin" role; every caller has the same capability.
- Standard input hardening still applies: request bodies are validated (`jakarta.validation`), and JPA/parameterized queries are used throughout (no string-concatenated SQL), consistent with the reference pattern's `@Query` usage.
- No PII beyond `name` is stored.

---

## Logging and Monitoring

- Structured request/response logging at INFO for each state-changing call (`POST /employees`, `POST /employees/{id}/leaves`), including `employeeId` and outcome (`success` / `insufficient_balance` / `not_found`) but never the caller's raw request body verbatim if it grows to include PII later.
- WARN on `NotFoundException` and `InsufficientBalanceException` paths (expected-but-notable business outcomes).
- ERROR + stack trace on the catch-all 500 handler.
- Spring Boot Actuator `/actuator/health` exposed for liveness/readiness, same as would be added to the reference pack's `application.yml` (not currently present there either - noted as a shared follow-up, not unique to this LLD).

---

## Performance Considerations

- Expected load is trivial (internal tool, low request volume) - no load testing or capacity planning beyond ensuring the balance-check-and-deduct path is a single indexed-row transaction (sub-10ms typical).
- The pessimistic lock on `employee.id` during `requestLeave` serializes concurrent leave requests for the *same* employee only; requests for different employees never block each other (identical reasoning to the reference system's per-room locking, FR-009-equivalent).
- No pagination is defined for `GET /api/employees/{employeeId}/leaves` in v1 since per-employee history is expected to stay small (order of tens of rows); add pagination if that assumption breaks.

---

## Assumptions, Dependencies, and Risks

**Assumptions**
- "By default whoever checks will have a 17-day leave balance" means every *newly registered* employee starts at 17 - not that unregistered/unknown IDs are silently treated as having 17 days (unknown IDs are `404`, per VR-04).
- One leave "day" is a whole day; no half-day granularity is required.
- No manager-approval step is required in v1 per the user's description ("they'll be able to see their balance as well" implies immediate self-service, not a pending-approval flow).

**Dependencies**
- PostgreSQL instance (local via `docker-compose`, matching the reference pack's `postgres:16-alpine` pattern).
- Java 21 / Spring Boot 3.4 toolchain, consistent with the engine's `target-stack-java-conventions` skill so this can run through the same `/speckit.orchestrate` pipeline once turned into a story via `lld-to-story`.

**Risks**
- **No authentication (accepted for v1):** any holder of an `employeeId` can spend another employee's leave balance. Flag for a follow-up EPIC if this ever leaves an internal/trusted-network context.
- **No idempotency key on `POST /leaves`:** a client-side retry after a network timeout could double-deduct if the original request actually committed. Mitigation (idempotency key or client-generated request ID) deferred as out of scope for the "very simple" version but should be revisited before production use.
- **No leave-type or accrual model:** if the business later needs sick/casual/earned distinctions or year-over-year accrual, the flat `leave_balance` integer column will need to become a richer ledger - a schema migration, not a config change.
