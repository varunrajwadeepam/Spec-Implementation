---
name: leave-management-domain
description: Technology-agnostic business-domain knowledge for leave (vacation) management systems.
---

> **STUB — fill in before running `/speckit.plan` or `/speckit.implement`.** This was
> auto-scaffolded so story generation could proceed; it carries no real client/domain
> knowledge yet. Populate it from the LLD's Capability Overview / Business Rules sections
> and any other client context you have, or the implementation phases will produce
> confidently generic output with no client-specific grounding.
