---
name: meeting-room-booking-domain
description: Technology-agnostic business-domain knowledge for meeting-room booking systems — room inventory, booking lifecycle, overlap/conflict semantics, and why concurrent booking decisions must be serialized per room. Load together with the meeting-room-booking-client skill.
---

# Meeting Room Booking — Business Domain

## 1. Core entities

| Concept | Meaning |
|---|---|
| **Room** | A bookable physical space with a name, location, and capacity. Rooms are a small, slowly-changing inventory — created once, rarely deleted. |
| **Booking** | A reservation of one room for one contiguous time window `[startTime, endTime)`, made by a named person (`bookedBy`). |

## 2. Booking lifecycle

A booking has exactly three observable states, derived from two facts (never a stored "status"
enum, to avoid the state and the facts drifting apart):

| State | Derived from |
|---|---|
| **Confirmed** | Not cancelled, and `endTime` is still in the future (or now). |
| **Cancelled** | The booking was explicitly cancelled by its ID, at any point before or after its window. |
| **Expired** | Not cancelled, but `endTime` has passed. No action is required to "expire" it — it simply is no longer active by the current time. |

Cancelled and expired bookings are functionally identical for one purpose: **neither blocks a new
booking** for the room and time window it used to occupy.

## 3. The conflict rule

Two bookings for the **same room** must never have overlapping time windows while both are active
(i.e., neither cancelled nor expired). Two half-open intervals `[s1, e1)` and `[s2, e2)` overlap
exactly when `s1 < e2 AND s2 < e1`. A booking that ends exactly when another starts does **not**
overlap it — back-to-back bookings are allowed.

Bookings for **different rooms** never conflict with each other, regardless of their time windows.

## 4. Why this needs a real lock, not just careful code

Two booking requests for the same room, arriving at nearly the same instant, will both read "no
conflicting booking exists" if the read and the write aren't serialized against each other — the
classic check-then-act race. This is true **even with a single application instance**, because a
single JVM still runs many request-handling threads concurrently. The correct fix is to make the
"check for conflicts, then insert" sequence atomic with respect to other attempts on the *same
room* — conventionally by acquiring an exclusive lock on that room's row before checking, so a
second concurrent attempt is forced to wait until the first transaction has committed (and can then
correctly see the just-inserted booking when it re-checks). Rooms are independent of each other, so
locking should be scoped per-room, not global — two people booking two different rooms
simultaneously should never wait on each other.

## 5. Cross-cutting invariants

| # | Invariant |
|---|---|
| D-01 | A room can hold many bookings; only overlapping *active* windows on the *same room* conflict. |
| D-02 | Cancellation is permanent — a cancelled booking is never reactivated. |
| D-03 | Expiry is a read-time computation, not a write. No process ever needs to "expire" a row. |
| D-04 | Booking-conflict decisions for one room must never be affected by concurrent activity on a different room. |
