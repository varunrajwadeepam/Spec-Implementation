---
name: meeting-room-booking-client
description: Client-landscape skill for the MEETING-ROOM-BOOKING portfolio — there is no external client; this is a standalone, internal reference/demo application, not a mainframe migration. Load whenever implementing or reviewing an MRBS story, together with the meeting-room-booking-domain skill and inputs/target-stack-java.md.
---

# Meeting Room Booking System — Client Landscape

There is no client estate here. This portfolio pack exists only to reuse this engine's
spec/plan/tasks discipline and directory layout for a standalone, greenfield application — a
single-node meeting-room booking REST service. Everything below replaces the migration-specific
content a normal client-landscape skill would carry.

## What this is

- A **net-new** Spring Boot application, not a modernization of any existing system. No COBOL, no
  CICS, no legacy tables, no obfuscated field names, no SME-confirmation gaps.
- **No authentication or authorization** — every endpoint is open. Swagger UI is the only
  "front end"; there is no separate consumer application to coordinate a contract with.
- **Single JVM node** is the explicit deployment target for now. Concurrency correctness (no two
  overlapping bookings for the same room) must therefore be enforced at the database level
  (a row-level pessimistic lock), not assumed away by "only one instance runs" — multiple threads
  within that one instance can still race.
- **Deployment target**: Docker Compose (the application container plus a PostgreSQL container).
  Nothing beyond `docker compose up` should be required to run the full stack.

## Working the portfolio

| Do | Don't |
|---|---|
| Treat this as an ordinary greenfield Spring Boot service | Look for COBOL evidence, legacy tables, or LLD sections — none exist |
| Keep the API surface exactly to what was asked (rooms, bookings, cancel) | Add authentication, multi-tenancy, or other unrequested scope |
| Enforce the booking-conflict rule at the database transaction level | Rely on application-only (in-JVM) locking as the sole safeguard |
| Use PostgreSQL via Docker Compose | Use DB2 or any of the TRDOC421-portfolio conventions verbatim |
