# Quickstart: Meeting Room Booking System

```bash
cd portfolios/MEETING-ROOM-BOOKING/POC
docker compose up --build
```

Then open `http://localhost:8080/swagger-ui.html`.

## Smoke scenarios (mirrors spec.md acceptance scenarios)

1. `POST /api/rooms` `{"name":"Falcon","location":"3F","capacity":8}` → `201`, note `id`.
2. `POST /api/bookings` `{"roomId":<id>,"startTime":"2026-09-11T10:00:00Z","endTime":"2026-09-11T11:00:00Z","bookedBy":"Ada"}` → `201`, note `id`.
3. Repeat step 2 with an overlapping window (e.g. `10:30`–`11:30`) → `409`.
4. Repeat step 2 with a back-to-back window (`11:00`–`12:00`) → `201`.
5. `POST /api/bookings/{id}/cancel` on the first booking → `200`, `status: CANCELLED`.
6. `POST /api/bookings` again for the freed window → `201`.
7. `GET /api/bookings/{id}` on an expired booking (past `endTime`, never cancelled) → `status: EXPIRED`.

## Concurrency verification

The integration test `BookingConcurrencyIT` fires N concurrent identical booking requests at the
same room/window and asserts exactly one `201` and N-1 `409` — this is the automated equivalent of
manually racing curl requests and is the primary evidence for SC-001.
