# Feature Specification: Meeting Room Booking System

**Feature Branch**: `MRBS-001-meeting-room-booking`
**Created**: 2026-09-10
**Status**: Draft
**Input**: User description: "A full end-to-end Spring Boot app (Java only) for a Meeting Room Booking system — persist meeting room details; multiple people can try to book any of the available rooms; the system runs on a single node, so we need a lock to ensure no two people can book the same room; cancel a booking by its booking ID; a booking expires automatically once its end time has passed; visible/testable via Swagger only, no auth; the whole stack comes up via Docker Compose."

## Decisions

These were resolved directly with the requester before writing this spec (no open
`[NEEDS CLARIFICATION]` markers remain):

- **Booking-conflict rule**: a room may have many bookings; two bookings for the *same room* can
  never have overlapping time windows. It is not "one booking per room, ever" — different, later,
  non-overlapping time slots on the same room are perfectly fine.
- **Concurrency safety**: enforced with a database-level pessimistic lock on the room being booked,
  acquired inside the same transaction as the conflict check and the insert. This is necessary even
  on a single node, because a single JVM still serves many requests concurrently on separate
  threads.
- **Expiry**: purely a computed, read-time fact — no background job, no persisted `EXPIRED` status
  column. A booking's displayed status is `CANCELLED` (if explicitly cancelled), else `EXPIRED` (if
  its end time has passed), else `CONFIRMED`.
- **No authentication or authorization** anywhere in this system.
- The system is exposed and demonstrated through the OpenAPI/Swagger UI it generates — there is no
  other client application.

## User Scenarios & Testing *(mandatory)*

### User Story 1 - Maintain the room inventory (Priority: P1)

An office administrator registers the meeting rooms that exist (name, location, capacity) so that
people booking a room can see what is available.

**Why this priority**: Nothing else in the system is possible without at least one room to book —
this is the foundation every other story depends on.

**Independent Test**: Can be fully tested by creating a room via the API and then listing/fetching
it back — delivers value on its own as a standalone room directory, even before any booking exists.

**Acceptance Scenarios**:

1. **Given** no rooms exist yet, **When** a client creates a room with a name, location, and
   capacity, **Then** the response is `201` with the created room's details, including a
   system-assigned room ID.
2. **Given** several rooms have been created, **When** a client lists all rooms, **Then** the
   response is `200` with every created room's details.
3. **Given** a room exists, **When** a client fetches it by ID, **Then** the response is `200` with
   that room's details.
4. **Given** no room exists with a given ID, **When** a client fetches it by that ID, **Then** the
   response is `404`.
5. **Given** a room-creation request with a missing name, a blank location, or a non-positive
   capacity, **When** a client submits it, **Then** the response is `400` describing which field is
   invalid.

---

### User Story 2 - Book a room for a time window, safely under concurrency (Priority: P1)

A person books a specific room for a specific start and end time. If two people try to book the
same room for overlapping times at the same moment, exactly one of them succeeds and the other is
told the room is unavailable for that window — never both, and never neither.

**Why this priority**: This is the entire point of the system. Getting the concurrency guarantee
right is the one requirement that most needs to be correct on the first attempt, because a
double-booking is silent and only shows up under real concurrent load.

**Independent Test**: Can be fully tested by creating one room, then issuing two (or more)
simultaneous booking requests for that room with overlapping time windows and observing that
exactly one request is accepted — independently of the room-inventory or cancellation stories.

**Acceptance Scenarios**:

1. **Given** a room exists with no bookings, **When** a client books it for a valid
   `[startTime, endTime)` window with a `bookedBy` name, **Then** the response is `201` with the
   created booking's details, including a system-assigned booking ID.
2. **Given** a room already has a confirmed booking for `[10:00, 11:00)`, **When** a client tries to
   book the same room for any overlapping window (e.g. `[10:30, 11:30)`, or `[09:30, 10:30)`, or a
   window that fully contains or is fully contained by the existing one), **Then** the response is
   `409` and no new booking is created.
3. **Given** a room has a confirmed booking for `[10:00, 11:00)`, **When** a client books the same
   room for a back-to-back, non-overlapping window (`[11:00, 12:00)` or `[09:00, 10:00)`), **Then**
   the response is `201` — adjacent windows do not conflict.
4. **Given** N clients simultaneously submit booking requests for the same room with overlapping
   time windows, **When** all N requests are processed, **Then** exactly one succeeds (`201`) and
   the remaining N-1 receive `409` — never more than one success, and never a lost update where two
   succeed.
5. **Given** a booking request for a room that does not exist, **When** a client submits it,
   **Then** the response is `404`.
6. **Given** a booking request where `startTime` is not strictly before `endTime`, or `bookedBy` is
   blank, **When** a client submits it, **Then** the response is `400`.
7. **Given** a room's existing booking has since been cancelled or has expired, **When** a client
   requests the same room for that same (or an overlapping) window, **Then** the response is `201`
   — a cancelled or expired booking never blocks a new one.

---

### User Story 3 - Cancel a booking (Priority: P2)

A person who made a booking (or an administrator) cancels it by its booking ID, freeing the room
for that window.

**Why this priority**: Necessary for a usable system but not required to demonstrate the core
booking/conflict behavior in User Story 2.

**Independent Test**: Can be fully tested by creating a booking, cancelling it by ID, and then
successfully booking the same room for the same window again — independently of the other stories.

**Acceptance Scenarios**:

1. **Given** a confirmed, non-expired booking exists, **When** a client cancels it by its booking
   ID, **Then** the response is `204` (or `200` with the updated booking) and the booking is now
   reported as `CANCELLED`.
2. **Given** no booking exists with a given ID, **When** a client tries to cancel it, **Then** the
   response is `404`.
3. **Given** a booking has already been cancelled, **When** a client tries to cancel it again,
   **Then** the response is `409` — cancellation is not silently idempotent, so a caller can detect
   a double-cancel attempt.
4. **Given** a booking has already expired (its end time has passed) but was never cancelled,
   **When** a client cancels it, **Then** the response is `204`/`200` and it is now reported as
   `CANCELLED` rather than `EXPIRED` — cancellation is still a meaningful, recorded action even
   after the window has passed.

---

### User Story 4 - Inspect bookings and their live status (Priority: P2)

A person looks up a booking, or lists bookings (optionally for one room), to see whether it is
still confirmed, was cancelled, or has expired.

**Why this priority**: Supporting/read-only capability; useful for verifying the other stories'
behavior but not itself a primary write path.

**Independent Test**: Can be fully tested by creating a booking, fetching it before and after its
end time passes, and observing its reported status change from `CONFIRMED` to `EXPIRED` with no
action taken on it — independently of the other stories.

**Acceptance Scenarios**:

1. **Given** a booking whose end time is in the future and which has not been cancelled, **When** a
   client fetches it, **Then** its reported status is `CONFIRMED`.
2. **Given** a booking whose end time has passed and which was never cancelled, **When** a client
   fetches it, **Then** its reported status is `EXPIRED` — with no scheduled job or write having
   touched it.
3. **Given** a cancelled booking, **When** a client fetches it, **Then** its reported status is
   `CANCELLED`, regardless of whether its window is in the past or future.
4. **Given** several bookings exist across multiple rooms, **When** a client lists bookings
   filtered by a room ID, **Then** the response contains only that room's bookings.
5. **Given** no booking exists with a given ID, **When** a client fetches it, **Then** the response
   is `404`.

---

### Edge Cases

- What happens when a booking's `startTime` equals another's `endTime` for the same room? Treated
  as non-overlapping (see User Story 2, AC-3) — a room can be booked back-to-back with no gap.
- What happens when a room referenced by a booking is looked up after having been created long ago
  with no updates? Room details are immutable in this system (no update/delete endpoint was
  requested) — a booking's room reference always resolves.
- What happens when two cancellation requests for the same booking ID race each other? Exactly one
  succeeds (`204`/`200`); the other observes the booking already cancelled and receives `409` — the
  same per-row-serialization principle as booking creation applies here too.
- What happens when a booking is requested with `capacity`-exceeding attendance? Out of scope — this
  system does not track attendee counts against room capacity; `capacity` is informational only.

## Requirements *(mandatory)*

### Functional Requirements

- **FR-001**: System MUST allow creating a room with a name, a location, and a positive integer
  capacity, returning a system-assigned room ID.
- **FR-002**: System MUST allow listing all rooms and fetching a single room by ID, returning `404`
  for an unknown room ID.
- **FR-003**: System MUST validate room-creation input (non-blank name, non-blank location,
  capacity > 0) and reject invalid input with `400`.
- **FR-004**: System MUST allow booking an existing room for a `[startTime, endTime)` window with a
  non-blank `bookedBy` identifier, returning a system-assigned booking ID on success.
- **FR-005**: System MUST reject a booking request where `startTime` is not strictly before
  `endTime`, or where `bookedBy` is blank, with `400`.
- **FR-006**: System MUST reject a booking request for a room ID that does not exist, with `404`.
- **FR-007**: System MUST reject a booking request that overlaps any other *active* (non-cancelled,
  non-expired) booking on the same room, with `409`, and MUST NOT create the conflicting booking.
- **FR-008**: System MUST serialize concurrent booking-creation attempts on the same room so that,
  under any number of simultaneous overlapping requests for that room, exactly one is accepted and
  every other is rejected with `409` — enforced via a database-level lock scoped to the room being
  booked, not by any in-process-only mechanism.
- **FR-009**: System MUST NOT allow booking-creation attempts on two different rooms to block or
  wait on each other.
- **FR-010**: System MUST allow cancelling a booking by its booking ID, returning `404` for an
  unknown booking ID and `409` if the booking is already cancelled.
- **FR-011**: System MUST compute a booking's status at read time as `CANCELLED` (if cancelled),
  else `EXPIRED` (if its `endTime` has passed), else `CONFIRMED` — with no persisted status column
  and no scheduled/background process performing the transition.
- **FR-012**: System MUST allow fetching a single booking by ID (`404` if unknown) and listing
  bookings, optionally filtered by room ID.
- **FR-013**: System MUST expose all of the above through a REST API documented and exercisable via
  an OpenAPI/Swagger UI, with no authentication or authorization on any endpoint.
- **FR-014**: The complete system (application plus its database) MUST be startable with a single
  Docker Compose command, with no manual setup steps beyond that command.

### Key Entities *(include if feature involves data)*

- **Room**: A bookable space — name, location, capacity, and a system-assigned identifier. Rooms
  are created once and read many times; no update or delete capability was requested.
- **Booking**: A reservation of one room for one `[startTime, endTime)` window by a named person.
  Carries a cancelled flag (the only mutable fact about a booking); its displayed status is always
  derived from that flag plus the current time versus `endTime`, never stored directly.

## Success Criteria *(mandatory)*

### Measurable Outcomes

- **SC-001**: Under any number of simultaneous, identical booking requests for the same room and
  overlapping time window, exactly one request succeeds and every other request is rejected with a
  clear conflict response — zero double-bookings, verified under concurrent load, not just
  sequential testing.
- **SC-002**: A cancelled or expired booking never prevents a new, otherwise-valid booking from
  being made for the room and time window it used to occupy.
- **SC-003**: Booking requests for two different rooms are never slowed down or blocked by each
  other, regardless of how many concurrent requests target either room.
- **SC-004**: A person can discover and exercise every capability of the system (create a room,
  book it, cancel a booking, view booking status) entirely through the generated Swagger UI, with
  no credentials of any kind.
- **SC-005**: Starting the entire system — application and its database — requires exactly one
  command (`docker compose up`) and no further manual configuration.
