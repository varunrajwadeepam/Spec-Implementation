# Data Model: Meeting Room Booking System

## Room

| Field | Type | Constraints |
|---|---|---|
| `id` | `Long` (identity) | PK, system-assigned |
| `name` | `String` | NOT NULL, non-blank |
| `location` | `String` | NOT NULL, non-blank |
| `capacity` | `Integer` | NOT NULL, > 0 |

Table: `room` (columns: `id`, `name`, `location`, `capacity`).

Relationships: one `Room` has many `Booking`s. Immutable after creation — no update/delete endpoint
(FR out of scope, per spec Edge Cases).

## Booking

| Field | Type | Constraints |
|---|---|---|
| `id` | `Long` (identity) | PK, system-assigned |
| `roomId` | `Long` (FK → `room.id`) | NOT NULL |
| `startTime` | `Instant` | NOT NULL |
| `endTime` | `Instant` | NOT NULL, strictly after `startTime` (enforced at request-validation layer, FR-005) |
| `bookedBy` | `String` | NOT NULL, non-blank |
| `cancelled` | `boolean` | NOT NULL, default `false` — the only mutable fact |

Table: `booking` (columns: `id`, `room_id`, `start_time`, `end_time`, `booked_by`, `cancelled`).
Index on `room_id` (every conflict/lookup query filters by room).

### Derived state — BookingStatus (not persisted)

Computed at the mapping layer from `cancelled` + `endTime` vs. "now" (domain skill §2 / FR-011):

| Status | Condition |
|---|---|
| `CANCELLED` | `cancelled == true` |
| `EXPIRED` | `cancelled == false` AND `endTime.isBefore(now)` |
| `CONFIRMED` | `cancelled == false` AND `endTime` is not before `now` |

### Conflict rule (enforced in `BookingService`, not the database schema)

Two bookings for the **same** `roomId` conflict iff both are *active* (not cancelled, not expired)
and their windows overlap: `s1 < e2 AND s2 < e1` (half-open intervals; touching endpoints do not
conflict). Enforced by: pessimistic lock on the `Room` row, then a query for active, overlapping
bookings on that `roomId`, then insert if none found — all inside one `@Transactional` boundary
(see research.md, data-model persistence notes, and target-stack-java.md §4).

## State Transitions

```
        create                     cancel
(none) --------> CONFIRMED  ------------------> CANCELLED (terminal)
                     |
                     | time passes endTime
                     v
                  EXPIRED  ------------------> CANCELLED (terminal, still allowed per US3-AC4)
```

`CANCELLED` is terminal — cancelling an already-cancelled booking returns `409` (FR-010, US3-AC3).
`EXPIRED` is not a stored state and has no transition trigger of its own — it is a read-time fact.
