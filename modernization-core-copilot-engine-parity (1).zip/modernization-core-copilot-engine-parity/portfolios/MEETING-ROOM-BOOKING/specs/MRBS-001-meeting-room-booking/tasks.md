# Tasks: Meeting Room Booking System

**Input**: plan.md, spec.md, data-model.md, contracts/, research.md, quickstart.md
**Implementation root**: `portfolios/MEETING-ROOM-BOOKING/POC/` (all file paths below are relative to this root)
**Tests**: requested — spec's Success Criteria (SC-001..SC-003) require concurrency verification, so tests are generated per plan.md's Testing table.

## Phase 1: Setup

- [X] T001 Research existing components for reuse before creating new ones
  - Search `portfolios/MEETING-ROOM-BOOKING/POC/` and the engine for existing room/booking components
  - Document: none found (greenfield pack, no prior implementation) — all components are new (see research.md § Component Reuse Research)
- [X] T002 Create Maven single-module project skeleton: `pom.xml` (Spring Boot 3.4.2 parent, Java 21, dependencies per target-stack-java.md §1: web, data-jpa, validation, springdoc-openapi-starter-webmvc-ui 2.7.0, postgresql, flyway-core, flyway-database-postgresql, spring-boot-starter-test, testcontainers-bom + testcontainers-postgresql + testcontainers-junit-jupiter, jacoco-maven-plugin 0.8.12 with ≥80% line check)
- [X] T003 [P] Create `src/main/resources/application.yml` (datasource env-var placeholders, `ddl-auto: none`, springdoc paths, server port 8080)
- [X] T004 [P] Create package skeleton directories `src/main/java/com/mrbs/{domain,dataaccess,application,application/exception,web,web/dto}` and `src/test/java/com/mrbs/{application,web,integration}`

## Phase 2: Foundational

- [X] T005 Create `src/main/java/com/mrbs/MrbsApplication.java` (`@SpringBootApplication` main class)
- [X] T006 Create `src/main/resources/db/migration/V1__init_schema.sql` — Flyway migration creating `room` (`id` bigserial PK, `name`, `location`, `capacity`) and `booking` (`id` bigserial PK, `room_id` FK → `room.id`, `start_time`, `end_time`, `booked_by`, `cancelled` boolean default false) with an index on `booking.room_id`, per data-model.md
- [X] T007 [P] Create `src/main/java/com/mrbs/domain/Room.java` — `@Entity` `@Table(name="room")`, fields `id`/`name`/`location`/`capacity` per data-model.md
- [X] T008 [P] Create `src/main/java/com/mrbs/domain/Booking.java` — `@Entity` `@Table(name="booking")`, fields `id`/`roomId`/`startTime`/`endTime`/`bookedBy`/`cancelled` per data-model.md
- [X] T009 Create `src/main/java/com/mrbs/application/BookingStatus.java` — enum `CONFIRMED`/`CANCELLED`/`EXPIRED`
- [X] T010 [P] Create `src/main/java/com/mrbs/application/exception/NotFoundException.java` and `ConflictException.java` — unchecked exceptions carrying a message, mapped by the global exception handler
- [X] T011 Create `src/main/java/com/mrbs/web/GlobalExceptionHandler.java` — `@RestControllerAdvice` mapping `MethodArgumentNotValidException`→400, `NotFoundException`→404, `ConflictException`→409, uncaught→500, all as RFC 9457 `ProblemDetail` (per target-stack-java.md §5)

## Phase 3: User Story 1 - Maintain the room inventory (Priority: P1)

**Goal**: Register and browse the room inventory.
**Independent Test**: Create a room via `POST /api/rooms`, then list/fetch it back via `GET`.

- [X] T012 [P] [US1] Create `src/main/java/com/mrbs/dataaccess/RoomRepository.java` — `JpaRepository<Room, Long>`
- [X] T013 [P] [US1] Create `src/main/java/com/mrbs/web/dto/RoomRequest.java` — `record` with `@NotBlank name`, `@NotBlank location`, `@Positive Integer capacity`
- [X] T014 [P] [US1] Create `src/main/java/com/mrbs/web/dto/RoomResponse.java` — `record(id, name, location, capacity)`
- [X] T015 [US1] Create `src/main/java/com/mrbs/application/RoomService.java` — `createRoom(RoomRequest)`, `listRooms()`, `getRoom(id)` (throws `NotFoundException` if absent)
- [X] T016 [US1] Create `src/main/java/com/mrbs/web/RoomController.java` — `@RestController` `/api/rooms`: `POST` (201), `GET` (200, list), `GET /{id}` (200/404), springdoc `@Operation`/`@ApiResponse` annotations per target-stack-java.md §3
- [X] T017 [P] [US1] Create `src/test/java/com/mrbs/web/RoomControllerTest.java` — `@WebMvcTest(RoomController.class)`, Mockito-mocked `RoomService`, covers spec US1 AC1-AC5 (create/list/fetch/404/400)

**Checkpoint**: Room inventory is independently usable and testable.

## Phase 4: User Story 2 - Book a room for a time window, safely under concurrency (Priority: P1)

**Goal**: Book a room for `[startTime, endTime)`, with exactly one winner under concurrent overlapping requests for the same room.
**Independent Test**: Create one room, fire two-plus simultaneous overlapping booking requests, assert exactly one `201`.

- [X] T018 [US2] Add pessimistic-lock lookup to `RoomRepository`: `@Lock(LockModeType.PESSIMISTIC_WRITE)` `@Query("select r from Room r where r.id = :id") Optional<Room> findByIdForUpdate(Long id)`
- [X] T019 [P] [US2] Create `src/main/java/com/mrbs/dataaccess/BookingRepository.java` — `JpaRepository<Booking, Long>` + derived/`@Query` method finding active (not cancelled, `endTime > now`) bookings on a `roomId` overlapping `[startTime, endTime)`, and a `findByRoomId(Long roomId)` / `findAll()` for listing
- [X] T020 [P] [US2] Create `src/main/java/com/mrbs/web/dto/BookingRequest.java` — `record` with `roomId` (`@NotNull`), `startTime`/`endTime` (`@NotNull`, class-level or service-level check that `startTime` is strictly before `endTime`), `bookedBy` (`@NotBlank`)
- [X] T021 [P] [US2] Create `src/main/java/com/mrbs/web/dto/BookingResponse.java` — `record(id, roomId, startTime, endTime, bookedBy, status)`, `status` computed via `BookingStatus`
- [X] T022 [US2] Create `src/main/java/com/mrbs/application/BookingService.java` — `createBooking(BookingRequest)`: `@Transactional`; validate `startTime < endTime` and non-blank `bookedBy` (400 via bean validation upstream, defensive check here); `findByIdForUpdate(roomId)` or throw `NotFoundException`; query active overlapping bookings for that room — if any, throw `ConflictException`; else persist and return. No cross-room blocking (different `roomId` → independent lock rows, per FR-009)
- [X] T023 [US2] Create `src/main/java/com/mrbs/web/BookingController.java` — `@RestController` `/api/bookings`: `POST` (201/400/404/409), springdoc annotations per target-stack-java.md §3
- [X] T024 [P] [US2] Create `src/test/java/com/mrbs/application/BookingServiceTest.java` — `@ExtendWith(MockitoExtension.class)`, mocked repositories, covers overlap-detection logic (overlapping → `ConflictException`, back-to-back → success, unknown room → `NotFoundException`, cancelled/expired existing booking never blocks) per spec US2 AC1-AC3, AC5-AC7 and data-model.md conflict rule
- [X] T025 [P] [US2] Create `src/test/java/com/mrbs/web/BookingControllerTest.java` — `@WebMvcTest(BookingController.class)`, covers 400 (bad window/blank `bookedBy`) and status-code mapping from service exceptions
- [X] T026 [US2] Create `src/test/java/com/mrbs/integration/BookingConcurrencyIT.java` — `@SpringBootTest` + Testcontainers PostgreSQL: create one room, launch N (≥10) threads submitting identical overlapping booking requests via a real `MockMvc`/`TestRestTemplate` call, assert exactly one `201` and N-1 `409` (SC-001, US2-AC4)

**Checkpoint**: Core booking + concurrency guarantee is independently verified.

## Phase 5: User Story 3 - Cancel a booking (Priority: P2)

**Goal**: Cancel a booking by ID, freeing the room for that window.
**Independent Test**: Create a booking, cancel it by ID, re-book the same room/window successfully.

- [X] T027 [US3] Add `cancelBooking(Long id)` to `BookingService` — `@Transactional`; fetch or throw `NotFoundException`; if already `cancelled`, throw `ConflictException`; else set `cancelled = true` and save; return updated entity (works identically whether the booking has expired or not, per US3-AC4)
- [X] T028 [US3] Add `POST /{id}/cancel` to `BookingController` — 200/404/409, springdoc annotations
- [X] T029 [P] [US3] Extend `BookingServiceTest` with cancel-path cases: success, unknown id → `NotFoundException`, double-cancel → `ConflictException`, cancel-after-expiry → success with `CANCELLED` status (US3 AC1-AC4)
- [X] T030 [P] [US3] Extend `BookingControllerTest` with cancel-endpoint status-code mapping (200/404/409)

**Checkpoint**: Cancellation is independently usable and testable (freeing the room, verified by re-booking).

## Phase 6: User Story 4 - Inspect bookings and their live status (Priority: P2)

**Goal**: Fetch a booking or list bookings (optionally by room), with correctly computed live status.
**Independent Test**: Create a booking, fetch it before/after `endTime` passes, observe status change `CONFIRMED` → `EXPIRED` with no write.

- [X] T031 [US4] Add `getBooking(Long id)` and `listBookings(Long roomId)` (nullable filter) to `BookingService`, mapping each entity to `BookingResponse` via the `BookingStatus` computation (data-model.md § Derived state)
- [X] T032 [US4] Add `GET /{id}` and `GET ?roomId=` to `BookingController` — 200/404, springdoc annotations
- [X] T033 [P] [US4] Extend `BookingServiceTest` with status-computation cases: future `endTime` → `CONFIRMED`, past `endTime` + not cancelled → `EXPIRED`, `cancelled=true` regardless of window → `CANCELLED` (US4 AC1-AC3)
- [X] T034 [P] [US4] Extend `BookingControllerTest`/`BookingConcurrencyIT` with a room-filtered list assertion (US4-AC4) and a 404-on-unknown-id case (US4-AC5)

**Checkpoint**: All four user stories are independently implemented and tested.

## Phase 7: Polish & Cross-Cutting Concerns

- [X] T035 [P] Create `Dockerfile` — multi-stage (`maven:3.9-eclipse-temurin-21` build → `eclipse-temurin:21-jre-alpine` runtime), per target-stack-java.md §7
- [X] T036 [P] Create `docker-compose.yml` — `db` (`postgres:16-alpine`, named volume, `pg_isready` healthcheck) + `app` (build from Dockerfile, `depends_on: db: condition: service_healthy`, `SPRING_DATASOURCE_*` env vars), per target-stack-java.md §7
- [X] T037 [P] Create `.dockerignore` (`target/`, `.git/`, `*.md` exclusions as appropriate)
- [X] T038 Run lint on all new/modified files (`mvn -q compile` — no dedicated linter configured for this pack; compiler warnings-as-errors stand in)
- [X] T039 Run full test suite with zero failures (`mvn -q test`) and verify JaCoCo ≥80% line coverage gate passes (`mvn -q verify`)
- [X] T040 Run production build successfully (`mvn -q package`) and verify the resulting JAR boots via `docker compose up --build` per quickstart.md

## Dependencies & Execution Order

- Phase 1 (Setup) → Phase 2 (Foundational) → Phase 3 (US1) → Phase 4 (US2) → Phase 5 (US3) → Phase 6 (US4) → Phase 7 (Polish)
- US3 and US4 both depend on US2's `BookingService`/`BookingController`/`BookingRequest`/`BookingResponse` existing (T018-T023), but are otherwise independent of each other and could be parallelized by a second implementer once T023 lands.
- US1 has no dependency on US2-US4; it could be implemented and shipped alone as the first increment.

## Parallel Execution Examples

```
# Phase 2, after T006 (schema) lands:
T007 [P] Room.java   ‖   T008 [P] Booking.java   ‖   T010 [P] exceptions

# Phase 3 (US1), after T012 exists:
T013 [P] RoomRequest   ‖   T014 [P] RoomResponse   (then T015 → T016 → T017)

# Phase 4 (US2), after T018 (lock method) exists:
T019 [P] BookingRepository   ‖   T020 [P] BookingRequest   ‖   T021 [P] BookingResponse
```

## Implementation Strategy

**MVP first**: Phase 1 → 2 → 3 (US1) delivers a working, independently testable room directory.
**Incremental delivery**: Phase 4 (US2) adds the core booking + concurrency guarantee — the
riskiest and most important increment; verify T026 (concurrency IT) passes before considering the
feature done in spirit, even though US3/US4 remain. Phases 5-6 (US3/US4) round out the CRUD surface.
Phase 7 packages and validates the deployable artifact.
