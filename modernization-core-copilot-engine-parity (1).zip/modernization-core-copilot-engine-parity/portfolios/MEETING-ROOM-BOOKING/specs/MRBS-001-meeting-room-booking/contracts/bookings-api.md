# Contract: Bookings API

Base path: `/api/bookings`. `application/json` only. No auth.

## POST /api/bookings — create a booking (US2)

Request body:
```json
{ "roomId": "integer", "startTime": "ISO-8601 instant", "endTime": "ISO-8601 instant, strictly after startTime", "bookedBy": "string, non-blank" }
```

Responses:
- `201 Created` → `BookingResponse` (`id`, `roomId`, `startTime`, `endTime`, `bookedBy`, `status`)
- `400 Bad Request` → `ProblemDetail` (`startTime >= endTime`, blank `bookedBy`)
- `404 Not Found` → `ProblemDetail` (unknown `roomId`)
- `409 Conflict` → `ProblemDetail` (overlapping active booking on the same room)

Concurrency guarantee (US2-AC4, SC-001): under N simultaneous overlapping requests for the same
room, exactly one returns `201`; every other returns `409`. Enforced via `[Lock]` on `Room` — see
data-model.md.

## POST /api/bookings/{id}/cancel — cancel a booking (US3)

Responses:
- `200 OK` → `BookingResponse` with `status: "CANCELLED"`
- `404 Not Found` → `ProblemDetail` (unknown booking id)
- `409 Conflict` → `ProblemDetail` (already cancelled)

## GET /api/bookings/{id} — fetch one booking (US4)

- `200 OK` → `BookingResponse` (`status` computed at read time)
- `404 Not Found` → `ProblemDetail`

## GET /api/bookings?roomId={roomId} — list bookings, optionally filtered by room (US4)

- `200 OK` → `BookingResponse[]`
- `roomId` query param optional; when present, filters to that room only.
