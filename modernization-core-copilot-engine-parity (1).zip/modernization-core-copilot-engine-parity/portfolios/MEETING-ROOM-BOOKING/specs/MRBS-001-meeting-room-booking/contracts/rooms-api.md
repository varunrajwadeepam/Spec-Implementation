# Contract: Rooms API

Base path: `/api/rooms`. `application/json` only. No auth.

## POST /api/rooms — create a room (US1)

Request body:
```json
{ "name": "string, non-blank", "location": "string, non-blank", "capacity": "integer > 0" }
```

Responses:
- `201 Created` → `RoomResponse` (`id`, `name`, `location`, `capacity`)
- `400 Bad Request` → RFC 9457 `ProblemDetail` (validation failure)

## GET /api/rooms — list all rooms (US1)

- `200 OK` → `RoomResponse[]`

## GET /api/rooms/{id} — fetch one room (US1)

- `200 OK` → `RoomResponse`
- `404 Not Found` → `ProblemDetail`
