# Research: Meeting Room Booking System

## Decision: Concurrency control for room booking

- **Decision**: Database-level pessimistic write lock (`SELECT ... FOR UPDATE` via Spring Data
  JPA `@Lock(LockModeType.PESSIMISTIC_WRITE)`) on the target `Room` row, acquired inside the same
  `@Transactional` boundary as the overlap-detection query and the `Booking` insert.
- **Rationale**: A single JVM still serves concurrent requests on separate threads, so an
  in-process-only lock (e.g. a `synchronized` block or a `ConcurrentHashMap` of per-room locks)
  would work today but silently stops working the moment the app is scaled to two instances —
  and more importantly, an in-process lock does not serialize against the actual read-then-write
  race at the point it matters (the DB transaction). Locking the `Room` row directly makes the
  critical section exactly as wide as the invariant it protects, and generalizes to multi-instance
  deployment for free.
- **Alternatives considered**:
  - *Optimistic locking (`@Version` on `Room` or `Booking`)*: would require a retry loop on every
    conflicting write and gives no natural place to also serialize the overlap-check read; rejected
    per target-stack-java.md §4 as unnecessary complexity at this scale (booking creation is
    comparatively rare and short-lived, so blocking is an acceptable trade-off).
  - `SERIALIZABLE` transaction isolation for the whole booking-creation transaction: would require
    aborting and retrying on serialization failure everywhere, and is a heavier-weight database-wide
    setting for a problem that is naturally scoped to one row; rejected in favor of a targeted lock.
  - Unique partial index on `(room_id, time-range)`: PostgreSQL has no native range-overlap unique
    constraint without the `btree_gist` extension (`EXCLUDE USING gist`), which is a viable
    alternative but was rejected here because the pessimistic-lock approach is explicitly mandated
    by target-stack-java.md §4 as "the mandated concurrency control."

## Decision: Booking status computed at read time

- **Decision**: `Booking` persists only a `cancelled` boolean plus `startTime`/`endTime`. Status
  (`CONFIRMED` / `CANCELLED` / `EXPIRED`) is derived at the DTO-mapping layer: `cancelled` →
  `CANCELLED`; else `endTime` in the past → `EXPIRED`; else `CONFIRMED`.
- **Rationale**: Per spec Decisions and domain skill §2 — avoids a background job and avoids the
  stored-status/derived-facts drift class of bug entirely.
- **Alternatives considered**: A `@Scheduled` job flipping a `status` column to `EXPIRED` — rejected
  explicitly by the spec ("no background job, no persisted `EXPIRED` status column").

## Decision: API documentation approach — code-first springdoc

- **Decision**: `springdoc-openapi-starter-webmvc-ui` generates the OpenAPI document and Swagger UI
  directly from annotated `@RestController` classes and DTOs. No separate `-contracts` module, no
  `openapi-generator-maven-plugin`.
- **Rationale**: target-stack-java.md §0 overrides the engine's default contract-first workflow —
  there is exactly one service and one consumer (the Swagger UI itself), so a generated-interface
  indirection has no payoff and was a documented source of build friction elsewhere in this engine.
- **Alternatives considered**: Contract-first (engine default) — rejected per the pack's explicit
  override.

## Decision: Persistence — PostgreSQL + Flyway + Spring Data JPA

- **Decision**: `Room`/`Booking` as `@Entity` classes mapped with Spring Data JPA over Hibernate 6,
  schema owned by Flyway migrations (`ddl-auto: none`), plain snake_case table/column names (no
  legacy schema to preserve).
- **Rationale**: target-stack-java.md §1/§4; `[JPA-01]`, `[JPA-05]`, `[JPA-07]` from the engine
  skill remain binding and unmodified for this pack.
- **Alternatives considered**: None — this is the pack's explicit, non-negotiable choice.

## Component Reuse Research

Searched `portfolios/MEETING-ROOM-BOOKING/POC/` (empty — greenfield, no prior code) and the engine
(`.claude/`, `schemas/`) for reusable room/booking components: none exist, as expected for a
standalone pack with no prior implementation. No reuse candidates found; all components are new.

## Dependency Readiness

Not applicable — this is not a migration; there are no upstream migration-unit dependencies to
verify readiness against.
