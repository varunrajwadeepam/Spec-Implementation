# Implementation Plan: Meeting Room Booking System

**Branch**: `MRBS-001-meeting-room-booking` | **Date**: 2026-09-10 | **Spec**: [spec.md](./spec.md)
**Input**: Feature specification from `portfolios/MEETING-ROOM-BOOKING/specs/MRBS-001-meeting-room-booking/spec.md`

## Summary

A single-service Spring Boot REST API for registering meeting rooms and booking them for time
windows, with room-scoped concurrency safety enforced by a database-level pessimistic lock, computed
(not stored) booking status, and no authentication. Exposed and exercised entirely through
Swagger UI; the whole stack (app + PostgreSQL) starts with one `docker compose up` command.

## Technical Context

**Language/Version**: Java 21
**Primary Dependencies**: Spring Boot 3.4.2 (`spring-boot-starter-web`, `spring-boot-starter-data-jpa`, `spring-boot-starter-validation`), springdoc-openapi-starter-webmvc-ui 2.7.0, Flyway (`flyway-core` + `flyway-database-postgresql`)
**Storage**: PostgreSQL 16 (via `org.postgresql:postgresql`, HikariCP pool, Flyway-owned schema)
**Testing**: JUnit 5 + Mockito 5 + AssertJ 3 (`spring-boot-starter-test`), Testcontainers (PostgreSQL) for the concurrency/integration test, JaCoCo 0.8.12 (≥80% line, build-failing)
**Target Platform**: Linux container (Docker Compose: `app` + `db` services)
**Project Type**: Single-module web service (REST API)
**Performance Goals**: Not throughput-critical (demo/reference scale); correctness under concurrency is the primary non-functional target, not raw req/s
**Constraints**: Single JVM node; no auth; no versioned API path; booking status always computed at read time, never persisted
**Scale/Scope**: 4 user stories, 2 entities (Room, Booking), ~6 REST endpoints

Authoritative source for all of the above: `portfolios/MEETING-ROOM-BOOKING/inputs/target-stack-java.md`
(overrides the generic `target-stack-java-conventions` engine skill's CXF/SOAP, multi-module, and
DB2 defaults — see that file's §0 override table). No `portfolios/MEETING-ROOM-BOOKING/specs/constitution.md`
exists, so no constitution gates apply beyond the stack-conventions rules already cited.

## Constitution Check

*GATE: Must pass before Phase 0 research. Re-check after Phase 1 design.*

No `constitution.md` exists for this portfolio (greenfield, non-migration pack — see client skill:
"no migration-specific content"). No gates to evaluate. PASS (vacuously).

## Project Structure

### Implementation Root

**Implementation Root**: `portfolios/MEETING-ROOM-BOOKING/POC/`

Single Maven module (per target-stack-java.md §0 override of `[PROJ-01]`/`[PROJ-02]`) — no
multi-module split; one bounded context, one team, one deployable JAR.

### Documentation (this feature)

```text
portfolios/MEETING-ROOM-BOOKING/specs/MRBS-001-meeting-room-booking/
├── plan.md              # This file
├── research.md          # Phase 0 output
├── data-model.md         # Phase 1 output
├── quickstart.md         # Phase 1 output
├── contracts/             # Phase 1 output — REST endpoint contracts
└── tasks.md               # Phase 2 output (/speckit.tasks)
```

### Source Code

```text
# Implementation root: portfolios/MEETING-ROOM-BOOKING/POC/

portfolios/MEETING-ROOM-BOOKING/POC/
├── pom.xml
├── Dockerfile
├── docker-compose.yml
├── .dockerignore
├── src/
│   ├── main/
│   │   ├── java/com/mrbs/
│   │   │   ├── MrbsApplication.java
│   │   │   ├── domain/
│   │   │   │   ├── Room.java
│   │   │   │   └── Booking.java
│   │   │   ├── dataaccess/
│   │   │   │   ├── RoomRepository.java
│   │   │   │   └── BookingRepository.java
│   │   │   ├── application/
│   │   │   │   ├── RoomService.java
│   │   │   │   ├── BookingService.java
│   │   │   │   ├── BookingStatus.java
│   │   │   │   └── exception/
│   │   │   │       ├── NotFoundException.java
│   │   │   │       └── ConflictException.java
│   │   │   └── web/
│   │   │       ├── RoomController.java
│   │   │       ├── BookingController.java
│   │   │       ├── GlobalExceptionHandler.java
│   │   │       └── dto/
│   │   │           ├── RoomRequest.java
│   │   │           ├── RoomResponse.java
│   │   │           ├── BookingRequest.java
│   │   │           └── BookingResponse.java
│   │   └── resources/
│   │       ├── application.yml
│   │       └── db/migration/
│   │           └── V1__init_schema.sql
│   └── test/
│       └── java/com/mrbs/
│           ├── application/
│           │   └── BookingServiceTest.java
│           ├── web/
│           │   ├── RoomControllerTest.java
│           │   └── BookingControllerTest.java
│           └── integration/
│               └── BookingConcurrencyIT.java
```

**Structure Decision**: Single-module layered Spring Boot app (`domain` → `dataaccess` →
`application` → `web`) exactly as declared in target-stack-java.md §2. No `-contracts` module, no
generated server interfaces — controllers/DTOs are hand-written and springdoc derives the OpenAPI
document + Swagger UI from their annotations at runtime (code-first, per target-stack-java.md §0).

## Complexity Tracking

No constitution violations to justify — table omitted.
