# MEETING-ROOM-BOOKING — Target Stack Definition (Java 21 / Spring Boot 3.4 / REST / PostgreSQL)

> **Precedence.** This file is the pack's `target_stack.definition` (declared in
> `portfolios/MEETING-ROOM-BOOKING/portfolio.yaml`). Per `CLAUDE.md` and
> `[target-stack-java-conventions]` §Precedence, **this file is authoritative over the engine
> skill wherever the two conflict.** The engine skill's remaining rules (`[JPA-*]` except where
> overridden below, `[DI-*]`, `[TEST-*]`, `[COV-*]`) still apply unchanged.
>
> There is no LLD for this pack — it is a greenfield application, not a migration. Every decision
> below is a direct product/engineering decision, not a COBOL-evidence citation.

---

## 0. Overrides of `target-stack-java-conventions`

The engine skill defaults to SOAP over Apache CXF, a DB2-backed multi-module estate, and a
contract-first OpenAPI workflow generating server interfaces from a hand-authored YAML in a
separate `-contracts` module. None of that fits a single-service greenfield app with one consumer
(its own Swagger UI). This pack overrides:

| Engine rule | Engine default | **MEETING-ROOM-BOOKING override** |
|---|---|---|
| `[DEP-02]`, `[CXF-01]`…`[CXF-05]` | Apache CXF / JAX-WS SOAP | **No CXF, no JAX-WS, no SOAP.** `spring-boot-starter-web`, `@RestController` REST/JSON only. |
| Contract-first (engine §1.6.7 / a typical pack's §3) | Hand-authored OpenAPI YAML in a shared `-contracts` module; `openapi-generator-maven-plugin` produces server interfaces; controllers implement the generated interface | **Code-first, reversed.** Controllers and DTOs are hand-written directly; `springdoc-openapi-starter-webmvc-ui` derives the OpenAPI document and Swagger UI from the annotated controllers at runtime. There is no `-contracts` module and no code generator — there is exactly one service and one "consumer" (Swagger UI itself), so a generated-interface indirection buys nothing and was the single largest source of build friction on this engine's other portfolio (mismatched generated-interface names, wrong `tags:`, etc.) |
| `[PROJ-01]`/`[PROJ-02]` | Maven multi-module estate, one deployable module per target service | **Single Maven module**, one deployable JAR. There is one bounded context (room + booking) and one team; a multi-module split has no benefit here. |
| `[DB2-01]`…`[DB2-05]` | DB2 LUW, JDBC Type 4 driver | **PostgreSQL**, `org.postgresql:postgresql` JDBC driver. Table/column names are plain snake_case — there is no legacy schema to preserve. |
| Security (engine §9, a typical pack) | OAuth2/OIDC + mTLS | **No security dependency at all.** No `spring-boot-starter-oauth2-resource-server`, no authentication, no authorization. Every endpoint is open. |
| Build tool | Maven (default) or Gradle (portfolio-specific choice elsewhere in this engine) | **Maven**, single module. No aggregation complexity to justify Gradle here. |

Unchanged and binding from the engine skill: `[JPA-01]`, `[JPA-03]`…`[JPA-07]` (adapted to
PostgreSQL naming, not DB2), `[DATA-01]`…`[DATA-04]`, `[DI-01]`…`[DI-04]`, `[TEST-01]`…`[TEST-10]`,
`[COV-01]`…`[COV-03]`. `[UTIL-*]` (CA:Gen) and anything CICS/COBOL-specific do not apply
(`codegen: handwritten`, no migration).

---

## 1. Platform and version pins

| Concern | Choice | Pin |
|---|---|---|
| Language / runtime | Java | **21** |
| Framework | Spring Boot | **3.4.2** (`spring-boot-starter-parent` BOM) |
| Web layer | Spring MVC (`spring-boot-starter-web`), embedded Tomcat | via BOM |
| API style | REST / JSON, code-first | — |
| API docs | `springdoc-openapi-starter-webmvc-ui` **2.7.0** — serves `/v3/api-docs` and `/swagger-ui.html`, generated from controller annotations | — |
| Persistence | Spring Data JPA + Hibernate 6 | via BOM |
| Database | **PostgreSQL 16** | `org.postgresql:postgresql` (runtime scope) |
| Connection pool | HikariCP | via BOM (defaults are adequate at this scale) |
| Schema migration | **Flyway** (`flyway-core` + `flyway-database-postgresql`) | via BOM |
| Validation | `spring-boot-starter-validation` (Jakarta Bean Validation) | via BOM |
| Build | **Maven**, single module | — |
| Test | JUnit 5 + Mockito 5 + AssertJ 3, **Testcontainers** (PostgreSQL) for the concurrency/integration test | `spring-boot-starter-test` BOM; `testcontainers-bom` |
| Coverage | JaCoCo, ≥ 80% line, build-failing | `0.8.12` |
| Containerization | Multi-stage Dockerfile (Maven build stage → slim JRE runtime stage); Docker Compose (`app` + `db` services) | — |

Group ID: `com.mrbs`. Base package: `com.mrbs`.

---

## 2. Module and package layout

Single Maven module at `portfolios/MEETING-ROOM-BOOKING/POC/`, internally layered:

```
com.mrbs
├── domain/          # JPA entities: Room, Booking
├── dataaccess/       # Spring Data JPA repositories, incl. the @Lock pessimistic-write method
├── application/      # Services: RoomService, BookingService (overlap check + lock)
└── web/               # @RestController classes, DTOs, @RestControllerAdvice error mapping
```

---

## 3. REST / OpenAPI conventions

- `application/json` request and response bodies only.
- Base path `/api/` (`/api/rooms`, `/api/bookings`) — no `/v1/` versioning; this is a small
  standalone app, not an estate with a multi-year migration lifecycle.
- Every controller method carries springdoc `@Operation`/`@ApiResponse` annotations so the
  generated Swagger document is complete and self-describing (there is no separate hand-authored
  contract to fall back on).
- Monetary values do not apply to this domain; `capacity` (integer) and time fields (`Instant`,
  ISO-8601 in JSON) are the only fields warranting explicit format documentation.
- No `Idempotency-Key` header, no correlation-ID propagation, no distributed tracing — single
  service, no downstream calls, not warranted at this scale.

---

## 4. Persistence — JPA / Hibernate / PostgreSQL

- `ddl-auto: none` — Flyway owns the schema.
- **Pessimistic locking is the mandated concurrency control** for booking creation:
  `RoomRepository` declares a method annotated `@Lock(LockModeType.PESSIMISTIC_WRITE)` that
  selects the target `Room` row; `BookingService.createBooking(...)` calls it inside a
  `@Transactional` boundary **before** running the overlap-detection query, so two concurrent
  transactions targeting the same room serialize on that row and the second one's overlap check
  correctly observes the first one's just-committed booking.
- No optimistic-locking `@Version` column is needed on `Room` — pessimistic locking is the sole
  and sufficient mechanism here (unlike a system needing high-throughput non-blocking reads,
  booking creation is comparatively rare and short-lived, so blocking is an acceptable, simpler
  trade-off than optimistic retry loops).
- `Booking.cancelled` is a plain boolean column; there is no `status` column — status is always
  computed at the DTO-mapping layer (see the domain skill, §2).

---

## 5. Error handling

A single `@RestControllerAdvice` maps to conventional, minimal REST semantics — there is no legacy
error-code catalog to preserve:

| Condition | HTTP | Body |
|---|---|---|
| Bean Validation failure (e.g. `startTime >= endTime`, blank `bookedBy`) | 400 | RFC 9457 `ProblemDetail` |
| Room or booking not found | 404 | RFC 9457 `ProblemDetail` |
| Overlapping booking for the same room, or cancelling an already-cancelled booking | 409 | RFC 9457 `ProblemDetail` |
| Uncaught exception | 500 | RFC 9457 `ProblemDetail`, no internal detail leaked |

---

## 6. Testing

| Layer | Framework | Notes |
|---|---|---|
| Unit | JUnit 5 + Mockito 5 + AssertJ 3, zero Spring context | Overlap-detection logic in `BookingService`, mocked repositories |
| Web slice | `@WebMvcTest` | Controller/validation/error-mapping behavior, no DB needed |
| Integration / concurrency | `@SpringBootTest` + Testcontainers PostgreSQL | The one test that matters most: fire N concurrent identical booking requests at the same room/overlapping window and assert exactly 1 succeeds (201) and N-1 receive 409 |
| Coverage | JaCoCo ≥ 80% line, build-failing | `[COV-01]` |

---

## 7. Deployment — Docker Compose

Two services:

| Service | Image / build | Notes |
|---|---|---|
| `db` | `postgres:16-alpine` | Named volume for data; healthcheck via `pg_isready` |
| `app` | Built from this module's `Dockerfile` (multi-stage: `maven:3.9-eclipse-temurin-21` build stage → `eclipse-temurin:21-jre-alpine` runtime stage) | `depends_on: db: condition: service_healthy`; `SPRING_DATASOURCE_URL` etc. wired via environment variables pointing at the `db` service name |

`docker compose up --build` is the only command required to bring up a working stack; Swagger UI
is reachable at `http://localhost:8080/swagger-ui.html` with no authentication.
