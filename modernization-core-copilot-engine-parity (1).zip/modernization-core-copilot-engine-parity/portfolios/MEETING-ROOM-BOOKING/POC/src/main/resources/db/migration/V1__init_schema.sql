-- Story: MRBS-001-meeting-room-booking

CREATE TABLE room (
    id       BIGSERIAL PRIMARY KEY,
    name     VARCHAR(255) NOT NULL,
    location VARCHAR(255) NOT NULL,
    capacity INTEGER      NOT NULL
);

CREATE TABLE booking (
    id         BIGSERIAL PRIMARY KEY,
    room_id    BIGINT      NOT NULL REFERENCES room (id),
    start_time TIMESTAMPTZ NOT NULL,
    end_time   TIMESTAMPTZ NOT NULL,
    booked_by  VARCHAR(255) NOT NULL,
    cancelled  BOOLEAN     NOT NULL DEFAULT FALSE
);

CREATE INDEX idx_booking_room_id ON booking (room_id);
