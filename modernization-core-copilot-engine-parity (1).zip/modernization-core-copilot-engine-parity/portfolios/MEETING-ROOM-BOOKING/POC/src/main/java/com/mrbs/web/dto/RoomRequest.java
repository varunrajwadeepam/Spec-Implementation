// Story: MRBS-001-meeting-room-booking
package com.mrbs.web.dto;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Positive;

public record RoomRequest(
        @Schema(description = "Room name", example = "Falcon")
        @NotBlank(message = "name must not be blank") String name,

        @Schema(description = "Room location", example = "3rd floor")
        @NotBlank(message = "location must not be blank") String location,

        @Schema(description = "Maximum capacity", example = "8")
        @NotNull(message = "capacity is required")
        @Positive(message = "capacity must be positive") Integer capacity
) {
}
