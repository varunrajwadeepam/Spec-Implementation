// Story: MRBS-001-meeting-room-booking
package com.mrbs.application;

import com.mrbs.application.exception.NotFoundException;
import com.mrbs.dataaccess.RoomRepository;
import com.mrbs.domain.Room;
import com.mrbs.web.dto.RoomRequest;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
public class RoomService {

    private final RoomRepository roomRepository;

    public RoomService(RoomRepository roomRepository) {
        this.roomRepository = roomRepository;
    }

    @Transactional
    public Room createRoom(RoomRequest request) {
        Room room = new Room(request.name(), request.location(), request.capacity());
        return roomRepository.save(room);
    }

    @Transactional(readOnly = true)
    public List<Room> listRooms() {
        return roomRepository.findAll();
    }

    @Transactional(readOnly = true)
    public Room getRoom(Long id) {
        return roomRepository.findById(id)
                .orElseThrow(() -> new NotFoundException("Room not found: " + id));
    }
}
