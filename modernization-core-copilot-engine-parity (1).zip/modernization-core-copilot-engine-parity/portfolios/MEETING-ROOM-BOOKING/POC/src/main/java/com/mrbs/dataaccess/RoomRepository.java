// Story: MRBS-001-meeting-room-booking
package com.mrbs.dataaccess;

import com.mrbs.domain.Room;
import jakarta.persistence.LockModeType;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Lock;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.Optional;

public interface RoomRepository extends JpaRepository<Room, Long> {

    /**
     * Acquires a row-level exclusive lock on the room, forcing any other concurrent
     * booking-creation transaction on the same room to wait until this transaction
     * commits — see target-stack-java.md §4 and research.md.
     */
    @Lock(LockModeType.PESSIMISTIC_WRITE)
    @Query("select r from Room r where r.id = :id")
    Optional<Room> findByIdForUpdate(@Param("id") Long id);
}
