// Story: MRBS-001-meeting-room-booking
package com.mrbs.web.dto;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;

import java.time.Instant;

public record BookingRequest(
        @Schema(description = "Room to book", example = "1")
        @NotNull(message = "roomId is required") Long roomId,

        @Schema(description = "Window start (inclusive)", example = "2026-09-11T10:00:00Z")
        @NotNull(message = "startTime is required") Instant startTime,

        @Schema(description = "Window end (exclusive)", example = "2026-09-11T11:00:00Z")
        @NotNull(message = "endTime is required") Instant endTime,

        @Schema(description = "Name of the person booking", example = "Ada Lovelace")
        @NotBlank(message = "bookedBy must not be blank") String bookedBy
) {
}
