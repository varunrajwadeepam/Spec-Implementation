// Story: MRBS-001-meeting-room-booking
package com.mrbs.application.exception;

public class NotFoundException extends RuntimeException {

    public NotFoundException(String message) {
        super(message);
    }
}
