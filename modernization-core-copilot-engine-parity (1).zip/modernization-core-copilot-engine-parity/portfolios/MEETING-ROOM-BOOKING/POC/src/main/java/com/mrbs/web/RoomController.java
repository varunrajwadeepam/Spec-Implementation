// Story: MRBS-001-meeting-room-booking
package com.mrbs.web;

import com.mrbs.application.RoomService;
import com.mrbs.domain.Room;
import com.mrbs.web.dto.RoomRequest;
import com.mrbs.web.dto.RoomResponse;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import jakarta.validation.Valid;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/rooms")
public class RoomController {

    private final RoomService roomService;

    public RoomController(RoomService roomService) {
        this.roomService = roomService;
    }

    @Operation(summary = "Create a room")
    @ApiResponse(responseCode = "201", description = "Room created")
    @ApiResponse(responseCode = "400", description = "Invalid room input")
    @PostMapping
    @ResponseStatus(HttpStatus.CREATED)
    public RoomResponse createRoom(@Valid @RequestBody RoomRequest request) {
        Room room = roomService.createRoom(request);
        return RoomResponse.from(room);
    }

    @Operation(summary = "List all rooms")
    @ApiResponse(responseCode = "200", description = "Rooms listed")
    @GetMapping
    public List<RoomResponse> listRooms() {
        return roomService.listRooms().stream().map(RoomResponse::from).toList();
    }

    @Operation(summary = "Fetch a room by id")
    @ApiResponse(responseCode = "200", description = "Room found")
    @ApiResponse(responseCode = "404", description = "Room not found")
    @GetMapping("/{id}")
    public ResponseEntity<RoomResponse> getRoom(@PathVariable Long id) {
        return ResponseEntity.ok(RoomResponse.from(roomService.getRoom(id)));
    }
}
