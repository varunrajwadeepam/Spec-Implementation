// Story: MRBS-001-meeting-room-booking
package com.mrbs.application;

import com.mrbs.application.exception.ConflictException;
import com.mrbs.application.exception.NotFoundException;
import com.mrbs.dataaccess.BookingRepository;
import com.mrbs.dataaccess.RoomRepository;
import com.mrbs.domain.Booking;
import com.mrbs.domain.Room;
import com.mrbs.web.dto.BookingRequest;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.Instant;
import java.util.List;

@Service
public class BookingService {

    private final RoomRepository roomRepository;
    private final BookingRepository bookingRepository;

    public BookingService(RoomRepository roomRepository, BookingRepository bookingRepository) {
        this.roomRepository = roomRepository;
        this.bookingRepository = bookingRepository;
    }

    /**
     * Books a room for [startTime, endTime). The pessimistic lock on the Room row
     * (acquired before the overlap check, inside this same transaction) is what makes
     * "check for conflicts, then insert" atomic with respect to concurrent attempts on
     * the SAME room — see target-stack-java.md §4 / research.md. Different rooms lock
     * different rows, so they never block each other (FR-009).
     */
    @Transactional
    public Booking createBooking(BookingRequest request) {
        if (!request.startTime().isBefore(request.endTime())) {
            throw new IllegalArgumentException("startTime must be strictly before endTime");
        }

        Room room = roomRepository.findByIdForUpdate(request.roomId())
                .orElseThrow(() -> new NotFoundException("Room not found: " + request.roomId()));

        Instant now = Instant.now();
        List<Booking> overlapping = bookingRepository.findActiveOverlapping(
                room.getId(), request.startTime(), request.endTime(), now);
        if (!overlapping.isEmpty()) {
            throw new ConflictException(
                    "Room " + room.getId() + " already has an active booking overlapping the requested window");
        }

        Booking booking = new Booking(room.getId(), request.startTime(), request.endTime(), request.bookedBy());
        return bookingRepository.save(booking);
    }

    @Transactional
    public Booking cancelBooking(Long id) {
        Booking booking = bookingRepository.findById(id)
                .orElseThrow(() -> new NotFoundException("Booking not found: " + id));
        if (booking.isCancelled()) {
            throw new ConflictException("Booking " + id + " is already cancelled");
        }
        booking.cancel();
        return bookingRepository.save(booking);
    }

    @Transactional(readOnly = true)
    public Booking getBooking(Long id) {
        return bookingRepository.findById(id)
                .orElseThrow(() -> new NotFoundException("Booking not found: " + id));
    }

    @Transactional(readOnly = true)
    public List<Booking> listBookings(Long roomId) {
        return roomId == null ? bookingRepository.findAll() : bookingRepository.findByRoomId(roomId);
    }
}
