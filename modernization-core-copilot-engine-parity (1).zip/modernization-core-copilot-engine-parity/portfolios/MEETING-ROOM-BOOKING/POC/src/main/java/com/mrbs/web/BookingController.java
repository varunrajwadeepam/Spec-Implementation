// Story: MRBS-001-meeting-room-booking
package com.mrbs.web;

import com.mrbs.application.BookingService;
import com.mrbs.domain.Booking;
import com.mrbs.web.dto.BookingRequest;
import com.mrbs.web.dto.BookingResponse;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import jakarta.validation.Valid;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.time.Instant;
import java.util.List;

@RestController
@RequestMapping("/api/bookings")
public class BookingController {

    private final BookingService bookingService;

    public BookingController(BookingService bookingService) {
        this.bookingService = bookingService;
    }

    @Operation(summary = "Book a room for a time window")
    @ApiResponse(responseCode = "201", description = "Booking created")
    @ApiResponse(responseCode = "400", description = "Invalid booking input")
    @ApiResponse(responseCode = "404", description = "Room not found")
    @ApiResponse(responseCode = "409", description = "Overlapping booking for this room")
    @PostMapping
    @ResponseStatus(HttpStatus.CREATED)
    public BookingResponse createBooking(@Valid @RequestBody BookingRequest request) {
        Booking booking = bookingService.createBooking(request);
        return BookingResponse.from(booking, Instant.now());
    }

    @Operation(summary = "Cancel a booking by id")
    @ApiResponse(responseCode = "200", description = "Booking cancelled")
    @ApiResponse(responseCode = "404", description = "Booking not found")
    @ApiResponse(responseCode = "409", description = "Booking already cancelled")
    @PostMapping("/{id}/cancel")
    public BookingResponse cancelBooking(@PathVariable Long id) {
        Booking booking = bookingService.cancelBooking(id);
        return BookingResponse.from(booking, Instant.now());
    }

    @Operation(summary = "Fetch a booking by id")
    @ApiResponse(responseCode = "200", description = "Booking found")
    @ApiResponse(responseCode = "404", description = "Booking not found")
    @GetMapping("/{id}")
    public ResponseEntity<BookingResponse> getBooking(@PathVariable Long id) {
        return ResponseEntity.ok(BookingResponse.from(bookingService.getBooking(id), Instant.now()));
    }

    @Operation(summary = "List bookings, optionally filtered by room")
    @ApiResponse(responseCode = "200", description = "Bookings listed")
    @GetMapping
    public List<BookingResponse> listBookings(@RequestParam(required = false) Long roomId) {
        Instant now = Instant.now();
        return bookingService.listBookings(roomId).stream()
                .map(booking -> BookingResponse.from(booking, now))
                .toList();
    }
}
