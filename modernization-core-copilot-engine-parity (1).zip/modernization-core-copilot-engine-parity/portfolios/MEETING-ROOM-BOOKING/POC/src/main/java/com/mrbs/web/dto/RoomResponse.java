// Story: MRBS-001-meeting-room-booking
package com.mrbs.web.dto;

import com.mrbs.domain.Room;

public record RoomResponse(Long id, String name, String location, Integer capacity) {

    public static RoomResponse from(Room room) {
        return new RoomResponse(room.getId(), room.getName(), room.getLocation(), room.getCapacity());
    }
}
