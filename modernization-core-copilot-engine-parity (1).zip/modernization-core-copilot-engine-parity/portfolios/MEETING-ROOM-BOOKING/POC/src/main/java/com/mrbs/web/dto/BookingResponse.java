// Story: MRBS-001-meeting-room-booking
package com.mrbs.web.dto;

import com.mrbs.application.BookingStatus;
import com.mrbs.domain.Booking;

import java.time.Instant;

public record BookingResponse(
        Long id,
        Long roomId,
        Instant startTime,
        Instant endTime,
        String bookedBy,
        BookingStatus status
) {

    public static BookingResponse from(Booking booking, Instant now) {
        return new BookingResponse(
                booking.getId(),
                booking.getRoomId(),
                booking.getStartTime(),
                booking.getEndTime(),
                booking.getBookedBy(),
                BookingStatus.of(booking, now));
    }
}
