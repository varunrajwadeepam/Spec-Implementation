// Story: MRBS-001-meeting-room-booking
package com.mrbs.dataaccess;

import com.mrbs.domain.Booking;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.time.Instant;
import java.util.List;

public interface BookingRepository extends JpaRepository<Booking, Long> {

    List<Booking> findByRoomId(Long roomId);

    /**
     * Active (not cancelled, not expired) bookings on the given room whose window
     * overlaps [startTime, endTime) — half-open interval overlap: s1 < e2 AND s2 < e1.
     * See data-model.md § Conflict rule.
     */
    @Query("""
            select b from Booking b
            where b.roomId = :roomId
              and b.cancelled = false
              and b.endTime > :now
              and b.startTime < :endTime
              and :startTime < b.endTime
            """)
    List<Booking> findActiveOverlapping(
            @Param("roomId") Long roomId,
            @Param("startTime") Instant startTime,
            @Param("endTime") Instant endTime,
            @Param("now") Instant now);
}
