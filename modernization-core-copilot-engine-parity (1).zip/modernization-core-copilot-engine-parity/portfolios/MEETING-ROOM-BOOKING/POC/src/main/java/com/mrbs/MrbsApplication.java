// Story: MRBS-001-meeting-room-booking
package com.mrbs;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MrbsApplication {

    public static void main(String[] args) {
        SpringApplication.run(MrbsApplication.class, args);
    }
}
