// Story: MRBS-001-meeting-room-booking
package com.mrbs.application;

import com.mrbs.domain.Booking;

import java.time.Instant;

public enum BookingStatus {
    CONFIRMED,
    CANCELLED,
    EXPIRED;

    public static BookingStatus of(Booking booking, Instant now) {
        if (booking.isCancelled()) {
            return CANCELLED;
        }
        if (booking.getEndTime().isBefore(now)) {
            return EXPIRED;
        }
        return CONFIRMED;
    }
}
