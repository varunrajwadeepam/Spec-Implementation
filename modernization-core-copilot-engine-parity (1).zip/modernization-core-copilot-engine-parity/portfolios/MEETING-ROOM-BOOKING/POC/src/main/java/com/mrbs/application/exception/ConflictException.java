// Story: MRBS-001-meeting-room-booking
package com.mrbs.application.exception;

public class ConflictException extends RuntimeException {

    public ConflictException(String message) {
        super(message);
    }
}
