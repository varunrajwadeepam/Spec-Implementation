// Story: MRBS-001-meeting-room-booking
package com.mrbs.web;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.mrbs.application.RoomService;
import com.mrbs.application.exception.NotFoundException;
import com.mrbs.domain.Room;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.test.context.bean.override.mockito.MockitoBean;
import org.springframework.test.web.servlet.MockMvc;

import java.util.List;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

@WebMvcTest(RoomController.class)
class RoomControllerTest {

    @Autowired
    private MockMvc mockMvc;
    @Autowired
    private ObjectMapper objectMapper;
    @MockitoBean
    private RoomService roomService;

    @Test
    void createRoom_valid_returns201() throws Exception {
        Room room = new Room("Falcon", "3F", 8);
        when(roomService.createRoom(any())).thenReturn(room);

        mockMvc.perform(post("/api/rooms")
                        .contentType("application/json")
                        .content("{\"name\":\"Falcon\",\"location\":\"3F\",\"capacity\":8}"))
                .andExpect(status().isCreated())
                .andExpect(jsonPath("$.name").value("Falcon"));
    }

    @Test
    void createRoom_blankName_returns400() throws Exception {
        mockMvc.perform(post("/api/rooms")
                        .contentType("application/json")
                        .content("{\"name\":\"\",\"location\":\"3F\",\"capacity\":8}"))
                .andExpect(status().isBadRequest());
    }

    @Test
    void createRoom_nonPositiveCapacity_returns400() throws Exception {
        mockMvc.perform(post("/api/rooms")
                        .contentType("application/json")
                        .content("{\"name\":\"Falcon\",\"location\":\"3F\",\"capacity\":0}"))
                .andExpect(status().isBadRequest());
    }

    @Test
    void listRooms_returnsAll() throws Exception {
        when(roomService.listRooms()).thenReturn(List.of(new Room("Falcon", "3F", 8)));

        mockMvc.perform(get("/api/rooms"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.length()").value(1));
    }

    @Test
    void getRoom_found_returns200() throws Exception {
        when(roomService.getRoom(1L)).thenReturn(new Room("Falcon", "3F", 8));

        mockMvc.perform(get("/api/rooms/1"))
                .andExpect(status().isOk());
    }

    @Test
    void getRoom_notFound_returns404() throws Exception {
        when(roomService.getRoom(99L)).thenThrow(new NotFoundException("Room not found: 99"));

        mockMvc.perform(get("/api/rooms/99"))
                .andExpect(status().isNotFound());
    }
}
