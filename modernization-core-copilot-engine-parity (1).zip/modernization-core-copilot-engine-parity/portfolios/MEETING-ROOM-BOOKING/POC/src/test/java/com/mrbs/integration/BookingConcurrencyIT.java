// Story: MRBS-001-meeting-room-booking
package com.mrbs.integration;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.web.client.TestRestTemplate;
import org.springframework.boot.test.web.server.LocalServerPort;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.DynamicPropertyRegistry;
import org.springframework.test.context.DynamicPropertySource;
import org.testcontainers.containers.PostgreSQLContainer;
import org.testcontainers.junit.jupiter.Container;
import org.testcontainers.junit.jupiter.Testcontainers;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.*;
import java.util.concurrent.atomic.AtomicInteger;

import static org.assertj.core.api.Assertions.assertThat;

/**
 * Fires N concurrent, identical, overlapping booking requests at the same room and asserts
 * exactly one succeeds (201) and the rest are rejected (409) — the automated evidence for
 * SC-001 / FR-008. See research.md and target-stack-java.md §4.
 */
@Testcontainers
@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
class BookingConcurrencyIT {

    @Container
    static PostgreSQLContainer<?> postgres = new PostgreSQLContainer<>("postgres:16-alpine")
            .withDatabaseName("mrbs")
            .withUsername("mrbs")
            .withPassword("mrbs");

    @DynamicPropertySource
    static void registerProperties(DynamicPropertyRegistry registry) {
        registry.add("spring.datasource.url", postgres::getJdbcUrl);
        registry.add("spring.datasource.username", postgres::getUsername);
        registry.add("spring.datasource.password", postgres::getPassword);
    }

    @LocalServerPort
    private int port;

    private final TestRestTemplate restTemplate = new TestRestTemplate();

    @Test
    void concurrentOverlappingBookings_exactlyOneSucceeds() throws InterruptedException {
        String roomJson = "{\"name\":\"Falcon\",\"location\":\"3F\",\"capacity\":8}";
        ResponseEntity<String> roomResponse = restTemplate.postForEntity(
                url("/api/rooms"), request(roomJson), String.class);
        assertThat(roomResponse.getStatusCode()).isEqualTo(HttpStatus.CREATED);
        Long roomId = extractId(roomResponse.getBody());

        int concurrentRequests = 10;
        String bookingJson = """
                {"roomId": %d, "startTime": "2026-09-11T10:00:00Z", "endTime": "2026-09-11T11:00:00Z", "bookedBy": "Ada"}
                """.formatted(roomId);

        ExecutorService pool = Executors.newFixedThreadPool(concurrentRequests);
        CountDownLatch ready = new CountDownLatch(concurrentRequests);
        CountDownLatch go = new CountDownLatch(1);
        AtomicInteger created = new AtomicInteger();
        AtomicInteger conflicted = new AtomicInteger();

        List<Future<?>> futures = new ArrayList<>();
        for (int i = 0; i < concurrentRequests; i++) {
            futures.add(pool.submit(() -> {
                ready.countDown();
                try {
                    go.await();
                } catch (InterruptedException e) {
                    Thread.currentThread().interrupt();
                }
                ResponseEntity<String> response = restTemplate.postForEntity(
                        url("/api/bookings"), request(bookingJson), String.class);
                if (response.getStatusCode() == HttpStatus.CREATED) {
                    created.incrementAndGet();
                } else if (response.getStatusCode() == HttpStatus.CONFLICT) {
                    conflicted.incrementAndGet();
                }
            }));
        }

        ready.await();
        go.countDown();
        for (Future<?> future : futures) {
            try {
                future.get(30, TimeUnit.SECONDS);
            } catch (Exception e) {
                throw new RuntimeException(e);
            }
        }
        pool.shutdown();

        assertThat(created.get()).isEqualTo(1);
        assertThat(conflicted.get()).isEqualTo(concurrentRequests - 1);
    }

    private String url(String path) {
        return "http://localhost:" + port + path;
    }

    private static org.springframework.http.HttpEntity<String> request(String body) {
        var headers = new org.springframework.http.HttpHeaders();
        headers.setContentType(org.springframework.http.MediaType.APPLICATION_JSON);
        return new org.springframework.http.HttpEntity<>(body, headers);
    }

    private static Long extractId(String json) {
        // Minimal extraction to avoid pulling in a JSON parser dependency for this one field.
        var matcher = java.util.regex.Pattern.compile("\"id\":(\\d+)").matcher(json);
        if (matcher.find()) {
            return Long.parseLong(matcher.group(1));
        }
        throw new IllegalStateException("No id found in response: " + json);
    }
}
