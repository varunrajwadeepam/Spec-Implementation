// Story: MRBS-001-meeting-room-booking
package com.mrbs.application;

import com.mrbs.application.exception.ConflictException;
import com.mrbs.application.exception.NotFoundException;
import com.mrbs.dataaccess.BookingRepository;
import com.mrbs.dataaccess.RoomRepository;
import com.mrbs.domain.Booking;
import com.mrbs.domain.Room;
import com.mrbs.web.dto.BookingRequest;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.time.Instant;
import java.time.temporal.ChronoUnit;
import java.util.List;
import java.util.Optional;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class BookingServiceTest {

    @Mock
    private RoomRepository roomRepository;
    @Mock
    private BookingRepository bookingRepository;

    private BookingService bookingService;

    private Room room;
    private final Instant start = Instant.parse("2026-09-11T10:00:00Z");
    private final Instant end = Instant.parse("2026-09-11T11:00:00Z");

    @BeforeEach
    void setUp() {
        bookingService = new BookingService(roomRepository, bookingRepository);
        room = new Room("Falcon", "3F", 8);
        setId(room, 1L);
    }

    @Test
    void createBooking_noOverlap_succeeds() {
        when(roomRepository.findByIdForUpdate(1L)).thenReturn(Optional.of(room));
        when(bookingRepository.findActiveOverlapping(eq(1L), eq(start), eq(end), any())).thenReturn(List.of());
        when(bookingRepository.save(any(Booking.class))).thenAnswer(inv -> inv.getArgument(0));

        Booking result = bookingService.createBooking(new BookingRequest(1L, start, end, "Ada"));

        assertThat(result.getRoomId()).isEqualTo(1L);
        assertThat(result.getBookedBy()).isEqualTo("Ada");
        assertThat(result.isCancelled()).isFalse();
    }

    @Test
    void createBooking_overlappingWindow_throwsConflict() {
        when(roomRepository.findByIdForUpdate(1L)).thenReturn(Optional.of(room));
        Booking existing = new Booking(1L, start, end, "Grace");
        when(bookingRepository.findActiveOverlapping(eq(1L), any(), any(), any())).thenReturn(List.of(existing));

        Instant overlapStart = start.plus(30, ChronoUnit.MINUTES);
        Instant overlapEnd = end.plus(30, ChronoUnit.MINUTES);

        assertThatThrownBy(() -> bookingService.createBooking(new BookingRequest(1L, overlapStart, overlapEnd, "Ada")))
                .isInstanceOf(ConflictException.class);
        verify(bookingRepository, never()).save(any());
    }

    @Test
    void createBooking_backToBackWindow_succeeds() {
        when(roomRepository.findByIdForUpdate(1L)).thenReturn(Optional.of(room));
        // No overlap reported by the repository for a back-to-back window.
        when(bookingRepository.findActiveOverlapping(eq(1L), any(), any(), any())).thenReturn(List.of());
        when(bookingRepository.save(any(Booking.class))).thenAnswer(inv -> inv.getArgument(0));

        Booking result = bookingService.createBooking(new BookingRequest(1L, end, end.plus(1, ChronoUnit.HOURS), "Ada"));

        assertThat(result).isNotNull();
    }

    @Test
    void createBooking_unknownRoom_throwsNotFound() {
        when(roomRepository.findByIdForUpdate(99L)).thenReturn(Optional.empty());

        assertThatThrownBy(() -> bookingService.createBooking(new BookingRequest(99L, start, end, "Ada")))
                .isInstanceOf(NotFoundException.class);
    }

    @Test
    void createBooking_startNotBeforeEnd_throwsIllegalArgument() {
        assertThatThrownBy(() -> bookingService.createBooking(new BookingRequest(1L, end, start, "Ada")))
                .isInstanceOf(IllegalArgumentException.class);
        verifyNoInteractions(roomRepository);
    }

    @Test
    void cancelBooking_confirmed_succeeds() {
        Booking booking = new Booking(1L, start, end, "Ada");
        setId(booking, 5L);
        when(bookingRepository.findById(5L)).thenReturn(Optional.of(booking));
        when(bookingRepository.save(any(Booking.class))).thenAnswer(inv -> inv.getArgument(0));

        Booking cancelled = bookingService.cancelBooking(5L);

        assertThat(cancelled.isCancelled()).isTrue();
    }

    @Test
    void cancelBooking_unknownId_throwsNotFound() {
        when(bookingRepository.findById(5L)).thenReturn(Optional.empty());

        assertThatThrownBy(() -> bookingService.cancelBooking(5L)).isInstanceOf(NotFoundException.class);
    }

    @Test
    void cancelBooking_alreadyCancelled_throwsConflict() {
        Booking booking = new Booking(1L, start, end, "Ada");
        booking.cancel();
        when(bookingRepository.findById(5L)).thenReturn(Optional.of(booking));

        assertThatThrownBy(() -> bookingService.cancelBooking(5L)).isInstanceOf(ConflictException.class);
    }

    @Test
    void cancelBooking_alreadyExpired_stillSucceeds() {
        Booking expired = new Booking(1L, start, start.plus(1, ChronoUnit.MINUTES), "Ada");
        when(bookingRepository.findById(7L)).thenReturn(Optional.of(expired));
        when(bookingRepository.save(any(Booking.class))).thenAnswer(inv -> inv.getArgument(0));

        Booking cancelled = bookingService.cancelBooking(7L);

        assertThat(cancelled.isCancelled()).isTrue();
    }

    @Test
    void getBooking_futureEndTime_statusConfirmed() {
        Instant future = Instant.now().plus(1, ChronoUnit.HOURS);
        Booking booking = new Booking(1L, Instant.now(), future, "Ada");
        assertThat(BookingStatus.of(booking, Instant.now())).isEqualTo(BookingStatus.CONFIRMED);
    }

    @Test
    void getBooking_pastEndTime_statusExpired() {
        Instant past = Instant.now().minus(1, ChronoUnit.HOURS);
        Booking booking = new Booking(1L, past.minus(1, ChronoUnit.HOURS), past, "Ada");
        assertThat(BookingStatus.of(booking, Instant.now())).isEqualTo(BookingStatus.EXPIRED);
    }

    @Test
    void getBooking_cancelled_statusCancelledRegardlessOfWindow() {
        Instant future = Instant.now().plus(1, ChronoUnit.HOURS);
        Booking booking = new Booking(1L, Instant.now(), future, "Ada");
        booking.cancel();
        assertThat(BookingStatus.of(booking, Instant.now())).isEqualTo(BookingStatus.CANCELLED);
    }

    @Test
    void listBookings_filteredByRoom_returnsOnlyThatRoom() {
        when(bookingRepository.findByRoomId(1L)).thenReturn(List.of(new Booking(1L, start, end, "Ada")));

        List<Booking> results = bookingService.listBookings(1L);

        assertThat(results).hasSize(1);
        verify(bookingRepository, never()).findAll();
    }

    private static void setId(Room room, Long id) {
        try {
            var field = Room.class.getDeclaredField("id");
            field.setAccessible(true);
            field.set(room, id);
        } catch (ReflectiveOperationException e) {
            throw new RuntimeException(e);
        }
    }

    private static void setId(Booking booking, Long id) {
        try {
            var field = Booking.class.getDeclaredField("id");
            field.setAccessible(true);
            field.set(booking, id);
        } catch (ReflectiveOperationException e) {
            throw new RuntimeException(e);
        }
    }
}
