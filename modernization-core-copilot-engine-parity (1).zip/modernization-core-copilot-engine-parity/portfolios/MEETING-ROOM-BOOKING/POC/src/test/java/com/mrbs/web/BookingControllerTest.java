// Story: MRBS-001-meeting-room-booking
package com.mrbs.web;

import com.mrbs.application.BookingService;
import com.mrbs.application.exception.ConflictException;
import com.mrbs.application.exception.NotFoundException;
import com.mrbs.domain.Booking;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.test.context.bean.override.mockito.MockitoBean;
import org.springframework.test.web.servlet.MockMvc;

import java.time.Instant;
import java.util.List;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

@WebMvcTest(BookingController.class)
class BookingControllerTest {

    @Autowired
    private MockMvc mockMvc;
    @MockitoBean
    private BookingService bookingService;

    private final Instant start = Instant.parse("2026-09-11T10:00:00Z");
    private final Instant end = Instant.parse("2026-09-11T11:00:00Z");

    @Test
    void createBooking_valid_returns201() throws Exception {
        when(bookingService.createBooking(any())).thenReturn(new Booking(1L, start, end, "Ada"));

        mockMvc.perform(post("/api/bookings")
                        .contentType("application/json")
                        .content("{\"roomId\":1,\"startTime\":\"2026-09-11T10:00:00Z\",\"endTime\":\"2026-09-11T11:00:00Z\",\"bookedBy\":\"Ada\"}"))
                .andExpect(status().isCreated());
    }

    @Test
    void createBooking_blankBookedBy_returns400() throws Exception {
        mockMvc.perform(post("/api/bookings")
                        .contentType("application/json")
                        .content("{\"roomId\":1,\"startTime\":\"2026-09-11T10:00:00Z\",\"endTime\":\"2026-09-11T11:00:00Z\",\"bookedBy\":\"\"}"))
                .andExpect(status().isBadRequest());
    }

    @Test
    void createBooking_unknownRoom_returns404() throws Exception {
        when(bookingService.createBooking(any())).thenThrow(new NotFoundException("Room not found: 1"));

        mockMvc.perform(post("/api/bookings")
                        .contentType("application/json")
                        .content("{\"roomId\":1,\"startTime\":\"2026-09-11T10:00:00Z\",\"endTime\":\"2026-09-11T11:00:00Z\",\"bookedBy\":\"Ada\"}"))
                .andExpect(status().isNotFound());
    }

    @Test
    void createBooking_overlapping_returns409() throws Exception {
        when(bookingService.createBooking(any())).thenThrow(new ConflictException("Overlap"));

        mockMvc.perform(post("/api/bookings")
                        .contentType("application/json")
                        .content("{\"roomId\":1,\"startTime\":\"2026-09-11T10:00:00Z\",\"endTime\":\"2026-09-11T11:00:00Z\",\"bookedBy\":\"Ada\"}"))
                .andExpect(status().isConflict());
    }

    @Test
    void cancelBooking_success_returns200WithCancelledStatus() throws Exception {
        Booking booking = new Booking(1L, start, end, "Ada");
        booking.cancel();
        when(bookingService.cancelBooking(1L)).thenReturn(booking);

        mockMvc.perform(post("/api/bookings/1/cancel"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.status").value("CANCELLED"));
    }

    @Test
    void cancelBooking_unknown_returns404() throws Exception {
        when(bookingService.cancelBooking(99L)).thenThrow(new NotFoundException("Booking not found: 99"));

        mockMvc.perform(post("/api/bookings/99/cancel"))
                .andExpect(status().isNotFound());
    }

    @Test
    void cancelBooking_alreadyCancelled_returns409() throws Exception {
        when(bookingService.cancelBooking(1L)).thenThrow(new ConflictException("Already cancelled"));

        mockMvc.perform(post("/api/bookings/1/cancel"))
                .andExpect(status().isConflict());
    }

    @Test
    void getBooking_found_returns200() throws Exception {
        when(bookingService.getBooking(1L)).thenReturn(new Booking(1L, start, end, "Ada"));

        mockMvc.perform(get("/api/bookings/1"))
                .andExpect(status().isOk());
    }

    @Test
    void getBooking_unknown_returns404() throws Exception {
        when(bookingService.getBooking(99L)).thenThrow(new NotFoundException("Booking not found: 99"));

        mockMvc.perform(get("/api/bookings/99"))
                .andExpect(status().isNotFound());
    }

    @Test
    void listBookings_filteredByRoom_returnsOnlyThatRoom() throws Exception {
        when(bookingService.listBookings(eq(1L))).thenReturn(List.of(new Booking(1L, start, end, "Ada")));

        mockMvc.perform(get("/api/bookings").param("roomId", "1"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.length()").value(1));
    }
}
