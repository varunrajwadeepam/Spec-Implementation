# Story Implementation Status Tracker

## Overview

`story_status.py` is a unified, per-portfolio story tracker that merges **two sources of truth**:

1. **LLD stories** — `portfolios/{portfolio}/docs/epics/**/STORY-*.md` (L05 output): `**Status:**`, `**Depends On:**`, `**Story Points:**`, `**Priority:**`
2. **Speckit workspaces** — `portfolios/{portfolio}/specs/{story-id}/` artifact files (spec.md → review-report.md, plus POC implementation files), detected via `speckit_status.py`

It answers three questions:
- **What is implemented?** (even when the LLD markdown status is stale — POC/speckit evidence wins)
- **What still needs to be implemented?** (and what is blocked, and why)
- **What can be implemented in parallel?** (dependency graph + ready-to-start frontier)

## Usage

```bash
# Terminal summary (default portfolio: $PORTFOLIO_NAME or ACME-CORE)
python3 scripts/story_status.py
python3 scripts/story_status.py --portfolio ACME-CORE-subset

# HTML dashboard — ALL portfolios in one page, switch via dropdown
python3 scripts/story_status.py --html
# → reports/story-status.html

# Single-portfolio HTML
python3 scripts/story_status.py --html --portfolio ACME-CORE --output portfolios/ACME-CORE/reports/story-status.html

# JSON for programmatic consumption
python3 scripts/story_status.py --json --portfolio ACME-CORE
```

## Effective status model

Each story gets one **effective status**, derived by precedence:

| Status | Meaning | Evidence |
|---|---|---|
| ✅ `implemented` | Code exists | LLD `**Status:** COMPLETE` **or** speckit implement phase done (POC files referenced by tasks.md exist) |
| ⛔ `blocked` | Cannot proceed | LLD status starts with `BLOCKED` / `POST-GATE` (e.g. SME gates R-01/R-02) |
| 🔄 `in_progress` | Work started | Any speckit phase completed, or LLD `In Progress` |
| ⚠ `pre_gate` | Partial work allowed | LLD status starts with `PRE-GATE` |
| ▶ `ready` | Can start **now** | Not started and **all** `**Depends On:**` stories are implemented |
| ⏳ `waiting` | Deps unmet | Not started, at least one dependency not yet implemented |

The **ready** set is the parallelization frontier: those stories have no unmet
dependencies and can be implemented concurrently.

## Story-ID normalization

The estate spells the same story several ways
(`STORY-ACME-CORE-MU-01-02-001`, `STORY-MU-01-02-001`, `STORY-MU-NPW-00-02-005`);
all collapse to the canonical key `MU-01-02-001` for matching and graphing.

## Dependency sources (in precedence order)

1. **Story-level** — `**Depends On:**` lines in the story markdown. Values support
   comma lists, `X through Y` ranges, and **EPIC references**
   (e.g. `EPIC-ACME-CORE-SUBSET-MU-01-02` = "all stories of that EPIC").
2. **README fallback** — when an MU declares **no** dependencies at all but its
   `README.md` has a `## Implementation Sequence` numbered list, EPICs are chained
   in that order (each EPIC waits on the previous one). The dashboard marks these
   MUs with "Sequencing derived at EPIC level (from the MU README …)".
3. **None** — the MU renders as a flat grid with an explicit warning that
   sequencing constraints are not written down.

EPIC-level dependencies gate readiness (a story is `ready` only when every story
of each prerequisite EPIC is implemented) and drive graph layering, but are not
drawn as individual edges — the step columns convey the ordering.

## HTML dashboard

`reports/story-status.html` — dark-theme, self-contained, no external assets:

- **Portfolio dropdown** (top-right) — selection persists in localStorage across the 120 s auto-refresh
- **Stat tiles** — totals per effective status
- **Ready-to-start panel** — the parallelizable frontier, grouped by MU, links to story rows
- **Per-MU section** (description pulled from the MU `README.md` H1):
  - **Dependency graph (SVG)** — columns are dependency steps; stories in the same
    column are parallelizable; thick outline = ready now; nodes link to table rows;
    hover for title/status/deps. MUs with no declared dependencies render as a
    compact grid with an explicit warning that sequencing data is absent.
  - **Story table** — effective status badge, raw LLD status, speckit phase progress
    bar (n/9), dependencies (unmet ones in red), points
- **Speckit-only workspaces** — spec dirs with no matching LLD story ID are listed, not hidden

## See Also

- [speckit_status.py](./speckit_status.py) — speckit phase detection this tool reuses
- [README-speckit-status.md](./README-speckit-status.md)
