#!/usr/bin/env bash
# Generate the GitHub Copilot mirror of the speckit pipeline.
#
#   scripts/gen-copilot.sh            write .github/skills/ and the manifest
#   scripts/gen-copilot.sh --check    regenerate to a temp dir and diff; exit 1 on drift
#   scripts/gen-copilot.sh --lint     run the source lints only
#
# What is mirrored and why only this
# ----------------------------------
# VS Code Copilot Chat reads .claude/skills/, .claude/agents/ and CLAUDE.md
# natively (confirmed in this repo, Phase 0 probes). The one thing it cannot see
# is .claude/commands/. So the mirror is deliberately small:
#
#   .claude/commands/speckit.<x>.md         -> .github/skills/speckit-<x>/SKILL.md
#   .claude/skills/speckit.<x>/SKILL.md     -> .github/skills/speckit-<x>/SKILL.md
#
# The second line exists because an Agent Skill's name may not contain a dot,
# so Copilot's native read of .claude/skills/speckit.orchestrate fails its name
# rule; the hyphenated generated copy is the Copilot path for those three.
# Everything else (the other skills, the three real agents) is NOT mirrored --
# a copy would double-register in the / picker and go stale.
#
# This is the same split upstream github/spec-kit (v1.0.7) makes: canonical
# templates are dotted, Copilot's skills-mode output is hyphenated, and the
# generator rewrites the separator. Users type /speckit.specify in Claude Code
# and /speckit-specify in Copilot.
#
# Transformations are kept to what is mechanical and safe: frontmatter is
# synthesised fresh, handoffs become a "Next steps" section, and speckit.<x>
# command references become speckit-<x>. Everything else is an ASSERTION (see
# lint) -- a translator that silently gets one case wrong is worse than a
# build failure.
set -euo pipefail

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$ROOT"

OUT_DIR=".github/skills"
MANIFEST=".github/.generated-manifest.json"
PHASES='specify|clarify|plan|tasks|analyze|implement|review|checklist|constitution|impact|taskstoissues|orchestrate|migrate|verify'
MODE=write
case "${1:-}" in
    --check) MODE=check;;
    --lint)  MODE=lint;;
    "") ;;
    *) echo "usage: $0 [--check|--lint]" >&2; exit 2;;
esac

if command -v sha256sum >/dev/null 2>&1; then SHA=sha256sum; else SHA="shasum -a 256"; fi
sha() { $SHA "$1" | cut -d' ' -f1; }

FAILS=0
fail() { printf 'LINT: %s\n' "$*" >&2; FAILS=$((FAILS+1)); }

# --------------------------------------------------------------------------
# Sources
# --------------------------------------------------------------------------

# Prints "slug<TAB>source-path" for every mirrored file.
sources() {
    local f
    for f in .claude/commands/speckit.*.md; do
        printf '%s\t%s\n' "$(basename "$f" .md | tr . -)" "$f"
    done
    for f in .claude/skills/speckit.*/SKILL.md; do
        printf '%s\t%s\n' "$(basename "$(dirname "$f")" | tr . -)" "$f"
    done
}

# Frontmatter helpers (all sources use single-line description/argument-hint).
fm_field() { awk -v k="$2" 'NR==1&&$0!="---"{exit} NR>1&&$0=="---"{exit} NR>1&&index($0,k":")==1{sub("^"k":[[:space:]]*",""); gsub(/^"|"$/,""); print; exit}' "$1"; }
body_of()  { awk 'NR==1&&$0!="---"{p=1} p{print;next} NR>1&&$0=="---"{p=1}' "$1"; }

# handoffs: -> "label<TAB>agent<TAB>prompt<TAB>send" lines
handoffs_of() {
    awk 'NR==1&&$0!="---"{exit} NR>1&&$0=="---"{exit}
         /^handoffs:/{h=1;next} h&&/^[^ ]/{h=0}
         h&&/^  - label:/{if(l!="")print l"\t"a"\t"p"\t"s; l=$0;sub(/^  - label:[[:space:]]*/,"",l);a="";p="";s="false";next}
         h&&/^    agent:/{a=$0;sub(/^    agent:[[:space:]]*/,"",a)}
         h&&/^    prompt:/{p=$0;sub(/^    prompt:[[:space:]]*/,"",p)}
         h&&/^    send:/{s=$0;sub(/^    send:[[:space:]]*/,"",s)}
         END{if(l!="")print l"\t"a"\t"p"\t"s}' "$1"
}

# Rewrite speckit.<x> -> speckit-<x> in prose, but never in a real file path
# (commands/speckit.plan.md, skills/speckit.review/) -- those files exist.
hyphenate() {
    perl -pe "s#(?<!\w/)speckit\.($PHASES)\b(?!\.md|/)#speckit-\$1#g"
}

# --------------------------------------------------------------------------
# Generate one skill
# --------------------------------------------------------------------------

emit_skill() {
    local slug="$1" src="$2" dest="$3"
    local desc hint
    desc=$(fm_field "$src" description)
    hint=$(fm_field "$src" argument-hint)
    [ -n "$desc" ] || { fail "$src has no description: frontmatter"; desc="(missing)"; }
    mkdir -p "$(dirname "$dest")"
    {
        printf -- '---\n'
        printf 'name: "%s"\n' "$slug"
        printf 'description: "%s"\n' "$(printf '%s' "$desc" | sed 's/"/\\"/g' | hyphenate)"
        [ -n "$hint" ] && printf 'argument-hint: "%s"\n' "$(printf '%s' "$hint" | sed 's/"/\\"/g')"
        printf 'compatibility: "Requires the portfolio-pack project structure (.specify/, portfolios/{portfolio}/portfolio.yaml)"\n'
        printf 'metadata:\n  author: "mainframe-modernization-core"\n  source: "%s"\n' "$src"
        printf -- '---\n\n'
        printf '<!-- GENERATED FILE -- DO NOT EDIT.\n     Source:     %s\n     Generator:  scripts/gen-copilot.sh\n     Regenerate: scripts/gen-copilot.sh\n     Hand edits here are rejected by the copilot-surface CI job. -->\n\n' "$src"
        printf '> **Copilot naming note.** This skill is `/%s` here. The canonical definitions in `.claude/` use dotted names (`/%s`); any `/speckit-<x>` reference below maps to `.claude/commands/speckit.<x>.md` or `.claude/skills/speckit.<x>/`. Use the form exposed by your agent.\n\n' "$slug" "$(printf '%s' "$slug" | tr - .)"
        body_of "$src" | hyphenate
        local ho; ho=$(handoffs_of "$src")
        if [ -n "$ho" ]; then
            printf '\n## Next steps\n\nWhen this skill completes, the natural continuations are:\n\n'
            printf '%s\n' "$ho" | while IFS=$'\t' read -r label agent prompt send; do
                local a; a=$(printf '%s' "$agent" | tr . -)
                if [ "$send" = true ]; then
                    printf -- '- **%s** — run `/%s` with: "%s" (you may proceed directly)\n' "$label" "$a" "$prompt"
                else
                    printf -- '- **%s** — run `/%s` with: "%s"\n' "$label" "$a" "$prompt"
                fi
            done
        fi
    } > "$dest"
}

generate_into() {
    local base="$1" manifest="$2" slug src dest
    rm -rf "$base/$OUT_DIR"; mkdir -p "$base/$OUT_DIR" "$(dirname "$manifest")"
    {
        printf '{\n  "generator": "scripts/gen-copilot.sh",\n  "generator_sha256": "%s",\n  "files": {\n' "$(sha scripts/gen-copilot.sh)"
        local first=1
        while IFS=$'\t' read -r slug src; do
            dest="$base/$OUT_DIR/$slug/SKILL.md"
            emit_skill "$slug" "$src" "$dest"
            [ $first -eq 1 ] || printf ',\n'; first=0
            printf '    "%s/%s/SKILL.md": {"source": "%s", "source_sha256": "%s", "output_sha256": "%s"}' \
                "$OUT_DIR" "$slug" "$src" "$(sha "$src")" "$(sha "$dest")"
        done < <(sources)
        printf '\n  }\n}\n'
    } > "$manifest"
}

# --------------------------------------------------------------------------
# Lints -- assertions over the canonical sources and the generated tree
# --------------------------------------------------------------------------

lint() {
    local f slug src name desc len d refs missing
    # 1. every generated name is a legal Agent Skill name, description within limit
    while IFS=$'\t' read -r slug src; do
        printf '%s' "$slug" | grep -Eq '^[a-z0-9][a-z0-9-]{0,63}$' || fail "illegal skill name '$slug' (from $src)"
        desc=$(fm_field "$src" description); len=${#desc}
        [ "$len" -le 1024 ] || fail "$src description is $len chars (max 1024)"
        [ "$len" -gt 0 ]    || fail "$src has no description"
    done < <(sources)
    # 2. no PowerShell or Python CLI invocations survive in the canonical prose
    if grep -rln 'scripts/powershell\|speckit-cli\.py' .claude/commands .claude/skills 2>/dev/null | grep -q .; then
        fail "PowerShell/Python invocations remain: $(grep -rln 'scripts/powershell\|speckit-cli\.py' .claude/commands .claude/skills | paste -sd, -)"
    fi
    # 3. every /speckit.<x> reference resolves to a command or skill (migrate/verify are
    #    known follow-up work and are allowed only where explicitly labelled as such)
    refs=$(grep -rhoE '/speckit\.[a-z]+' .claude CLAUDE.md 2>/dev/null | sort -u | sed 's#^/##')
    for name in $refs; do
        case "$name" in speckit.migrate|speckit.verify) continue;; esac
        [ -f ".claude/commands/$name.md" ] || [ -d ".claude/skills/$name" ] || fail "dangling reference /$name"
    done
    # 4. every .claude/skills/*/SKILL.md has name == dirname and a description
    for f in .claude/skills/*/SKILL.md; do
        d=$(basename "$(dirname "$f")"); name=$(fm_field "$f" name)
        [ "$name" = "$d" ] || fail "$f: name '$name' != directory '$d'"
        [ -n "$(fm_field "$f" description)" ] || fail "$f: no description"
    done
    # 5. bundled reference files must be reachable by a relative Markdown link
    for d in .claude/skills/*/reference; do
        [ -d "$d" ] || continue
        for f in "$d"/*; do
            grep -qF "](reference/$(basename "$f"))" "$(dirname "$d")/SKILL.md" || fail "$f is not linked from its SKILL.md"
        done
    done
    # 6. generated tree must not be hand-edited: manifest hashes match
    if [ -f "$MANIFEST" ]; then
        while IFS=$'\t' read -r path expected; do
            [ -f "$path" ] || { fail "manifest lists missing file $path"; continue; }
            [ "$(sha "$path")" = "$expected" ] || fail "$path was hand-edited (hash differs from manifest) -- regenerate instead"
        done < <(sed -n 's/^    "\([^"]*\)": {.*"output_sha256": "\([0-9a-f]*\)"}.*/\1\t\2/p' "$MANIFEST")
    fi
}

# --------------------------------------------------------------------------
# Main
# --------------------------------------------------------------------------

case "$MODE" in
    lint)
        lint; [ "$FAILS" -eq 0 ] && echo "lint: ok" || { echo "lint: $FAILS problem(s)" >&2; exit 1; };;
    write)
        generate_into "." "$MANIFEST"
        lint; [ "$FAILS" -eq 0 ] || { echo "generated, but lint found $FAILS problem(s)" >&2; exit 1; }
        echo "generated $(sources | wc -l | tr -d ' ') skills into $OUT_DIR";;
    check)
        TMP=$(mktemp -d); trap 'rm -rf "$TMP"' EXIT
        generate_into "$TMP" "$TMP/manifest.json"
        drift=0
        if ! diff -r "$OUT_DIR" "$TMP/$OUT_DIR" >/dev/null 2>&1; then
            echo "check: $OUT_DIR is stale -- run scripts/gen-copilot.sh" >&2
            diff -ru "$OUT_DIR" "$TMP/$OUT_DIR" >&2 || true; drift=1
        fi
        # compare manifests ignoring nothing -- generator sha is part of the contract
        if ! diff "$MANIFEST" "$TMP/manifest.json" >/dev/null 2>&1; then
            echo "check: $MANIFEST is stale -- run scripts/gen-copilot.sh" >&2; drift=1
        fi
        lint
        [ "$drift" -eq 0 ] && [ "$FAILS" -eq 0 ] && echo "check: ok" || exit 1;;
esac
