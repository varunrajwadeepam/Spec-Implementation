#!/usr/bin/env python3
"""check-open-core.py — CI guard for the engine repo.

Fails the build when client-specific content leaks out of portfolio packs into
the open engine, or when a pack becomes committable. Run in CI and before any
public release.

  python3 scripts/check-open-core.py                 # default checks
  python3 scripts/check-open-core.py --terms A,B,C   # extra denylist terms

Checks:
  1. Denylist   — client names / program IDs must not appear outside portfolios/.
  2. Gitignore  — every pack except _template must be ignored, and none may be tracked.
  3. Manifests  — every installed pack has a manifest valid against the schema,
                  and every skill it declares resolves on disk.
"""
from __future__ import annotations

import argparse
import json
import pathlib
import re
import subprocess
import sys

REPO = pathlib.Path(__file__).resolve().parent.parent

# Terms that must never appear in the open engine. Extend per engagement.
DENYLIST = [
    "Travellers", "TravellersInsurance", "TRV-", "TradeShift",
    "NPW-H421", "RevDB", "npw-modernization", "revdb-modernization",
    "npw-domain", "revdb-domain", "trvs-underwriting-domain",
    "EC017600", "UWRSCORE", "Npw.Shared", "Npw.FormQnA",
]

# Regex denylist for things a literal term matches too bluntly — internal
# hostnames must be caught without flagging HttpStatus.INTERNAL_SERVER_ERROR
# or System.Data.Entity.Internal.
DENY_PATTERNS = [
    (r"\b[a-z0-9-]+\.internal(?=[/\s\"\':]|$)", "internal hostname"),
    (r"\bdev\.azure\.com/", "internal Azure DevOps URL"),
    # Bare client fragments. The literal denylist only catches full names like
    # NPW-H421; these catch the pieces that survive partial genericization
    # (Uwr.Services, UWRDB, NPW-XX, H421). Word-bounded to avoid false hits.
    # Concrete client artifacts only. "MU-UWR-01" and similar are illustrative
    # underwriting example IDs that agents explicitly label as such -- they are
    # industry vocabulary, not client identifiers, so they are NOT matched here.
    (r"\bUWRDB\b|\bUWRTEST\b|\bUwrServices\b|\buwr-db2\b"
     r"|\bUwr\.(?:Services|Domain|Shared|Tests|Application|Integration)\b", "client artifact name (UWR estate)"),
    (r"\bNPW\b(?!-XX)|\bNpw\.(?:Shared|FormQnA|Integration|Application)\b", "client system code (NPW)"),
    (r"\bH421\b", "client system code (H421)"),
]

# Engine paths to scan. Packs are excluded by construction — they are the
# legitimate home for client content.
SCAN_DIRS = [".claude", "schemas", "scripts", "mcp", "tests", "code-review", ".specify", ".gates", ".github", ".vscode"]
SCAN_FILES = ["CLAUDE.md", "README.md", ".gitlab-ci.yml", ".mcp.json", "pyproject.toml"]
EXTS = {".md", ".py", ".ps1", ".sh", ".json", ".yaml", ".yml", ".txt"}

SELF = pathlib.Path(__file__).name


def gitignored(paths: set[pathlib.Path]) -> set[pathlib.Path]:
    """Subset of paths that git ignores. One batched call, not one per file."""
    if not paths:
        return set()
    res = subprocess.run(["git", "check-ignore", "--stdin"], cwd=REPO,
                         input="\n".join(str(p) for p in paths), capture_output=True, text=True)
    return {pathlib.Path(line) for line in res.stdout.splitlines() if line}


def scan_denylist(terms: list[str]) -> list[str]:
    checks = [(re.compile(re.escape(t), re.IGNORECASE), "client term") for t in terms]
    checks += [(re.compile(p, re.IGNORECASE), label) for p, label in DENY_PATTERNS]
    files: list[pathlib.Path] = []
    for d in SCAN_DIRS:
        base = REPO / d
        if base.exists():
            files += [f for f in base.rglob("*") if f.is_file() and f.suffix in EXTS]
    files += [REPO / f for f in SCAN_FILES if (REPO / f).exists()]

    # This file holds the denylist itself; gitignored files (settings.local.json,
    # developer scratch) are never published, so they are out of scope.
    files = [f for f in sorted(set(files)) if f.name != SELF]
    ignored = gitignored({f.relative_to(REPO) for f in files})
    files = [f for f in files if f.relative_to(REPO) not in ignored]

    failures = []
    for f in files:
        try:
            text = f.read_text(encoding="utf-8")
        except (UnicodeDecodeError, OSError):
            continue
        for i, line in enumerate(text.splitlines(), 1):
            for rx, label in checks:
                m = rx.search(line)
                if m:
                    rel = f.relative_to(REPO)
                    failures.append(f"{rel}:{i}: {label} '{m.group(0)}' in open engine — move to a pack or genericize")
                    break
    return failures


def check_gitignore() -> list[str]:
    failures = []

    # 1. Every pack must be ignored. Only _template is engine content.
    ignorable = [p for p in (REPO / "portfolios").glob("*")
                 if p.is_dir() and p.name != "_template"]
    if ignorable:
        probes = {(p / ".ignore-probe").relative_to(REPO) for p in ignorable}
        for p in sorted(probes - gitignored(probes)):
            failures.append(f"portfolios/{p.parent.name} is NOT gitignored — client content could be "
                            f"committed to the open repo")

    # 2. Ignored is not enough: `git mv` and `git add -f` track files past .gitignore.
    #    Nothing under portfolios/ except _template, and nothing under private/, may be tracked.
    res = subprocess.run(["git", "ls-files", "portfolios/", "private/"],
                         cwd=REPO, capture_output=True, text=True)
    tracked = [line for line in res.stdout.splitlines()
               if line and not line.startswith("portfolios/_template/")]
    if tracked:
        shown = ", ".join(tracked[:5]) + (f" (+{len(tracked) - 5} more)" if len(tracked) > 5 else "")
        failures.append(f"{len(tracked)} pack/quarantine file(s) are TRACKED despite .gitignore "
                        f"(git mv / git add -f bypasses it): {shown}")
    return failures


def check_manifests() -> list[str]:
    failures = []
    schema_path = REPO / "schemas" / "portfolio-manifest.schema.json"
    try:
        import yaml
    except ImportError:
        return ["pyyaml not installed — cannot validate pack manifests (pip install pyyaml)"]
    try:
        import jsonschema
        schema = json.loads(schema_path.read_text())
    except ImportError:
        jsonschema = schema = None

    for pack in sorted((REPO / "portfolios").glob("*")):
        if not pack.is_dir() or pack.name == "_template":
            continue
        mf = pack / "portfolio.yaml"
        if not mf.is_file():
            failures.append(f"portfolios/{pack.name}: missing portfolio.yaml")
            continue
        manifest = yaml.safe_load(mf.read_text())
        if jsonschema:
            try:
                jsonschema.validate(manifest, schema)
            except jsonschema.ValidationError as e:
                failures.append(f"portfolios/{pack.name}/portfolio.yaml: {e.message}")
                continue
        if manifest.get("portfolio") != pack.name:
            failures.append(f"portfolios/{pack.name}: manifest portfolio '{manifest.get('portfolio')}' != directory name")

        skills = [manifest.get("client_skill"), manifest.get("domain_skill")]
        ts = manifest.get("target_stack") or {}
        skills.append(ts.get("conventions_skill"))
        skills += manifest.get("extra_skills") or []
        bases, parent, seen = [pack / "skills"], manifest.get("subset_of"), {pack.name}
        while parent and parent not in seen:
            seen.add(parent)
            parent_manifest = REPO / "portfolios" / parent / "portfolio.yaml"
            if not parent_manifest.is_file():
                failures.append(f"portfolios/{pack.name}: subset_of '{parent}' is not an installed pack — "
                                f"inherited skills cannot resolve")
                break
            bases.append(REPO / "portfolios" / parent / "skills")
            parent = yaml.safe_load(parent_manifest.read_text()).get("subset_of")
        bases.append(REPO / ".claude" / "skills")

        for s in filter(None, skills):
            if not any((base / s / "SKILL.md").is_file() for base in bases):
                failures.append(f"portfolios/{pack.name}: skill '{s}' does not resolve in "
                                f"{', '.join(str(b.relative_to(REPO)) for b in bases)}")
        definition = ts.get("definition")
        if definition and not (pack / definition).is_file():
            failures.append(f"portfolios/{pack.name}: target_stack.definition '{definition}' does not exist")
    return failures


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--terms", help="comma-separated extra denylist terms")
    ap.add_argument("--skip-denylist", action="store_true",
                    help="skip the denylist scan (use while packs still live in-repo)")
    args = ap.parse_args()

    terms = DENYLIST + ([t.strip() for t in args.terms.split(",")] if args.terms else [])

    failures: list[str] = []
    if not args.skip_denylist:
        failures += scan_denylist(terms)
    failures += check_gitignore()
    failures += check_manifests()

    if failures:
        print(f"FAIL — {len(failures)} issue(s):\n")
        for f in failures:
            print(f"  {f}")
        return 1
    print("PASS — open core is clean, packs are ignored, manifests validate")
    return 0


if __name__ == "__main__":
    sys.exit(main())
