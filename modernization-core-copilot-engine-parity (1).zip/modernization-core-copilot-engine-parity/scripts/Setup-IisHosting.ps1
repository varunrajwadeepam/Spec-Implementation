﻿#Requires -Version 5.1
<#
.SYNOPSIS
    Idempotent IIS hosting setup for Uwr.UnderwritingService WCF service.

.DESCRIPTION
    Configures on-premises IIS 10.0 to host the Uwr.UnderwritingService WCF service.
    Creates an application pool, HTTPS site, HTTP-redirect companion site, enforces TLS 1.2
    via Schannel registry, sets NTFS ACL on the logs directory, and optionally grants
    least-privilege DB2 access for the service account.

    Idempotent: safe to run multiple times. Existing IIS objects are left unchanged unless
    their properties differ from the required values.

.VERSION
    1.0.0

.CONTRACT
    specs/006-iis-apppool-site-setup/contracts/iis-setup-contract.md

.NOTES
    Requires: WebAdministration module (Windows built-in via Web-Scripting-Tools feature)
    Platform:  Windows Server 2016+ / IIS 10.0
    Run as:    Local Administrator or equivalent
#>

# T003  -  Parameter block (must appear before any executable statements)
[CmdletBinding(SupportsShouldProcess = $true)]
param(
    [Parameter(Mandatory = $true)]
    [string]$ServiceAccountName,

    [Parameter(Mandatory = $true)]
    [System.Security.SecureString]$ServiceAccountPassword,

    [Parameter(Mandatory = $true)]
    [string]$SslCertificateThumbprint,

    [Parameter(Mandatory = $false)]
    [string]$PhysicalPath = 'C:\inetpub\wwwroot\Uwr.Services',

    [Parameter(Mandatory = $false)]
    [int]$HttpPort = 8080,

    [Parameter(Mandatory = $false)]
    [int]$HttpsPort = 8443,

    [Parameter(Mandatory = $false)]
    [string]$LogsPath = '',

    [Parameter(Mandatory = $false)]
    [string]$HostName = $env:COMPUTERNAME,

    [Parameter(Mandatory = $false)]
    [string]$DatabaseName = '',

    [Parameter(Mandatory = $false)]
    [switch]$GrantDb2Privileges
)

# T004  -  Strict mode and error handling (after param block)
Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'
Import-Module WebAdministration -ErrorAction Stop

# Derive default LogsPath from PhysicalPath
if ([string]::IsNullOrEmpty($LogsPath)) {
    $LogsPath = Join-Path $PhysicalPath 'logs'
}

# T025  -  DB2 table constant
$script:UnderwritingTables = @(
    'UWR.POLICY',
    'UWR.APPLICANT',
    'UWR.CREDIT_PROFILE',
    'UWR.COVERAGE_LIMITS',
    'UWR.CLAIM_HISTORY'
)

# Internal: tracks whether a server restart is needed for Schannel changes
$script:RequiresRestart = $false

# Named IIS resources (fixed contract  -  must not change without contract version bump)
$script:AppPoolName     = 'Uwr.UnderwritingService.AppPool'
$script:SiteName        = 'Uwr.UnderwritingService'
$script:RedirectSiteName = 'Uwr.UnderwritingService.Redirect'
$script:RedirectPath    = 'C:\inetpub\wwwroot\Uwr.Redirect'

# ---------------------------------------------------------------------------
# T005  -  Write-SetupLog helper
# ---------------------------------------------------------------------------
function Write-SetupLog {
    [Diagnostics.CodeAnalysis.SuppressMessageAttribute('PSAvoidUsingWriteHost', '',
        Justification = 'Intentional console progress output for an interactive setup script.')]
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)]
        [string]$Message,

        [Parameter(Mandatory = $false)]
        [ValidateSet('Info', 'Warn', 'Error')]
        [string]$Level = 'Info'
    )

    $timestamp = Get-Date -Format 'yyyy-MM-dd HH:mm:ss'
    $entry = "[$timestamp] [$Level] $Message"

    switch ($Level) {
        'Warn'  { Write-Warning $entry }
        'Error' { Write-Error $entry -ErrorAction Continue }
        default { Write-Verbose $entry; Write-Host $entry }
    }
}

# ---------------------------------------------------------------------------
# T006  -  Assert-Prerequisites
# ---------------------------------------------------------------------------
function Assert-Prerequisites {
    [Diagnostics.CodeAnalysis.SuppressMessageAttribute('PSUseSingularNouns', 'Assert-Prerequisites',
        Justification = 'Contract-mandated name (iis-setup-contract.md v1.1.0); plural form required.')]
    [CmdletBinding()]
    param(
        [string]$ServiceAccountName,
        [string]$PhysicalPath,
        [string]$SslCertificateThumbprint,
        [int]$HttpPort,
        [int]$HttpsPort
    )

    Write-SetupLog -Message 'Checking prerequisites...'

    # (a) IIS installed
    $iisFeature = Get-WindowsFeature -Name 'Web-Server' -ErrorAction SilentlyContinue
    if ($null -eq $iisFeature -or $iisFeature.InstallState -ne 'Installed') {
        throw "Prerequisite failed: IIS (Web-Server) is not installed. Install it with 'Install-WindowsFeature Web-Server -IncludeManagementTools'."
    }

    # (b) Physical path exists
    if (-not (Test-Path -LiteralPath $PhysicalPath)) {
        throw "Prerequisite failed: PhysicalPath '$PhysicalPath' does not exist. Deploy service binaries first (EPIC-01-005)."
    }

    # (c) SSL certificate in LocalMachine\My
    $cert = Get-ChildItem -Path 'Cert:\LocalMachine\My' |
        Where-Object { $_.Thumbprint -eq $SslCertificateThumbprint }
    if ($null -eq $cert) {
        throw "Prerequisite failed: SSL certificate with thumbprint '$SslCertificateThumbprint' not found in Cert:\LocalMachine\My."
    }

    # (d) Service account exists
    $account = Get-LocalUser -Name $ServiceAccountName -ErrorAction SilentlyContinue
    if ($null -eq $account) {
        throw "Prerequisite failed: Local Windows account '$ServiceAccountName' does not exist. Create it before running this script."
    }

    # (e) HttpPort not already bound
    $existingHttp = Get-WebBinding | Where-Object { $_.bindingInformation -match ":${HttpPort}:" }
    if ($existingHttp) {
        $siteName = $existingHttp.ItemXPath -replace ".*@name='([^']+)'.*", '$1'
        throw "Prerequisite failed: Port $HttpPort is already bound to site '$siteName'. Resolve the port conflict before running this script (SC-006)."
    }

    # (f) HttpsPort not already bound
    $existingHttps = Get-WebBinding | Where-Object { $_.bindingInformation -match ":${HttpsPort}:" }
    if ($existingHttps) {
        $siteName = $existingHttps.ItemXPath -replace ".*@name='([^']+)'.*", '$1'
        throw "Prerequisite failed: Port $HttpsPort is already bound to site '$siteName'. Resolve the port conflict before running this script (SC-006)."
    }

    Write-SetupLog -Message 'All prerequisites satisfied.'
}

# ---------------------------------------------------------------------------
# T013  -  New-AppPool
# ---------------------------------------------------------------------------
function New-AppPool {
    [CmdletBinding(SupportsShouldProcess = $true)]
    param(
        [string]$AppPoolName,
        [string]$ServiceAccountName,
        [System.Security.SecureString]$ServiceAccountPassword
    )

    if (-not (Test-Path "IIS:\AppPools\$AppPoolName")) {
        if ($PSCmdlet.ShouldProcess("IIS:\AppPools\$AppPoolName", 'Create Application Pool')) {
            New-WebAppPool -Name $AppPoolName | Out-Null
            Write-SetupLog -Message "Created application pool '$AppPoolName'."
        }
    }
    else {
        Write-SetupLog -Message "Application pool '$AppPoolName' already exists  -  skipping creation."
    }

    # Always apply property settings (idempotent)
    if ($PSCmdlet.ShouldProcess("IIS:\AppPools\$AppPoolName", 'Configure Application Pool Properties')) {
        $plainPassword = [System.Net.NetworkCredential]::new('', $ServiceAccountPassword).Password
        Set-ItemProperty "IIS:\AppPools\$AppPoolName" -Name 'managedRuntimeVersion' -Value 'v4.0'
        Set-ItemProperty "IIS:\AppPools\$AppPoolName" -Name 'managedPipelineMode'   -Value 'Integrated'
        Set-ItemProperty "IIS:\AppPools\$AppPoolName" -Name 'processModel.identityType' -Value 3  # SpecificUser
        Set-ItemProperty "IIS:\AppPools\$AppPoolName" -Name 'processModel.userName'  -Value $ServiceAccountName
        Set-ItemProperty "IIS:\AppPools\$AppPoolName" -Name 'processModel.password'  -Value $plainPassword
        Write-SetupLog -Message "Configured app pool runtime, pipeline mode, and identity."
    }
}

# ---------------------------------------------------------------------------
# T014  -  New-IisSite
# ---------------------------------------------------------------------------
function New-IisSite {
    [CmdletBinding(SupportsShouldProcess = $true)]
    param(
        [string]$SiteName,
        [string]$PhysicalPath,
        [string]$AppPoolName,
        [int]$HttpsPort,
        [string]$SslCertificateThumbprint
    )

    $existing = Get-Website -Name $SiteName -ErrorAction SilentlyContinue
    if ($null -eq $existing) {
        if ($PSCmdlet.ShouldProcess("IIS:\Sites\$SiteName", 'Create Website')) {
            New-Website -Name $SiteName `
                        -PhysicalPath $PhysicalPath `
                        -ApplicationPool $AppPoolName `
                        -Ssl `
                        -Port $HttpsPort | Out-Null
            Write-SetupLog -Message "Created website '$SiteName' on port $HttpsPort."
        }
    }
    else {
        Write-SetupLog -Message "Website '$SiteName' already exists  -  skipping creation."
    }

    # HTTPS binding
    $existingBinding = Get-WebBinding -Name $SiteName -Protocol 'https' -ErrorAction SilentlyContinue |
        Where-Object { $_.bindingInformation -match ":${HttpsPort}:" }

    if ($null -eq $existingBinding) {
        if ($PSCmdlet.ShouldProcess("$SiteName HTTPS:$HttpsPort", 'Add HTTPS Binding')) {
            $binding = New-WebBinding -Name $SiteName -Protocol 'https' -Port $HttpsPort -IPAddress '*'
            # Attach SSL certificate
            $binding = Get-WebBinding -Name $SiteName -Protocol 'https' |
                Where-Object { $_.bindingInformation -match ":${HttpsPort}:" }
            $binding.AddSslCertificate($SslCertificateThumbprint, 'My')
            Write-SetupLog -Message "Added HTTPS binding with certificate '$SslCertificateThumbprint'."
        }
    }
    else {
        Write-SetupLog -Message "HTTPS binding on port $HttpsPort already exists  -  skipping."
    }
}

# ---------------------------------------------------------------------------
# T015  -  New-HttpRedirectSite
# ---------------------------------------------------------------------------
function New-HttpRedirectSite {
    [CmdletBinding(SupportsShouldProcess = $true)]
    param(
        [string]$RedirectSiteName,
        [string]$RedirectPath,
        [int]$HttpPort,
        [int]$HttpsPort,
        [string]$HostName
    )

    # Create redirect physical directory
    if (-not (Test-Path -LiteralPath $RedirectPath)) {
        if ($PSCmdlet.ShouldProcess($RedirectPath, 'Create Redirect Physical Directory')) {
            New-Item -ItemType Directory -Path $RedirectPath -Force | Out-Null

            # Minimal web.config required for IIS HTTP Redirect feature
            $webConfig = @'
<?xml version="1.0" encoding="UTF-8"?>
<configuration>
    <system.webServer>
        <httpRedirect enabled="true" />
    </system.webServer>
</configuration>
'@
            Set-Content -Path (Join-Path $RedirectPath 'web.config') -Value $webConfig -Encoding UTF8
            Write-SetupLog -Message "Created redirect physical directory at '$RedirectPath'."
        }
    }
    else {
        Write-SetupLog -Message "Redirect directory '$RedirectPath' already exists."
    }

    # Create redirect site
    $existing = Get-Website -Name $RedirectSiteName -ErrorAction SilentlyContinue
    if ($null -eq $existing) {
        if ($PSCmdlet.ShouldProcess("IIS:\Sites\$RedirectSiteName", 'Create HTTP Redirect Website')) {
            New-Website -Name $RedirectSiteName `
                        -PhysicalPath $RedirectPath `
                        -Port $HttpPort `
                        -IPAddress '*' | Out-Null
            Write-SetupLog -Message "Created redirect site '$RedirectSiteName' on port $HttpPort."
        }
    }
    else {
        Write-SetupLog -Message "Redirect site '$RedirectSiteName' already exists  -  skipping creation."
    }

    # Configure IIS HTTP Redirect
    $destination = "https://$HostName`:$HttpsPort"
    if ($PSCmdlet.ShouldProcess("$RedirectSiteName httpRedirect", 'Configure HTTP Redirect')) {
        Set-WebConfigurationProperty -PSPath 'MACHINE/WEBROOT/APPHOST' `
            -Location $RedirectSiteName `
            -Filter 'system.webServer/httpRedirect' `
            -Name 'enabled' `
            -Value $true
        Set-WebConfigurationProperty -PSPath 'MACHINE/WEBROOT/APPHOST' `
            -Location $RedirectSiteName `
            -Filter 'system.webServer/httpRedirect' `
            -Name 'destination' `
            -Value $destination
        Set-WebConfigurationProperty -PSPath 'MACHINE/WEBROOT/APPHOST' `
            -Location $RedirectSiteName `
            -Filter 'system.webServer/httpRedirect' `
            -Name 'exactDestination' `
            -Value $false
        Set-WebConfigurationProperty -PSPath 'MACHINE/WEBROOT/APPHOST' `
            -Location $RedirectSiteName `
            -Filter 'system.webServer/httpRedirect' `
            -Name 'httpResponseStatus' `
            -Value 'Permanent'
        Write-SetupLog -Message "Configured HTTP redirect to '$destination' (301 Permanent)."
    }
}

# ---------------------------------------------------------------------------
# T016  -  Set-TlsMinimumVersion
# ---------------------------------------------------------------------------
function Set-TlsMinimumVersion {
    [CmdletBinding(SupportsShouldProcess = $true)]
    param()

    $schannelBase = 'HKLM:\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Protocols'

    $tlsConfig = @(
        @{ Path = "$schannelBase\TLS 1.0\Server"; Name = 'Enabled';          Value = 0 }
        @{ Path = "$schannelBase\TLS 1.0\Server"; Name = 'DisabledByDefault'; Value = 1 }
        @{ Path = "$schannelBase\TLS 1.1\Server"; Name = 'Enabled';          Value = 0 }
        @{ Path = "$schannelBase\TLS 1.1\Server"; Name = 'DisabledByDefault'; Value = 1 }
        @{ Path = "$schannelBase\TLS 1.2\Server"; Name = 'Enabled';          Value = 1 }
        @{ Path = "$schannelBase\TLS 1.2\Server"; Name = 'DisabledByDefault'; Value = 0 }
    )

    foreach ($entry in $tlsConfig) {
        if (-not (Test-Path -LiteralPath $entry.Path)) {
            if ($PSCmdlet.ShouldProcess($entry.Path, 'Create Registry Key')) {
                New-Item -Path $entry.Path -Force | Out-Null
            }
        }

        if ($PSCmdlet.ShouldProcess("$($entry.Path)\$($entry.Name)", "Set Registry Value = $($entry.Value)")) {
            Set-ItemProperty -Path $entry.Path -Name $entry.Name -Value $entry.Value -Type DWord
            $script:RequiresRestart = $true
        }
    }

    if ($script:RequiresRestart) {
        Write-Warning 'RESTART REQUIRED: TLS Schannel changes take effect after server restart.'
        Write-SetupLog -Level Warn -Message 'Schannel registry updated  -  server restart required for TLS changes to take effect.'
    }
}

# ---------------------------------------------------------------------------
# T017  -  Set-LogsDirectoryPermission
# ---------------------------------------------------------------------------
function Set-LogsDirectoryPermission {
    [CmdletBinding(SupportsShouldProcess = $true)]
    param(
        [string]$LogsPath,
        [string]$ServiceAccountName
    )

    if (-not (Test-Path -LiteralPath $LogsPath)) {
        if ($PSCmdlet.ShouldProcess($LogsPath, 'Create Logs Directory')) {
            New-Item -ItemType Directory -Path $LogsPath -Force | Out-Null
            Write-SetupLog -Message "Created logs directory '$LogsPath'."
        }
    }
    else {
        Write-SetupLog -Message "Logs directory '$LogsPath' already exists."
    }

    if ($PSCmdlet.ShouldProcess("$LogsPath ACL", "Grant $ServiceAccountName Write+ReadAndExecute+ListDirectory")) {
        $acl = Get-Acl -Path $LogsPath
        $rights = [System.Security.AccessControl.FileSystemRights]'Write, ReadAndExecute, ListDirectory'
        $inherit = [System.Security.AccessControl.InheritanceFlags]'ContainerInherit, ObjectInherit'
        $propagation = [System.Security.AccessControl.PropagationFlags]::None
        $accessType = [System.Security.AccessControl.AccessControlType]::Allow

        $rule = New-Object System.Security.AccessControl.FileSystemAccessRule(
            $ServiceAccountName, $rights, $inherit, $propagation, $accessType
        )
        $acl.AddAccessRule($rule)
        Set-Acl -Path $LogsPath -AclObject $acl
        Write-SetupLog -Message "Granted '$ServiceAccountName' Write+ReadAndExecute+ListDirectory on '$LogsPath'."
    }
}

# ---------------------------------------------------------------------------
# T021  -  Disable-PeriodicRecycling
# ---------------------------------------------------------------------------
function Disable-PeriodicRecycling {
    [CmdletBinding(SupportsShouldProcess = $true)]
    param([string]$AppPoolName)

    if ($PSCmdlet.ShouldProcess("IIS:\AppPools\$AppPoolName", 'Disable Periodic Recycling')) {
        Set-ItemProperty "IIS:\AppPools\$AppPoolName" -Name 'recycling.periodicRestart.time'     -Value ([TimeSpan]::Zero)
        Set-ItemProperty "IIS:\AppPools\$AppPoolName" -Name 'recycling.periodicRestart.requests' -Value 0
        Set-ItemProperty "IIS:\AppPools\$AppPoolName" -Name 'recycling.periodicRestart.memory'   -Value 0
        Write-SetupLog -Message "Disabled all periodic recycling triggers for '$AppPoolName'."
    }
}

# ---------------------------------------------------------------------------
# T022  -  Enable-AlwaysRunning
# ---------------------------------------------------------------------------
function Enable-AlwaysRunning {
    [CmdletBinding(SupportsShouldProcess = $true)]
    param([string]$AppPoolName)

    if ($PSCmdlet.ShouldProcess("IIS:\AppPools\$AppPoolName", 'Enable AlwaysRunning + AutoStart')) {
        Set-ItemProperty "IIS:\AppPools\$AppPoolName" -Name 'startMode'  -Value 'AlwaysRunning'
        Set-ItemProperty "IIS:\AppPools\$AppPoolName" -Name 'autoStart'  -Value $true
        Write-SetupLog -Message "Configured '$AppPoolName' startMode=AlwaysRunning, autoStart=true."
    }
}

# ---------------------------------------------------------------------------
# T025  -  Grant-Db2ServiceAccountPrivileges
# ---------------------------------------------------------------------------
function Grant-Db2ServiceAccountPrivileges {
    [Diagnostics.CodeAnalysis.SuppressMessageAttribute('PSUseSingularNouns', 'Grant-Db2ServiceAccountPrivileges',
        Justification = 'Contract-mandated name (iis-setup-contract.md v1.1.0); plural form required.')]
    [CmdletBinding(SupportsShouldProcess = $true)]
    param(
        [string]$DatabaseName,
        [string]$ServiceAccountName
    )

    if ([string]::IsNullOrEmpty($DatabaseName)) {
        throw 'DatabaseName is required when -GrantDb2Privileges is specified.'
    }

    Write-SetupLog -Message "Connecting to DB2 database '$DatabaseName'..."
    & db2 "CONNECT TO $DatabaseName"
    if ($LASTEXITCODE -ne 0) {
        throw "DB2 connect failed (exit code $LASTEXITCODE). SQL: CONNECT TO $DatabaseName"
    }

    if ($PSCmdlet.ShouldProcess($DatabaseName, "GRANT CONNECT TO $ServiceAccountName")) {
        & db2 "GRANT CONNECT ON DATABASE TO USER $ServiceAccountName"
        if ($LASTEXITCODE -ne 0) {
            throw "DB2 GRANT CONNECT failed (exit code $LASTEXITCODE)."
        }
        Write-SetupLog -Message "Granted CONNECT ON DATABASE to '$ServiceAccountName'."
    }

    foreach ($table in $script:UnderwritingTables) {
        if ($PSCmdlet.ShouldProcess($table, "GRANT SELECT/INSERT/UPDATE/DELETE TO $ServiceAccountName")) {
            & db2 "GRANT SELECT, INSERT, UPDATE, DELETE ON TABLE $table TO USER $ServiceAccountName"
            if ($LASTEXITCODE -ne 0) {
                throw "DB2 table grant failed for '$table' (exit code $LASTEXITCODE)."
            }
            Write-SetupLog -Message "Granted SELECT/INSERT/UPDATE/DELETE on $table to '$ServiceAccountName'."
        }
    }

    # NOTE: DBADM, SECADM, DDL privileges are intentionally NOT granted.
}

# ---------------------------------------------------------------------------
# T026  -  Test-Db2ServiceAccountPrivileges (audit helper)
# ---------------------------------------------------------------------------
function Test-Db2ServiceAccountPrivileges {
    [Diagnostics.CodeAnalysis.SuppressMessageAttribute('PSUseSingularNouns', 'Test-Db2ServiceAccountPrivileges',
        Justification = 'Contract-mandated name (iis-setup-contract.md v1.1.0); plural form required.')]
    [CmdletBinding()]
    param(
        # Note: connection must already be established via Grant-Db2ServiceAccountPrivileges
        [string]$ServiceAccountName
    )

    # Query CONNECT privilege
    $dbAuthResult = & db2 "SELECT CONNECTAUTH FROM SYSCAT.DBAUTH WHERE GRANTEE = '$($ServiceAccountName.ToUpper())' AND GRANTEETYPE = 'U'"
    $hasConnect = $dbAuthResult -match 'Y'

    # Query table grants
    $tabResult = & db2 "SELECT TABSCHEMA, TABNAME FROM SYSCAT.TABAUTH WHERE GRANTEE = '$($ServiceAccountName.ToUpper())' AND GRANTEETYPE = 'U'"
    $tableGrants = @($tabResult | Where-Object { $_ -match 'UWR\.' })

    # Check for admin rights (should be none)
    $adminResult = & db2 "SELECT DBADMAUTH, SECADMAUTH FROM SYSCAT.DBAUTH WHERE GRANTEE = '$($ServiceAccountName.ToUpper())' AND GRANTEETYPE = 'U'"
    $hasAdminRights = $adminResult -match '\bY\b'

    return [PSCustomObject]@{
        HasConnect     = [bool]$hasConnect
        TableGrants    = [string[]]$tableGrants
        HasAdminRights = [bool]$hasAdminRights
    }
}

# ---------------------------------------------------------------------------
# T029  -  Invoke-SmokeTest
# ---------------------------------------------------------------------------
function Invoke-SmokeTest {
    [CmdletBinding()]
    param(
        [int]$HttpsPort,
        [int]$HttpPort
    )

    $httpsReachable   = $false
    $httpRedirectWorks = $false
    $details          = [System.Collections.Generic.List[string]]::new()

    try {
        $resp = Invoke-WebRequest -Uri "https://localhost:$HttpsPort/UnderwritingService.svc" `
            -UseBasicParsing -SkipCertificateCheck -TimeoutSec 10 -ErrorAction Stop
        $httpsReachable = ($resp.StatusCode -eq 200)
        $details.Add("HTTPS: $($resp.StatusCode)")
    }
    catch {
        $details.Add("HTTPS: FAILED  -  $($_.Exception.Message)")
    }

    try {
        $resp = Invoke-WebRequest -Uri "http://localhost:$HttpPort" `
            -UseBasicParsing -MaximumRedirection 0 -ErrorAction SilentlyContinue
        $httpRedirectWorks = ($resp.StatusCode -eq 301)
        $details.Add("HTTP redirect: $($resp.StatusCode)")
    }
    catch [System.Net.WebException] {
        # 301 may surface as exception depending on PowerShell version
        if ($_.Exception.Response -and [int]$_.Exception.Response.StatusCode -eq 301) {
            $httpRedirectWorks = $true
            $details.Add('HTTP redirect: 301 (via exception path)')
        }
        else {
            $details.Add("HTTP redirect: FAILED  -  $($_.Exception.Message)")
        }
    }

    return [PSCustomObject]@{
        HttpsReachable    = $httpsReachable
        HttpRedirectWorks = $httpRedirectWorks
        Details           = ($details -join '; ')
    }
}

# ===========================================================================
# T018 + T023  -  Main script body
# Guard: skip main execution when script is dot-sourced for unit testing.
# When Pester dot-sources this file, InvocationName is '.'.
# ===========================================================================
if ($MyInvocation.InvocationName -ne '.') {

# Validate all prerequisites before making any changes
Assert-Prerequisites `
    -ServiceAccountName     $ServiceAccountName `
    -PhysicalPath           $PhysicalPath `
    -SslCertificateThumbprint $SslCertificateThumbprint `
    -HttpPort               $HttpPort `
    -HttpsPort              $HttpsPort

# US1: Configure IIS hosting environment
New-AppPool `
    -AppPoolName          $script:AppPoolName `
    -ServiceAccountName   $ServiceAccountName `
    -ServiceAccountPassword $ServiceAccountPassword

New-IisSite `
    -SiteName                 $script:SiteName `
    -PhysicalPath             $PhysicalPath `
    -AppPoolName              $script:AppPoolName `
    -HttpsPort                $HttpsPort `
    -SslCertificateThumbprint $SslCertificateThumbprint

New-HttpRedirectSite `
    -RedirectSiteName  $script:RedirectSiteName `
    -RedirectPath      $script:RedirectPath `
    -HttpPort          $HttpPort `
    -HttpsPort         $HttpsPort `
    -HostName          $HostName

Set-TlsMinimumVersion

Set-LogsDirectoryPermission `
    -LogsPath           $LogsPath `
    -ServiceAccountName $ServiceAccountName

# US2: Service recovery  -  disable periodic recycling + always-running
Disable-PeriodicRecycling -AppPoolName $script:AppPoolName
Enable-AlwaysRunning      -AppPoolName $script:AppPoolName

# T023  -  Verify pool state
$poolState = (Get-WebAppPoolState -Name $script:AppPoolName).Value
Write-SetupLog -Message "App pool '$($script:AppPoolName)' state after setup: $poolState"

# US3 (optional): Grant DB2 least-privilege access
$db2AuditResult = $null
if ($GrantDb2Privileges) {
    Grant-Db2ServiceAccountPrivileges `
        -DatabaseName       $DatabaseName `
        -ServiceAccountName $ServiceAccountName

    if (-not [string]::IsNullOrEmpty($DatabaseName)) {
        $db2AuditResult = Test-Db2ServiceAccountPrivileges `
            -ServiceAccountName $ServiceAccountName
    }
}

# T018  -  Smoke test (mandatory unless -WhatIf)
$smokeResult = $null
$httpsReachable    = $false
$httpRedirectWorks = $false

if (-not $WhatIfPreference) {
    # TODO(T029): Invoke-SmokeTest is defined above; stub is replaced by real implementation
    $smokeResult = Invoke-SmokeTest -HttpsPort $HttpsPort -HttpPort $HttpPort
    $httpsReachable    = $smokeResult.HttpsReachable
    $httpRedirectWorks = $smokeResult.HttpRedirectWorks
}

$success = (-not $WhatIfPreference) -and $httpsReachable -and $httpRedirectWorks

$resultMessage = if ($success) {
    "IIS setup completed successfully. HTTPS reachable: $httpsReachable; HTTP redirect: $httpRedirectWorks."
} elseif ($WhatIfPreference) {
    'WhatIf mode: no changes made. All planned operations printed above.'
} else {
    "IIS setup completed but smoke test failed. HTTPS reachable: $httpsReachable; HTTP redirect: $httpRedirectWorks. Check IIS logs."
}

Write-SetupLog -Message $resultMessage

[PSCustomObject]@{
    Success            = $success
    RequiresRestart    = $script:RequiresRestart
    AppPoolName        = $script:AppPoolName
    SiteName           = $script:SiteName
    RedirectSiteName   = $script:RedirectSiteName
    HttpsUrl           = "https://$HostName`:$HttpsPort"
    HttpRedirectUrl    = "http://$HostName`:$HttpPort"
    HttpsReachable     = $httpsReachable
    HttpRedirectWorks  = $httpRedirectWorks
    Db2AuditResult     = $db2AuditResult
    Message            = $resultMessage
}

} # end if ($MyInvocation.InvocationName -ne '.')
