#!/usr/bin/env python3
"""
speckit_status.py  —  Speckit pipeline status reporter.

Derives all state from files under portfolios/{portfolio}/specs/{story-id}/.
Supplements with portfolios/{portfolio}/specs/speckit-state.json for metadata.

Standalone:
    python scripts/speckit_status.py
    python scripts/speckit_status.py --html
    python scripts/speckit_status.py --html --output reports/speckit-status.html
    python scripts/speckit_status.py --json
    python scripts/speckit_status.py --portfolio ACME-CORE
    python scripts/speckit_status.py --write-entry STORY-ACME-CORE-MU-01-02-002 phase=implement status=completed
"""
from __future__ import annotations

import json
import os
import re
import sys
from dataclasses import dataclass, field
from datetime import datetime
from pathlib import Path
from typing import Dict, List, Optional, Tuple

ROOT = Path(__file__).resolve().parent.parent
PACKS_DIR = ROOT / "portfolios"


def _specs(portfolio: str) -> Path:
    """Speckit workspace root for a portfolio pack."""
    return PACKS_DIR / portfolio / "specs"

# Get portfolio from environment or command line
DEFAULT_PORTFOLIO = os.getenv("PORTFOLIO_NAME", "ACME-CORE")

CHARS_PER_TOKEN = 4   # rough approximation for English/code text

# ---------------------------------------------------------------------------
# Pricing per million tokens (approximate, mid-2025)
# ---------------------------------------------------------------------------
_PRICE: Dict[str, Tuple[float, float]] = {
    # model-key: ($/M input tokens, $/M output tokens)
    "opus":   (15.0,  75.0),
    "sonnet": ( 3.0,  15.0),
    "haiku":  ( 0.8,   4.0),
}

# Default model for speckit (can be overridden)
DEFAULT_MODEL = "sonnet"

# ---------------------------------------------------------------------------
# Speckit phases and their artifacts
# ---------------------------------------------------------------------------
SPECKIT_PHASES = [
    ("specify",   "Specification",         "spec.md"),
    ("clarify",   "Clarification",         "spec.md"),  # updates spec.md
    ("plan",      "Implementation plan",   "plan.md"),
    ("research",  "Research & discovery",  "research.md"),
    ("data",      "Data model",            "data-model.md"),
    ("contracts", "Interface contracts",   "contracts/"),
    ("tasks",     "Task breakdown",        "tasks.md"),
    ("implement", "Implementation",        None),  # Multiple files in POC/
    ("review",    "Code review",           "review-report.md"),
]


def _estimate_tokens_from_size(size_bytes: int) -> int:
    """Estimate tokens from file size in bytes."""
    if size_bytes == 0:
        return 0
    return max(1, size_bytes // CHARS_PER_TOKEN)


def _fmt_tokens(tok: Optional[int]) -> str:
    if tok is None:
        return "—"
    if tok >= 1_000_000:
        return f"~{tok/1_000_000:.1f}M"
    if tok >= 1_000:
        return f"~{tok//1_000}k"
    return str(tok)


def _est_cost_usd(tok: Optional[int], model: Optional[str]) -> Optional[float]:
    if tok is None or model is None:
        return None
    inp_price, out_price = _PRICE.get(model, (3.0, 15.0))
    # Assume 80% input / 20% output split (conservative)
    inp = tok * 0.8
    out = tok * 0.2
    return (inp * inp_price + out * out_price) / 1_000_000


# ---------------------------------------------------------------------------
# Data model
# ---------------------------------------------------------------------------

@dataclass
class Phase:
    id: str
    label: str
    artifact: Optional[str]
    status: str = "pending"       # pending|completed|failed
    ts: Optional[str] = None
    notes: str = ""
    est_tokens: Optional[int] = None
    model: Optional[str] = None


@dataclass
class Story:
    story_id: str
    portfolio: str
    phases: List[Phase]
    status: str = "pending"       # pending|in_progress|completed|failed

    @property
    def path(self) -> Path:
        return _specs(self.portfolio) / self.story_id

    @property
    def total_tokens(self) -> int:
        return sum(p.est_tokens or 0 for p in self.phases)

    @property
    def total_cost_usd(self) -> float:
        total = 0.0
        for p in self.phases:
            c = _est_cost_usd(p.est_tokens, p.model or DEFAULT_MODEL)
            if c:
                total += c
        return total


@dataclass
class SpeckitState:
    stories: List[Story]
    portfolio: str
    generated_at: str
    next_action: str = ""

    @property
    def total_tokens(self) -> int:
        return sum(s.total_tokens for s in self.stories)

    @property
    def total_cost_usd(self) -> float:
        return sum(s.total_cost_usd for s in self.stories)


# ---------------------------------------------------------------------------
# File readers / parsers
# ---------------------------------------------------------------------------

def _mtime(path: Path) -> Optional[str]:
    if path.exists():
        return datetime.fromtimestamp(path.stat().st_mtime).strftime("%Y-%m-%d %H:%M")
    return None


def _read_speckit_state(portfolio: str) -> dict:
    state_path = _specs(portfolio) / "speckit-state.json"
    if state_path.exists():
        try:
            return json.loads(state_path.read_text())
        except Exception:
            return {}
    return {}


def _discover_stories(portfolio: str) -> List[str]:
    """Discover all story directories under portfolios/{portfolio}/specs/."""
    portfolio_dir = _specs(portfolio)
    if not portfolio_dir.exists():
        return []

    stories = []
    for item in sorted(portfolio_dir.iterdir()):
        if item.is_dir() and not item.name.startswith('.'):
            # Story dirs typically follow pattern: 001-name, STORY-*, etc.
            stories.append(item.name)
    return stories


def _find_poc_file(poc_root: Path, ref_path: str) -> Optional[Path]:
    """
    Find a POC file by reference path, trying multiple variations.
    Some tasks reference portfolios/ACME-CORE/POC/Project/File.cs but actual path is portfolios/ACME-CORE/POC/Project/src/File.cs
    """
    # Try the exact path first
    exact_path = ROOT / ref_path.replace('/', os.sep)
    if exact_path.exists():
        return exact_path

    # Extract filename and try to find it under POC root
    filename = Path(ref_path).name
    if filename:
        # Search for the file within the POC directory (limit depth to avoid performance issues)
        for candidate in poc_root.rglob(filename):
            # Exclude obj/ and bin/ directories
            if 'obj' not in candidate.parts and 'bin' not in candidate.parts:
                return candidate

    return None


def _check_implementation_status(story_path: Path) -> Tuple[str, Optional[str], int]:
    """
    Check implementation phase by looking for .cs/.config files referenced in tasks.md.
    Returns: (status, timestamp, estimated_tokens)
    """
    tasks_file = story_path / "tasks.md"
    if not tasks_file.exists():
        return "pending", None, 0

    try:
        tasks_text = tasks_file.read_text(encoding='utf-8')

        # Extract portfolio name from story_path (portfolios/{portfolio}/specs/{story-id})
        portfolio = story_path.parent.name
        poc_root = ROOT / "portfolios" / portfolio / "POC"

        # Extract POC file paths from tasks.md
        poc_files = []

        # Pattern 1: Absolute paths like portfolios/ACME-CORE/POC/Acme.Service.Domain/Entities/File.cs
        for match in re.finditer(r'POC/[^/]+/[^\s`\]]+\.(cs|config)', tasks_text):
            found = _find_poc_file(poc_root, match.group(0))
            if found:
                poc_files.append(found)

        # Pattern 2: Relative paths like src/Acme.Shared/DataContracts/File.cs
        # (relative to portfolios/{portfolio}/POC/)
        for match in re.finditer(r'(?:src|tests)/[^\s`\]]+\.(cs|config)', tasks_text):
            rel_path = match.group(0).replace('/', os.sep)
            poc_path = poc_root / rel_path
            if poc_path.exists():
                poc_files.append(poc_path)

        # Remove duplicates (same file might match both patterns)
        poc_files = list(set(poc_files))

        if not poc_files:
            return "pending", None, 0

        # Calculate total size and find newest file
        total_size = sum(f.stat().st_size for f in poc_files)
        newest = max(poc_files, key=lambda f: f.stat().st_mtime)

        return "completed", _mtime(newest), _estimate_tokens_from_size(total_size)

    except Exception:
        return "pending", None, 0


def _check_phase_status(story_path: Path, phase_id: str, artifact: Optional[str]) -> Tuple[str, Optional[str], int]:
    """
    Check if a phase is completed by looking for its artifact.
    Returns: (status, timestamp, estimated_tokens)
    """
    if artifact is None:
        # Implementation phase - check POC files referenced in tasks.md
        return _check_implementation_status(story_path)

    artifact_path = story_path / artifact

    # Handle directory artifacts (contracts/)
    if artifact.endswith('/'):
        if artifact_path.exists() and artifact_path.is_dir():
            files = list(artifact_path.glob("*.md"))
            if files:
                newest = max(files, key=lambda f: f.stat().st_mtime)
                total_size = sum(f.stat().st_size for f in files)
                return "completed", _mtime(newest), _estimate_tokens_from_size(total_size)
        return "pending", None, 0

    # Handle file artifacts
    if artifact_path.exists():
        size = artifact_path.stat().st_size
        return "completed", _mtime(artifact_path), _estimate_tokens_from_size(size)

    return "pending", None, 0


def _parse_review_report(path: Path) -> Tuple[str, str]:
    """Parse review-report.md to extract verdict and notes."""
    try:
        text = path.read_text()
        # Look for verdict patterns
        verdict_match = re.search(r"## (?:Overall )?Verdict[:\s]*\n+(.+)", text)
        if verdict_match:
            verdict = verdict_match.group(1).strip()
            if any(word in verdict.upper() for word in ["PASS", "APPROVE", "✓", "READY"]):
                return "completed", verdict
            elif any(word in verdict.upper() for word in ["FAIL", "BLOCK", "❌", "NOT READY"]):
                return "failed", verdict
        return "completed", "see report"
    except Exception:
        return "completed", "see report"


def _apply_state_entry(phase: Phase, story_state: dict) -> None:
    """Apply metadata from speckit-state.json entry."""
    entry = story_state.get(phase.id, {})
    if not entry:
        return

    if entry.get("status") and phase.status == "pending":
        phase.status = entry["status"]
    if entry.get("completedAt") and not phase.ts:
        phase.ts = entry["completedAt"][:16].replace("T", " ")
    if entry.get("notes"):
        phase.notes = entry["notes"]
    if entry.get("model"):
        phase.model = entry["model"]


def _resolve_phase(phase: Phase, story_path: Path, story_state: dict) -> None:
    """Resolve phase status by checking artifacts and state file."""
    status, ts, tokens = _check_phase_status(story_path, phase.id, phase.artifact)
    phase.status = status
    phase.ts = ts
    phase.est_tokens = tokens
    phase.model = DEFAULT_MODEL

    # Special handling for review phase
    if phase.id == "review" and phase.artifact:
        review_path = story_path / phase.artifact
        if review_path.exists():
            phase.status, phase.notes = _parse_review_report(review_path)

    # Apply metadata from state file
    _apply_state_entry(phase, story_state)


def _build_story(story_id: str, portfolio: str, state_data: dict) -> Story:
    """Build Story object with all phases resolved."""
    story_path = _specs(portfolio) / story_id
    story_state = state_data.get("stories", {}).get(story_id, {})

    phases = []
    for phase_id, label, artifact in SPECKIT_PHASES:
        phase = Phase(id=phase_id, label=label, artifact=artifact)
        _resolve_phase(phase, story_path, story_state.get("phases", {}))
        phases.append(phase)

    # Determine overall story status
    # Code review is optional - don't require it for story completion
    required_phases = [p for p in phases if p.id != "review"]
    completed = sum(1 for p in required_phases if p.status == "completed")
    failed = sum(1 for p in phases if p.status == "failed")

    if failed > 0:
        status = "failed"
    elif completed == len(required_phases):
        status = "completed"
    elif completed > 0:
        status = "in_progress"
    else:
        status = "pending"

    return Story(
        story_id=story_id,
        portfolio=portfolio,
        phases=phases,
        status=status,
    )


# ---------------------------------------------------------------------------
# Next-action detector
# ---------------------------------------------------------------------------

def _find_next_action(stories: List[Story]) -> str:
    """Determine what should be done next across all stories."""
    if not stories:
        return "No stories found. Run /speckit.orchestrate to create a story."

    # Find first story with pending or failed phases
    for story in stories:
        for phase in story.phases:
            if phase.status == "failed":
                return f"{story.story_id}: Fix and re-run /{phase.id}"
            if phase.status == "pending":
                return f"{story.story_id}: Run /speckit-{phase.id}"

    return "All stories complete."


# ---------------------------------------------------------------------------
# Result text helpers
# ---------------------------------------------------------------------------

_STATUS_ICON = {"completed": "✅", "failed": "❌", "pending": "⬜", "in_progress": "🔄"}


def _fmt_phase(p: Phase) -> str:
    if p.status == "pending":
        return "not started"
    if p.status == "failed":
        return p.notes or "failed"
    if p.status == "completed" and p.notes:
        return p.notes
    return "completed"


# ---------------------------------------------------------------------------
# Terminal renderer
# ---------------------------------------------------------------------------

def render_terminal(state: SpeckitState) -> None:
    try:
        from rich.console import Console
        from rich.table import Table
        from rich import box

        console = Console()
        console.print(
            f"\n[bold cyan]Speckit Pipeline Status — {state.portfolio}[/bold cyan]"
            f"  [dim]{state.generated_at}[/dim]\n"
        )

        for story in state.stories:
            # Story header
            icon = _STATUS_ICON.get(story.status, "⬜")
            console.print(f"\n{icon} [bold]{story.story_id}[/bold]  ({story.status})")

            # Phases table
            tbl = Table(box=box.SIMPLE, show_header=True,
                       header_style="bold dim", expand=False, padding=(0, 1))
            tbl.add_column("",      width=3,  no_wrap=True)
            tbl.add_column("Phase", width=20, no_wrap=True)
            tbl.add_column("Status", min_width=24)
            tbl.add_column("Est. tokens", width=11, no_wrap=True)
            tbl.add_column("Completed", width=17, no_wrap=True, style="dim")

            for phase in story.phases:
                icon = _STATUS_ICON.get(phase.status, "⬜")
                result = _fmt_phase(phase)
                result_style = (
                    "[green]" if phase.status == "completed" else
                    "[red]"   if phase.status == "failed"    else "[dim]"
                )
                tbl.add_row(
                    icon,
                    phase.label,
                    f"{result_style}{result}[/{result_style[1:]}",
                    _fmt_tokens(phase.est_tokens),
                    phase.ts or ""
                )

            console.print(tbl)

            # Story totals
            if story.total_tokens > 0:
                console.print(
                    f"  [dim]Story total:[/dim] {_fmt_tokens(story.total_tokens)}"
                    + (f"  [dim]≈ ${story.total_cost_usd:.2f}[/dim]" if story.total_cost_usd else "")
                )

        # Overall totals
        if state.total_tokens > 0:
            console.print(
                f"\n[bold]Portfolio total:[/bold] {_fmt_tokens(state.total_tokens)}"
                + (f"  [dim]≈ ${state.total_cost_usd:.2f}[/dim]" if state.total_cost_usd else "")
            )

        if state.next_action:
            console.print(f"\n[bold]Next:[/bold]  {state.next_action}\n")

    except ImportError:
        _render_ascii(state)


def _render_ascii(state: SpeckitState) -> None:
    # ASCII-only icons for Windows console compatibility
    ascii_icons = {"completed": "[OK]", "failed": "[X]", "pending": "[ ]", "in_progress": "[~]"}

    print(f"\nSpeckit Pipeline Status - {state.portfolio}  {state.generated_at}\n")

    for story in state.stories:
        icon = ascii_icons.get(story.status, "[ ]")
        print(f"\n{icon}  {story.story_id}  ({story.status})")
        print("  " + "-" * 60)

        for phase in story.phases:
            icon = ascii_icons.get(phase.status, "[ ]")
            lbl = phase.label[:24].ljust(24)
            res = _fmt_phase(phase)[:28].ljust(28)
            toks = _fmt_tokens(phase.est_tokens).ljust(9)
            ts = phase.ts or ""
            print(f"  {icon}  {lbl}  {res}  {toks}  {ts}")

        if story.total_tokens > 0:
            print(f"  Story total: {_fmt_tokens(story.total_tokens)}"
                  + (f"  ~${story.total_cost_usd:.2f}" if story.total_cost_usd else ""))

    if state.total_tokens > 0:
        print(f"\nPortfolio total: {_fmt_tokens(state.total_tokens)}"
              + (f"  ~${state.total_cost_usd:.2f}" if state.total_cost_usd else ""))

    if state.next_action:
        print(f"\nNext:  {state.next_action}\n")


# ---------------------------------------------------------------------------
# HTML renderer
# ---------------------------------------------------------------------------

_HTML_CSS = """
:root{
  --ok:#22c55e;--fail:#ef4444;--warn:#f59e0b;--pending:#64748b;--info:#38bdf8;
  --bg:#0f172a;--surface:#1e293b;--border:#334155;
  --text:#e2e8f0;--dim:#64748b;--accent:#38bdf8;
}
*{box-sizing:border-box;margin:0;padding:0}
body{font-family:ui-monospace,"Cascadia Code",Menlo,monospace;
     background:var(--bg);color:var(--text);padding:2rem;font-size:13px}
h1{color:var(--accent);font-size:1.1rem;margin-bottom:.25rem}
.meta{color:var(--dim);margin-bottom:1.5rem;font-size:11px}
.story{margin-bottom:2rem;border:1px solid var(--border);border-radius:6px;padding:1rem}
.story-header{display:flex;align-items:center;gap:8px;margin-bottom:1rem;
              padding-bottom:.5rem;border-bottom:1px solid var(--border)}
.story-title{font-size:1rem;font-weight:bold;color:var(--accent)}
.story-status{font-size:11px;padding:2px 8px;border-radius:4px;background:var(--surface)}
table{width:100%;border-collapse:collapse}
th{text-align:left;padding:6px 10px;color:var(--dim);
   border-bottom:1px solid var(--border);font-weight:normal;font-size:11px}
td{padding:5px 10px;vertical-align:top}
tr.phase:hover td{background:var(--surface)}
.icon{width:24px;text-align:center}
.phase-lbl{min-width:200px}
.status-col{min-width:180px}
.toks{width:120px;white-space:nowrap}
.ts{color:var(--dim);white-space:nowrap;width:130px}
.badge{display:inline-block;padding:2px 8px;border-radius:4px;font-size:11px}
.ok{background:#14532d;color:var(--ok)}
.fail{background:#450a0a;color:var(--fail)}
.dim{background:#1e293b;color:var(--pending)}
.story-total{margin-top:.5rem;padding-top:.5rem;border-top:1px solid var(--border);
             font-size:11px;color:var(--dim)}
.file-link{color:var(--info);text-decoration:none;font-size:11px;margin-left:4px}
.file-link:hover{text-decoration:underline}
.footer{margin-top:1.5rem;padding:10px 14px;background:var(--surface);
        border-radius:4px;font-size:12px;color:var(--dim)}
.footer strong{color:var(--text)}
.next{margin-top:.75rem;padding:10px 14px;background:var(--surface);
      border-left:3px solid var(--accent);border-radius:4px}
"""


def _esc(s: str) -> str:
    return s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")


def _html_phase_result(phase: Phase, story: Story) -> str:
    if phase.status == "pending":
        return '<span class="badge dim">not started</span>'

    result = _fmt_phase(phase)
    cls = "ok" if phase.status == "completed" else ("fail" if phase.status == "failed" else "dim")
    badge = f'<span class="badge {cls}">{_esc(result)}</span>'

    # Add artifact links if exists
    if phase.artifact and phase.status == "completed":
        artifact_path = story.path / phase.artifact

        # Handle directory artifacts (like contracts/)
        if phase.artifact.endswith('/') and artifact_path.exists() and artifact_path.is_dir():
            files = sorted([f for f in artifact_path.glob("*.md") if f.is_file()])
            if files:
                links = []
                for f in files[:3]:  # Limit to first 3 files
                    abs_path = f.resolve().as_posix()
                    links.append(f'<a class="file-link" href="file:///{abs_path}" target="_blank">{f.name}</a>')
                if len(files) > 3:
                    links.append(f'<span style="color:var(--dim)">+{len(files)-3} more</span>')
                badge += ' ' + ' '.join(links)
        # Handle file artifacts
        elif artifact_path.exists() and artifact_path.is_file():
            abs_path = artifact_path.resolve().as_posix()
            badge += f' <a class="file-link" href="file:///{abs_path}" target="_blank">view</a>'

    return badge


def render_html(state: SpeckitState) -> str:
    stories_html = []

    for story in state.stories:
        icon = _STATUS_ICON.get(story.status, "⬜")

        rows = []
        for phase in story.phases:
            p_icon = _STATUS_ICON.get(phase.status, "⬜")
            rows.append(
                f'<tr class="phase">'
                f'<td class="icon">{p_icon}</td>'
                f'<td class="phase-lbl">{_esc(phase.label)}</td>'
                f'<td class="status-col">{_html_phase_result(phase, story)}</td>'
                f'<td class="toks">{_fmt_tokens(phase.est_tokens)}</td>'
                f'<td class="ts">{phase.ts or "—"}</td>'
                f'</tr>'
            )

        total_line = ""
        if story.total_tokens > 0:
            total_line = (
                f'<div class="story-total">'
                f'<strong>Story total:</strong> {_fmt_tokens(story.total_tokens)}'
                + (f' &nbsp; <strong>Cost:</strong> ~${story.total_cost_usd:.2f}' if story.total_cost_usd else "")
                + '</div>'
            )

        stories_html.append(f'''
<div class="story">
  <div class="story-header">
    <span>{icon}</span>
    <span class="story-title">{_esc(story.story_id)}</span>
    <span class="story-status">{story.status}</span>
  </div>
  <table>
    <thead><tr>
      <th></th><th>Phase</th><th>Status</th><th>Est. tokens</th><th>Completed</th>
    </tr></thead>
    <tbody>
      {''.join(rows)}
    </tbody>
  </table>
  {total_line}
</div>''')

    overall_total = ""
    if state.total_tokens > 0:
        overall_total = (
            f'<div class="footer">'
            f'<strong>Portfolio total:</strong> {_fmt_tokens(state.total_tokens)}'
            + (f' &nbsp; <strong>Est. cost:</strong> ~${state.total_cost_usd:.2f}' if state.total_cost_usd else "")
            + '</div>'
        )

    next_html = (
        f'<div class="next"><strong>Next:</strong> {_esc(state.next_action)}</div>'
        if state.next_action else ""
    )

    return f"""<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta http-equiv="refresh" content="30">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>Speckit Pipeline Status — {_esc(state.portfolio)}</title>
<style>{_HTML_CSS}</style>
</head>
<body>
<h1>Speckit Pipeline Status — {_esc(state.portfolio)}</h1>
<div class="meta">Generated {state.generated_at} &nbsp;·&nbsp; Auto-refreshes every 30 s</div>
{''.join(stories_html)}
{overall_total}
{next_html}
</body>
</html>"""


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------

def build_state(portfolio: str) -> SpeckitState:
    state_data = _read_speckit_state(portfolio)
    story_ids = _discover_stories(portfolio)

    stories = [_build_story(sid, portfolio, state_data) for sid in story_ids]

    return SpeckitState(
        stories=stories,
        portfolio=portfolio,
        generated_at=datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
        next_action=_find_next_action(stories),
    )


def print_status(portfolio: str) -> None:
    render_terminal(build_state(portfolio))


def generate_html_report(portfolio: str, output_path: Optional[Path] = None) -> Path:
    html = render_html(build_state(portfolio))
    if output_path is None:
        out_dir = ROOT / "portfolios" / portfolio / "reports"
        out_dir.mkdir(parents=True, exist_ok=True)
        output_path = out_dir / "speckit-status.html"
    output_path.write_text(html, encoding="utf-8")
    return output_path


def write_speckit_state_entry(portfolio: str, story_id: str, **kwargs) -> None:
    """
    Write/update one entry in portfolios/{portfolio}/specs/speckit-state.json.
    Called by speckit skills via:
        python scripts/speckit_status.py --portfolio ACME-CORE --write-entry STORY-ACME-CORE-MU-01-02-002 phase=implement status=completed
    """
    state_path = _specs(portfolio) / "speckit-state.json"
    state_path.parent.mkdir(parents=True, exist_ok=True)

    state: dict = {}
    if state_path.exists():
        try:
            state = json.loads(state_path.read_text())
        except Exception:
            pass

    state.setdefault("version", "1")
    story_entry = state.setdefault("stories", {}).setdefault(story_id, {})
    story_entry["lastUpdated"] = datetime.utcnow().strftime("%Y-%m-%dT%H:%M:%SZ")

    # Handle phase-specific updates
    if "phase" in kwargs:
        phase_id = kwargs.pop("phase")
        phase_entry = story_entry.setdefault("phases", {}).setdefault(phase_id, {})
        phase_entry["completedAt"] = datetime.utcnow().strftime("%Y-%m-%dT%H:%M:%SZ")
        for k, v in kwargs.items():
            phase_entry[k] = v
    else:
        # Story-level updates
        for k, v in kwargs.items():
            story_entry[k] = v

    state["lastUpdated"] = datetime.utcnow().strftime("%Y-%m-%dT%H:%M:%SZ")
    state_path.write_text(json.dumps(state, indent=2), encoding="utf-8")


# ---------------------------------------------------------------------------
# Standalone CLI
# ---------------------------------------------------------------------------

def main() -> None:
    import argparse

    parser = argparse.ArgumentParser(description="Speckit pipeline status reporter.")
    parser.add_argument("--portfolio", type=str, default=DEFAULT_PORTFOLIO,
                       help=f"Portfolio name (default: {DEFAULT_PORTFOLIO})")
    parser.add_argument("--html", action="store_true",
                       help="Generate HTML report")
    parser.add_argument("--output", type=Path, default=None,
                       help="Output path for HTML report")
    parser.add_argument("--json", action="store_true",
                       help="Output JSON format")
    parser.add_argument("--write-entry", metavar="STORY_ID",
                       help="Write/update state entry for a story")
    args, extra = parser.parse_known_args()

    if args.write_entry:
        kwargs = dict(p.split("=", 1) for p in extra if "=" in p)
        write_speckit_state_entry(args.portfolio, args.write_entry, **kwargs)
        print(f"speckit-state.json updated for {args.write_entry}")
        return

    if args.html:
        out = generate_html_report(args.portfolio, args.output)
        print(f"HTML report written to: {out}")
        return

    if args.json:
        state = build_state(args.portfolio)
        print(json.dumps({
            "portfolio":     state.portfolio,
            "generatedAt":   state.generated_at,
            "nextAction":    state.next_action,
            "totalTokens":   state.total_tokens,
            "estCostUsd":    round(state.total_cost_usd, 4),
            "stories": [
                {
                    "storyId": s.story_id,
                    "status": s.status,
                    "totalTokens": s.total_tokens,
                    "estCostUsd": round(s.total_cost_usd, 4),
                    "phases": [
                        {
                            "id": p.id,
                            "label": p.label,
                            "status": p.status,
                            "ts": p.ts,
                            "notes": p.notes,
                            "estTokens": p.est_tokens,
                            "model": p.model,
                        }
                        for p in s.phases
                    ]
                }
                for s in state.stories
            ],
        }, indent=2))
        return

    print_status(args.portfolio)


if __name__ == "__main__":
    main()
