#!/bin/bash
# Script to align MU folder paths with new naming convention
# Pattern: MU-NPW-XX → MU-ACME-CORE-XX

set -e

PORTFOLIO="ACME-CORE"
EPICS_DIR="docs/$PORTFOLIO/epics"

echo "=== Aligning MU Folder Paths with Naming Convention ==="
echo "Pattern: MU-NPW-XX → MU-ACME-CORE-XX"
echo ""

# Find all MU folders that need renaming
mu_folders=$(find "$EPICS_DIR" -maxdepth 1 -type d -name "MU-NPW-*" | sort)

if [ -z "$mu_folders" ]; then
    echo "✅ All MU folders already in aligned format!"
    exit 0
fi

count=0
total=$(echo "$mu_folders" | wc -l)

echo "Found $total MU folders to rename"
echo ""

# Process each folder
while IFS= read -r old_path; do
    # Extract parent directory and folder name
    parent_dir=$(dirname "$old_path")
    old_folder_name=$(basename "$old_path")

    # Pattern: MU-NPW-XX → MU-ACME-CORE-XX
    if [[ $old_folder_name =~ ^MU-NPW-([0-9]{2})$ ]]; then
        mu_num="${BASH_REMATCH[1]}"

        # Construct new folder name with H421 inserted
        new_folder_name="MU-ACME-CORE-${mu_num}"
        new_path="$parent_dir/$new_folder_name"

        # Rename the folder
        if [ -d "$old_path" ]; then
            mv "$old_path" "$new_path"
            count=$((count + 1))
            echo "[$count/$total] Renamed: $old_folder_name → $new_folder_name"
        else
            echo "WARNING: Folder not found: $old_path"
        fi
    else
        echo "SKIP: $old_folder_name (doesn't match expected pattern)"
    fi
done <<< "$mu_folders"

echo ""
echo "✅ Renamed $count MU folders"

# Show sample of new structure
echo ""
echo "=== New MU Folder Structure ==="
find "$EPICS_DIR" -maxdepth 1 -type d -name "MU-ACME-CORE-*" | sort
