#!/usr/bin/env bash
# install-portfolio.sh — plug a portfolio pack into the engine.
#
# Usage: ./scripts/install-portfolio.sh <path-to-pack-dir> [--copy]
#
#   <path-to-pack-dir>  Directory containing portfolio.yaml (e.g. ../my-portfolios/portfolios/ACME-CORE)
#   --copy              Copy the pack instead of symlinking (default: symlink, so
#                       pipeline outputs land in the pack's own git working tree)
#
# Validates the manifest against schemas/portfolio-manifest.schema.json and
# verifies every declared skill resolves (pack skills/ -> each subset_of ancestor's
# skills/ -> .claude/skills/). This validation IS the portfolio registration step —
# there is no registry to edit.
set -euo pipefail

ENGINE_ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
PACK_SRC="${1:?usage: install-portfolio.sh <path-to-pack-dir> [--copy]}"
MODE="${2:-link}"

PACK_SRC="$(cd "$PACK_SRC" && pwd)"
MANIFEST="$PACK_SRC/portfolio.yaml"
[ -f "$MANIFEST" ] || { echo "ERROR: $MANIFEST not found — not a portfolio pack" >&2; exit 1; }

python3 - "$MANIFEST" "$ENGINE_ROOT" "$PACK_SRC" <<'PY'
import json, sys, pathlib
try:
    import yaml
except ImportError:
    sys.exit("ERROR: pyyaml is required (pip install pyyaml)")

manifest_path, engine_root, pack_src = map(pathlib.Path, sys.argv[1:4])
manifest = yaml.safe_load(manifest_path.read_text())

schema_path = engine_root / "schemas" / "portfolio-manifest.schema.json"
try:
    import jsonschema
    jsonschema.validate(manifest, json.loads(schema_path.read_text()))
    print(f"OK   manifest valid against {schema_path.name}")
except ImportError:
    missing = [k for k in ("portfolio", "description", "client_skill", "domain_skill", "target_stack", "codegen") if k not in manifest]
    if missing:
        sys.exit(f"ERROR: manifest missing required fields: {missing}")
    print("WARN jsonschema not installed — required-field check only")

name = manifest["portfolio"]
if name != pack_src.name:
    sys.exit(f"ERROR: manifest portfolio '{name}' != pack directory name '{pack_src.name}'")

def skill_search_path(pack_dir, manifest_data):
    """Pack skills/, then each subset_of ancestor's skills/, then engine skills."""
    bases = [pack_dir / "skills"]
    seen = {pack_dir.name}
    parent = manifest_data.get("subset_of")
    while parent:
        if parent in seen:
            sys.exit(f"ERROR: subset_of cycle at '{parent}'")
        seen.add(parent)
        parent_pack = engine_root / "portfolios" / parent
        parent_manifest = parent_pack / "portfolio.yaml"
        if not parent_manifest.is_file():
            sys.exit(f"ERROR: subset_of '{parent}' is not an installed pack "
                     f"({parent_manifest} not found) — inherited skills cannot resolve")
        bases.append(parent_pack / "skills")
        parent = yaml.safe_load(parent_manifest.read_text()).get("subset_of")
    bases.append(engine_root / ".claude" / "skills")
    return bases


def resolve(skill):
    for base in skill_search_path(pack_src, manifest):
        if (base / skill / "SKILL.md").is_file():
            return base / skill / "SKILL.md"
    return None

skills = [manifest["client_skill"], manifest["domain_skill"],
          manifest["target_stack"]["conventions_skill"], *manifest.get("extra_skills", [])]
ok = True
for s in skills:
    p = resolve(s)
    if p:
        print(f"OK   skill {s} -> {p}")
    else:
        searched = ", ".join(str(b) for b in skill_search_path(pack_src, manifest))
        print(f"ERROR: skill '{s}' not found in any of: {searched}", file=sys.stderr)
        ok = False

stack_def = pack_src / manifest["target_stack"]["definition"]
if stack_def.is_file():
    print(f"OK   target-stack definition {stack_def.relative_to(pack_src)}")
else:
    print(f"ERROR: target-stack definition missing: {stack_def}", file=sys.stderr)
    ok = False

sys.exit(0 if ok else 1)
PY

NAME="$(basename "$PACK_SRC")"
DEST="$ENGINE_ROOT/portfolios/$NAME"

if [ "$PACK_SRC" = "$DEST" ]; then
    echo "OK   pack already lives in-engine at portfolios/$NAME — nothing to install"
    exit 0
fi
if [ -e "$DEST" ] || [ -L "$DEST" ]; then
    echo "ERROR: portfolios/$NAME already exists — remove it first" >&2
    exit 1
fi

mkdir -p "$ENGINE_ROOT/portfolios"
if [ "$MODE" = "--copy" ]; then
    cp -R "$PACK_SRC" "$DEST"
    echo "OK   copied pack to portfolios/$NAME"
else
    ln -s "$PACK_SRC" "$DEST"
    echo "OK   symlinked portfolios/$NAME -> $PACK_SRC (outputs commit to the pack repo)"
fi
echo "Done. Set PORTFOLIO_NAME=$NAME in .env or pass portfolio=$NAME to agents."
