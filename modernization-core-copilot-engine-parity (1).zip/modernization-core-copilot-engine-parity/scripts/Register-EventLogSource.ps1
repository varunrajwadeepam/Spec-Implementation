<#
.SYNOPSIS
    Registers the Uwr.UnderwritingService Windows Event Log source and sets write
    permissions on the IIS application-pool log directory.

.DESCRIPTION
    This script must be run as Administrator on the target IIS server (or in a privileged
    CI stage). It is idempotent: if the source is already registered the creation step is
    skipped.

    Actions performed:
      1. Check / create the "Uwr.UnderwritingService" event source in the Application log.
      2. Grant the IIS application-pool identity write + create permissions on the logs\
         directory under the service root so NLog can create and rotate log files.

.PARAMETER AppPoolName
    Name of the IIS application-pool identity that runs Uwr.Services.
    Defaults to "Uwr.UnderwritingServicePool".

.PARAMETER ServiceRoot
    Absolute path to the directory where the Uwr.Services application is deployed.
    Defaults to "C:\inetpub\wwwroot\Uwr.Services".

.EXAMPLE
    .\Register-EventLogSource.ps1

.EXAMPLE
    .\Register-EventLogSource.ps1 -AppPoolName "MyCustomPool" -ServiceRoot "D:\Apps\UwrServices"

.NOTES
    Requires: PowerShell 5.1+, Administrator privileges.
    FR-006, DD-004
#>
[CmdletBinding(SupportsShouldProcess)]
param (
    [string] $AppPoolName = "Uwr.UnderwritingServicePool",
    [string] $ServiceRoot = "C:\inetpub\wwwroot\Uwr.Services"
)

Set-StrictMode -Version Latest
$ErrorActionPreference = "Stop"

$EventSource = "Uwr.UnderwritingService"
$EventLog    = "Application"
$LogDir      = Join-Path $ServiceRoot "logs"

# ── 1. Event Log source registration ────────────────────────────────────────────

Write-Host "Checking event source '$EventSource' in '$EventLog' log..."

if ([System.Diagnostics.EventLog]::SourceExists($EventSource)) {
    $existing = [System.Diagnostics.EventLog]::LogNameFromSourceName($EventSource, ".")
    Write-Host "  Source already registered in '$existing'. Skipping creation."
} else {
    if ($PSCmdlet.ShouldProcess(
            "EventLog '$EventLog'",
            "Register event source '$EventSource'")) {

        [System.Diagnostics.EventLog]::CreateEventSource($EventSource, $EventLog)
        Write-Host "  Event source '$EventSource' registered in '$EventLog' log."
    }
}

# ── 2. Log directory creation ────────────────────────────────────────────────────

Write-Host "Ensuring log directory exists: $LogDir"

if (-not (Test-Path $LogDir)) {
    if ($PSCmdlet.ShouldProcess($LogDir, "Create log directory")) {
        New-Item -ItemType Directory -Path $LogDir -Force | Out-Null
        Write-Host "  Created: $LogDir"
    }
} else {
    Write-Host "  Directory already exists: $LogDir"
}

# ── 3. ACL: grant IIS application-pool identity write access ─────────────────────
#
# The IIS_IUSRS group provides base read access; the app-pool identity additionally
# needs (OI)(CI)W so NLog can create new log files and write to existing ones.
# Using icacls is the most reliable cross-Windows-version approach (avoids Get-Acl
# quirks on older OS builds).
#
# Permission mask explanation:
#   (OI) Object Inherit   — applies to new files created in the directory
#   (CI) Container Inherit — applies to sub-directories
#   W    Write + Append + WriteAttributes + WriteExtendedAttributes + Delete + DeleteChild + Synchronize

$AppPoolIdentity = "IIS AppPool\$AppPoolName"

Write-Host "Granting write permissions to '$AppPoolIdentity' on '$LogDir'..."

if ($PSCmdlet.ShouldProcess($LogDir, "Grant write access to '$AppPoolIdentity'")) {
    & icacls $LogDir /grant "${AppPoolIdentity}:(OI)(CI)W" /T /Q
    if ($LASTEXITCODE -ne 0) {
        Write-Error "icacls failed with exit code $LASTEXITCODE. Verify '$AppPoolName' is a valid IIS app pool."
    } else {
        Write-Host "  Permissions granted."
    }
}

Write-Host ""
Write-Host "Setup complete."
Write-Host "  Event source : $EventSource → $EventLog"
Write-Host "  Log directory: $LogDir"
Write-Host "  App-pool ACL : $AppPoolIdentity → (OI)(CI)W"
