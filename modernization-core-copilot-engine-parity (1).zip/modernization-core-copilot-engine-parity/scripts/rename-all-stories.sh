#!/bin/bash
# Script to rename all story files to the new pattern: STORY-MU-ACME-CORE-XX-YY-ZZZ.md

set -e

PORTFOLIO="ACME-CORE"
EPICS_DIR="docs/$PORTFOLIO/epics"

echo "=== Renaming Story Files to New Pattern ==="
echo "Target: STORY-MU-ACME-CORE-XX-YY-ZZZ.md"
echo ""

# Find all story files that need renaming
story_files=$(find "$EPICS_DIR" -name "STORY-*.md" -type f | grep -v "STORY-MU-ACME-CORE-")

if [ -z "$story_files" ]; then
    echo "✅ All story files already in new format!"
    exit 0
fi

count=0
total=$(echo "$story_files" | wc -l)

echo "Found $total story files to rename"
echo ""

# Process each file
while IFS= read -r old_path; do
    # Extract directory and filename
    dir=$(dirname "$old_path")
    old_filename=$(basename "$old_path")

    # Pattern 1: STORY-MU-NPW-XX-YY-ZZZ.md → STORY-MU-ACME-CORE-XX-YY-ZZZ.md
    if [[ $old_filename =~ ^STORY-MU-NPW-([0-9]{2})-([0-9]{2})-([0-9]{3})\.md$ ]]; then
        mu_num="${BASH_REMATCH[1]}"
        epic_num="${BASH_REMATCH[2]}"
        story_num="${BASH_REMATCH[3]}"
        new_filename="STORY-MU-ACME-CORE-${mu_num}-${epic_num}-${story_num}.md"

    # Pattern 2: STORY-MU-XX-YY-ZZZ.md → STORY-MU-ACME-CORE-XX-YY-ZZZ.md
    elif [[ $old_filename =~ ^STORY-MU-([0-9]{2})-([0-9]{2})-([0-9]{3})\.md$ ]]; then
        mu_num="${BASH_REMATCH[1]}"
        epic_num="${BASH_REMATCH[2]}"
        story_num="${BASH_REMATCH[3]}"
        new_filename="STORY-MU-ACME-CORE-${mu_num}-${epic_num}-${story_num}.md"

    # Pattern 3: STORY-MU-NPW-XX-YY-POST-ZZZ.md → Keep as is (special case)
    elif [[ $old_filename =~ ^STORY-MU-NPW-[0-9]{2}-[0-9]{2}-POST- ]]; then
        echo "SKIP: $old_filename (POST stories kept as-is for now)"
        continue

    else
        echo "SKIP: $old_filename (unknown pattern)"
        continue
    fi

    new_path="$dir/$new_filename"

    # Rename the file
    if [ -f "$old_path" ]; then
        mv "$old_path" "$new_path"
        count=$((count + 1))
        echo "[$count/$total] Renamed: $old_filename → $new_filename"
    else
        echo "WARNING: File not found: $old_path"
    fi
done <<< "$story_files"

echo ""
echo "✅ Renamed $count story files"
