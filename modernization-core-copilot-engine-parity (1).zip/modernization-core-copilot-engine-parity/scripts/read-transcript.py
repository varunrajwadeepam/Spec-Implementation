"""
Read Claude Code JSONL transcript as a readable conversation.

Usage:
    python scripts/read-transcript.py <path-to-jsonl>
    python scripts/read-transcript.py <path-to-jsonl> --tools-only
    python scripts/read-transcript.py <path-to-jsonl> --no-thinking
    python scripts/read-transcript.py <path-to-jsonl> --full
    python scripts/read-transcript.py <path-to-jsonl> --output chat.md

Examples:
    # Main conversation
    python scripts/read-transcript.py "C:\\Users\\...\\session-id.jsonl"

    # Subagent conversation
    python scripts/read-transcript.py "C:\\Users\\...\\subagents\\agent-xxx.jsonl"

    # Full text, no truncation
    python scripts/read-transcript.py <path> --full --output transcript.md

    # Show only tool calls + results
    python scripts/read-transcript.py <path> --tools-only --full
"""

import json
import sys
import argparse
from pathlib import Path
from textwrap import indent


SEPARATOR = "─" * 60
COLORS = {
    "system": "\033[90m",
    "user": "\033[36m",
    "assistant": "\033[32m",
    "thinking": "\033[90;3m",
    "tool_use": "\033[33m",
    "tool_result": "\033[35m",
    "reset": "\033[0m",
}


def colorize(text, role, use_color=True):
    if not use_color:
        return text
    color = COLORS.get(role, "")
    return f"{color}{text}{COLORS['reset']}"


def truncate_text(text, max_lines=30, full=False):
    if full:
        return text
    lines = text.split("\n")
    if len(lines) > max_lines:
        return "\n".join(lines[:max_lines]) + f"\n  ... ({len(lines) - max_lines} more lines)"
    return text


def format_tool_input(inp, full=False):
    lines = []

    for k, v in inp.items():
        val = str(v)
        if not full and len(val) > 200:
            val = val[:200] + "..."
        lines.append(f"  {k}: {val}")

    return "\n".join(lines)


def format_tool_result_text(content, max_lines=30, full=False):
    if isinstance(content, list):
        parts = []
        for block in content:
            if isinstance(block, dict):
                text = block.get("text", block.get("content", json.dumps(block, indent=2)))
                parts.append(str(text))
            else:
                parts.append(str(block))
        text = "\n".join(parts)
    elif isinstance(content, dict):
        text = content.get("text", content.get("content", json.dumps(content, indent=2)))
    else:
        text = str(content) if content else "(empty)"

    return truncate_text(text, max_lines, full)


def read_jsonl(path):
    entries = []
    with open(path, "r", encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if not line:
                continue
            try:
                entries.append(json.loads(line))
            except json.JSONDecodeError:
                continue
    return entries


def render_transcript(entries, tools_only=False, show_thinking=True, use_color=True, max_result_lines=30, full=False):
    output = []
    step = 0

    # Track tool_use IDs to match with results
    pending_tools = {}

    for entry in entries:
        entry_type = entry.get("type", "")

        # Skip non-conversation entries
        if entry_type in ("queue-operation", "file-history-snapshot", "ai-title", "last-prompt", "attachment"):
            continue

        message = entry.get("message", {})
        role = message.get("role", entry_type)
        content = message.get("content", "")

        # --- USER messages (contain tool results OR text) ---
        if entry_type == "user" or role == "user":
            if isinstance(content, list):
                for block in content:
                    if not isinstance(block, dict):
                        continue

                    block_type = block.get("type", "")

                    # Tool result block
                    if block_type == "tool_result":
                        tool_id = block.get("tool_use_id", "")
                        tool_name = pending_tools.get(tool_id, "unknown")
                        result_content = block.get("content", "")
                        is_error = block.get("is_error", False)

                        step += 1
                        err_marker = " [ERROR]" if is_error else ""
                        header = f"[{step}] <<< RESULT ({tool_name}){err_marker} <<< (id: {tool_id})"
                        formatted = format_tool_result_text(result_content, max_result_lines, full)

                        output.append(colorize(header, "tool_result", use_color))
                        output.append(colorize(formatted, "tool_result", use_color))
                        output.append("")

                    # Text block in user message
                    elif block_type == "text":
                        if tools_only:
                            continue
                        text = block.get("text", "")
                        if not text.strip():
                            continue
                        step += 1
                        header = f"[{step}] === USER {'=' * 50}"
                        text = truncate_text(text, 30, full)
                        output.append(colorize(header, "user", use_color))
                        output.append(colorize(text, "user", use_color))
                        output.append("")

            elif isinstance(content, str) and content.strip():
                if tools_only:
                    continue
                step += 1
                header = f"[{step}] === USER {'=' * 50}"
                body = truncate_text(content, 30, full)
                output.append(colorize(header, "user", use_color))
                output.append(colorize(body, "user", use_color))
                output.append("")

        # --- ASSISTANT messages ---
        elif entry_type == "assistant" or role == "assistant":
            if not isinstance(content, list):
                content = [{"type": "text", "text": str(content)}] if content else []

            for block in content:
                if not isinstance(block, dict):
                    continue

                block_type = block.get("type", "")

                # Thinking
                if block_type == "thinking":
                    if not show_thinking or tools_only:
                        continue
                    step += 1
                    header = f"[{step}] --- thinking ---"
                    thinking = block.get("thinking", "")
                    thinking = truncate_text(thinking, 10, full)
                    output.append(colorize(header, "thinking", use_color))
                    output.append(colorize(indent(thinking, "  "), "thinking", use_color))
                    output.append("")

                # Text output
                elif block_type == "text":
                    if tools_only:
                        continue
                    text = block.get("text", "")
                    if not text.strip():
                        continue
                    step += 1
                    header = f"[{step}] === ASSISTANT {'=' * 46}"
                    text = truncate_text(text, 30, full)
                    output.append(colorize(header, "assistant", use_color))
                    output.append(colorize(text, "assistant", use_color))
                    output.append("")

                # Tool use
                elif block_type == "tool_use":
                    step += 1
                    tool_id = block.get("id", "")
                    name = block.get("name", "unknown")
                    inp = block.get("input", {})

                    # Track for matching with result
                    pending_tools[tool_id] = name

                    header = f"[{step}] >>> TOOL: {name} >>> (id: {tool_id})"
                    input_text = format_tool_input(inp, full)

                    output.append(colorize(header, "tool_use", use_color))
                    output.append(colorize(f"  Parameters ({len(inp)}):", "tool_use", use_color))
                    if input_text:
                        output.append(colorize(input_text, "tool_use", use_color))
                    output.append("")

    return "\n".join(output)


def main():
    parser = argparse.ArgumentParser(
        description="Read Claude Code JSONL transcript as a readable conversation"
    )
    parser.add_argument("file", help="Path to the .jsonl transcript file")
    parser.add_argument("--tools-only", action="store_true", help="Show only tool calls and results")
    parser.add_argument("--no-thinking", action="store_true", help="Hide thinking blocks")
    parser.add_argument("--no-color", action="store_true", help="Disable colored output")
    parser.add_argument("--full", action="store_true", help="Show full text without any truncation")
    parser.add_argument("--output", "-o", help="Write to file instead of stdout")
    parser.add_argument("--max-result-lines", type=int, default=30, help="Max lines per tool result (default: 30)")

    args = parser.parse_args()

    path = Path(args.file)
    if not path.exists():
        print(f"Error: File not found: {path}", file=sys.stderr)
        sys.exit(1)

    entries = read_jsonl(path)
    if not entries:
        print("No entries found in file.", file=sys.stderr)
        sys.exit(1)

    use_color = not args.no_color and not args.output
    max_lines = 999999 if args.full else args.max_result_lines
    transcript = render_transcript(
        entries,
        tools_only=args.tools_only,
        show_thinking=not args.no_thinking,
        use_color=use_color,
        max_result_lines=max_lines,
        full=args.full,
    )

    if args.output:
        out_path = Path(args.output)
        out_path.write_text(transcript, encoding="utf-8")
        print(f"Written to {out_path} ({len(entries)} entries)")
    else:
        print(transcript)
        print(f"\n{'=' * 60}")
        print(f"Total entries: {len(entries)}")
        print(f"File: {path}")


if __name__ == "__main__":
    main()
