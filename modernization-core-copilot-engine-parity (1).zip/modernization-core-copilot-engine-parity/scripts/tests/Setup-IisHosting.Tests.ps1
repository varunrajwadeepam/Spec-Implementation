#Requires -Module @{ ModuleName='Pester'; ModuleVersion='5.0.0' }

# ---------------------------------------------------------------------------
# T007 — BeforeAll block: dot-source script and stub all WebAdministration cmdlets
# ---------------------------------------------------------------------------

BeforeAll {
    # Stub WebAdministration module before dot-sourcing the script
    function global:Import-Module { param([string]$Name, [string]$ErrorAction) <# stub #> }

    # --- IIS/WebAdministration stubs ---
    function global:Get-WindowsFeature {
        param([string]$Name, [string]$ErrorAction)
        return [PSCustomObject]@{ Name = $Name; InstallState = 'Installed' }
    }
    function global:Get-LocalUser {
        param([string]$Name, [string]$ErrorAction)
        return [PSCustomObject]@{ Name = $Name; Enabled = $true }
    }
    function global:Get-ChildItem {
        param([string]$Path, [string]$Filter)
        if ($Path -like 'Cert:\LocalMachine\My') {
            return [PSCustomObject]@{ Thumbprint = 'AABBCCDDEEFF' }
        }
        Microsoft.PowerShell.Management\Get-ChildItem @PSBoundParameters
    }
    # Port-conflict stub: default = no existing bindings
    function global:Get-WebBinding {
        param([string]$Name, [string]$Protocol, [string]$ErrorAction)
        return $null
    }
    function global:New-WebAppPool  { param([string]$Name) return [PSCustomObject]@{ Name = $Name } }
    function global:Set-ItemProperty { param($Path, $Name, $Value, $Type) <# stub #> }
    function global:Get-WebAppPoolState { param([string]$Name) return [PSCustomObject]@{ Value = 'Started' } }
    function global:New-Website {
        param([string]$Name, [string]$PhysicalPath, [string]$ApplicationPool, [switch]$Ssl, [int]$Port, [string]$IPAddress)
        return [PSCustomObject]@{ Name = $Name }
    }
    function global:Get-Website {
        param([string]$Name, [string]$ErrorAction)
        return $null  # default: site does not exist
    }
    function global:New-WebBinding {
        param([string]$Name, [string]$Protocol, [int]$Port, [string]$IPAddress)
        return [PSCustomObject]@{ bindingInformation = "*:${Port}:"; protocol = $Protocol }
    }
    function global:Set-WebConfigurationProperty {
        param($PSPath, $Location, $Filter, $Name, $Value)
        <# stub #>
    }
    function global:New-Item {
        param([string]$ItemType, [string]$Path, [switch]$Force, [string]$Value, [string]$ErrorAction)
        return [PSCustomObject]@{ FullName = $Path }
    }
    function global:Test-Path {
        param([string]$LiteralPath, [string]$Path)
        return $false  # default: nothing exists (fresh install)
    }
    function global:Get-Acl { param([string]$Path) return New-Object System.Security.AccessControl.DirectorySecurity }
    function global:Set-Acl { param([string]$Path, $AclObject) <# stub #> }
    function global:Get-ItemProperty { param($Path, $Name) return [PSCustomObject]@{} }

    # Suppress Write-Host/Write-Warning noise in tests
    function global:Write-Host { param($Object, $ForegroundColor, $NoNewLine) <# stub #> }

    # db2 CLI stub - prevents errors during dot-source; returns empty by default
    function global:db2 { param([string]$Statement) $global:LASTEXITCODE = 0; return @() }

    # Dot-source the script to load all functions.
    # Pass dummy mandatory params so PowerShell does not prompt interactively.
    # The main body is guarded by ($MyInvocation.InvocationName -ne '.') and will not execute.
    $scriptPath = Join-Path (Split-Path $PSScriptRoot -Parent) 'Setup-IisHosting.ps1'
    . $scriptPath `
        -ServiceAccountName       'TEST_ACCOUNT' `
        -ServiceAccountPassword   (ConvertTo-SecureString 'TestP@ssw0rd' -AsPlainText -Force) `
        -SslCertificateThumbprint 'AABBCCDDEEFF'
}

# ---------------------------------------------------------------------------
# T008 — Describe 'New-AppPool'
# ---------------------------------------------------------------------------

Describe 'New-AppPool' {
    BeforeEach {
        # Reset Test-Path to return $false (pool absent)
        Mock Test-Path { return $false } -ParameterFilter { $LiteralPath -like 'IIS:\AppPools\*' }
        Mock New-WebAppPool { return [PSCustomObject]@{ Name = $Name } }
        Mock Set-ItemProperty { }
    }

    It 'creates the application pool when it does not exist' {
        New-AppPool -AppPoolName 'Uwr.UnderwritingService.AppPool' `
                    -ServiceAccountName 'UWR_SVC' `
                    -ServiceAccountPassword (ConvertTo-SecureString 'P@ssw0rd' -AsPlainText -Force)

        Should -Invoke New-WebAppPool -Exactly 1 -ParameterFilter { $Name -eq 'Uwr.UnderwritingService.AppPool' }
    }

    It 'does NOT create the application pool when it already exists' {
        Mock Test-Path { return $true } -ParameterFilter { $LiteralPath -like 'IIS:\AppPools\*' }

        New-AppPool -AppPoolName 'Uwr.UnderwritingService.AppPool' `
                    -ServiceAccountName 'UWR_SVC' `
                    -ServiceAccountPassword (ConvertTo-SecureString 'P@ssw0rd' -AsPlainText -Force)

        Should -Invoke New-WebAppPool -Exactly 0
    }

    It 'always sets managedRuntimeVersion to v4.0' {
        New-AppPool -AppPoolName 'Uwr.UnderwritingService.AppPool' `
                    -ServiceAccountName 'UWR_SVC' `
                    -ServiceAccountPassword (ConvertTo-SecureString 'P@ssw0rd' -AsPlainText -Force)

        Should -Invoke Set-ItemProperty -ParameterFilter { $Name -eq 'managedRuntimeVersion' -and $Value -eq 'v4.0' }
    }

    It 'always sets managedPipelineMode to Integrated' {
        New-AppPool -AppPoolName 'Uwr.UnderwritingService.AppPool' `
                    -ServiceAccountName 'UWR_SVC' `
                    -ServiceAccountPassword (ConvertTo-SecureString 'P@ssw0rd' -AsPlainText -Force)

        Should -Invoke Set-ItemProperty -ParameterFilter { $Name -eq 'managedPipelineMode' -and $Value -eq 'Integrated' }
    }

    It 'always sets processModel.identityType to 3 (SpecificUser)' {
        New-AppPool -AppPoolName 'Uwr.UnderwritingService.AppPool' `
                    -ServiceAccountName 'UWR_SVC' `
                    -ServiceAccountPassword (ConvertTo-SecureString 'P@ssw0rd' -AsPlainText -Force)

        Should -Invoke Set-ItemProperty -ParameterFilter { $Name -eq 'processModel.identityType' -and $Value -eq 3 }
    }

    It 'always sets processModel.userName to service account name' {
        New-AppPool -AppPoolName 'Uwr.UnderwritingService.AppPool' `
                    -ServiceAccountName 'UWR_SVC' `
                    -ServiceAccountPassword (ConvertTo-SecureString 'P@ssw0rd' -AsPlainText -Force)

        Should -Invoke Set-ItemProperty -ParameterFilter { $Name -eq 'processModel.userName' -and $Value -eq 'UWR_SVC' }
    }
}

# ---------------------------------------------------------------------------
# T009 — Describe 'New-IisSite'
# ---------------------------------------------------------------------------

Describe 'New-IisSite' {
    BeforeEach {
        Mock Get-Website { return $null }
        Mock New-Website { return [PSCustomObject]@{ Name = $Name } }
        Mock New-WebBinding { return [PSCustomObject]@{ bindingInformation = '*:8443:'; protocol = 'https' } }
        Mock Set-ItemProperty { }

        # Stub AddSslCertificate on returned binding
        $fakeSslBinding = [PSCustomObject]@{ bindingInformation = '*:8443:' }
        $fakeSslBinding | Add-Member -MemberType ScriptMethod -Name AddSslCertificate `
            -Value { param($thumb, $store) <# stub #> }

        Mock Get-WebBinding { return $fakeSslBinding } -ParameterFilter { $Protocol -eq 'https' }
    }

    It 'creates the website when it does not exist' {
        New-IisSite -SiteName 'Uwr.UnderwritingService' `
                    -PhysicalPath 'C:\inetpub\wwwroot\Uwr.Services' `
                    -AppPoolName 'Uwr.UnderwritingService.AppPool' `
                    -HttpsPort 8443 `
                    -SslCertificateThumbprint 'AABBCCDDEEFF'

        Should -Invoke New-Website -Exactly 1 -ParameterFilter { $Name -eq 'Uwr.UnderwritingService' }
    }

    It 'skips New-Website when site already exists' {
        Mock Get-Website { return [PSCustomObject]@{ Name = 'Uwr.UnderwritingService' } }

        New-IisSite -SiteName 'Uwr.UnderwritingService' `
                    -PhysicalPath 'C:\inetpub\wwwroot\Uwr.Services' `
                    -AppPoolName 'Uwr.UnderwritingService.AppPool' `
                    -HttpsPort 8443 `
                    -SslCertificateThumbprint 'AABBCCDDEEFF'

        Should -Invoke New-Website -Exactly 0
    }

    It 'adds HTTPS binding when absent' {
        Mock Get-WebBinding { return $null } -ParameterFilter { $Protocol -eq 'https' -and $Name -eq 'Uwr.UnderwritingService' }
        Mock Get-WebBinding {
            $b = [PSCustomObject]@{ bindingInformation = '*:8443:' }
            $b | Add-Member -MemberType ScriptMethod -Name AddSslCertificate -Value { param($t,$s) }
            return $b
        } -ParameterFilter { $Protocol -eq 'https' -and -not $Name }

        New-IisSite -SiteName 'Uwr.UnderwritingService' `
                    -PhysicalPath 'C:\inetpub\wwwroot\Uwr.Services' `
                    -AppPoolName 'Uwr.UnderwritingService.AppPool' `
                    -HttpsPort 8443 `
                    -SslCertificateThumbprint 'AABBCCDDEEFF'

        Should -Invoke New-WebBinding -Exactly 1 -ParameterFilter { $Protocol -eq 'https' -and $Port -eq 8443 }
    }

    It 'skips binding when HTTPS binding already exists' {
        Mock Get-WebBinding { return [PSCustomObject]@{ bindingInformation = '*:8443:' } } `
            -ParameterFilter { $Name -eq 'Uwr.UnderwritingService' -and $Protocol -eq 'https' }

        New-IisSite -SiteName 'Uwr.UnderwritingService' `
                    -PhysicalPath 'C:\inetpub\wwwroot\Uwr.Services' `
                    -AppPoolName 'Uwr.UnderwritingService.AppPool' `
                    -HttpsPort 8443 `
                    -SslCertificateThumbprint 'AABBCCDDEEFF'

        Should -Invoke New-WebBinding -Exactly 0
    }
}

# ---------------------------------------------------------------------------
# T010 — Describe 'New-HttpRedirectSite'
# ---------------------------------------------------------------------------

Describe 'New-HttpRedirectSite' {
    BeforeEach {
        Mock Test-Path { return $false }
        Mock New-Item { return [PSCustomObject]@{ FullName = $Path } }
        Mock Set-Content { }
        Mock Get-Website { return $null }
        Mock New-Website { return [PSCustomObject]@{ Name = $Name } }
        Mock Set-WebConfigurationProperty { }
    }

    It 'creates the redirect physical directory when absent' {
        New-HttpRedirectSite -RedirectSiteName 'Uwr.UnderwritingService.Redirect' `
                             -RedirectPath 'C:\inetpub\wwwroot\Uwr.Redirect' `
                             -HttpPort 8080 `
                             -HttpsPort 8443 `
                             -HostName 'MYSERVER'

        Should -Invoke New-Item -ParameterFilter { $Path -eq 'C:\inetpub\wwwroot\Uwr.Redirect' }
    }

    It 'creates the redirect site on the correct HTTP port' {
        New-HttpRedirectSite -RedirectSiteName 'Uwr.UnderwritingService.Redirect' `
                             -RedirectPath 'C:\inetpub\wwwroot\Uwr.Redirect' `
                             -HttpPort 8080 `
                             -HttpsPort 8443 `
                             -HostName 'MYSERVER'

        Should -Invoke New-Website -ParameterFilter { $Name -eq 'Uwr.UnderwritingService.Redirect' -and $Port -eq 8080 }
    }

    It 'sets httpRedirect enabled to true' {
        New-HttpRedirectSite -RedirectSiteName 'Uwr.UnderwritingService.Redirect' `
                             -RedirectPath 'C:\inetpub\wwwroot\Uwr.Redirect' `
                             -HttpPort 8080 `
                             -HttpsPort 8443 `
                             -HostName 'MYSERVER'

        Should -Invoke Set-WebConfigurationProperty -ParameterFilter { $Name -eq 'enabled' -and $Value -eq $true }
    }

    It 'sets redirect destination URL using HostName parameter' {
        New-HttpRedirectSite -RedirectSiteName 'Uwr.UnderwritingService.Redirect' `
                             -RedirectPath 'C:\inetpub\wwwroot\Uwr.Redirect' `
                             -HttpPort 8080 `
                             -HttpsPort 8443 `
                             -HostName 'MYSERVER'

        Should -Invoke Set-WebConfigurationProperty -ParameterFilter { $Name -eq 'destination' -and $Value -eq 'https://MYSERVER:8443' }
    }

    It 'sets httpResponseStatus to Permanent (301)' {
        New-HttpRedirectSite -RedirectSiteName 'Uwr.UnderwritingService.Redirect' `
                             -RedirectPath 'C:\inetpub\wwwroot\Uwr.Redirect' `
                             -HttpPort 8080 `
                             -HttpsPort 8443 `
                             -HostName 'MYSERVER'

        Should -Invoke Set-WebConfigurationProperty -ParameterFilter { $Name -eq 'httpResponseStatus' -and $Value -eq 'Permanent' }
    }

    It 'is idempotent when redirect site already exists' {
        Mock Test-Path { return $true }
        Mock Get-Website { return [PSCustomObject]@{ Name = 'Uwr.UnderwritingService.Redirect' } }

        { New-HttpRedirectSite -RedirectSiteName 'Uwr.UnderwritingService.Redirect' `
                               -RedirectPath 'C:\inetpub\wwwroot\Uwr.Redirect' `
                               -HttpPort 8080 `
                               -HttpsPort 8443 `
                               -HostName 'MYSERVER' } | Should -Not -Throw

        Should -Invoke New-Website -Exactly 0
        Should -Invoke New-Item   -Exactly 0
    }
}

# ---------------------------------------------------------------------------
# T011 — Describe 'Set-TlsMinimumVersion'
# ---------------------------------------------------------------------------

Describe 'Set-TlsMinimumVersion' {
    BeforeEach {
        Mock Test-Path { return $false }
        Mock New-Item  { return [PSCustomObject]@{ FullName = $Path } }
        Mock Set-ItemProperty { }
        $script:RequiresRestart = $false
    }

    It 'creates all six Schannel registry paths when absent' {
        Set-TlsMinimumVersion

        Should -Invoke New-Item -Exactly 3  # One per TLS version (TLS 1.0, 1.1, 1.2 Server path)
    }

    It 'sets Enabled=0 and DisabledByDefault=1 for TLS 1.0' {
        Set-TlsMinimumVersion

        Should -Invoke Set-ItemProperty -ParameterFilter {
            $Path -like '*TLS 1.0*' -and $Name -eq 'Enabled' -and $Value -eq 0
        }
        Should -Invoke Set-ItemProperty -ParameterFilter {
            $Path -like '*TLS 1.0*' -and $Name -eq 'DisabledByDefault' -and $Value -eq 1
        }
    }

    It 'sets Enabled=0 and DisabledByDefault=1 for TLS 1.1' {
        Set-TlsMinimumVersion

        Should -Invoke Set-ItemProperty -ParameterFilter {
            $Path -like '*TLS 1.1*' -and $Name -eq 'Enabled' -and $Value -eq 0
        }
    }

    It 'sets Enabled=1 and DisabledByDefault=0 for TLS 1.2' {
        Set-TlsMinimumVersion

        Should -Invoke Set-ItemProperty -ParameterFilter {
            $Path -like '*TLS 1.2*' -and $Name -eq 'Enabled' -and $Value -eq 1
        }
        Should -Invoke Set-ItemProperty -ParameterFilter {
            $Path -like '*TLS 1.2*' -and $Name -eq 'DisabledByDefault' -and $Value -eq 0
        }
    }

    It 'sets RequiresRestart to $true after writing registry keys' {
        Set-TlsMinimumVersion

        $script:RequiresRestart | Should -Be $true
    }
}

# ---------------------------------------------------------------------------
# T012 — Describe 'Set-LogsDirectoryPermission'
# ---------------------------------------------------------------------------

Describe 'Set-LogsDirectoryPermission' {
    BeforeEach {
        Mock Test-Path { return $false }
        Mock New-Item  { return [PSCustomObject]@{ FullName = $Path } }
        Mock Get-Acl   { return New-Object System.Security.AccessControl.DirectorySecurity }
        Mock Set-Acl   { }
    }

    It 'creates the logs directory when absent' {
        Set-LogsDirectoryPermission -LogsPath 'C:\inetpub\wwwroot\Uwr.Services\logs' `
                                    -ServiceAccountName 'UWR_SVC'

        Should -Invoke New-Item -ParameterFilter { $Path -eq 'C:\inetpub\wwwroot\Uwr.Services\logs' }
    }

    It 'calls Get-Acl and Set-Acl to apply the NTFS permission' {
        Set-LogsDirectoryPermission -LogsPath 'C:\inetpub\wwwroot\Uwr.Services\logs' `
                                    -ServiceAccountName 'UWR_SVC'

        Should -Invoke Get-Acl -Exactly 1
        Should -Invoke Set-Acl -Exactly 1
    }

    It 'is idempotent when directory already exists' {
        Mock Test-Path { return $true }

        { Set-LogsDirectoryPermission -LogsPath 'C:\inetpub\wwwroot\Uwr.Services\logs' `
                                       -ServiceAccountName 'UWR_SVC' } | Should -Not -Throw

        Should -Invoke New-Item -Exactly 0
        Should -Invoke Set-Acl  -Exactly 1  # ACL still applied
    }
}

# ---------------------------------------------------------------------------
# T006 — Assert-Prerequisites — Port Conflict Context
# ---------------------------------------------------------------------------

Describe 'Assert-Prerequisites' {
    Context 'when a port conflict exists on HttpPort' {
        BeforeEach {
            # Simulate port 8080 already bound to another site
            Mock Get-WebBinding {
                return [PSCustomObject]@{
                    bindingInformation = '*:8080:'
                    ItemXPath          = "//sites/site[@name='ExistingSite']"
                }
            } -ParameterFilter { $true }

            Mock Get-WindowsFeature { [PSCustomObject]@{ Name = 'Web-Server'; InstallState = 'Installed' } }
            Mock Test-Path { return $true }
            Mock Get-LocalUser { [PSCustomObject]@{ Name = 'UWR_SVC'; Enabled = $true } }
        }

        It 'throws a terminating error mentioning the conflicting site' {
            {
                Assert-Prerequisites `
                    -ServiceAccountName 'UWR_SVC' `
                    -PhysicalPath 'C:\inetpub\wwwroot\Uwr.Services' `
                    -SslCertificateThumbprint 'AABBCCDDEEFF' `
                    -HttpPort 8080 `
                    -HttpsPort 8443
            } | Should -Throw '*Port 8080*'
        }
    }

    Context 'when all prerequisites are satisfied' {
        BeforeEach {
            Mock Get-WindowsFeature { [PSCustomObject]@{ Name = 'Web-Server'; InstallState = 'Installed' } }
            Mock Test-Path { return $true }
            Mock Get-LocalUser { [PSCustomObject]@{ Name = 'UWR_SVC'; Enabled = $true } }
            Mock Get-WebBinding { return $null }
        }

        It 'does not throw' {
            {
                Assert-Prerequisites `
                    -ServiceAccountName 'UWR_SVC' `
                    -PhysicalPath 'C:\inetpub\wwwroot\Uwr.Services' `
                    -SslCertificateThumbprint 'AABBCCDDEEFF' `
                    -HttpPort 8080 `
                    -HttpsPort 8443
            } | Should -Not -Throw
        }
    }
}

# ---------------------------------------------------------------------------
# T019 — Describe 'Disable-PeriodicRecycling'
# ---------------------------------------------------------------------------

Describe 'Disable-PeriodicRecycling' {
    BeforeEach {
        Mock Set-ItemProperty { }
    }

    It 'sets recycling.periodicRestart.time to TimeSpan.Zero' {
        Disable-PeriodicRecycling -AppPoolName 'Uwr.UnderwritingService.AppPool'

        Should -Invoke Set-ItemProperty -ParameterFilter {
            $Name -eq 'recycling.periodicRestart.time' -and $Value -eq [TimeSpan]::Zero
        }
    }

    It 'sets recycling.periodicRestart.requests to 0' {
        Disable-PeriodicRecycling -AppPoolName 'Uwr.UnderwritingService.AppPool'

        Should -Invoke Set-ItemProperty -ParameterFilter {
            $Name -eq 'recycling.periodicRestart.requests' -and $Value -eq 0
        }
    }

    It 'sets recycling.periodicRestart.memory to 0' {
        Disable-PeriodicRecycling -AppPoolName 'Uwr.UnderwritingService.AppPool'

        Should -Invoke Set-ItemProperty -ParameterFilter {
            $Name -eq 'recycling.periodicRestart.memory' -and $Value -eq 0
        }
    }

    It 'is idempotent (no error on re-run)' {
        { Disable-PeriodicRecycling -AppPoolName 'Uwr.UnderwritingService.AppPool' } | Should -Not -Throw
        { Disable-PeriodicRecycling -AppPoolName 'Uwr.UnderwritingService.AppPool' } | Should -Not -Throw
    }
}

# ---------------------------------------------------------------------------
# T020 — Describe 'Enable-AlwaysRunning'
# ---------------------------------------------------------------------------

Describe 'Enable-AlwaysRunning' {
    BeforeEach {
        Mock Set-ItemProperty { }
    }

    It 'sets startMode to AlwaysRunning' {
        Enable-AlwaysRunning -AppPoolName 'Uwr.UnderwritingService.AppPool'

        Should -Invoke Set-ItemProperty -ParameterFilter {
            $Name -eq 'startMode' -and $Value -eq 'AlwaysRunning'
        }
    }

    It 'sets autoStart to $true' {
        Enable-AlwaysRunning -AppPoolName 'Uwr.UnderwritingService.AppPool'

        Should -Invoke Set-ItemProperty -ParameterFilter {
            $Name -eq 'autoStart' -and $Value -eq $true
        }
    }

    It 'is idempotent (no error on re-run)' {
        { Enable-AlwaysRunning -AppPoolName 'Uwr.UnderwritingService.AppPool' } | Should -Not -Throw
        { Enable-AlwaysRunning -AppPoolName 'Uwr.UnderwritingService.AppPool' } | Should -Not -Throw
    }
}

# ---------------------------------------------------------------------------
# T024 — Describe 'Grant-Db2ServiceAccountPrivileges'
# ---------------------------------------------------------------------------

Describe 'Grant-Db2ServiceAccountPrivileges' {
    BeforeEach {
        # Capture SQL statements passed to db2 CLI
        $script:IssuedCommands = [System.Collections.Generic.List[string]]::new()
        Mock db2 {
            param([string]$Statement)
            $script:IssuedCommands.Add($Statement)
            $global:LASTEXITCODE = 0
            return @()
        }
    }

    It 'issues GRANT CONNECT ON DATABASE for the service account' {
        Grant-Db2ServiceAccountPrivileges -DatabaseName 'UWRDB' -ServiceAccountName 'UWR_SVC'

        $script:IssuedCommands | Should -Contain 'GRANT CONNECT ON DATABASE TO USER UWR_SVC'
    }

    It 'issues GRANT SELECT, INSERT, UPDATE, DELETE for each underwriting table' {
        Grant-Db2ServiceAccountPrivileges -DatabaseName 'UWRDB' -ServiceAccountName 'UWR_SVC'

        $expectedTables = @('UWR.POLICY', 'UWR.APPLICANT', 'UWR.CREDIT_PROFILE', 'UWR.COVERAGE_LIMITS', 'UWR.CLAIM_HISTORY')
        foreach ($table in $expectedTables) {
            $script:IssuedCommands | Should -Contain "GRANT SELECT, INSERT, UPDATE, DELETE ON TABLE $table TO USER UWR_SVC"
        }
    }

    It 'does NOT issue GRANT DBADM or GRANT SECADM' {
        Grant-Db2ServiceAccountPrivileges -DatabaseName 'UWRDB' -ServiceAccountName 'UWR_SVC'

        ($script:IssuedCommands | Where-Object { $_ -match 'DBADM|SECADM' }).Count | Should -Be 0
    }

    It 'throws when db2 CLI returns non-zero exit code' {
        Mock db2 {
            param([string]$Statement)
            $global:LASTEXITCODE = 8
            return @()
        }

        { Grant-Db2ServiceAccountPrivileges -DatabaseName 'UWRDB' -ServiceAccountName 'UWR_SVC' } | Should -Throw
    }
}

# ---------------------------------------------------------------------------
# T028 — Describe 'End-to-End Idempotency'
# ---------------------------------------------------------------------------

Describe 'End-to-End Idempotency' {
    BeforeAll {
        # Simulate a server where all resources already exist
        Mock Test-Path         { return $true }
        Mock Get-Website       { return [PSCustomObject]@{ Name = $Name } }
        Mock Get-WebBinding    { return [PSCustomObject]@{ bindingInformation = '*:8443:' } }
        Mock Get-WindowsFeature { [PSCustomObject]@{ Name = 'Web-Server'; InstallState = 'Installed' } }
        Mock Get-LocalUser      { [PSCustomObject]@{ Name = 'UWR_SVC'; Enabled = $true } }
        Mock New-WebAppPool    { }
        Mock New-Website       { }
        Mock New-WebBinding    { }
        Mock Set-ItemProperty  { }
        Mock New-Item          { }
        Mock Set-Content       { }
        Mock Set-WebConfigurationProperty { }
        Mock Get-Acl           { return New-Object System.Security.AccessControl.DirectorySecurity }
        Mock Set-Acl           { }
        Mock Get-WebAppPoolState { [PSCustomObject]@{ Value = 'Started' } }
        Mock Invoke-SmokeTest   { [PSCustomObject]@{ HttpsReachable = $true; HttpRedirectWorks = $true; Details = 'All OK' } }
    }

    It 'does not call New-WebAppPool on re-run' {
        # Re-run the main orchestration functions directly (not the script entry point)
        New-AppPool -AppPoolName 'Uwr.UnderwritingService.AppPool' `
                    -ServiceAccountName 'UWR_SVC' `
                    -ServiceAccountPassword (ConvertTo-SecureString 'P@ssw0rd' -AsPlainText -Force)

        Should -Invoke New-WebAppPool -Exactly 0
    }

    It 'does not call New-Website on re-run' {
        New-IisSite -SiteName 'Uwr.UnderwritingService' `
                    -PhysicalPath 'C:\inetpub\wwwroot\Uwr.Services' `
                    -AppPoolName 'Uwr.UnderwritingService.AppPool' `
                    -HttpsPort 8443 `
                    -SslCertificateThumbprint 'AABBCCDDEEFF'

        Should -Invoke New-Website -Exactly 0
    }

    It 'does not call New-WebBinding on re-run' {
        New-IisSite -SiteName 'Uwr.UnderwritingService' `
                    -PhysicalPath 'C:\inetpub\wwwroot\Uwr.Services' `
                    -AppPoolName 'Uwr.UnderwritingService.AppPool' `
                    -HttpsPort 8443 `
                    -SslCertificateThumbprint 'AABBCCDDEEFF'

        Should -Invoke New-WebBinding -Exactly 0
    }

    It 'does not throw any terminating errors on re-run' {
        {
            New-AppPool -AppPoolName 'Uwr.UnderwritingService.AppPool' `
                        -ServiceAccountName 'UWR_SVC' `
                        -ServiceAccountPassword (ConvertTo-SecureString 'P@ssw0rd' -AsPlainText -Force)
            New-IisSite -SiteName 'Uwr.UnderwritingService' `
                        -PhysicalPath 'C:\inetpub\wwwroot\Uwr.Services' `
                        -AppPoolName 'Uwr.UnderwritingService.AppPool' `
                        -HttpsPort 8443 `
                        -SslCertificateThumbprint 'AABBCCDDEEFF'
            New-HttpRedirectSite -RedirectSiteName 'Uwr.UnderwritingService.Redirect' `
                                 -RedirectPath 'C:\inetpub\wwwroot\Uwr.Redirect' `
                                 -HttpPort 8080 -HttpsPort 8443 -HostName 'MYSERVER'
            Disable-PeriodicRecycling -AppPoolName 'Uwr.UnderwritingService.AppPool'
            Enable-AlwaysRunning      -AppPoolName 'Uwr.UnderwritingService.AppPool'
        } | Should -Not -Throw
    }
}
