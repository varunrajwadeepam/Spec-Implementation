#!/bin/bash
# Script to rename EPIC folders to include full portfolio code
# Pattern: EPIC-MU-NPW-XX-YY-Name → EPIC-ACME-CORE-MU-XX-YY-Name

set -e

PORTFOLIO="ACME-CORE"
EPICS_DIR="docs/$PORTFOLIO/epics"

echo "=== Renaming EPIC Folders to Include Portfolio Code ==="
echo "Pattern: EPIC-MU-NPW-XX-YY-Name → EPIC-ACME-CORE-MU-XX-YY-Name"
echo ""

# Find all EPIC folders that need renaming
epic_folders=$(find "$EPICS_DIR" -type d -name "EPIC-MU-NPW-*" | sort)

if [ -z "$epic_folders" ]; then
    echo "✅ All EPIC folders already in new format!"
    exit 0
fi

count=0
total=$(echo "$epic_folders" | wc -l)

echo "Found $total EPIC folders to rename"
echo ""

# Process each folder
while IFS= read -r old_path; do
    # Extract parent directory and folder name
    parent_dir=$(dirname "$old_path")
    old_folder_name=$(basename "$old_path")

    # Pattern: EPIC-MU-NPW-XX-YY-Name → EPIC-ACME-CORE-MU-XX-YY-Name
    if [[ $old_folder_name =~ ^EPIC-MU-NPW-([0-9]{2})-([0-9]{2})-(.+)$ ]]; then
        mu_num="${BASH_REMATCH[1]}"
        epic_num="${BASH_REMATCH[2]}"
        epic_name="${BASH_REMATCH[3]}"

        # Construct new folder name with H421 inserted
        new_folder_name="EPIC-ACME-CORE-MU-${mu_num}-${epic_num}-${epic_name}"
        new_path="$parent_dir/$new_folder_name"

        # Rename the folder
        if [ -d "$old_path" ]; then
            mv "$old_path" "$new_path"
            count=$((count + 1))
            echo "[$count/$total] Renamed: $old_folder_name → $new_folder_name"
        else
            echo "WARNING: Folder not found: $old_path"
        fi
    else
        echo "SKIP: $old_folder_name (doesn't match expected pattern)"
    fi
done <<< "$epic_folders"

echo ""
echo "✅ Renamed $count EPIC folders"

# Show sample of new structure
echo ""
echo "=== Sample of New Structure ==="
find "$EPICS_DIR" -type d -name "EPIC-ACME-CORE-*" | head -5
