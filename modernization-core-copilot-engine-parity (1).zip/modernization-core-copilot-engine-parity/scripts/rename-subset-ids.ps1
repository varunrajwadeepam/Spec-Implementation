[CmdletBinding()]
param(
    [string]$Base = 'portfolios/ACME-CORE-subset/docs'
)

$ErrorActionPreference = 'Stop'

$files = Get-ChildItem -Path $Base -Recurse -File -Include *.md,*.csv
$count = 0
foreach ($f in $files) {
    $content = Get-Content -Raw -LiteralPath $f.FullName
    $orig = $content

    # 1. EPIC-MU-NPW-SUBSET-01-NN  ->  EPIC-ACME-CORE-SUBSET-MU-01-NN
    $content = [regex]::Replace($content, 'EPIC-MU-NPW-SUBSET-01-(\d{2})', 'EPIC-ACME-CORE-SUBSET-MU-01-$1')

    # 2. bare story IDs EPIC-NN-NNN  ->  STORY-ACME-CORE-SUBSET-MU-01-NN-NNN
    #    (NN restricted to 01..06 to avoid colliding with legitimate EPIC-ACME-CORE-... text)
    $content = [regex]::Replace($content, '\bEPIC-(0[1-6])-(\d{3})\b', 'STORY-ACME-CORE-SUBSET-MU-01-$1-$2')

    if ($content -ne $orig) {
        Set-Content -LiteralPath $f.FullName -Value $content -NoNewline
        $count++
        Write-Host ('updated: ' + $f.FullName)
    }
}

Write-Host ('Total files updated: ' + $count)
