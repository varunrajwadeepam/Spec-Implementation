#!/bin/bash
# Script to rename story files from STORY-MU-NPW-XX-YY-ZZZ.md to STORY-MU-ACME-CORE-XX-YY-ZZZ.md

set -e

PORTFOLIO="ACME-CORE"
EPICS_DIR="docs/$PORTFOLIO/epics"

# Find all story files
story_files=$(find "$EPICS_DIR" -name "STORY-MU-NPW-*.md" -type f)

if [ -z "$story_files" ]; then
    echo "No story files found matching pattern STORY-MU-NPW-*.md"
    exit 0
fi

count=0
total=$(echo "$story_files" | wc -l)

echo "Found $total story files to rename"
echo "Pattern: STORY-MU-NPW-XX-YY-ZZZ.md → STORY-MU-ACME-CORE-XX-YY-ZZZ.md"
echo ""

# Process each file
while IFS= read -r old_path; do
    # Extract directory and filename
    dir=$(dirname "$old_path")
    old_filename=$(basename "$old_path")

    # Check if file matches the pattern STORY-MU-NPW-XX-YY-ZZZ.md (not already renamed)
    if [[ $old_filename =~ ^STORY-MU-NPW-([0-9]{2})-([0-9]{2})-([0-9]{3})\.md$ ]]; then
        mu_num="${BASH_REMATCH[1]}"
        epic_num="${BASH_REMATCH[2]}"
        story_num="${BASH_REMATCH[3]}"

        # Construct new filename with H421 inserted
        new_filename="STORY-MU-ACME-CORE-${mu_num}-${epic_num}-${story_num}.md"
        new_path="$dir/$new_filename"

        # Rename the file
        if [ -f "$old_path" ]; then
            mv "$old_path" "$new_path"
            count=$((count + 1))
            echo "[$count/$total] Renamed: $old_filename → $new_filename"
        else
            echo "WARNING: File not found: $old_path"
        fi
    else
        echo "SKIP: $old_filename (already in new format or doesn't match pattern)"
    fi
done <<< "$story_files"

echo ""
echo "✅ Renamed $count story files"
