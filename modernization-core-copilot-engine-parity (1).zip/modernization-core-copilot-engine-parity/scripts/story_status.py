#!/usr/bin/env python3
"""
story_status.py — Unified story implementation tracker (LLD + Speckit).

Merges two sources of truth per portfolio:
  1. LLD stories:     portfolios/{portfolio}/docs/epics/**/STORY-*.md
                      (**Status:**, **Depends On:**, **Story Points:**, ...)
  2. Speckit specs:   portfolios/{portfolio}/specs/{story-id}/
                      (spec.md, plan.md, tasks.md, POC files, review-report.md)

Produces:
  - Terminal summary: per-MU progress, ready-to-start (parallelizable) frontier
  - HTML dashboard with a layered dependency graph (SVG), one graph per MU
  - JSON for programmatic consumption

Usage:
    python scripts/story_status.py                          # terminal, default portfolio
    python scripts/story_status.py --portfolio ACME-CORE
    python scripts/story_status.py --html                   # portfolios/{portfolio}/reports/story-status.html
    python scripts/story_status.py --html --output path.html
    python scripts/story_status.py --json
"""
from __future__ import annotations

import json
import os
import re
import sys
from dataclasses import dataclass, field
from datetime import datetime
from pathlib import Path
from typing import Dict, List, Optional, Tuple

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(Path(__file__).resolve().parent))

import speckit_status as sk  # noqa: E402  (reuse speckit artifact detection)

DEFAULT_PORTFOLIO = os.getenv("PORTFOLIO_NAME", "ACME-CORE")

# ---------------------------------------------------------------------------
# Story-ID normalization
#
# The estate uses several ID spellings for the same story:
#   STORY-ACME-CORE-MU-01-02-001   (file / specs dir name)
#   STORY-MU-01-02-001            (MU-01 docs)
#   STORY-MU-NPW-00-02-005        (MU-00/03/04/05 docs)
# All collapse to the canonical key  MU-01-02-001.
# ---------------------------------------------------------------------------
_KEY_RE = re.compile(r"MU[-_](?:NPW[-_])?(?:H421[-_])?(?:SUBSET[-_])?(\d{1,2})[-_](\d{1,2})[-_](\d{1,3})([A-Z]?)")


def story_key(text: str) -> Optional[str]:
    m = _KEY_RE.search(text)
    if not m:
        return None
    mu, epic, num, suffix = m.groups()
    return f"MU-{int(mu):02d}-{int(epic):02d}-{int(num):03d}{suffix}"


# ---------------------------------------------------------------------------
# Status normalization (LLD **Status:** field)
# ---------------------------------------------------------------------------

def normalize_lld_status(raw: str) -> str:
    """Collapse the free-form **Status:** value into a small vocabulary."""
    u = raw.upper()
    if u.startswith("BLOCKED") or u.startswith("POST-GATE"):
        return "blocked"
    if u.startswith("PRE-GATE"):
        return "pre_gate"
    if "IN PROGRESS" in u:
        return "in_progress"
    if "COMPLETE" in u or "✅" in raw or "DONE" in u:
        return "complete"
    return "not_started"


# Effective status vocabulary (ordered by display priority)
EFFECTIVE_ORDER = ["implemented", "blocked", "in_progress", "pre_gate", "ready", "waiting"]

STATUS_META = {
    # effective-status: (icon, label, hex on dark surface)
    "implemented": ("✅", "Implemented",   "#0ca30c"),
    "in_progress": ("\U0001f504", "In progress", "#3987e5"),
    "ready":       ("▶",  "Ready to start", "#d55181"),
    "pre_gate":    ("⚠",  "Pre-gate only",  "#fab219"),
    "blocked":     ("⛔",  "Blocked",        "#d03b3b"),
    "waiting":     ("⏳",  "Waiting on deps", "#898781"),
}


# ---------------------------------------------------------------------------
# Data model
# ---------------------------------------------------------------------------

@dataclass
class StoryNode:
    key: str                       # canonical MU-xx-yy-zzz
    display_id: str                # best-known full id (file stem or spec dir)
    mu: str                        # "MU-01"
    title: str = ""
    epic: str = ""                 # epic folder / label
    points: Optional[int] = None
    priority: str = ""
    # LLD side
    lld_file: Optional[Path] = None
    lld_status_raw: str = ""
    lld_status: str = "none"       # complete|in_progress|blocked|pre_gate|not_started|none
    deps: List[str] = field(default_factory=list)        # canonical story keys
    epic_deps: List[str] = field(default_factory=list)   # epic keys, e.g. MU-01-02
    epic_dep_source: str = ""      # "declared" | "readme"
    deps_unresolved: List[str] = field(default_factory=list)
    # Speckit side
    spec_dir: Optional[str] = None
    speckit_status: str = "none"   # none|pending|in_progress|completed|failed
    phases_done: int = 0
    phases_total: int = 0
    implement_done: bool = False
    review_done: bool = False
    # Derived
    effective: str = "waiting"
    layer: int = 0
    unmet_deps: List[str] = field(default_factory=list)


# ---------------------------------------------------------------------------
# LLD parsing
# ---------------------------------------------------------------------------

_FIELD_RE = re.compile(r"^\*\*([A-Za-z /()]+):\*\*\s*(.*)$")
_STORY_TOKEN_RE = re.compile(r"STORY-[A-Z0-9]+(?:-[A-Z0-9]+)*-\d{3}[A-Z]?")
# EPIC reference in a Depends On value, e.g. EPIC-ACME-CORE-SUBSET-MU-01-02
_EPIC_TOKEN_RE = re.compile(r"EPIC-(?:[A-Z0-9]+-)*?MU-(\d{1,2})-(\d{1,2})\b")


def epic_key_of(story_key_: str) -> str:
    """MU-01-02-003 → MU-01-02 (the story's EPIC)."""
    return story_key_.rsplit("-", 1)[0]


def discover_portfolios() -> List[str]:
    """Portfolios = packs whose docs/epics or specs/STORY-* workspaces exist."""
    found = set()
    packs = ROOT / "portfolios"
    if packs.exists():
        for pack in packs.iterdir():
            if not pack.is_dir() or pack.name == "_template":
                continue
            if (pack / "docs" / "epics").exists():
                found.add(pack.name)
                continue
            specs = pack / "specs"
            if specs.exists() and any(c.is_dir() and c.name.startswith("STORY-")
                                      for c in specs.iterdir()):
                found.add(pack.name)
    return sorted(found)


def scan_mu_titles(portfolio: str) -> Dict[str, str]:
    """MU description from portfolios/{portfolio}/docs/epics/{MU-dir}/README.md H1."""
    titles: Dict[str, str] = {}
    epics_root = ROOT / "portfolios" / portfolio / "docs" / "epics"
    if not epics_root.exists():
        return titles
    for mu_dir in epics_root.iterdir():
        readme = mu_dir / "README.md"
        m = re.search(r"(\d+)$", mu_dir.name)
        if not (mu_dir.is_dir() and readme.exists() and m):
            continue
        mu = f"MU-{int(m.group(1)):02d}"
        try:
            for line in readme.read_text(encoding="utf-8", errors="replace").splitlines():
                if line.startswith("# "):
                    t = line[2:].strip()
                    t = re.sub(r"^EPICs?\s+for\s+", "", t, flags=re.IGNORECASE)
                    t = re.sub(r"^MU[-A-Za-z0-9]*\s*[—:–]\s*", "", t)
                    t = re.sub(r"\s*[—–-]*\s*EPIC Index\s*$", "", t, flags=re.IGNORECASE)
                    titles[mu] = t.strip()
                    break
        except OSError:
            pass
    return titles


def scan_epic_sequences(portfolio: str) -> Dict[str, List[str]]:
    """Parse each MU README's '## Implementation Sequence' numbered list.

    Returns {mu ("MU-01"): [epic keys ("MU-01-01", ...) in implementation order]}.
    """
    seqs: Dict[str, List[str]] = {}
    epics_root = ROOT / "portfolios" / portfolio / "docs" / "epics"
    if not epics_root.exists():
        return seqs
    for mu_dir in epics_root.iterdir():
        readme = mu_dir / "README.md"
        m = re.search(r"(\d+)$", mu_dir.name)
        if not (mu_dir.is_dir() and readme.exists() and m):
            continue
        mu_num = int(m.group(1))
        try:
            text = readme.read_text(encoding="utf-8", errors="replace")
        except OSError:
            continue
        sec = re.search(r"^##+\s*Implementation Sequence\s*$(.*?)(?=^##+\s|\Z)",
                        text, re.MULTILINE | re.DOTALL)
        if not sec:
            continue
        order: List[str] = []
        for line in sec.group(1).splitlines():
            item = re.match(r"\s*\d+\.\s+.*?EPIC-(\d{1,2})\b", line)
            if item:
                ek = f"MU-{mu_num:02d}-{int(item.group(1)):02d}"
                if ek not in order:
                    order.append(ek)
        if len(order) > 1:
            seqs[f"MU-{mu_num:02d}"] = order
    return seqs


def _expand_deps(value: str) -> List[str]:
    """Extract dependency story IDs, expanding 'X through Y' ranges."""
    deps: List[str] = []
    for chunk in value.split(","):
        tokens = _STORY_TOKEN_RE.findall(chunk)
        if len(tokens) == 2 and re.search(r"\bthrough\b", chunk, re.IGNORECASE):
            k1, k2 = story_key(tokens[0]), story_key(tokens[1])
            if k1 and k2 and epic_key_of(k1) == epic_key_of(k2):  # same MU-xx-yy prefix
                prefix = epic_key_of(k1)
                lo = int(re.sub(r"[A-Z]", "", k1.rsplit("-", 1)[1]))
                hi = int(re.sub(r"[A-Z]", "", k2.rsplit("-", 1)[1]))
                deps.extend(f"{prefix}-{n:03d}" for n in range(lo, hi + 1))
                continue
        deps.extend(tokens)
    return deps


def scan_lld_stories(portfolio: str) -> Dict[str, StoryNode]:
    epics_root = ROOT / "portfolios" / portfolio / "docs" / "epics"
    nodes: Dict[str, StoryNode] = {}
    if not epics_root.exists():
        return nodes

    for f in sorted(epics_root.rglob("STORY-*.md")):
        key = story_key(f.stem)
        if not key:
            continue
        mu = f"MU-{key[3:5]}"
        node = nodes.get(key) or StoryNode(key=key, display_id=f.stem, mu=mu)
        node.lld_file = f
        node.display_id = f.stem
        # epic folder name, e.g. EPIC-ACME-CORE-MU-01-02-DomainModel
        node.epic = f.parent.name if f.parent.name.startswith("EPIC") else ""

        try:
            text = f.read_text(encoding="utf-8", errors="replace")
        except OSError:
            continue

        for line in text.splitlines():
            hm = re.match(r"^#{1,4}\s+(.*)$", line)
            if hm and not node.title:
                h1 = hm.group(1).strip()
                h1 = re.sub(r"^Story\s+(?:STORY-[A-Za-z0-9-]+|\d+)\s*[—:–]\s*", "", h1)
                node.title = re.sub(r"^STORY-[A-Za-z0-9-]+\s*[—:–]\s*", "", h1).strip() or h1
            m = _FIELD_RE.match(line.strip())
            if not m:
                continue
            label, value = m.group(1).strip().lower(), m.group(2).strip()
            if label == "status":
                node.lld_status_raw = value
                node.lld_status = normalize_lld_status(value)
            elif label == "depends on":
                for em in _EPIC_TOKEN_RE.finditer(value):
                    ek = f"MU-{int(em.group(1)):02d}-{int(em.group(2)):02d}"
                    if ek != epic_key_of(key) and ek not in node.epic_deps:
                        node.epic_deps.append(ek)
                        node.epic_dep_source = "declared"
                for tok in _expand_deps(value):
                    dk = tok if tok.startswith("MU-") else story_key(tok)
                    if dk and dk != key:
                        if dk not in node.deps:
                            node.deps.append(dk)
                    elif not dk:
                        node.deps_unresolved.append(tok)
            elif label == "story points":
                try:
                    node.points = int(re.search(r"\d+", value).group(0))
                except (AttributeError, ValueError):
                    pass
            elif label == "priority":
                node.priority = value
            # stop scanning fields once the body starts
            if line.startswith("## Card") or line.startswith("## Conversation"):
                break

        if node.lld_status == "none":
            node.lld_status = "not_started"
        nodes[key] = node
    return nodes


# ---------------------------------------------------------------------------
# Speckit merge
# ---------------------------------------------------------------------------

def merge_speckit(portfolio: str, nodes: Dict[str, StoryNode]) -> List[dict]:
    """Merge speckit artifact state into nodes; return speckit-only leftovers."""
    state = sk.build_state(portfolio)
    orphans: List[dict] = []

    for s in state.stories:
        done = sum(1 for p in s.phases if p.status == "completed")
        impl = any(p.id == "implement" and p.status == "completed" for p in s.phases)
        review = any(p.id == "review" and p.status == "completed" for p in s.phases)
        key = story_key(s.story_id)
        info = {
            "spec_dir": s.story_id,
            "speckit_status": s.status,
            "phases_done": done,
            "phases_total": len(s.phases),
            "implement_done": impl,
            "review_done": review,
        }
        if key and key in nodes:
            n = nodes[key]
            n.spec_dir = s.story_id
            n.speckit_status = s.status
            n.phases_done = done
            n.phases_total = len(s.phases)
            n.implement_done = impl
            n.review_done = review
        elif key:
            # speckit spec exists but no LLD story doc — still track it
            mu = f"MU-{key[3:5]}"
            n = StoryNode(key=key, display_id=s.story_id, mu=mu,
                          title="(no LLD story document)", **info)
            nodes[key] = n
        else:
            orphans.append({"dir": s.story_id, **info})
    return orphans


# ---------------------------------------------------------------------------
# Derived state: effective status, dependency layers, ready frontier
# ---------------------------------------------------------------------------

def epic_members(nodes: Dict[str, StoryNode]) -> Dict[str, List[str]]:
    members: Dict[str, List[str]] = {}
    for k in nodes:
        members.setdefault(epic_key_of(k), []).append(k)
    return members


def apply_readme_sequences(nodes: Dict[str, StoryNode],
                           sequences: Dict[str, List[str]]) -> None:
    """Fallback: when an MU has NO declared dependencies at all, sequence its
    EPICs per the MU README 'Implementation Sequence' (each EPIC after the
    previous listed one)."""
    by_mu: Dict[str, List[StoryNode]] = {}
    for n in nodes.values():
        by_mu.setdefault(n.mu, []).append(n)
    for mu, items in by_mu.items():
        if mu not in sequences:
            continue
        if any(n.deps or n.epic_deps for n in items):
            continue  # MU already has declared sequencing — don't mix sources
        order = sequences[mu]
        for n in items:
            ek = epic_key_of(n.key)
            if ek in order and order.index(ek) > 0:
                n.epic_deps = [order[order.index(ek) - 1]]
                n.epic_dep_source = "readme"


def compute_effective(nodes: Dict[str, StoryNode]) -> None:
    members = epic_members(nodes)

    # first pass: implemented / blocked / in_progress / pre_gate
    for n in nodes.values():
        if n.lld_status == "complete" or n.implement_done:
            n.effective = "implemented"
        elif n.lld_status == "blocked":
            n.effective = "blocked"
        elif n.lld_status == "in_progress" or n.phases_done > 0:
            n.effective = "in_progress"
        elif n.lld_status == "pre_gate":
            n.effective = "pre_gate"
        else:
            n.effective = "waiting"  # provisional

    # second pass: ready vs waiting (deps resolved against known nodes only)
    for n in nodes.values():
        n.unmet_deps = [d for d in n.deps
                        if d in nodes and nodes[d].effective != "implemented"]
        n.unmet_deps += [f"EPIC {e}" for e in n.epic_deps
                         if any(nodes[m].effective != "implemented"
                                for m in members.get(e, []))]
        if n.effective == "waiting":
            n.effective = "waiting" if n.unmet_deps else "ready"


def compute_layers(nodes: Dict[str, StoryNode]) -> None:
    """Longest-path layer per node (graph column). Cycles are broken defensively."""
    members = epic_members(nodes)
    memo: Dict[str, int] = {}

    def depth(k: str, stack: frozenset) -> int:
        if k in memo:
            return memo[k]
        if k in stack:
            return 0  # cycle guard
        n = nodes.get(k)
        if not n:
            return 0
        prereqs = [d for d in n.deps if d in nodes]
        for e in n.epic_deps:
            prereqs.extend(m for m in members.get(e, []) if m != k)
        if not prereqs:
            memo[k] = 0
            return 0
        d = max(depth(p, stack | {k}) + 1 for p in prereqs)
        memo[k] = d
        return d

    for k in nodes:
        nodes[k].layer = depth(k, frozenset())


# ---------------------------------------------------------------------------
# Aggregation helpers
# ---------------------------------------------------------------------------

def group_by_mu(nodes: Dict[str, StoryNode]) -> Dict[str, List[StoryNode]]:
    mus: Dict[str, List[StoryNode]] = {}
    for n in nodes.values():
        mus.setdefault(n.mu, []).append(n)
    for lst in mus.values():
        lst.sort(key=lambda n: n.key)
    return dict(sorted(mus.items()))


def status_counts(items: List[StoryNode]) -> Dict[str, int]:
    c = {s: 0 for s in EFFECTIVE_ORDER}
    for n in items:
        c[n.effective] += 1
    return c


# ---------------------------------------------------------------------------
# Terminal renderer
# ---------------------------------------------------------------------------

def render_terminal(portfolio: str, nodes: Dict[str, StoryNode], orphans: List[dict]) -> None:
    mus = group_by_mu(nodes)
    total = status_counts(list(nodes.values()))
    n_all = len(nodes)

    print(f"\nStory Implementation Status — {portfolio}   "
          f"{datetime.now().strftime('%Y-%m-%d %H:%M')}")
    print("=" * 78)
    print(f"  Stories: {n_all}   "
          + "   ".join(f"{STATUS_META[s][0]} {STATUS_META[s][1]}: {total[s]}"
                       for s in EFFECTIVE_ORDER if total[s]))

    print("\nPer Migration Unit")
    print("-" * 78)
    hdr = f"  {'MU':<8}{'total':>6}{'impl':>6}{'wip':>5}{'ready':>7}{'blocked':>9}{'pre-gate':>10}{'waiting':>9}"
    print(hdr)
    for mu, items in mus.items():
        c = status_counts(items)
        done = c["implemented"]
        bar = "█" * round(20 * done / len(items)) if items else ""
        print(f"  {mu:<8}{len(items):>6}{done:>6}{c['in_progress']:>5}"
              f"{c['ready']:>7}{c['blocked']:>9}{c['pre_gate']:>10}{c['waiting']:>9}"
              f"   {bar}")

    ready = [n for n in nodes.values() if n.effective == "ready"]
    if ready:
        print(f"\n▶ Ready to start now — {len(ready)} stories, "
              "no unmet dependencies (parallelizable):")
        by_mu: Dict[str, List[StoryNode]] = {}
        for n in ready:
            by_mu.setdefault(n.mu, []).append(n)
        for mu, items in sorted(by_mu.items()):
            ids = ", ".join(n.key for n in sorted(items, key=lambda x: x.key))
            print(f"  {mu}: {ids}")

    wip = [n for n in nodes.values() if n.effective == "in_progress"]
    if wip:
        print(f"\n\U0001f504 In progress ({len(wip)}):")
        for n in sorted(wip, key=lambda x: x.key):
            print(f"  {n.key}  speckit {n.phases_done}/{n.phases_total}  {n.title[:60]}")

    blocked = [n for n in nodes.values() if n.effective == "blocked"]
    if blocked:
        print(f"\n⛔ Blocked ({len(blocked)}):")
        for n in sorted(blocked, key=lambda x: x.key)[:15]:
            print(f"  {n.key}  {n.lld_status_raw[:70]}")
        if len(blocked) > 15:
            print(f"  ... and {len(blocked) - 15} more (see HTML report)")

    if orphans:
        print(f"\nSpeckit-only workspaces (no story-ID match): "
              + ", ".join(o["dir"] for o in orphans))
    print()


# ---------------------------------------------------------------------------
# JSON renderer
# ---------------------------------------------------------------------------

def render_json(portfolio: str, nodes: Dict[str, StoryNode], orphans: List[dict]) -> str:
    return json.dumps({
        "portfolio": portfolio,
        "generatedAt": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
        "summary": status_counts(list(nodes.values())),
        "readyFrontier": sorted(n.key for n in nodes.values() if n.effective == "ready"),
        "stories": [
            {
                "key": n.key,
                "displayId": n.display_id,
                "mu": n.mu,
                "epic": n.epic,
                "title": n.title,
                "points": n.points,
                "effective": n.effective,
                "lldStatus": n.lld_status,
                "lldStatusRaw": n.lld_status_raw,
                "lldFile": str(n.lld_file.relative_to(ROOT)) if n.lld_file else None,
                "speckit": {
                    "dir": n.spec_dir,
                    "status": n.speckit_status,
                    "phasesDone": n.phases_done,
                    "phasesTotal": n.phases_total,
                    "implementDone": n.implement_done,
                    "reviewDone": n.review_done,
                },
                "dependsOn": n.deps,
                "dependsOnEpics": n.epic_deps,
                "epicDepSource": n.epic_dep_source or None,
                "unmetDeps": n.unmet_deps,
                "layer": n.layer,
            }
            for n in sorted(nodes.values(), key=lambda x: x.key)
        ],
        "speckitOnly": orphans,
    }, indent=2)


# ---------------------------------------------------------------------------
# HTML renderer (dashboard + layered dependency graph)
# ---------------------------------------------------------------------------

_CSS = """
:root{
  --bg:#0f172a;--surface:#1e293b;--border:#334155;--text:#e2e8f0;
  --dim:#94a3b8;--muted:#64748b;--accent:#38bdf8;
  --implemented:#0ca30c;--in_progress:#3987e5;--ready:#d55181;
  --pre_gate:#fab219;--blocked:#d03b3b;--waiting:#898781;
}
*{box-sizing:border-box;margin:0;padding:0}
body{font-family:system-ui,-apple-system,"Segoe UI",sans-serif;
     background:var(--bg);color:var(--text);padding:1.5rem 2rem;font-size:13px}
h1{color:var(--accent);font-size:1.15rem;margin-bottom:.25rem}
h2{font-size:1rem;margin:0}
.meta{color:var(--muted);margin-bottom:1.25rem;font-size:11px}
.topbar{display:flex;justify-content:space-between;align-items:flex-start;
        gap:16px;margin-bottom:1rem;flex-wrap:wrap}
.psel-label{font-size:11px;color:var(--dim);display:flex;flex-direction:column;gap:4px}
#psel{background:var(--surface);color:var(--text);border:1px solid var(--border);
      border-radius:6px;padding:6px 10px;font-size:13px;min-width:220px}
.mu-desc{font-size:12px;color:var(--text);font-weight:400}
.tiles{display:flex;flex-wrap:wrap;gap:10px;margin-bottom:1.25rem}
.tile{background:var(--surface);border:1px solid var(--border);border-radius:8px;
      padding:10px 16px;min-width:118px}
.tile .num{font-size:1.6rem;font-weight:600;line-height:1.2}
.tile .lbl{font-size:11px;color:var(--dim);white-space:nowrap}
.tile .dot{display:inline-block;width:9px;height:9px;border-radius:50%;margin-right:5px}
.legend{display:flex;flex-wrap:wrap;gap:14px;font-size:11px;color:var(--dim);
        margin-bottom:1.25rem;align-items:center}
.legend .dot{display:inline-block;width:9px;height:9px;border-radius:50%;margin-right:4px}
.mu{border:1px solid var(--border);border-radius:8px;margin-bottom:1.5rem;
    background:rgba(30,41,59,.35)}
.mu>summary{cursor:pointer;padding:.7rem 1rem;display:flex;gap:14px;align-items:center;
            list-style:none}
.mu>summary::-webkit-details-marker{display:none}
.mu>summary::before{content:'\\25B8';color:var(--muted);transition:transform .15s}
.mu[open]>summary::before{transform:rotate(90deg)}
.mu-stats{font-size:11px;color:var(--dim)}
.mu-body{padding:0 1rem 1rem}
.graph-wrap{overflow-x:auto;border:1px solid var(--border);border-radius:6px;
            background:var(--bg);margin-bottom:.9rem;padding:8px}
.graph-note{font-size:11px;color:var(--muted);margin:.35rem 0 .8rem}
svg text{font-family:ui-monospace,Menlo,monospace}
.node rect{fill-opacity:.16;stroke-width:1.4}
.node.ready rect{stroke-width:2.4}
.node:hover rect{fill-opacity:.35}
table{width:100%;border-collapse:collapse;font-size:12px}
th{text-align:left;padding:5px 8px;color:var(--muted);font-weight:500;font-size:11px;
   border-bottom:1px solid var(--border);white-space:nowrap}
td{padding:5px 8px;vertical-align:top;border-bottom:1px solid rgba(51,65,85,.4)}
tr:hover td{background:rgba(56,189,248,.05)}
.badge{display:inline-block;padding:1px 8px;border-radius:10px;font-size:11px;
       white-space:nowrap;border:1px solid}
a{color:var(--accent);text-decoration:none}
a:hover{text-decoration:underline}
.mono{font-family:ui-monospace,Menlo,monospace;font-size:11px}
.phasebar{font-family:ui-monospace,monospace;font-size:10px;letter-spacing:1px;
          color:var(--in_progress)}
.phasebar .off{color:#334155}
.dimtxt{color:var(--muted);font-size:11px}
.raw{color:var(--dim);font-size:11px;max-width:340px;display:inline-block}
"""


def _esc(s: str) -> str:
    return (s or "").replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")


def _badge(effective: str) -> str:
    icon, label, color = STATUS_META[effective]
    return (f'<span class="badge" style="color:{color};border-color:{color}">'
            f'{icon} {label}</span>')


def _phasebar(n: StoryNode) -> str:
    if n.phases_total == 0:
        return '<span class="dimtxt">—</span>'
    on = "▆" * n.phases_done
    off = "▆" * (n.phases_total - n.phases_done)
    return (f'<span class="phasebar">{on}<span class="off">{off}</span></span> '
            f'<span class="dimtxt">{n.phases_done}/{n.phases_total}</span>')


NODE_W, NODE_H, GAP_X, GAP_Y = 96, 26, 70, 12


def _epic_short(epic: str) -> str:
    """EPIC-ACME-CORE-MU-01-02-DomainModel → DomainModel."""
    m = re.search(r"MU-\d+-\d+-(.+)$", epic)
    return m.group(1) if m else ""


def _step_description(col_nodes: List["StoryNode"], max_chars: int) -> Tuple[str, str]:
    """Brief per-step label: the EPIC areas the column's stories belong to.

    Returns (truncated label, full label for the tooltip).
    """
    seen: List[str] = []
    for n in col_nodes:
        s = _epic_short(n.epic)
        if s and s not in seen:
            seen.append(s)
    if not seen:
        return "", ""
    full = " · ".join(seen)
    label = full
    if len(label) > max_chars:
        # drop trailing areas until it fits, then note how many were dropped
        kept = []
        for s in seen:
            candidate = " · ".join(kept + [s])
            if kept and len(candidate) + 3 > max_chars:
                break
            kept.append(s)
        extra = len(seen) - len(kept)
        label = " · ".join(kept) + (f" +{extra}" if extra else "")
        if len(label) > max_chars:
            label = label[:max_chars - 1] + "…"
    return label, full


def _mu_graph_svg(items: List[StoryNode], anchor_prefix: str) -> str:
    """Layered DAG: columns = dependency depth; rows = stories. Left→right = build order.

    MUs with no declared intra-MU dependencies render as a wrapped grid instead of
    one enormous single column.
    """
    # re-layer within the MU so columns reflect intra-MU deps only
    local: Dict[str, StoryNode] = {n.key: n for n in items}
    members = epic_members(local)
    has_edges = any((d in local for n in items for d in n.deps)) \
        or any(n.epic_deps for n in items)
    layers: Dict[str, int] = {}

    def depth(k: str, stack: frozenset) -> int:
        if k in layers:
            return layers[k]
        if k in stack:
            return 0
        n = local[k]
        prereqs = [d for d in n.deps if d in local]
        for e in n.epic_deps:
            prereqs.extend(m for m in members.get(e, []) if m != k)
        d = 0
        for p in prereqs:
            d = max(d, depth(p, stack | {k}) + 1)
        layers[k] = d
        return d

    for k in local:
        depth(k, frozenset())

    cols: Dict[int, List[StoryNode]] = {}
    if has_edges:
        for n in items:
            cols.setdefault(layers[n.key], []).append(n)
        for lst in cols.values():
            lst.sort(key=lambda n: n.key)
        gap_x = GAP_X
    else:
        # no dependency data: wrap into a compact grid (max 8 rows per column)
        ordered = sorted(items, key=lambda n: n.key)
        rows_per_col = 8
        for i, n in enumerate(ordered):
            cols.setdefault(i // rows_per_col, []).append(n)
        gap_x = 14

    max_rows = max(len(v) for v in cols.values())
    n_cols = max(cols) + 1
    top = 40 if has_edges else 12  # room for step name + description line
    width = n_cols * (NODE_W + gap_x) - gap_x + 20
    height = max_rows * (NODE_H + GAP_Y) - GAP_Y + top + 10

    pos: Dict[str, Tuple[float, float]] = {}
    for c, lst in cols.items():
        for r, n in enumerate(lst):
            pos[n.key] = (10 + c * (NODE_W + gap_x), top + r * (NODE_H + GAP_Y))

    parts = [f'<svg xmlns="http://www.w3.org/2000/svg" width="{width}" height="{height}" '
             f'font-size="10">']
    parts.append('<defs><marker id="arr" viewBox="0 0 8 8" refX="7" refY="4" '
                 'markerWidth="6" markerHeight="6" orient="auto">'
                 '<path d="M0,0 L8,4 L0,8 z" fill="#475569"/></marker></defs>')
    # column headers (only meaningful when layered by dependencies)
    if has_edges:
        max_desc_chars = max(10, int((NODE_W + gap_x - 14) / 5.2))
        last_col = max(cols)
        for c in sorted(cols):
            x_left = 10 + c * (NODE_W + gap_x)
            if c == 0 and last_col > 0:
                anchor, tx = "start", x_left
            elif c == last_col and last_col > 0:
                anchor, tx = "end", x_left + NODE_W
            else:
                anchor, tx = "middle", x_left + NODE_W / 2
            parts.append(f'<text x="{tx}" y="12" text-anchor="{anchor}" fill="#94a3b8" '
                         f'font-size="9" font-weight="bold">step {c + 1}</text>')
            desc, full = _step_description(cols[c], max_desc_chars)
            if desc:
                parts.append(f'<text x="{tx}" y="24" text-anchor="{anchor}" fill="#64748b" '
                             f'font-size="8.5"><title>{_esc(full)}</title>'
                             f'{_esc(desc)}</text>')
    # edges beneath nodes
    for n in items:
        x2, y2 = pos[n.key]
        for dep in n.deps:
            if dep in pos:
                x1, y1 = pos[dep]
                sx, sy = x1 + NODE_W, y1 + NODE_H / 2
                tx, ty = x2, y2 + NODE_H / 2
                mx = (sx + tx) / 2
                parts.append(f'<path d="M{sx},{sy} C{mx},{sy} {mx},{ty} {tx - 3},{ty}" '
                             f'fill="none" stroke="#475569" stroke-opacity="0.65" '
                             f'stroke-width="1.1" marker-end="url(#arr)"/>')
    # nodes
    for n in items:
        x, y = pos[n.key]
        icon, label, color = STATUS_META[n.effective]
        short = n.key[3:]  # drop "MU-"
        dep_bits = n.deps + [f"EPIC {e}" for e in n.epic_deps]
        tip = (f"{n.display_id}\n{n.title}\nStatus: {label}"
               + (f"\nLLD: {n.lld_status_raw}" if n.lld_status_raw else "")
               + (f"\nSpeckit: {n.phases_done}/{n.phases_total} phases" if n.phases_total else "")
               + (f"\nDepends on: {', '.join(dep_bits)}" if dep_bits else ""))
        cls = "node ready" if n.effective == "ready" else "node"
        parts.append(
            f'<a href="#s-{anchor_prefix}{n.key}"><g class="{cls}">'
            f'<title>{_esc(tip)}</title>'
            f'<rect x="{x}" y="{y}" width="{NODE_W}" height="{NODE_H}" rx="6" '
            f'fill="{color}" stroke="{color}"/>'
            f'<circle cx="{x + 11}" cy="{y + NODE_H / 2}" r="3.5" fill="{color}"/>'
            f'<text x="{x + 20}" y="{y + NODE_H / 2 + 3.5}" fill="#e2e8f0">{short}</text>'
            f'</g></a>')
    parts.append("</svg>")
    return "".join(parts)


def _portfolio_section(portfolio: str, nodes: Dict[str, StoryNode],
                       orphans: List[dict], mu_titles: Dict[str, str]) -> str:
    slug = re.sub(r"[^A-Za-z0-9]+", "-", portfolio)
    anchor_prefix = f"{slug}-"
    mus = group_by_mu(nodes)
    total = status_counts(list(nodes.values()))
    ready = sorted((n for n in nodes.values() if n.effective == "ready"), key=lambda x: x.key)

    if not nodes:
        return (f'<div class="portfolio" data-p="{_esc(portfolio)}">'
                f'<div class="meta">No stories found for this portfolio.</div></div>')

    tiles = [f'<div class="tile"><div class="num">{len(nodes)}</div>'
             f'<div class="lbl">Total stories</div></div>']
    for s in EFFECTIVE_ORDER:
        icon, label, color = STATUS_META[s]
        tiles.append(
            f'<div class="tile"><div class="num" style="color:{color}">{total[s]}</div>'
            f'<div class="lbl"><span class="dot" style="background:{color}"></span>'
            f'{icon} {label}</div></div>')

    legend = '<div class="legend"><strong style="color:var(--dim)">Legend:</strong>' + "".join(
        f'<span><span class="dot" style="background:{c}"></span>{i} {l}</span>'
        for i, l, c in STATUS_META.values()
    ) + ('<span style="margin-left:auto">Graph: columns are dependency steps; '
         'stories in the same column can be implemented in parallel. '
         'Thick outline = ready now.</span></div>')

    sections = []
    for mu, items in mus.items():
        c = status_counts(items)
        done = c["implemented"]
        mu_desc = mu_titles.get(mu, "")
        rows = []
        for n in items:
            link = (f'<a class="mono" href="file:///{n.lld_file.resolve().as_posix()}">{n.key}</a>'
                    if n.lld_file else f'<span class="mono">{n.key}</span>')
            deps_html = []
            for d in n.deps:
                unmet = d in n.unmet_deps
                col = "var(--blocked)" if unmet else "var(--muted)"
                deps_html.append(f'<span class="mono" style="color:{col}">{d[3:]}</span>')
            for e in n.epic_deps:
                unmet = f"EPIC {e}" in n.unmet_deps
                col = "var(--blocked)" if unmet else "var(--muted)"
                src = " (from README)" if n.epic_dep_source == "readme" else ""
                deps_html.append(f'<span class="mono" style="color:{col}" '
                                 f'title="all stories of EPIC {e}{src}">EPIC&nbsp;{e[3:]}</span>')
            xmu = [d for d in n.deps if d[:5] != n.key[:5]]
            rows.append(
                f'<tr id="s-{anchor_prefix}{n.key}"><td>{link}</td>'
                f'<td>{_esc(n.title[:90])}</td>'
                f'<td>{_badge(n.effective)}</td>'
                f'<td><span class="raw">{_esc(n.lld_status_raw or "—")}</span></td>'
                f'<td>{_phasebar(n)}</td>'
                f'<td>{", ".join(deps_html) or "<span class=dimtxt>—</span>"}'
                + (' <span class="dimtxt">(cross-MU)</span>' if xmu else "") + '</td>'
                f'<td class="dimtxt">{n.points if n.points is not None else "—"}</td></tr>')

        has_story_deps = any(n.deps for n in items)
        has_epic_deps = any(n.epic_deps for n in items)
        from_readme = any(n.epic_dep_source == "readme" for n in items)
        if has_story_deps:
            graph_note = ""
        elif has_epic_deps:
            src = ("the MU README Implementation Sequence" if from_readme
                   else "EPIC-level Depends On declarations")
            graph_note = (f'<div class="graph-note">ℹ Sequencing derived at EPIC level '
                          f'(from {src}) — stories within a step are parallelizable.</div>')
        else:
            graph_note = ('<div class="graph-note">⚠ No dependencies declared for this MU '
                          '— all stories shown as one parallel step. Sequencing constraints '
                          'may exist but are not written in the story documents.</div>')

        desc_html = (f'<span class="mu-desc">{_esc(mu_desc)}</span>' if mu_desc else "")
        sections.append(f'''
<details class="mu" open>
<summary><h2>{mu}</h2>{desc_html}
  <span class="mu-stats">{len(items)} stories · {done} implemented ·
  {c["in_progress"]} in progress · {c["ready"]} ready · {c["blocked"]} blocked</span>
</summary>
<div class="mu-body">
  <div class="graph-wrap">{_mu_graph_svg(items, anchor_prefix)}</div>
  {graph_note}
  <table>
    <thead><tr><th>Story</th><th>Title</th><th>Status</th><th>LLD status (raw)</th>
    <th>Speckit phases</th><th>Depends on</th><th>Pts</th></tr></thead>
    <tbody>{"".join(rows)}</tbody>
  </table>
</div>
</details>''')

    ready_html = ""
    if ready:
        by_mu: Dict[str, List[StoryNode]] = {}
        for n in ready:
            by_mu.setdefault(n.mu, []).append(n)
        lines = "".join(
            f'<div><strong>{mu}:</strong> '
            + " ".join(f'<a class="mono" href="#s-{anchor_prefix}{n.key}">{n.key[3:]}</a>'
                       for n in lst)
            + "</div>"
            for mu, lst in sorted(by_mu.items()))
        ready_html = (f'<div class="mu" style="padding:.8rem 1rem;margin-bottom:1.5rem">'
                      f'<strong style="color:var(--ready)">▶ Ready to start now '
                      f'({len(ready)} stories — all dependencies met, parallelizable):</strong>'
                      f'<div style="margin-top:.4rem;display:flex;flex-direction:column;gap:3px">'
                      f'{lines}</div></div>')

    orphan_html = ""
    if orphans:
        items = ", ".join(f'<span class="mono">{_esc(o["dir"])}</span> '
                          f'({o["phases_done"]}/{o["phases_total"]} phases)' for o in orphans)
        orphan_html = (f'<div class="meta">Speckit-only workspaces without a matching '
                       f'LLD story ID: {items}</div>')

    return f"""<div class="portfolio" data-p="{_esc(portfolio)}">
<div class="meta">Sources: <span class="mono">docs/{_esc(portfolio)}/epics</span> (LLD) +
 <span class="mono">specs/{_esc(portfolio)}</span> (Speckit)</div>
<div class="tiles">{"".join(tiles)}</div>
{legend}
{ready_html}
{"".join(sections)}
{orphan_html}
</div>"""


def render_html(data: List[Tuple[str, Dict[str, StoryNode], List[dict], Dict[str, str]]]) -> str:
    options = "".join(f'<option value="{_esc(p)}">{_esc(p)}</option>'
                      for p, _, _, _ in data)
    sections = "".join(_portfolio_section(p, nodes, orphans, mu_titles)
                       for p, nodes, orphans, mu_titles in data)
    return f"""<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta http-equiv="refresh" content="120">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>Story Implementation Status</title>
<style>{_CSS}</style>
</head>
<body>
<div class="topbar">
  <div>
    <h1>Story Implementation Status</h1>
    <div class="meta" style="margin:0">Generated {datetime.now().strftime("%Y-%m-%d %H:%M:%S")}
     · auto-refreshes every 120s</div>
  </div>
  <label class="psel-label">Portfolio
    <select id="psel">{options}</select>
  </label>
</div>
{sections}
<script>
const sel = document.getElementById('psel');
function show(p) {{
  document.querySelectorAll('.portfolio').forEach(
    d => d.style.display = (d.dataset.p === p ? '' : 'none'));
  try {{ localStorage.setItem('storyStatusPortfolio', p); }} catch (e) {{}}
}}
sel.addEventListener('change', e => show(e.target.value));
let saved = null;
try {{ saved = localStorage.getItem('storyStatusPortfolio'); }} catch (e) {{}}
if (saved && [...sel.options].some(o => o.value === saved)) sel.value = saved;
show(sel.value);
</script>
</body>
</html>"""


# ---------------------------------------------------------------------------
# CLI
# ---------------------------------------------------------------------------

def build(portfolio: str) -> Tuple[Dict[str, StoryNode], List[dict], Dict[str, str]]:
    nodes = scan_lld_stories(portfolio)
    orphans = merge_speckit(portfolio, nodes)
    apply_readme_sequences(nodes, scan_epic_sequences(portfolio))
    compute_effective(nodes)
    compute_layers(nodes)
    return nodes, orphans, scan_mu_titles(portfolio)


def main() -> None:
    import argparse
    parser = argparse.ArgumentParser(description="Unified story status tracker (LLD + Speckit).")
    parser.add_argument("--portfolio", default=None,
                        help="Portfolio name. Terminal/JSON default: "
                             f"{DEFAULT_PORTFOLIO}. HTML default: all portfolios "
                             "(switchable via the dashboard dropdown).")
    parser.add_argument("--html", action="store_true", help="Generate HTML dashboard")
    parser.add_argument("--output", type=Path, default=None, help="HTML output path")
    parser.add_argument("--json", action="store_true", help="Emit JSON to stdout")
    args = parser.parse_args()

    if args.html:
        portfolios = [args.portfolio] if args.portfolio else discover_portfolios()
        if not portfolios:
            print("No portfolios found under docs/ or specs/.")
            sys.exit(1)
        data = []
        for p in portfolios:
            nodes, orphans, mu_titles = build(p)
            if nodes or args.portfolio:
                data.append((p, nodes, orphans, mu_titles))
        out = args.output
        if out is None:
            out_dir = ROOT / "reports"
            out_dir.mkdir(parents=True, exist_ok=True)
            out = out_dir / "story-status.html"
        out.write_text(render_html(data), encoding="utf-8")
        print(f"HTML dashboard written to: {out}")
        print(f"Portfolios included: {', '.join(p for p, *_ in data)}")
        return

    portfolio = args.portfolio or DEFAULT_PORTFOLIO
    nodes, orphans, _ = build(portfolio)
    if not nodes:
        print(f"No stories found for portfolio '{portfolio}' "
              f"(looked in portfolios/{portfolio}/docs/epics and portfolios/{portfolio}/specs).")
        sys.exit(1)
    if args.json:
        print(render_json(portfolio, nodes, orphans))
        return
    render_terminal(portfolio, nodes, orphans)


if __name__ == "__main__":
    main()
