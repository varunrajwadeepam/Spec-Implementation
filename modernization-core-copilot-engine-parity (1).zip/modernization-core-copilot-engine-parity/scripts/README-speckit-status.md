# Speckit Pipeline Status Script

## Overview

`speckit_status.py` is a portfolio-scoped status reporter for the Speckit implementation pipeline. It tracks progress across all user stories in a portfolio by monitoring artifact files and provides terminal, HTML, and JSON output formats.

## Features

- **Portfolio-scoped tracking**: Monitors all stories under `portfolios/{portfolio}/specs/`
- **Phase-by-phase visibility**: Tracks 9 speckit phases per story (specify → clarify → plan → research → data → contracts → tasks → implement → review)
- **Multiple output formats**: Terminal (with Rich/ASCII fallback), HTML dashboard, JSON
- **Cost estimation**: Estimates token usage and costs based on artifact file sizes
- **Auto-discovery**: Automatically finds all story directories without manual configuration
- **Next-action guidance**: Suggests what to do next based on current state

## Usage

### Terminal Output (Default)

```bash
# Use default portfolio (from PORTFOLIO_NAME env var or ACME-CORE)
python scripts/speckit_status.py

# Explicit portfolio
python scripts/speckit_status.py --portfolio ACME-CORE
```

### HTML Dashboard

```bash
# Generate HTML report (auto-refreshes every 30s)
python scripts/speckit_status.py --portfolio ACME-CORE --html

# Custom output path
python scripts/speckit_status.py --portfolio ACME-CORE --html --output reports/custom.html
```

Default location: `portfolios/{portfolio}/reports/speckit-status.html`

### JSON Output

```bash
# JSON format for programmatic consumption
python scripts/speckit_status.py --portfolio ACME-CORE --json
```

### State Tracking (Internal Use)

```bash
# Record phase completion (used by speckit skills)
python scripts/speckit_status.py --portfolio ACME-CORE \
    --write-entry STORY-ACME-CORE-MU-01-02-002 \
    phase=implement status=completed

# Record story-level metadata
python scripts/speckit_status.py --portfolio ACME-CORE \
    --write-entry STORY-ACME-CORE-MU-01-02-002 \
    model=opus notes="High complexity story"
```

## Tracked Phases

| Phase ID    | Label                    | Artifact                |
|-------------|--------------------------|-------------------------|
| `specify`   | Specification            | `spec.md`               |
| `clarify`   | Clarification            | `spec.md` (updated)     |
| `plan`      | Implementation plan      | `plan.md`               |
| `research`  | Research & discovery     | `research.md`           |
| `data`      | Data model               | `data-model.md`         |
| `contracts` | Interface contracts      | `contracts/`            |
| `tasks`     | Task breakdown           | `tasks.md`              |
| `implement` | Implementation           | (POC files)             |
| `review`    | Code review              | `review-report.md`      |

## Phase Status Detection

The script derives phase status from artifact files:

- **`pending`**: Artifact does not exist
- **`completed`**: Artifact exists and is non-empty
- **`failed`**: Review phase with failure verdict
- **`in_progress`**: At least one phase completed, but not all

Story status is rolled up from phase statuses.

## Cost Estimation

Token estimation uses file sizes divided by 4 characters per token (rough approximation). Costs are calculated using Claude Sonnet 4 pricing:

- **Input tokens**: $3.00 per million
- **Output tokens**: $15.00 per million
- **Split**: 80% input / 20% output (conservative)

## State Persistence

Optional metadata is stored in `portfolios/{portfolio}/specs/speckit-state.json`:

```json
{
  "version": "1",
  "lastUpdated": "2026-06-19T15:47:00Z",
  "stories": {
    "STORY-ACME-CORE-MU-01-02-002": {
      "lastUpdated": "2026-06-19T15:47:00Z",
      "phases": {
        "implement": {
          "completedAt": "2026-06-19T15:47:00Z",
          "status": "completed",
          "model": "sonnet",
          "notes": ""
        }
      }
    }
  }
}
```

State file supplements (but does not replace) artifact-based detection.

## Directory Structure

```
specs/
└── {portfolio}/              # e.g., ACME-CORE/
    ├── speckit-state.json    # Optional metadata
    └── {story-id}/           # e.g., STORY-ACME-CORE-MU-01-02-002/
        ├── spec.md
        ├── plan.md
        ├── research.md
        ├── data-model.md
        ├── tasks.md
        ├── review-report.md
        ├── contracts/
        │   └── *.md
        └── checklists/
            └── *.md
```

## Integration with Speckit Workflow

The script is designed to work with the `/speckit.orchestrate` workflow:

1. **Before workflow**: All phases show `pending`
2. **During workflow**: Phases transition to `completed` as artifacts are created
3. **After workflow**: Script shows overall progress and next action

## Examples

### Example Terminal Output

```
Speckit Pipeline Status - ACME-CORE  2026-06-19 15:46:59

[~]  STORY-ACME-CORE-MU-01-02-002  (in_progress)
  ------------------------------------------------------------
  [OK]  Specification             completed                     ~3k        2026-06-19 15:26
  [OK]  Clarification             completed                     ~3k        2026-06-19 15:26
  [OK]  Implementation plan       completed                     ~2k        2026-06-19 15:30
  [OK]  Research & discovery      completed                     ~4k        2026-06-19 15:31
  [OK]  Data model                completed                     ~3k        2026-06-19 15:32
  [OK]  Interface contracts       completed                     ~2k        2026-06-19 15:33
  [OK]  Task breakdown            completed                     ~4k        2026-06-19 15:42
  [ ]  Implementation            not started                   0          
  [ ]  Code review               not started                   0          
  Story total: ~23k  ~$0.13

Portfolio total: ~569k  ~$3.08

Next:  STORY-ACME-CORE-MU-01-02-002: Run /speckit.implement
```

### Example JSON Output

```json
{
  "portfolio": "ACME-CORE",
  "generatedAt": "2026-06-19 15:47:08",
  "nextAction": "STORY-ACME-CORE-MU-01-02-002: Run /speckit.implement",
  "totalTokens": 569563,
  "estCostUsd": 3.0756,
  "stories": [
    {
      "storyId": "STORY-ACME-CORE-MU-01-02-002",
      "status": "in_progress",
      "totalTokens": 23189,
      "estCostUsd": 0.1252,
      "phases": [...]
    }
  ]
}
```

## Troubleshooting

### No stories found

**Cause**: Portfolio directory doesn't exist or is empty.

**Solution**: Run `/speckit.orchestrate {STORY-ID}` to create the first story.

### Phases show `pending` but artifacts exist

**Cause**: Artifact path mismatch or file is empty.

**Solution**: Check that artifact files match expected names (`spec.md`, `plan.md`, etc.) and have non-zero size.

### Token estimates seem low

**Cause**: Estimation uses file size only; doesn't account for loaded context.

**Solution**: Estimates are conservative lower bounds. Actual usage may be 20-50% higher when skills load additional context.

## See Also

- [CLAUDE.md](../CLAUDE.md) — Speckit workflow documentation
- [speckit.orchestrate skill](./.claude/skills/speckit.orchestrate/) — Orchestrator that uses this script
