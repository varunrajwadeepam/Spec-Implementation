<#
.SYNOPSIS
install-portfolio.ps1 — plug a portfolio pack into the engine (Windows junction variant).

.DESCRIPTION
Validates the pack manifest against schemas/portfolio-manifest.schema.json and
verifies every declared skill resolves (pack skills\ -> each subset_of ancestor's
skills\ -> .claude\skills\), then creates a directory junction portfolios\{name} -> pack.
This validation IS the portfolio registration step — there is no registry to edit.

.EXAMPLE
.\scripts\install-portfolio.ps1 ..\my-portfolios\portfolios\ACME-CORE
.\scripts\install-portfolio.ps1 ..\my-portfolios\portfolios\ACME-CORE -Copy
#>
param(
    [Parameter(Mandatory = $true)] [string]$PackPath,
    [switch]$Copy
)
$ErrorActionPreference = 'Stop'

$EngineRoot = Split-Path -Parent $PSScriptRoot
$PackSrc = (Resolve-Path $PackPath).Path
$Manifest = Join-Path $PackSrc 'portfolio.yaml'
if (-not (Test-Path $Manifest)) { throw "ERROR: $Manifest not found — not a portfolio pack" }

# Manifest + skill validation shares the python validator with the .sh variant.
$py = @'
import json, sys, pathlib
try:
    import yaml
except ImportError:
    sys.exit("ERROR: pyyaml is required (pip install pyyaml)")

manifest_path, engine_root, pack_src = map(pathlib.Path, sys.argv[1:4])
manifest = yaml.safe_load(manifest_path.read_text())

schema_path = engine_root / "schemas" / "portfolio-manifest.schema.json"
try:
    import jsonschema
    jsonschema.validate(manifest, json.loads(schema_path.read_text()))
    print(f"OK   manifest valid against {schema_path.name}")
except ImportError:
    missing = [k for k in ("portfolio", "description", "client_skill", "domain_skill", "target_stack", "codegen") if k not in manifest]
    if missing:
        sys.exit(f"ERROR: manifest missing required fields: {missing}")
    print("WARN jsonschema not installed — required-field check only")

name = manifest["portfolio"]
if name != pack_src.name:
    sys.exit(f"ERROR: manifest portfolio '{name}' != pack directory name '{pack_src.name}'")

def skill_search_path(pack_dir, manifest_data):
    """Pack skills/, then each subset_of ancestor's skills/, then engine skills."""
    bases = [pack_dir / "skills"]
    seen = {pack_dir.name}
    parent = manifest_data.get("subset_of")
    while parent:
        if parent in seen:
            sys.exit(f"ERROR: subset_of cycle at '{parent}'")
        seen.add(parent)
        parent_pack = engine_root / "portfolios" / parent
        parent_manifest = parent_pack / "portfolio.yaml"
        if not parent_manifest.is_file():
            sys.exit(f"ERROR: subset_of '{parent}' is not an installed pack "
                     f"({parent_manifest} not found) — inherited skills cannot resolve")
        bases.append(parent_pack / "skills")
        parent = yaml.safe_load(parent_manifest.read_text()).get("subset_of")
    bases.append(engine_root / ".claude" / "skills")
    return bases


def resolve(skill):
    for base in skill_search_path(pack_src, manifest):
        if (base / skill / "SKILL.md").is_file():
            return base / skill / "SKILL.md"
    return None

skills = [manifest["client_skill"], manifest["domain_skill"],
          manifest["target_stack"]["conventions_skill"], *manifest.get("extra_skills", [])]
ok = True
for s in skills:
    p = resolve(s)
    if p:
        print(f"OK   skill {s} -> {p}")
    else:
        searched = ", ".join(str(b) for b in skill_search_path(pack_src, manifest))
        print(f"ERROR: skill '{s}' not found in any of: {searched}", file=sys.stderr)
        ok = False

stack_def = pack_src / manifest["target_stack"]["definition"]
if stack_def.is_file():
    print(f"OK   target-stack definition {stack_def.relative_to(pack_src)}")
else:
    print(f"ERROR: target-stack definition missing: {stack_def}", file=sys.stderr)
    ok = False

sys.exit(0 if ok else 1)
'@
$tmp = New-TemporaryFile
Set-Content -Path $tmp -Value $py -Encoding UTF8
try {
    python $tmp.FullName $Manifest $EngineRoot $PackSrc
    if ($LASTEXITCODE -ne 0) { throw "Manifest validation failed" }
}
finally { Remove-Item $tmp -Force }

$Name = Split-Path -Leaf $PackSrc
$Dest = Join-Path $EngineRoot "portfolios\$Name"

if ($PackSrc -eq (Join-Path $EngineRoot "portfolios\$Name")) {
    Write-Host "OK   pack already lives in-engine at portfolios\$Name — nothing to install"
    exit 0
}
if (Test-Path $Dest) { throw "ERROR: portfolios\$Name already exists — remove it first" }

New-Item -ItemType Directory -Force -Path (Join-Path $EngineRoot 'portfolios') | Out-Null
if ($Copy) {
    Copy-Item -Recurse $PackSrc $Dest
    Write-Host "OK   copied pack to portfolios\$Name"
}
else {
    New-Item -ItemType Junction -Path $Dest -Target $PackSrc | Out-Null
    Write-Host "OK   junction portfolios\$Name -> $PackSrc (outputs commit to the pack repo)"
}
Write-Host "Done. Set PORTFOLIO_NAME=$Name in .env or pass portfolio=$Name to agents."
