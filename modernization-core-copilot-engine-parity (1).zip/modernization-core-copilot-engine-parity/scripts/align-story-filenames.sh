#!/bin/bash
# Script to align story filenames with EPIC template pattern
# Pattern: STORY-MU-ACME-CORE-XX-YY-ZZZ.md → STORY-ACME-CORE-MU-XX-YY-ZZZ.md

set -e

PORTFOLIO="ACME-CORE"
EPICS_DIR="docs/$PORTFOLIO/epics"

echo "=== Aligning Story Filenames with EPIC Template Pattern ==="
echo "Pattern: STORY-MU-ACME-CORE-XX-YY-ZZZ.md → STORY-ACME-CORE-MU-XX-YY-ZZZ.md"
echo ""

# Find all story files that need renaming
story_files=$(find "$EPICS_DIR" -name "STORY-MU-ACME-CORE-*.md" -type f | sort)

if [ -z "$story_files" ]; then
    echo "✅ All story files already in aligned format!"
    exit 0
fi

count=0
total=$(echo "$story_files" | wc -l)

echo "Found $total story files to rename"
echo ""

# Process each file
while IFS= read -r old_path; do
    # Extract directory and filename
    dir=$(dirname "$old_path")
    old_filename=$(basename "$old_path")

    # Pattern: STORY-MU-ACME-CORE-XX-YY-ZZZ.md → STORY-ACME-CORE-MU-XX-YY-ZZZ.md
    if [[ $old_filename =~ ^STORY-MU-ACME-CORE-([0-9]{2})-([0-9]{2})-([0-9]{3})\.md$ ]]; then
        mu_num="${BASH_REMATCH[1]}"
        epic_num="${BASH_REMATCH[2]}"
        story_num="${BASH_REMATCH[3]}"

        # Construct new filename: move MU after portfolio code
        new_filename="STORY-ACME-CORE-MU-${mu_num}-${epic_num}-${story_num}.md"
        new_path="$dir/$new_filename"

        # Rename the file
        if [ -f "$old_path" ]; then
            mv "$old_path" "$new_path"
            count=$((count + 1))
            if [ $((count % 20)) -eq 0 ]; then
                echo "[$count/$total] Renamed: $old_filename → $new_filename"
            fi
        else
            echo "WARNING: File not found: $old_path"
        fi
    else
        echo "SKIP: $old_filename (doesn't match expected pattern)"
    fi
done <<< "$story_files"

echo ""
echo "✅ Renamed $count story files"

# Show sample of new structure
echo ""
echo "=== Sample of New Structure ==="
find "$EPICS_DIR" -name "STORY-ACME-CORE-MU-*.md" -type f | head -5
