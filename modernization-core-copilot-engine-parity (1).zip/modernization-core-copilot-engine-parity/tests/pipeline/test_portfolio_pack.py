"""Contract tests for the portfolio-pack plugin seam.

These protect the property that makes the engine reusable: a portfolio — including
its target stack and architecture conventions — plugs in through its manifest with
zero engine changes. If someone reintroduces a hardcoded registry or prefix
inference, these fail.
"""
from __future__ import annotations

import json
from pathlib import Path

import pytest

yaml = pytest.importorskip("yaml")

ROOT = Path(__file__).resolve().parent.parent.parent
PACKS_DIR = ROOT / "portfolios"
NON_PACKS = {"_template"}
SCHEMA = json.loads((ROOT / "schemas" / "portfolio-manifest.schema.json").read_text())


def installed_packs() -> list[Path]:
    if not PACKS_DIR.exists():
        return []
    return sorted(p for p in PACKS_DIR.iterdir() if p.is_dir() and p.name not in NON_PACKS)


def skill_search_path(pack: Path) -> list[Path]:
    """Pack skills/, then each subset_of ancestor's skills/, then engine skills.

    Mirrors portfolio-resolution SKILL.md section 4.
    """
    bases = [pack / "skills"]
    manifest = yaml.safe_load((pack / "portfolio.yaml").read_text())
    parent, seen = manifest.get("subset_of"), {pack.name}
    while parent and parent not in seen:
        seen.add(parent)
        parent_manifest = PACKS_DIR / parent / "portfolio.yaml"
        if not parent_manifest.is_file():
            break
        bases.append(PACKS_DIR / parent / "skills")
        parent = yaml.safe_load(parent_manifest.read_text()).get("subset_of")
    bases.append(ROOT / ".claude" / "skills")
    return bases


def resolve_skill(pack: Path, name: str) -> Path | None:
    for base in skill_search_path(pack):
        candidate = base / name / "SKILL.md"
        if candidate.is_file():
            return candidate
    return None


class TestManifestSchema:
    def test_template_manifest_validates(self):
        import jsonschema

        manifest = yaml.safe_load((PACKS_DIR / "_template" / "portfolio.yaml").read_text())
        jsonschema.validate(manifest, SCHEMA)

    def test_manifest_requires_target_stack_and_codegen(self):
        """The two fields that make stacks and non-CA:Gen estates pluggable."""
        assert "target_stack" in SCHEMA["required"]
        assert "codegen" in SCHEMA["required"]
        assert set(SCHEMA["properties"]["codegen"]["enum"]) == {"cagen", "handwritten"}
        stack = SCHEMA["properties"]["target_stack"]
        assert set(stack["required"]) == {"id", "definition", "conventions_skill"}

    @pytest.mark.parametrize("pack", installed_packs(), ids=lambda p: p.name)
    def test_installed_pack_manifest_validates(self, pack: Path):
        import jsonschema

        manifest_path = pack / "portfolio.yaml"
        assert manifest_path.is_file(), f"{pack.name} has no portfolio.yaml"
        manifest = yaml.safe_load(manifest_path.read_text())
        jsonschema.validate(manifest, SCHEMA)
        assert manifest["portfolio"] == pack.name


class TestPackSelfContainment:
    @pytest.mark.parametrize("pack", installed_packs(), ids=lambda p: p.name)
    def test_declared_skills_resolve(self, pack: Path):
        manifest = yaml.safe_load((pack / "portfolio.yaml").read_text())
        names = [manifest["client_skill"], manifest["domain_skill"],
                 manifest["target_stack"]["conventions_skill"], *manifest.get("extra_skills", [])]
        unresolved = [n for n in names if resolve_skill(pack, n) is None]
        assert not unresolved, f"{pack.name}: unresolved skills {unresolved}"

    @pytest.mark.parametrize("pack", installed_packs(), ids=lambda p: p.name)
    def test_target_stack_definition_exists(self, pack: Path):
        manifest = yaml.safe_load((pack / "portfolio.yaml").read_text())
        definition = pack / manifest["target_stack"]["definition"]
        assert definition.is_file(), f"{pack.name}: missing {definition}"


class TestNoHardcodedRegistry:
    """Skill resolution must come from manifests, never from a table or a name prefix."""

    def test_resolution_skill_has_no_portfolio_table(self):
        text = (ROOT / ".claude" / "skills" / "portfolio-resolution" / "SKILL.md").read_text()
        for banned in ("Portfolios starting with", "portfolio → skill registry", "infer from the portfolio name"):
            assert banned not in text, f"prefix inference reintroduced: {banned!r}"

    def test_engine_declares_no_client_skill_names(self):
        """Client and domain skill names live in packs, never in engine skill dirs."""
        engine_skills = {p.name for p in (ROOT / ".claude" / "skills").iterdir() if p.is_dir()}
        pack_skills = set()
        for pack in installed_packs():
            skills_dir = pack / "skills"
            if skills_dir.exists():
                pack_skills |= {p.name for p in skills_dir.iterdir() if p.is_dir()}
        assert not (engine_skills & pack_skills), \
            f"pack skills shadowed by engine copies: {engine_skills & pack_skills}"


class TestSubsetChain:
    """subset_of is load-bearing: it is how a parent holds skills for its whole set."""

    @pytest.mark.parametrize("pack", installed_packs(), ids=lambda p: p.name)
    def test_subset_of_names_an_installed_pack(self, pack: Path):
        parent = yaml.safe_load((pack / "portfolio.yaml").read_text()).get("subset_of")
        if parent is None:
            pytest.skip("not a subset")
        assert (PACKS_DIR / parent / "portfolio.yaml").is_file(), \
            f"{pack.name}: subset_of '{parent}' is not an installed pack"

    @pytest.mark.parametrize("pack", installed_packs(), ids=lambda p: p.name)
    def test_subset_chain_terminates(self, pack: Path):
        seen, current = set(), pack.name
        while current:
            assert current not in seen, f"subset_of cycle through {current}"
            seen.add(current)
            manifest_path = PACKS_DIR / current / "portfolio.yaml"
            if not manifest_path.is_file():
                break
            current = yaml.safe_load(manifest_path.read_text()).get("subset_of")

    def test_no_shared_skills_side_channel(self):
        """Skills shared by sibling subsets belong in the parent, not a shared dir."""
        assert not (PACKS_DIR / "shared-skills").exists(), \
            "portfolios/shared-skills/ is back — move those skills into the parent pack named by subset_of"

    def test_subset_inherits_parent_skills(self):
        """At least one subset resolves a skill it does not itself ship."""
        inheriting = []
        for pack in installed_packs():
            manifest = yaml.safe_load((pack / "portfolio.yaml").read_text())
            if not manifest.get("subset_of"):
                continue
            for name in (manifest["client_skill"], manifest["domain_skill"]):
                resolved = resolve_skill(pack, name)
                if resolved and not resolved.is_relative_to(pack):
                    inheriting.append((pack.name, name))
        assert inheriting, "no subset inherits a skill from its parent — the subset_of walk is untested"
