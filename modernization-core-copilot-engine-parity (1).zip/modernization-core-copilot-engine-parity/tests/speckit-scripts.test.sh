#!/usr/bin/env bash
# Tests for the speckit helper scripts (.specify/scripts/bash/).
#
# Plain bash, no framework: `bash tests/speckit-scripts.test.sh`. Each test runs
# in a fresh throwaway git repo shaped like this one, with the four pack-name
# shapes that the old two-segment regex could not handle.
#
# Focus is portfolio resolution, the stdout/stderr contract, and the guardrails
# that were bugs in the PowerShell originals.
set -u

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
SCRIPTS="$ROOT/.specify/scripts/bash"
PASS=0; FAIL=0; CURRENT=""

ok()   { PASS=$((PASS+1)); }
fail() { FAIL=$((FAIL+1)); printf 'FAIL %s: %s\n' "$CURRENT" "$*" >&2; }
assert_eq()       { if [ "$1" = "$2" ]; then ok; else fail "expected '$2', got '$1'"; fi; }
assert_contains() { if printf '%s' "$1" | grep -qF -- "$2"; then ok; else fail "expected to contain '$2', got: $1"; fi; }
assert_exit()     { if [ "$1" -eq "$2" ]; then ok; else fail "expected exit $2, got $1"; fi; }

json_get() { printf '%s' "$1" | sed -n "s/.*\"$2\":\"\([^\"]*\)\".*/\1/p"; }

make_repo() {
    WORK=$(mktemp -d); cd "$WORK"
    git init -q -b main . && git config user.email t@t && git config user.name t
    mkdir -p .specify/templates .specify/scripts
    cp -R "$SCRIPTS" .specify/scripts/bash
    printf '# Spec\n' > .specify/templates/spec-template.md
    printf '# Plan\n' > .specify/templates/plan-template.md
    cp "$ROOT/.specify/templates/agent-file-template.md" .specify/templates/
    for p in TRDOC421 ACME-CORE MEETING-ROOM-BOOKING ACME-REF-subset; do
        mkdir -p "portfolios/$p/specs"; printf 'portfolio: %s\ndescription: test\n' "$p" > "portfolios/$p/portfolio.yaml"
    done
    mkdir -p portfolios/_template; printf 'portfolio: _template\n' > portfolios/_template/portfolio.yaml
    git add -A && git commit -qm init
    S=.specify/scripts/bash
    unset PORTFOLIO_NAME SPECIFY_FEATURE
}
teardown() { cd "$ROOT"; rm -rf "$WORK"; }

test_case() { CURRENT="$1"; make_repo; "$1"; teardown; }

# --- portfolio resolution ---------------------------------------------------

t_installed_packs_excludes_template() {
    . "$S/common.sh"
    out=$(installed_packs "$WORK")
    assert_eq "$(printf '%s\n' "$out" | grep -c _template)" 0
    assert_eq "$(printf '%s\n' "$out" | head -1)" "MEETING-ROOM-BOOKING"   # longest first
}

t_resolve_two_segment()   { . "$S/common.sh"; assert_eq "$(portfolio_from_identifier STORY-ACME-CORE-MU-00-01-004 "$WORK")" ACME-CORE; }
t_resolve_one_segment()   { . "$S/common.sh"; assert_eq "$(portfolio_from_identifier STORY-TRDOC421-MU-01-01-001 "$WORK")" TRDOC421; }
t_resolve_three_segment() { . "$S/common.sh"; assert_eq "$(portfolio_from_identifier STORY-MEETING-ROOM-BOOKING-MU-01-01-001 "$WORK")" MEETING-ROOM-BOOKING; }
t_resolve_mixed_case()    { . "$S/common.sh"; assert_eq "$(portfolio_from_identifier STORY-ACME-REF-subset-MU-01-02-001 "$WORK")" ACME-REF-subset; }
t_resolve_legacy_mu()     { . "$S/common.sh"; assert_eq "$(portfolio_from_identifier STORY-MU-ACME-CORE-01-02-001 "$WORK")" ACME-CORE; }
t_resolve_bare_prefix()   { . "$S/common.sh"; assert_eq "$(portfolio_from_identifier ACME-CORE-hotfix-42 "$WORK")" ACME-CORE; }
t_resolve_lowercase_id()  { . "$S/common.sh"; assert_eq "$(portfolio_from_identifier story-acme-core-mu-00-01-004 "$WORK")" ACME-CORE; }
t_resolve_rejects() {
    . "$S/common.sh"
    for id in "" main copilot/engine-parity MRBS-001-meeting-room-booking STORY-UNKNOWN-MU-01-01-001; do
        assert_eq "$(portfolio_from_identifier "$id" "$WORK")" ""
    done
}
t_resolve_spec_dir_for_unrelated_name() {
    . "$S/common.sh"
    mkdir -p portfolios/MEETING-ROOM-BOOKING/specs/MRBS-001-meeting-room-booking
    assert_eq "$(portfolio_from_identifier MRBS-001-meeting-room-booking "$WORK")" ""
    assert_eq "$(portfolio_from_spec_dir MRBS-001-meeting-room-booking "$WORK")" MEETING-ROOM-BOOKING
    assert_eq "$(resolve_portfolio MRBS-001-meeting-room-booking)" MEETING-ROOM-BOOKING
}
t_resolve_story_file() {
    . "$S/common.sh"
    mkdir -p portfolios/ACME-REF-subset/docs/epics/MU-01
    : > portfolios/ACME-REF-subset/docs/epics/MU-01/STORY-MU-ACMEREF-SUBSET-01-02-001.md
    assert_eq "$(portfolio_from_identifier STORY-MU-ACMEREF-SUBSET-01-02-001 "$WORK")" ""
    assert_eq "$(portfolio_from_story_file STORY-MU-ACMEREF-SUBSET-01-02-001 "$WORK")" ACME-REF-subset
}
t_resolve_precedence() {
    . "$S/common.sh"
    assert_eq "$(PORTFOLIO_NAME=ACME-CORE resolve_portfolio x TRDOC421)" TRDOC421          # explicit > env
    assert_eq "$(PORTFOLIO_NAME=TRDOC421 resolve_portfolio STORY-ACME-CORE-MU-00-01-004)" TRDOC421   # env > id
    printf '# c\nexport PORTFOLIO_NAME = "ACME-CORE"  # inline\n' > .env
    assert_eq "$(resolve_portfolio "")" ACME-CORE                                          # .env
}

# --- .env parsing -------------------------------------------------------------

t_dotenv_variants() {
    . "$S/common.sh"
    while IFS='|' read -r content expected; do
        printf '%b\n' "$content" > .env
        assert_eq "$(dotenv_get PORTFOLIO_NAME "$WORK")" "$expected"
    done <<'EOF'
PORTFOLIO_NAME=ACME|ACME
  PORTFOLIO_NAME = ACME  |ACME
export PORTFOLIO_NAME=ACME|ACME
PORTFOLIO_NAME="ACME"|ACME
PORTFOLIO_NAME='ACME'|ACME
PORTFOLIO_NAME=ACME # trailing|ACME
# PORTFOLIO_NAME=NO\nPORTFOLIO_NAME=ACME|ACME
PORTFOLIO_NAME="ACME # kept"|ACME # kept
garbage\nPORTFOLIO_NAME=OK|OK
EOF
}

# --- feature pin -----------------------------------------------------------

t_feature_pin_roundtrip() {
    assert_contains "$($S/feature.sh show)" '"CURRENT_FEATURE":null'
    $S/feature.sh set STORY-ACME-CORE-MU-00-01-004 >/dev/null
    assert_contains "$($S/feature.sh show)" 'STORY-ACME-CORE-MU-00-01-004'
    assert_contains "$($S/feature.sh clear)" '"CLEARED":true'
    assert_contains "$($S/feature.sh clear)" '"CLEARED":false'
}

# --- create-new-feature -------------------------------------------------------

t_new_feature_verbatim_name() {
    out=$($S/create-new-feature.sh --json --feature-name MRBS-002-x --portfolio MEETING-ROOM-BOOKING "desc")
    assert_eq "$(json_get "$out" BRANCH_NAME)" MRBS-002-x
    assert_eq "$(json_get "$out" PORTFOLIO)" MEETING-ROOM-BOOKING
    assert_eq "$(git branch --show-current)" MRBS-002-x
    [ -f portfolios/MEETING-ROOM-BOOKING/specs/MRBS-002-x/spec.md ] && ok || fail "spec.md missing"
    assert_contains "$($S/feature.sh show)" MRBS-002-x
}
t_new_feature_resolves_from_story_id() {
    out=$($S/create-new-feature.sh --json --feature-name STORY-TRDOC421-MU-01-01-009 "d")
    assert_eq "$(json_get "$out" PORTFOLIO)" TRDOC421
}
t_new_feature_short_name_slug() {
    out=$($S/create-new-feature.sh --json --short-name "User Auth" --portfolio ACME-CORE "Add user authentication" 2>/dev/null)
    assert_eq "$(json_get "$out" BRANCH_NAME)" 001-user-auth
    assert_eq "$(json_get "$out" FEATURE_NUM)" 001
}
t_new_feature_rejects_story_id_as_short_name() {
    out=$($S/create-new-feature.sh --json --short-name STORY-ACME-CORE-MU-00-01-004 "d"); rc=$?
    assert_exit $rc 1; assert_contains "$out" "must be used verbatim"
}
t_new_feature_rejects_empty_description() {
    out=$($S/create-new-feature.sh --json --feature-name X --portfolio TRDOC421 "  "); rc=$?
    assert_exit $rc 1; assert_contains "$out" "cannot be empty"
}
t_new_feature_rejects_uninstalled_pack() {
    out=$($S/create-new-feature.sh --json --feature-name X --portfolio NOPE "d"); rc=$?
    assert_exit $rc 1; assert_contains "$out" "not installed"
}
t_new_feature_rejects_existing() {
    $S/create-new-feature.sh --json --feature-name STORY-TRDOC421-MU-01-01-001 "d" >/dev/null
    git checkout -q main; $S/feature.sh clear >/dev/null
    out=$($S/create-new-feature.sh --json --feature-name STORY-TRDOC421-MU-01-01-001 "d"); rc=$?
    assert_exit $rc 1; assert_contains "$out" "already exists"
}

# --- check-prerequisites / setup-plan -------------------------------------------

t_check_before_plan_reports_plan_not_pack() {
    $S/create-new-feature.sh --json --feature-name MRBS-002-x --portfolio MEETING-ROOM-BOOKING "d" >/dev/null
    out=$($S/check-prerequisites.sh --json); rc=$?
    assert_exit $rc 1; assert_contains "$out" "plan.md not found"
}
t_docs_ordering() {
    $S/create-new-feature.sh --json --feature-name STORY-ACME-CORE-MU-00-01-004 "d" >/dev/null
    $S/setup-plan.sh --json >/dev/null 2>&1
    d=portfolios/ACME-CORE/specs/STORY-ACME-CORE-MU-00-01-004
    touch $d/research.md $d/data-model.md $d/quickstart.md $d/tasks.md; mkdir -p $d/contracts; touch $d/contracts/a.md
    out=$($S/check-prerequisites.sh --json --require-tasks --include-tasks)
    assert_contains "$out" '"AVAILABLE_DOCS":["research.md","data-model.md","contracts/","quickstart.md","tasks.md"]'
    out=$($S/check-prerequisites.sh --json)
    assert_contains "$out" '"AVAILABLE_DOCS":["research.md","data-model.md","contracts/","quickstart.md"]'
}
t_require_tasks() {
    $S/create-new-feature.sh --json --feature-name STORY-ACME-CORE-MU-00-01-004 "d" >/dev/null
    $S/setup-plan.sh --json >/dev/null 2>&1
    out=$($S/check-prerequisites.sh --json --require-tasks); rc=$?
    assert_exit $rc 1; assert_contains "$out" "tasks.md not found"
}
t_paths_only_keys() {
    $S/create-new-feature.sh --json --feature-name STORY-ACME-CORE-MU-00-01-004 "d" >/dev/null
    out=$($S/check-prerequisites.sh --json --paths-only)
    for k in REPO_ROOT BRANCH FEATURE_DIR FEATURE_SPEC IMPL_PLAN TASKS; do assert_contains "$out" "\"$k\":"; done
}
t_main_is_refused_with_actionable_error() {
    out=$($S/check-prerequisites.sh --json --paths-only); rc=$?
    assert_exit $rc 1; assert_contains "$out" "Cannot run on 'main'"
}
t_stale_pin_warns_on_stderr_not_stdout() {
    $S/create-new-feature.sh --json --feature-name STORY-ACME-CORE-MU-00-01-004 "d" >/dev/null
    git checkout -q main
    out=$($S/check-prerequisites.sh --json --paths-only 2>/tmp/err.$$)
    assert_contains "$out" '"BRANCH":"STORY-ACME-CORE-MU-00-01-004"'
    assert_contains "$(cat /tmp/err.$$)" "differs from the checked-out branch"; rm -f /tmp/err.$$
}
t_stdout_is_single_json_line() {
    $S/create-new-feature.sh --json --feature-name STORY-ACME-CORE-MU-00-01-004 "d" >/dev/null
    out=$($S/check-prerequisites.sh --json --paths-only 2>/dev/null)
    assert_eq "$(printf '%s\n' "$out" | wc -l | tr -d ' ')" 1
    case "$out" in \{*\}) ok;; *) fail "not a json object: $out";; esac
}

# --- update-agent-context -----------------------------------------------------

t_agent_context_skips_template_slots() {
    $S/create-new-feature.sh --json --feature-name STORY-ACME-CORE-MU-00-01-004 "d" >/dev/null
    $S/setup-plan.sh --json >/dev/null 2>&1
    printf '**Language/Version**: [e.g., Python 3.11 or NEEDS CLARIFICATION]\n**Language/Version**: Java 21\n**Primary Dependencies**: Spring Boot 3.4\n**Project Type**: [single/web/mobile - determines source structure]\n' >> portfolios/ACME-CORE/specs/STORY-ACME-CORE-MU-00-01-004/plan.md
    $S/update-agent-context.sh --agent copilot >/dev/null 2>&1
    f=.github/copilot-instructions.md
    assert_contains "$(cat $f)" "- Java 21 + Spring Boot 3.4 (STORY-ACME-CORE-MU-00-01-004)"
    assert_contains "$(cat $f)" "mvn verify"
    assert_eq "$(grep -c 'e.g., Python' $f)" 0
    assert_eq "$(grep -c '^frontend/' $f)" 0                       # "web" in the slot must not leak
    $S/update-agent-context.sh --agent copilot >/dev/null 2>&1      # idempotent
    assert_eq "$(grep -c 'Java 21' $f)" 3
}
t_agent_context_all_does_not_create() {
    $S/create-new-feature.sh --json --feature-name STORY-ACME-CORE-MU-00-01-004 "d" >/dev/null
    $S/setup-plan.sh --json >/dev/null 2>&1
    out=$($S/update-agent-context.sh --json 2>/dev/null)
    assert_contains "$out" '"UPDATED":[]'
    [ -e .github/copilot-instructions.md ] && fail "created a file under --agent all" || ok
}

# --- runner ---------------------------------------------------------------------

for t in $(declare -F | awk '{print $3}' | grep '^t_'); do test_case "$t"; done
printf '\n%d passed, %d failed\n' "$PASS" "$FAIL"
[ "$FAIL" -eq 0 ]
