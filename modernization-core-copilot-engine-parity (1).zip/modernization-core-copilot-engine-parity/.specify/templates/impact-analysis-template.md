# Impact Analysis: [CHANGE TITLE]

**Branch**: `[###-branch-name]`  
**Author**: [Developer Name]  
**Reviewed By**: [Reviewer Name] _(required before implementation begins)_  
**Date**: [YYYY-MM-DD]  
**Status**: Draft | In Review | Approved  
**Risk Level**: HIGH | MEDIUM | LOW  

---

## 1. Change Summary

> _Plain-language description of what is being changed and why.
> Non-technical stakeholders should be able to understand this section._

**What**: [Describe the change]

**Why**: [Business or technical reason driving the change]

**Type of change**:
- [ ] Migration of an existing unit (source system → target stack — name both in §1)
- [ ] Shared component / module modification
- [ ] Shared service / helper / middleware / interceptor change
- [ ] Global state structure change (state, actions, reducers, selectors, effects, events)
- [ ] Route / guard / resolver change
- [ ] Published service contract change (WSDL, OpenAPI, gRPC, GraphQL, message schema)
- [ ] Third-party dependency update
- [ ] Other: _______________

**Interop / bridge layer involved?**
> _A bridge layer connects two stacks (e.g., a legacy shell consuming a new module, or a new shell consuming a legacy service)._
- [ ] Yes — a target-stack unit is consumed by the source-system shell (see §3b)
- [ ] Yes — a source-system service is consumed by the target stack (see §3b)
- [ ] No

---

## 2. Affected Screens / Endpoints (User-Facing Impact)

> _List every user-facing screen, endpoint, or surface that will be visually or
> behaviorally affected by this change. This is the business-level impact view —
> identify these BEFORE diving into technical files._

| Screen / Endpoint | Stack | Impact Description |
|-------------------|-------|--------------------|
| [e.g., `/<route>` or `POST /api/<path>`] | [target / source / mixed] | [what users observe] |

> If the change is purely internal (no user-visible effect), state:
> **"No user-facing surfaces are directly affected."**

---

## 3. Scope — Files Being Modified

> _List every file that will be directly changed. No estimating — verify each path exists._

| File | Change Type | Description |
|------|-------------|-------------|
| `path/to/file.<ext>` | Modified / Added / Deleted | What changes in this file |

---

## 4. Consumers Inventory

> _Every location in the codebase that imports, uses, or depends on each item in
> Scope. MUST be produced by actual codebase search — not from memory.
> Record the exact search commands run so they can be reproduced._

**Search commands used**:
```
# Example — adapt to the project's source-tree layout declared in plan.md
grep -r "SymbolName" <source-roots> --include="*.<ext1>" --include="*.<ext2>"
grep -r "<element-or-selector>" <template-roots>
grep -r "ServiceName" <source-roots>
```

### 4a. Target-Stack Consumers

| Consumer File | How It Uses the Changed Item |
|---------------|------------------------------|
| `path/to/consumer.<ext>` | [e.g., imports the symbol, uses the selector / element, declares in test harness] |

### 4b. Source-Stack / Bridge Consumers

> _Complete this section if the changed item is reached via an interop / bridge layer
> (a target-stack unit consumed by the source shell, or a source-stack service consumed
> by the target stack). If not applicable, state "None."_

| Consumer File | How It Uses the Changed Item |
|---------------|------------------------------|
| `path/to/source-system/template.<ext>` | [e.g., uses the bridged unit's identifier] |
| `path/to/source-system/source-file.<ext>` | [e.g., injects the bridged service by identifier] |

**Bridge registration location** _(if applicable — declared in plan.md)_:  
`<bridge-file>` — registered identifier: `[identifier]`

_(Repeat §4a and §4b for each distinct symbol / component / service in Scope)_

---

## 5. Breaking Changes

> _Explicit list of contract changes. If none, state "**None — fully backwards compatible.**"_
> _Each entry must state the OLD contract and the NEW contract, plus the severity._

**Severity definitions:**
- 🔴 **Compile-time / static-analysis** — compiler / type-checker / linter error; build will fail without consumer updates
- 🟠 **Runtime** — no build error but application throws at runtime
- 🟡 **Behavioral** — builds and runs but produces different output / UX

### BC-001: [Short title]

**Severity**: 🔴 Compile-time | 🟠 Runtime | 🟡 Behavioral

| | Before | After |
|---|--------|-------|
| **Identifier / selector** | `oldName` | `newName` |
| **Input / parameter** | `data: OldType` | `data: NewType` |
| **Output / event** | `oldEvent: void` | `newEvent: EventPayload` |
| **Schema field** | `{ field: string }` | `{ field: string; newField: number }` |
| **Behavior** | [Old behavior] | [New behavior] |

**Consumers broken by this change**:
- `path/to/consumer-a.<ext>` — uses old identifier
- `path/to/bridge-consumer.<ext>` — uses bridged identifier with old attribute name

---

### BC-002: [Short title]

_(Add as many BC entries as needed. Remove this heading if no further breaking changes.)_

---

## 6. Migration Path for Consumers

> _Concrete, actionable code-level instructions for every consumer listed in §5.
> Must be detailed enough that another developer can execute without asking questions._

### Consumers of BC-001: [Short title]

**`path/to/consumer-a.<ext>`** _(target-stack consumer)_
```
// BEFORE — show the actual syntax in the file's language

// AFTER — show the updated syntax
```

**`path/to/consumer-a.<ext>`** _(if import / type / contract changes)_
```
// BEFORE
import { OldType } from './old-type';

// AFTER
import { NewType } from './new-type';
```

**`path/to/bridge-consumer.<ext>`** _(consumer via the interop bridge)_
```
// BEFORE — show the actual bridge usage

// AFTER — show the updated bridge usage
```

**`<bridge-file>`** _(if the bridged identifier changed — file declared in plan.md)_
```
// BEFORE — bridge registration with the old identifier

// AFTER — bridge registration with the new identifier
```

_(Repeat for every breaking change and every consumer)_

---

## 7. Regression Risk

> _Rate each changed item HIGH / MEDIUM / LOW with justification._
> _HIGH = widely used or on a critical user journey._
> _MEDIUM = used in a few places or on a non-critical path._
> _LOW = isolated, single consumer, or internal-only change._

| Changed Item | Target-Stack Consumers | Bridge Consumers | Risk | Justification |
|--------------|:----------------------:|:----------------:|------|---------------|
| `Name` | N | N | HIGH / MEDIUM / LOW | [Reason] |

**Overall risk rating**: HIGH | MEDIUM | LOW

> If **HIGH**: a second reviewer and QA sign-off are required before merge (see §10).

---

## 8. Test Coverage Plan

### Existing tests covering the changed code

| Test File | What It Tests | Will It Break? | Action Required |
|-----------|---------------|:--------------:|-----------------|
| `path/to/<test-file>` | [Scenario] | Yes / No | Update test / No action |

### New tests required

| Test File | Scenario to Cover | Priority |
|-----------|-------------------|----------|
| `path/to/<test-file>` | [New scenario] | Must / Should / Nice-to-have |

### QA / E2E scenarios to re-run

- [ ] [Scenario 1]
- [ ] [Scenario 2]
- [ ] [Add every affected user journey from §2]

---

## 9. Rollback Plan

> _How to revert this change safely if production issues are detected post-merge._

**Rollback approach**: Git revert | Feature flag | Hotfix | Redeploy previous build

**Steps**:
1. [Step 1]
2. [Step 2]
3. [Step 3]

**Data / state concerns**: [Any persisted state — global store, local storage, session, DB schema, cached schemas — that complicates rollback? If none: "None."]

**Estimated rollback time**: [e.g., "< 30 minutes — `git revert` + redeploy"]

---

## 10. Sign-off

> _Reviewer must approve before implementation begins. HIGH-risk changes require QA sign-off too._

| Role | Name | Date | Decision |
|------|------|------|----------|
| Author | | | Submitted |
| Reviewer | | | Approved / Rejected / Changes Requested |
| QA _(HIGH risk only)_ | | | Approved / Rejected |

**Review notes**:
> [Concerns, conditions, or required changes from the reviewer]

---

## Change History

| Version | Date | Author | Summary of Changes to This Document |
|---------|------|--------|--------------------------------------|
| 1.0 | [YYYY-MM-DD] | [Name] | Initial draft |

---

_Template version: 2.0 | Governed by the project Constitution_
