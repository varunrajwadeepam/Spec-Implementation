#!/usr/bin/env bash
# Inspect or pin the active feature. Replaces $env:SPECIFY_FEATURE, which the
# original create-new-feature.ps1 set inside a process that then exited, so no
# later step could ever observe it.
#
# Usage: feature.sh set <name> | clear | show
set -euo pipefail
. "$(dirname "${BASH_SOURCE[0]}")/common.sh"
JSON=true
ROOT=$(get_repo_root)
case "${1:-}" in
    set)   [ -n "${2:-}" ] || die "feature.sh set requires a name"
           feature_pin_write "$ROOT" "$2"; printf '{"CURRENT_FEATURE":"%s"}\n' "$(json_escape "$2")";;
    clear) if [ -f "$ROOT/$STATE_FILE_REL" ]; then feature_pin_clear "$ROOT"; c=true; else c=false; fi
           printf '{"CURRENT_FEATURE":null,"CLEARED":%s}\n' "$c";;
    show)  p=$(feature_pin_read "$ROOT")
           if [ -n "$p" ]; then printf '{"CURRENT_FEATURE":"%s"}\n' "$(json_escape "$p")"; else printf '{"CURRENT_FEATURE":null}\n'; fi;;
    *)     die "Usage: feature.sh set <name> | clear | show";;
esac
