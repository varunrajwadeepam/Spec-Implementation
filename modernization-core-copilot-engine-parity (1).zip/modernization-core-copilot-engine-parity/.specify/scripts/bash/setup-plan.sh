#!/usr/bin/env bash
# Create the feature dir and lay down plan.md from the template.
#
# Usage: setup-plan.sh [--json] [--portfolio NAME]
set -euo pipefail
. "$(dirname "${BASH_SOURCE[0]}")/common.sh"

JSON=false; EXPLICIT=""
while [ $# -gt 0 ]; do
    case "$1" in
        --json) JSON=true;;
        --portfolio) EXPLICIT="${2:-}"; shift;;
        --help|-h) sed -n '2,4p' "$0" | sed 's/^# \{0,1\}//'; exit 0;;
        *) die "Unknown option: $1";;
    esac; shift
done

get_feature_paths "$EXPLICIT"
mkdir -p "$FEATURE_DIR"

TEMPLATE="$REPO_ROOT/.specify/templates/plan-template.md"
# Overwriting is the original behaviour and /speckit.plan depends on it, but it
# silently discards hand edits on a re-run — so say so.
[ -f "$IMPL_PLAN" ] && warn "[specify] Warning: overwriting the existing plan.md with a fresh template copy. Any hand edits to it are discarded."
if [ -f "$TEMPLATE" ]; then
    cp -f "$TEMPLATE" "$IMPL_PLAN"; warn "Copied plan template to $IMPL_PLAN"
else
    warn "[specify] Warning: plan template not found at $TEMPLATE"; : > "$IMPL_PLAN"
fi

if [ "$JSON" = true ]; then
    printf '{"FEATURE_SPEC":"%s","IMPL_PLAN":"%s","SPECS_DIR":"%s","BRANCH":"%s","HAS_GIT":%s}\n' \
        "$(json_escape "$FEATURE_SPEC")" "$(json_escape "$IMPL_PLAN")" "$(json_escape "$FEATURE_DIR")" \
        "$(json_escape "$CURRENT_BRANCH")" "$HAS_GIT"
else
    echo "FEATURE_SPEC: $FEATURE_SPEC"; echo "IMPL_PLAN: $IMPL_PLAN"; echo "SPECS_DIR: $FEATURE_DIR"
    echo "BRANCH: $CURRENT_BRANCH"; echo "HAS_GIT: $HAS_GIT"
fi
