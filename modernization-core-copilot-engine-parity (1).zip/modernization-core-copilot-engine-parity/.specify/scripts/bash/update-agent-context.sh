#!/usr/bin/env bash
# Refresh the instruction file(s) from the active feature's plan.md.
#
# Usage: update-agent-context.sh [--json] [--agent claude|copilot|all] [--portfolio NAME]
#
# Targets are cut to the two tools this repo supports (the original shipped 19,
# 17 of them dead), and the Copilot path is .github/copilot-instructions.md —
# the .github/agents/ path the original wrote to is not read by Copilot.
#
# plan.md fields that still hold an unfilled template slot (a bracketed
# "[e.g., Python 3.11 ...]" prompt, "NEEDS CLARIFICATION", "N/A") are treated as
# empty. Reading the first match blindly used to leak the template's own prompt
# into the generated file, and the stray "web" in "[single/web/mobile ...]"
# selected a backend/frontend layout for single-project features.
set -euo pipefail
. "$(dirname "${BASH_SOURCE[0]}")/common.sh"

JSON=false; AGENT=all; EXPLICIT=""
while [ $# -gt 0 ]; do
    case "$1" in
        --json) JSON=true;;
        --agent) AGENT="${2:-all}"; shift;;
        --portfolio) EXPLICIT="${2:-}"; shift;;
        --help|-h) sed -n '2,5p' "$0" | sed 's/^# \{0,1\}//'; exit 0;;
        claude|copilot|all) AGENT="$1";;    # positional, as upstream accepts
        *) die "Unknown option: $1";;
    esac; shift
done
case "$AGENT" in claude|copilot|all) ;; *) die "Unknown agent '$AGENT'. Choose one of: claude, copilot, all";; esac

get_feature_paths "$EXPLICIT"
[ -f "$IMPL_PLAN" ] || die "No plan.md found at $IMPL_PLAN. Run /speckit.plan first."
TEMPLATE="$REPO_ROOT/.specify/templates/agent-file-template.md"
[ -f "$TEMPLATE" ] || die "Template not found at $TEMPLATE."

target_path() { case "$1" in claude) echo "$REPO_ROOT/CLAUDE.md";; copilot) echo "$REPO_ROOT/.github/copilot-instructions.md";; esac; }

is_placeholder() {
    local v="$1"
    [ -z "$v" ] && return 0
    case "$v" in "N/A"|"NEEDS CLARIFICATION"|*"NEEDS CLARIFICATION"*) return 0;; esac
    case "$v" in \[*\]) return 0;; esac
    return 1
}
# plan_field NAME — first non-placeholder "**NAME**: value" line in plan.md.
plan_field() {
    local v
    while IFS= read -r v; do
        v="${v#"${v%%[![:space:]]*}"}"; v="${v%"${v##*[![:space:]]}"}"
        is_placeholder "$v" || { printf '%s\n' "$v"; return; }
    done < <(grep -F -- "**$1**:" "$IMPL_PLAN" | sed 's/^\*\*[^*]*\*\*:[[:space:]]*//')
}

LANG_=$(plan_field 'Language/Version');  FRAMEWORK=$(plan_field 'Primary Dependencies')
DB=$(plan_field 'Storage');               PROJECT_TYPE=$(plan_field 'Project Type')
[ -n "$LANG_" ] || warn "[specify] Warning: no language information found in plan.md"

STACK=""; [ -n "$LANG_" ] && STACK="$LANG_"; [ -n "$FRAMEWORK" ] && STACK="${STACK:+$STACK + }$FRAMEWORK"
# Literal "\n" — awk -v expands escape sequences itself, and BSD awk rejects a real newline.
case "$(printf '%s' "$PROJECT_TYPE" | tr '[:upper:]' '[:lower:]')" in *web*) STRUCTURE='backend/\nfrontend/\ntests/';; *) STRUCTURE='src/\ntests/';; esac
case "$(printf '%s' "$LANG_" | tr '[:upper:]' '[:lower:]')" in
    *python*) COMMANDS="cd src; pytest; ruff check .";;
    *rust*) COMMANDS="cargo test; cargo clippy";;
    *javascript*|*typescript*) COMMANDS="npm test; npm run lint";;
    *java*|*kotlin*|*spring*) COMMANDS="mvn verify";;
    *"c#"*|*.net*|*dotnet*) COMMANDS="dotnet test";;
    "") COMMANDS="# Add commands";;
    *) COMMANDS="# Add commands for $LANG_";;
esac
CONVENTIONS="${LANG_:+$LANG_: }Follow standard conventions"; [ -n "$LANG_" ] || CONVENTIONS="General: Follow standard conventions"
TODAY=$(date +%Y-%m-%d); PROJECT=$(basename "$REPO_ROOT")

# Plain string substitution via awk (no regex-escape round trip, which the
# original used and which corrupted any backslash in substituted content).
create_file() {
    local target="$1"
    mkdir -p "$(dirname "$target")"
    awk -v project="$PROJECT" -v today="$TODAY" -v branch="$CURRENT_BRANCH" -v stack="$STACK" \
        -v structure="$STRUCTURE" -v commands="$COMMANDS" -v conventions="$CONVENTIONS" '
        function rep(s, needle, val,   i) { i = index(s, needle); while (i) { s = substr(s, 1, i-1) val substr(s, i+length(needle)); i = index(s, needle) } return s }
        {
            $0 = rep($0, "[PROJECT NAME]", project)
            $0 = rep($0, "[DATE]", today)
            $0 = rep($0, "[EXTRACTED FROM ALL PLAN.MD FILES]", stack ? "- " stack " (" branch ")" : "")
            $0 = rep($0, "[ACTUAL STRUCTURE FROM PLANS]", structure)
            $0 = rep($0, "[ONLY COMMANDS FOR ACTIVE TECHNOLOGIES]", commands)
            $0 = rep($0, "[LANGUAGE-SPECIFIC, ONLY FOR LANGUAGES IN USE]", conventions)
            $0 = rep($0, "[LAST 3 FEATURES AND WHAT THEY ADDED]", stack ? "- " branch ": Added " stack : "")
            print
        }' "$TEMPLATE" > "$target"
}

update_file() {
    local target="$1" tmp
    tmp=$(mktemp)
    local tech_entry="" db_entry="" change_entry=""
    if [ -n "$STACK" ] && ! grep -qF -- "$STACK" "$target"; then tech_entry="- $STACK ($CURRENT_BRANCH)"; fi
    if [ -n "$DB" ] && ! grep -qF -- "$DB" "$target"; then db_entry="- $DB ($CURRENT_BRANCH)"; fi
    if [ -n "$STACK" ]; then change_entry="- $CURRENT_BRANCH: Added $STACK"; elif [ -n "$DB" ]; then change_entry="- $CURRENT_BRANCH: Added $DB"; fi
    [ -n "$change_entry" ] && grep -qF -- "$change_entry" "$target" && change_entry=""   # already logged
    awk -v tech="$tech_entry" -v dbe="$db_entry" -v change="$change_entry" -v today="$TODAY" '
        function flush() { if (!added) { if (tech != "") print tech; if (dbe != "") print dbe; added = 1 } }
        BEGIN { in_tech = 0; in_changes = 0; added = 0; kept = 0 }
        $0 == "## Active Technologies" { print; in_tech = 1; next }
        in_tech && /^## /            { flush(); print; in_tech = 0; next }
        in_tech && /^[[:space:]]*$/  { flush(); print; next }
        $0 == "## Recent Changes"    { print; if (change != "") print change; in_changes = 1; next }
        in_changes && /^## /         { print; in_changes = 0; next }
        in_changes && /^- /          { if (kept < 2) { print; kept++ }; next }
        /Last updated:?[^0-9]*[0-9]{4}-[0-9]{2}-[0-9]{2}/ { sub(/[0-9]{4}-[0-9]{2}-[0-9]{2}/, today) }
        { print }
        END { if (in_tech) flush() }' "$target" > "$tmp"
    mv "$tmp" "$target"
}

UPDATED=()
for key in $( [ "$AGENT" = all ] && echo "claude copilot" || echo "$AGENT" ); do
    target=$(target_path "$key")
    if [ -f "$target" ]; then update_file "$target"; action=updated
    elif [ "$AGENT" = all ]; then continue        # don't conjure a file the project hasn't opted into
    else create_file "$target"; action=created; fi
    UPDATED+=("$key:$action"); warn "✓ $action $key context file: $target"
done

if [ "$JSON" = true ]; then
    printf '{"BRANCH":"%s","PLAN":"%s","UPDATED":[' "$(json_escape "$CURRENT_BRANCH")" "$(json_escape "$IMPL_PLAN")"
    for i in "${!UPDATED[@]}"; do [ "$i" -gt 0 ] && printf ','; printf '"%s"' "${UPDATED[$i]}"; done
    printf ']}\n'
fi
