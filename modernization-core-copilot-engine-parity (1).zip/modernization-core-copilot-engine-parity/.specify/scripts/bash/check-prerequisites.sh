#!/usr/bin/env bash
# Consolidated prerequisite checking for the speckit workflow.
#
# Usage: check-prerequisites.sh [--json] [--require-tasks] [--include-tasks] [--paths-only] [--portfolio NAME]
#
#   --json            JSON output (the only format the command prose parses)
#   --require-tasks   fail when tasks.md is absent (implementation phase)
#   --include-tasks   include tasks.md in AVAILABLE_DOCS
#   --paths-only      path variables only, no validation
#   --portfolio NAME  override portfolio resolution
set -euo pipefail
. "$(dirname "${BASH_SOURCE[0]}")/common.sh"

JSON=false; REQUIRE_TASKS=false; INCLUDE_TASKS=false; PATHS_ONLY=false; EXPLICIT=""
while [ $# -gt 0 ]; do
    case "$1" in
        --json) JSON=true;;
        --require-tasks) REQUIRE_TASKS=true;;
        --include-tasks) INCLUDE_TASKS=true;;
        --paths-only) PATHS_ONLY=true;;
        --portfolio) EXPLICIT="${2:-}"; shift;;
        --help|-h) sed -n '2,10p' "$0" | sed 's/^# \{0,1\}//'; exit 0;;
        *) die "Unknown option: $1";;
    esac; shift
done

get_feature_paths "$EXPLICIT"

if [ "$PATHS_ONLY" = true ]; then
    if [ "$JSON" = true ]; then
        printf '{"REPO_ROOT":"%s","BRANCH":"%s","FEATURE_DIR":"%s","FEATURE_SPEC":"%s","IMPL_PLAN":"%s","TASKS":"%s"}\n' \
            "$(json_escape "$REPO_ROOT")" "$(json_escape "$CURRENT_BRANCH")" "$(json_escape "$FEATURE_DIR")" \
            "$(json_escape "$FEATURE_SPEC")" "$(json_escape "$IMPL_PLAN")" "$(json_escape "$TASKS")"
    else
        echo "REPO_ROOT: $REPO_ROOT"; echo "BRANCH: $CURRENT_BRANCH"; echo "FEATURE_DIR: $FEATURE_DIR"
        echo "FEATURE_SPEC: $FEATURE_SPEC"; echo "IMPL_PLAN: $IMPL_PLAN"; echo "TASKS: $TASKS"
    fi
    exit 0
fi

[ -d "$FEATURE_DIR" ] || die "Feature directory not found: $FEATURE_DIR. Run /speckit.specify first to create the feature structure."
[ -f "$IMPL_PLAN" ]   || die "plan.md not found in $FEATURE_DIR. Run /speckit.plan first to create the implementation plan."
if [ "$REQUIRE_TASKS" = true ] && [ ! -f "$TASKS" ]; then
    die "tasks.md not found in $FEATURE_DIR. Run /speckit.tasks first to create the task list."
fi

# Emission order is load-bearing: prose reads AVAILABLE_DOCS positionally in places.
docs=()
[ -f "$RESEARCH" ]   && docs+=("research.md")
[ -f "$DATA_MODEL" ] && docs+=("data-model.md")
if [ -d "$CONTRACTS_DIR" ] && [ -n "$(ls -A "$CONTRACTS_DIR" 2>/dev/null)" ]; then docs+=("contracts/"); fi
[ -f "$QUICKSTART" ] && docs+=("quickstart.md")
if [ "$INCLUDE_TASKS" = true ] && [ -f "$TASKS" ]; then docs+=("tasks.md"); fi

if [ "$JSON" = true ]; then
    printf '{"FEATURE_DIR":"%s","AVAILABLE_DOCS":[' "$(json_escape "$FEATURE_DIR")"
    for i in "${!docs[@]}"; do [ "$i" -gt 0 ] && printf ','; printf '"%s"' "${docs[$i]}"; done
    printf ']}\n'
else
    echo "FEATURE_DIR:$FEATURE_DIR"; echo "AVAILABLE_DOCS:"
    mark() { if [ -e "$1" ]; then echo "  ✓ $2"; else echo "  ✗ $2"; fi; }
    mark "$RESEARCH" research.md; mark "$DATA_MODEL" data-model.md
    if [ -d "$CONTRACTS_DIR" ] && [ -n "$(ls -A "$CONTRACTS_DIR" 2>/dev/null)" ]; then echo "  ✓ contracts/"; else echo "  ✗ contracts/"; fi
    mark "$QUICKSTART" quickstart.md
    [ "$INCLUDE_TASKS" = true ] && mark "$TASKS" tasks.md
fi
