#!/usr/bin/env bash
# Create the feature branch and spec folder.
#
# Usage: create-new-feature.sh [--json] (--feature-name NAME | --short-name NAME [--number N])
#                              [--portfolio NAME] <feature description>
#
#   --feature-name NAME  exact branch + spec-folder name, used verbatim. Required
#                        for story/epic ids and CODE-NNN custom-code features.
#   --short-name NAME    2-4 word slug, auto-numbered as NNN-<slug>. Refuses a
#                        story/epic id: it would lowercase and prefix it, turning
#                        STORY-ACME-CORE-MU-00-01-004 into
#                        007-story-acme-core-mu-00-01-004 while the prose
#                        promises the name is used "as-is".
#   --number N           force the branch number
#   --portfolio NAME     override portfolio resolution
set -euo pipefail
. "$(dirname "${BASH_SOURCE[0]}")/common.sh"

JSON=false; FEATURE_NAME=""; SHORT_NAME=""; NUMBER=0; EXPLICIT=""; DESC=()
while [ $# -gt 0 ]; do
    case "$1" in
        --json) JSON=true;;
        --feature-name) FEATURE_NAME="${2:-}"; shift;;
        --short-name)   SHORT_NAME="${2:-}"; shift;;
        --number)       NUMBER="${2:-0}"; shift;;
        --portfolio)    EXPLICIT="${2:-}"; shift;;
        --help|-h) sed -n '2,15p' "$0" | sed 's/^# \{0,1\}//'; exit 0;;
        --) shift; DESC+=("$@"); break;;
        *) DESC+=("$1");;
    esac; shift
done

FEATURE_DESC="$(printf '%s ' "${DESC[@]+"${DESC[@]}"}")"
FEATURE_DESC="${FEATURE_DESC#"${FEATURE_DESC%%[![:space:]]*}"}"; FEATURE_DESC="${FEATURE_DESC%"${FEATURE_DESC##*[![:space:]]}"}"
[ -n "$FEATURE_DESC" ] || die "Feature description cannot be empty or only whitespace."
[ -n "$FEATURE_NAME" ] && [ -n "$SHORT_NAME" ] && die "Pass either --feature-name or --short-name, not both."
case "$SHORT_NAME" in
    STORY-*|EPIC-*|story-*|epic-*)
        die "'$SHORT_NAME' is a story/epic id and must be used verbatim. Pass it as --feature-name, not --short-name.";;
esac

REPO_ROOT=$(get_repo_root); cd "$REPO_ROOT"
if has_git; then HAS_GIT=true; else HAS_GIT=false; fi

PORTFOLIO=$(resolve_portfolio "${FEATURE_NAME:-${SHORT_NAME:-$FEATURE_DESC}}" "$EXPLICIT")
[ -n "$PORTFOLIO" ] || die "Portfolio is required. Pass --portfolio <name>, set PORTFOLIO_NAME in .env, or use a story id that begins with an installed pack name. Installed packs: $(installed_packs "$REPO_ROOT" | paste -sd, - || echo '(none)')"
pack_installed "$REPO_ROOT" "$PORTFOLIO" || die "Portfolio '$PORTFOLIO' has no manifest at portfolios/$PORTFOLIO/portfolio.yaml. The pack is not installed — run scripts/install-portfolio.sh <path-to-pack>, or check the name."

SPECS_DIR="$REPO_ROOT/portfolios/$PORTFOLIO/specs"; mkdir -p "$SPECS_DIR"

clean_branch_name() {
    printf '%s' "$1" | tr '[:upper:]' '[:lower:]' | sed 's/[^a-z0-9]/-/g; s/--*/-/g; s/^-//; s/-$//'
}

# 3-4 meaningful words from the description, dropping stop words (upstream rule:
# exactly four meaningful words keeps all four, any other count takes three).
branch_name_from_description() {
    local stop=" i a an the to for of in on at by with from is are was were be been being have has had do does did will would should could can may might must shall this that these those my your our their want need add get set "
    local words=() w
    for w in $(printf '%s' "$1" | tr '[:upper:]' '[:lower:]' | sed 's/[^a-z0-9 ]/ /g'); do
        case "$stop" in *" $w "*) continue;; esac
        if [ ${#w} -ge 3 ] || printf '%s' "$1" | grep -qw "$(printf '%s' "$w" | tr '[:lower:]' '[:upper:]')"; then words+=("$w"); fi
    done
    if [ ${#words[@]} -gt 0 ]; then
        local n=3; [ ${#words[@]} -eq 4 ] && n=4
        printf '%s\n' "${words[@]:0:$n}" | paste -sd- -
    else
        clean_branch_name "$1" | cut -d- -f1-3
    fi
}
highest_from_specs() {
    local h=0 n d
    for d in "$SPECS_DIR"/[0-9]*/; do
        [ -d "$d" ] || continue; n=$(basename "$d"); n=$((10#$(printf '%s' "$n" | sed 's/[^0-9].*//')))
        [ "$n" -gt "$h" ] && h=$n
    done; echo "$h"
}
highest_from_branches() {
    local h=0 n b
    has_git || { echo 0; return; }
    while IFS= read -r b; do
        b=${b#\* }; b="${b#"${b%%[![:space:]]*}"}"; b=${b#remotes/*/}
        case "$b" in [0-9]*-*) n=$((10#${b%%-*})); [ "$n" -gt "$h" ] && h=$n;; esac
    done < <(git branch -a 2>/dev/null)
    echo "$h"
}

if [ -n "$FEATURE_NAME" ]; then
    BRANCH_NAME="$FEATURE_NAME"; FEATURE_NUM=""
else
    if [ -n "$SHORT_NAME" ]; then SUFFIX=$(clean_branch_name "$SHORT_NAME"); else SUFFIX=$(branch_name_from_description "$FEATURE_DESC"); fi
    if [ "$NUMBER" -eq 0 ]; then
        [ "$HAS_GIT" = true ] && git fetch --all --prune >/dev/null 2>&1 || true
        a=$(highest_from_branches); b=$(highest_from_specs)
        NUMBER=$(( (a > b ? a : b) + 1 ))
    fi
    FEATURE_NUM=$(printf '%03d' "$NUMBER"); BRANCH_NAME="$FEATURE_NUM-$SUFFIX"
    if [ ${#BRANCH_NAME} -gt 244 ]; then      # git ref-name limit on GitHub/GitLab
        BRANCH_NAME="$FEATURE_NUM-${SUFFIX:0:240}"; BRANCH_NAME="${BRANCH_NAME%-}"
        warn "[specify] Branch name exceeded the 244-byte ref limit; truncated to $BRANCH_NAME"
    fi
fi

FEATURE_DIR="$SPECS_DIR/$BRANCH_NAME"
[ -e "$FEATURE_DIR" ] && die "Spec folder already exists: $FEATURE_DIR. Use a different feature name, or continue with the existing feature instead of re-running."

if [ "$HAS_GIT" = true ]; then
    if ! err=$(git checkout -b "$BRANCH_NAME" 2>&1 >/dev/null); then
        if [ -n "$(git branch --list "$BRANCH_NAME")" ]; then
            die "Branch '$BRANCH_NAME' already exists. Use a different feature name, or pass --number to pick another number."
        fi
        die "Failed to create git branch '$BRANCH_NAME': ${err:-unknown git error}"
    fi
else
    warn "[specify] Warning: git repository not detected; skipped branch creation for $BRANCH_NAME"
fi

mkdir -p "$FEATURE_DIR"
SPEC_FILE="$FEATURE_DIR/spec.md"
TEMPLATE="$REPO_ROOT/.specify/templates/spec-template.md"
if [ -f "$TEMPLATE" ]; then cp -f "$TEMPLATE" "$SPEC_FILE"; else : > "$SPEC_FILE"; fi

# Pin the feature so later steps agree with this one even if HEAD moves.
feature_pin_write "$REPO_ROOT" "$BRANCH_NAME"

if [ "$JSON" = true ]; then
    printf '{"BRANCH_NAME":"%s","SPEC_FILE":"%s","FEATURE_NUM":"%s","HAS_GIT":%s,"PORTFOLIO":"%s"}\n' \
        "$(json_escape "$BRANCH_NAME")" "$(json_escape "$SPEC_FILE")" "$FEATURE_NUM" "$HAS_GIT" "$(json_escape "$PORTFOLIO")"
else
    echo "BRANCH_NAME: $BRANCH_NAME"; echo "SPEC_FILE: $SPEC_FILE"; echo "FEATURE_NUM: $FEATURE_NUM"
    echo "HAS_GIT: $HAS_GIT"; echo "PORTFOLIO: $PORTFOLIO"
fi
