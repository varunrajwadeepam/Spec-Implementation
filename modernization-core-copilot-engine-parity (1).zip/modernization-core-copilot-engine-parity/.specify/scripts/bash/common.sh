#!/usr/bin/env bash
# Shared functions for the speckit helper scripts.
#
# Output contract, relied on by every speckit command's prose:
#   * stdout carries JSON (or the plain-text report) and nothing else
#   * stderr carries human diagnostics
#   * a failure is {"ERROR":"..."} on stdout plus exit 1 in --json mode, so a
#     caller that only parses stdout still gets a structured reason
#
# Portfolio resolution asks the filesystem which packs are installed instead of
# guessing at a name shape. The earlier regex ^STORY-([A-Z]+-[A-Z0-9]+)-MU-
# demanded exactly two uppercase segments and so matched neither pack on disk
# (TRDOC421 has one, MEETING-ROOM-BOOKING has three).

# ---------------------------------------------------------------------------
# Repo / git
# ---------------------------------------------------------------------------

get_repo_root() {
    local r
    if r=$(git rev-parse --show-toplevel 2>/dev/null); then
        printf '%s\n' "$r"; return
    fi
    ( cd "$(dirname "${BASH_SOURCE[0]}")/../../.." && pwd )
}

has_git() { git rev-parse --show-toplevel >/dev/null 2>&1; }

# Current branch, or empty when detached / no git.
git_branch() {
    local b
    b=$(git rev-parse --abbrev-ref HEAD 2>/dev/null) || return 0
    [ "$b" = "HEAD" ] && return 0
    printf '%s\n' "$b"
}

# ---------------------------------------------------------------------------
# Output helpers
# ---------------------------------------------------------------------------

JSON=${JSON:-false}

json_escape() { printf '%s' "$1" | sed 's/\\/\\\\/g; s/"/\\"/g'; }

warn() { printf '%s\n' "$*" >&2; }

# die MESSAGE — structured error on stdout (JSON mode) or stderr, exit 1.
die() {
    if [ "$JSON" = true ]; then
        printf '{"ERROR":"%s"}\n' "$(json_escape "$*")"
    else
        printf 'ERROR: %s\n' "$*" >&2
    fi
    exit 1
}

# ---------------------------------------------------------------------------
# .env
# ---------------------------------------------------------------------------

# dotenv_get KEY [ROOT] — value of KEY from the process env, then the repo .env.
# Handles comments, `export` prefixes, quotes, and trailing inline comments.
dotenv_get() {
    local key="$1" root="${2:-$(get_repo_root)}" f line v
    v="${!key:-}"
    if [ -n "$v" ]; then printf '%s\n' "$v"; return; fi
    f="$root/.env"; [ -f "$f" ] || return 0
    while IFS= read -r line || [ -n "$line" ]; do
        line="${line#"${line%%[![:space:]]*}"}"          # ltrim
        case "$line" in ''|'#'*) continue;; esac
        line="${line#export }"; line="${line#"${line%%[![:space:]]*}"}"
        [ "${line%%=*}" = "$line" ] && continue          # no '='
        local k="${line%%=*}"; k="${k%"${k##*[![:space:]]}"}"
        [ "$k" = "$key" ] || continue
        v="${line#*=}"; v="${v#"${v%%[![:space:]]*}"}"; v="${v%"${v##*[![:space:]]}"}"
        case "$v" in
            \"*) v="${v#\"}"; v="${v%%\"*}";;
            \'*) v="${v#\'}"; v="${v%%\'*}";;
            *)   v="${v%% #*}"; v="${v%"${v##*[![:space:]]}"}";;
        esac
        printf '%s\n' "$v"; return
    done < "$f"
}

# ---------------------------------------------------------------------------
# Portfolio resolution
# ---------------------------------------------------------------------------

# Installed packs (dirs with a portfolio.yaml), longest name first so prefix
# matching prefers the most specific pack. _template never counts.
installed_packs() {
    local root="$1" d n
    for d in "$root"/portfolios/*/; do
        [ -f "$d/portfolio.yaml" ] || continue
        n=$(basename "$d"); [ "$n" = "_template" ] && continue
        printf '%d\t%s\n' "${#n}" "$n"
    done | sort -t$'\t' -k1,1nr -k2,2 | cut -f2
}

# Longest installed pack that prefixes IDENT (case-insensitive).
_match_pack_prefix() {
    local ident="$1" root="$2" p up
    [ -n "$ident" ] || return 0
    up=$(printf '%s' "$ident" | tr '[:lower:]' '[:upper:]')
    while IFS= read -r p; do
        [ -n "$p" ] || continue
        case "$up" in "$(printf '%s' "$p" | tr '[:lower:]' '[:upper:]')"*) printf '%s\n' "$p"; return;; esac
    done < <(installed_packs "$root")
}

# From a branch / story id / feature name: try raw, then with STORY-/EPIC-/MU- stripped.
portfolio_from_identifier() {
    local ident="$1" root="$2" p stem
    p=$(_match_pack_prefix "$ident" "$root"); [ -n "$p" ] && { printf '%s\n' "$p"; return; }
    stem=$(printf '%s' "$ident" | sed -E 's/^(STORY|EPIC|story|epic)-(MU-|mu-)?//')
    [ "$stem" != "$ident" ] && _match_pack_prefix "$stem" "$root"
}

# An existing portfolios/*/specs/IDENT/ folder — filesystem truth, works for
# any naming convention (e.g. MRBS-001-* living in MEETING-ROOM-BOOKING).
portfolio_from_spec_dir() {
    local ident="$1" root="$2" p
    [ -n "$ident" ] || return 0
    while IFS= read -r p; do
        [ -n "$p" ] && [ -d "$root/portfolios/$p/specs/$ident" ] && { printf '%s\n' "$p"; return; }
    done < <(installed_packs "$root")
}

# Locate IDENT.md inside a pack's docs (story/epic ids only).
portfolio_from_story_file() {
    local ident="$1" root="$2" hit
    case "$ident" in STORY-*|EPIC-*|story-*|epic-*) ;; *) return 0;; esac
    hit=$(find "$root/portfolios" -mindepth 2 -name "$ident.md" -print 2>/dev/null | grep -v '/portfolios/_template/' | head -1)
    [ -n "$hit" ] && printf '%s\n' "${hit#"$root/portfolios/"}" | cut -d/ -f1
}

# resolve_portfolio IDENT [EXPLICIT] — precedence:
#   explicit arg > PORTFOLIO_NAME env > .env > spec dir > pack-name prefix > story file
resolve_portfolio() {
    local ident="$1" explicit="${2:-}" root p
    root=$(get_repo_root)
    [ -n "$explicit" ] && { printf '%s\n' "$explicit"; return; }
    p=$(dotenv_get PORTFOLIO_NAME "$root"); [ -n "$p" ] && { printf '%s\n' "$p"; return; }
    p=$(portfolio_from_spec_dir "$ident" "$root"); [ -n "$p" ] && { printf '%s\n' "$p"; return; }
    p=$(portfolio_from_identifier "$ident" "$root"); [ -n "$p" ] && { printf '%s\n' "$p"; return; }
    portfolio_from_story_file "$ident" "$root"
}

pack_installed() { [ -f "$1/portfolios/$2/portfolio.yaml" ]; }

# ---------------------------------------------------------------------------
# Active feature (replaces the never-observable $env:SPECIFY_FEATURE)
# ---------------------------------------------------------------------------

STATE_FILE_REL=".specify/state/current-feature"

feature_pin_read()  { [ -f "$1/$STATE_FILE_REL" ] && tr -d '[:space:]' < "$1/$STATE_FILE_REL"; return 0; }
feature_pin_write() { mkdir -p "$(dirname "$1/$STATE_FILE_REL")"; printf '%s\n' "$2" > "$1/$STATE_FILE_REL"; }
feature_pin_clear() { rm -f "$1/$STATE_FILE_REL"; }

# current_feature ROOT [PORTFOLIO] — SPECIFY_FEATURE > pin file > git branch >
# highest NNN-* spec dir. Errors instead of falling back to "main".
current_feature() {
    local root="$1" portfolio="${2:-}" branch pinned
    branch=$(git_branch)
    pinned="${SPECIFY_FEATURE:-}"
    if [ -n "$pinned" ]; then
        [ -n "$branch" ] && [ "$pinned" != "$branch" ] && warn "[specify] Note: active feature '$pinned' (SPECIFY_FEATURE) differs from the checked-out branch '$branch'."
        printf '%s\n' "$pinned"; return
    fi
    pinned=$(feature_pin_read "$root")
    if [ -n "$pinned" ]; then
        [ -n "$branch" ] && [ "$pinned" != "$branch" ] && warn "[specify] Note: active feature '$pinned' (pinned in $STATE_FILE_REL) differs from the checked-out branch '$branch'. Run .specify/scripts/bash/feature.sh clear to follow the branch instead."
        printf '%s\n' "$pinned"; return
    fi
    [ -n "$branch" ] && { printf '%s\n' "$branch"; return; }

    [ -n "$portfolio" ] || portfolio=$(resolve_portfolio "")
    if [ -n "$portfolio" ] && [ -d "$root/portfolios/$portfolio/specs" ]; then
        local d n latest="" highest=0
        for d in "$root/portfolios/$portfolio/specs"/[0-9][0-9][0-9]-*/; do
            [ -d "$d" ] || continue
            n=$(basename "$d"); n=$((10#${n%%-*}))
            [ "$n" -gt "$highest" ] && { highest=$n; latest=$(basename "$d"); }
        done
        [ -n "$latest" ] && { printf '%s\n' "$latest"; return; }
    fi
    return 1
}

require_feature_branch() {
    local branch="$1"
    if ! has_git; then warn "[specify] Warning: git repository not detected; skipped branch validation"; return 0; fi
    case "$branch" in main|master|MAIN|MASTER) die "Cannot run on '$branch'. Create or switch to a feature branch first.";; esac
}

# get_feature_paths [EXPLICIT_PORTFOLIO] — populates REPO_ROOT CURRENT_BRANCH
# HAS_GIT PORTFOLIO FEATURE_DIR FEATURE_SPEC IMPL_PLAN TASKS RESEARCH DATA_MODEL
# QUICKSTART CONTRACTS_DIR. The branch guard runs BEFORE portfolio resolution so
# that on main the actionable "Cannot run on main" wins over a pack error.
get_feature_paths() {
    local explicit="${1:-}"
    REPO_ROOT=$(get_repo_root)
    if ! CURRENT_BRANCH=$(current_feature "$REPO_ROOT"); then
        local p; p=$(resolve_portfolio "" "$explicit")
        [ -n "$p" ] && CURRENT_BRANCH=$(current_feature "$REPO_ROOT" "$p") || \
            die "Cannot determine the active feature. Set SPECIFY_FEATURE, run .specify/scripts/bash/feature.sh set <name>, check out a feature branch, or run /speckit.specify to create one."
    fi
    if has_git; then HAS_GIT=true; else HAS_GIT=false; fi
    require_feature_branch "$CURRENT_BRANCH"
    PORTFOLIO=$(resolve_portfolio "$CURRENT_BRANCH" "$explicit")
    [ -n "$PORTFOLIO" ] || die "Cannot resolve portfolio for '$CURRENT_BRANCH'. Pass --portfolio <name>, set PORTFOLIO_NAME in .env, or use a branch whose name begins with an installed pack name. Installed packs: $(installed_packs "$REPO_ROOT" | paste -sd, - || echo '(none)')"
    FEATURE_DIR="$REPO_ROOT/portfolios/$PORTFOLIO/specs/$CURRENT_BRANCH"
    FEATURE_SPEC="$FEATURE_DIR/spec.md"
    IMPL_PLAN="$FEATURE_DIR/plan.md"
    TASKS="$FEATURE_DIR/tasks.md"
    RESEARCH="$FEATURE_DIR/research.md"
    DATA_MODEL="$FEATURE_DIR/data-model.md"
    QUICKSTART="$FEATURE_DIR/quickstart.md"
    CONTRACTS_DIR="$FEATURE_DIR/contracts"
}
