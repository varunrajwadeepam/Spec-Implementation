# MCP — MFLens Server Configuration

This directory documents the Model Context Protocol (MCP) server that exposes **MFLens**
static-analysis artifacts to the pipeline agents.

`mflens-server.json` is an exact mirror of the live server's `tools/list` (48 tools, with
descriptions and input schemas). The live connection is configured in the project-root
`.mcp.json`:

```json
{
  "mcpServers": {
    "MFlens": {
      "type": "streamable-http",
      "url": "http://localhost:8989/api/mcp"
    }
  }
}
```

The pipeline runs **without local COBOL source files** — every agent that needs program
detail retrieves it from MFLens instead of scanning `portfolios/{portfolio}/inputs/source/`. MFLens
serves both analyzed metadata (call chains, SQL/MQ/CICS usage, lineage, paragraphs) **and
verbatim source excerpts** (`get_program_source_code`, `get_program_paragraph_details`), so
nothing is lost by dropping the source tree.

> **Agent-facing copy.** The usage contract agents follow (deferred-tool discovery,
> `portfolioId` resolution, `sourceEvidence` citation, tool-by-need table, fallback) lives in
> `.claude/skills/mflens-mcp/SKILL.md` — the single copy all agents Read; per-agent
> boilerplate was removed. When the server contract changes, update this file **and** that
> skill together.

> **Superseded contract.** Earlier revisions of this file described a resource-based design
> (`mflens://…` URIs) plus a single `query_program` tool. The deployed MFLens server does
> **not** implement that design — it exposes the 48 tools below and no resources/prompts.
> The old `mflens://` URIs and `query_program` are retired; use the tools listed here.

---

## Portfolio ID (read this first)

Every program/portfolio-scoped tool takes a **numeric `portfolioId`** (e.g. `182`) — *not*
the portfolio name (`ACME-CORE-subset`). Resolve it once at the start of a run with
`search_program` (or `search_component`) on any known in-scope program; the response includes
the portfolio's numeric ID and PDS. Reuse that ID for all subsequent calls.

Most per-program tools accept `programName` (required) plus optional `portfolioId` and `pds`
(defaults to `SRC`). Portfolio-wide tools require `portfolioId`.

---

## Tools

48 tools, grouped by purpose. `*` marks tools that **write** to MFLens.

### Portfolio discovery & health
| Tool | Key inputs | Description |
|------|-----------|-------------|
| `get_portfolio_overview` | `portfolioId` | Processing stats, code-quality metrics, dependency summary, health |
| `get_portfolio_assets` | `portfolioId`, `assetType?` | Assets by type (PROGRAM, COPYBOOK, …), paginated |
| `get_portfolio_files` | `portfolioId` | COBOL + JCL dataset files with IO types |
| `search_program` | `programName` | Locate a program across portfolios → portfolio ID, PDS, type |
| `search_component` | `componentName` | Locate any component (PROGRAM/JCL/TRANSACTION) across portfolios |
| `get_complex_programs` | `portfolioId`, `minComplexity?` | Programs ranked by inclusive cyclomatic complexity |

### Capabilities & classification
| Tool | Key inputs | Description |
|------|-----------|-------------|
| `get_business_capabilities` | `portfolioId` | Distinct product / process / capability values available |
| `get_programs_by_capabilities` | `portfolioId`, `product?`, `businessCapability?` | Filter programs by capability (comma-separated OR) |
| `update_program_classification` * | `pgm`, + fields | Upsert a program's product/capability/process classification |

### Call chains & dependencies
| Tool | Key inputs | Description |
|------|-----------|-------------|
| `get_portfolio_call_chain_statistics` | `portfolioId` | Graph size, node types, most-connected/isolated programs (call this first) |
| `get_portfolio_call_chain` | `portfolioId` | Call-chain graph nodes + edges, 20/page |
| `find_portfolio_call_paths` | `portfolioId`, `minDepth` | Internal call chains meeting a minimum depth |
| `get_program_deep_call_chain` | `portfolioId`, `programName` | All call paths from a program (default depth 8) |
| `analyze_migration_impact` | `programName` | Blast radius: callers, JCL, DB2, MQ, CICS, datasets |
| `recommend_modernization_start` | `portfolioId?` | Programs ranked by Migratability Score (0–100) |

### Program structure & source
| Tool | Key inputs | Description |
|------|-----------|-------------|
| `get_program_paragraphs` | `programName` | Paragraph list with line ranges + code preview |
| `get_program_paragraph_details` | `programName`, `paragraphName` | A paragraph's **full source code**, line range, summary |
| `get_program_source_code` | `programName`, `startLine`, `endLine?` | Verbatim source for a line range |
| `get_control_flow_graph` | `fileName` | Paragraph-level control-flow graph (PERFORM/GO TO/THRU) |
| `get_program_dead_paragraphs` | `programName` | Unused / unreachable / obsolete paragraphs |
| `search_code` | `programName`, `searchQuery` | Text search within one program's source |
| `search_code_portfolio` | `portfolioId`, `searchQuery` | Text search across all programs in a portfolio |

### Documentation & business rules
| Tool | Key inputs | Description |
|------|-----------|-------------|
| `get_program_prd` | `programName` | PRD: business requirements / functional spec (markdown) |
| `get_program_summary` | `programName` | Program summary documentation (markdown) |
| `get_program_export` | `programName` | Comprehensive export of everything known (large — explicit asks only) |
| `update_program_prd_documentation` * | `programName`, `prdDocumentation` | Write the PRD doc |
| `update_program_summary` * | `programName`, `documentation` | Write the summary doc |

### Data structures & lineage
| Tool | Key inputs | Description |
|------|-----------|-------------|
| `list_data_structures` | `programName` | Level-01 structures: names, types, line numbers |
| `get_data_structure_details` | `programName`, `structureName` | A structure + all nested fields (PIC clauses, layouts) |
| `get_program_outputs` | `programName` | Outputs grouped by type (DB tables, files, MQ, TDQ/TSQ, CALLs) |
| `get_lineage_summary` | `programName` | Terminal-source counts + max lineage depth |
| `get_field_lineage` | `programName`, `fieldName` | Transformations touching a field, with paragraph source |
| `trace_field_lineage` | `programName`, `targetType`, `fieldName` | One output field traced back to terminal sources |
| `trace_output_structure` | `programName`, `targetType` | All fields of an output structure traced to sources |

### DB2 / SQL
| Tool | Key inputs | Description |
|------|-----------|-------------|
| `get_portfolio_sql_tables` | `portfolioId` | Tables discovered across the portfolio |
| `get_program_sql_statements` | `programName` | Embedded `EXEC SQL` blocks, 20/page |
| `get_sql_table_structure` | `portfolioId`, `tableName` | Table columns, types, lengths |
| `get_sql_table_usage` | `portfolioId`, `tableName` | Programs using a table (SELECT/INSERT/UPDATE/DELETE/DECLARE) |

### MQ
| Tool | Key inputs | Description |
|------|-----------|-------------|
| `get_mq_usage_portfolio` | `portfolioId` | MQ operations across the portfolio, grouped by program |
| `get_mq_usage_program` | `programName` | Per-program MQ ops (CONNECT/OPEN/PUT/GET/CLOSE), queues, lines |

### CICS
| Tool | Key inputs | Description |
|------|-----------|-------------|
| `get_cics_usage` | `programName`, `verb?` | CICS verbs/commands with resource names, types, line numbers |

### JCL
| Tool | Key inputs | Description |
|------|-----------|-------------|
| `list_portfolio_jcl_jobs` | `portfolioId` | JCL jobs with step/program/dataset counts |
| `get_jcl_job_execution_details` | `portfolioId`, `jobName` | Step-by-step EXEC flow, programs, PARM values |
| `get_jcl_job_io` | `portfolioId`, `jobName` | Consolidated input/output/update datasets (DSNs) |
| `get_jcl_bottom_up_file_analysis` | `portfolioId`, `jclName`, `fileName` | Trace an output file back through programs/inputs |
| `map_jcl_job_files_to_cobol_data_structures` | `portfolioId`, `jobName` | Map JCL DSNs to COBOL FD/SELECT/copybooks |
| `search_jcl_source` | `portfolioId`, `searchPattern` | Text search across JCL source |

### Conversion helper
| Tool | Key inputs | Description |
|------|-----------|-------------|
| `cobol_ibm_to_iso` | `cobolCode` | IBM Enterprise COBOL → ISO/ANSI COBOL conversion rules/guidance |

---

## Which agents use what

The AS-IS and LLD generation pipelines (A01–A15, L00–L05, and the standalone design
validators) that used to call most MFLens tools have been retired from this engine — see
`CLAUDE.md`. The one remaining MFLens-calling agent:

| Agent | Primary MFLens tools |
|-------|----------------------|
| **fwd-cobol-dotnet-consistency-checker** | `get_program_paragraph_details`, `get_program_source_code`, `list_data_structures`, `get_data_structure_details`, `get_program_sql_statements`, `search_code` |

---

## Calling MFLens from an agent

MFLens tools are **deferred MCP tools** inside Claude Code. In an agent run:

1. Discover them with `ToolSearch` using the query `MFlens`, then load what you need with
   `select:<tool_name>` (e.g. `select:get_program_prd,get_program_paragraphs`).
2. Resolve `portfolioId` once (see [Portfolio ID](#portfolio-id-read-this-first)).
3. Call the tool(s). Cite MFLens as evidence in outputs — e.g. `MFLens:<program>` — instead
   of a source path like `PROGRAM.cbl:142`.

> The tools register only when the MCP server is reachable at session start. If MFLens was
> down when the session began, reconnect it (restart Claude Code, or `/mcp`) so `ToolSearch`
> can see the tools.

---

## Fallback when MFLens is unavailable

If MFLens is unreachable or returns nothing for a program, agents fall back to the static
exports already in the repo and lower their confidence accordingly:

- `portfolios/{portfolio}/knowledge-store/programs-enriched.json`
- `portfolios/{portfolio}/inputs/static-analysis/*.csv`

---

## Notes

- `mflens-server.json` is a generated **mirror** of the live `tools/list`. If the server's
  tools change, regenerate it from `tools/list` rather than hand-editing.
- The server exposed **no** MCP resources or prompts at capture time — tools only.
- Write tools (`update_program_classification`, `update_program_prd_documentation`,
  `update_program_summary`) mutate MFLens records; use them only when an agent is explicitly
  meant to persist classification/documentation back to MFLens.
