# Changelog

## 2026-07-21 — Post-merge sweep

After merging `origin/main` (its `features/skills-cleanup` trim of the 8 portfolio skills) into `skills_cleanup`, a re-verification sweep found five more references to the nonexistent `trvs` skill, phrased without a "Part N" suffix and therefore missed by the earlier passes: `asis-A08-validator` (MU naming convention), `asis-A14-completeness-checker` (capability taxonomy), `asis-A15-consistency-validator` (2×: MU naming, capability codes), and `tobe-A09-target-state-architect` (service split guidance). All now point to "the portfolio's client-specific skill".

## 2026-07-20 — Deduplication step 2: stack-convention skills

Extracted the per-stack implementation conventions ("Pre-Synthesis Rules") from the LLD agent pairs into two shared skills. Rule text was moved **verbatim** (rule IDs unchanged) except where noted.

- **New skill `.claude/skills/target-stack-net-conventions/SKILL.md`** — consolidates the .NET conventions previously embedded in `lld-L01-wsdl-contract-generator` (WCF→WSDL mapping, [WSDL-*]), `lld-L02-data-flow-designer` ([EF6-*], [DB2-*], [DATA-*]), `lld-L03-implementation-detailer` ([PROJ-*], [PKG-*], [WCF-*], [IIS-*]), and `lld-L04-test-strategy-author` ([TEST-*], [COV-*], test-data [DATA-*]).
- **New skill `.claude/skills/target-stack-java-conventions/SKILL.md`** — consolidates the Java conventions from `lld-L01-rest-api-contract-generator` ([REST-*]), `lld-java-L02-data-flow-designer` ([JPA-*], [DB2-*], [DATA-*]), `lld-java-L03-implementation-detailer` ([PROJ-*], [DEP-*], [CXF-*], [DI-*]), and `lld-java-L04-test-strategy-author` ([TEST-*], [COV-*]).
- **8 agents slimmed** (~340 lines total): each Pre-Synthesis Rules section is now a pointer naming the exact skill sections that apply. The per-agent Domain Neutrality warnings and all worked templates/examples in the Task steps stay in the agents — they are step-specific.
- **Precedence made explicit**: version pins in the conventions skills are defaults; the portfolio's `inputs/{portfolio}/target-stack*.md` wins on conflict. `migration` skill Parts 3 and 5 now defer to the conventions skills for implementation rules.
- **Fixed eight more phantom-skill references** found during extraction: [WSDL-04], [REST-04], the Task/Re-run sections of both L01 agents, and two sections of `lld-SAD-assembly` all cited parts of a nonexistent `trvs` skill — now "the portfolio's client-specific skill".
- **⚠️ Flagged (not resolved) — DB2 schema naming contradiction**: the .NET convention says schema = `{MAINFRAME_SCHEMA}_LUW` ([DB2-01] .NET) while the Java convention says the mainframe schema name is preserved unchanged per `TSA-db2-migration.md` ([DB2-01] Java, [JPA-02]). Both rules were preserved as-is with a cross-reference warning in each skill; the team should confirm which reflects the actual TSA decision and align the other.
- **CLAUDE.md**: new "Stack Skills" catalog section documenting both skills.

## 2026-07-20 — Deduplication: shared `portfolio-resolution` skill

Follow-up to the architecture cleanup below: the skill-resolution rules that were copy-pasted into 28 agents are now a single shared skill.

- **New skill `.claude/skills/portfolio-resolution/SKILL.md`** — single source of truth for: portfolio name resolution (`portfolio=` arg → `.env` → error), `client_skill`/`domain_skill` argument handling, the LLD-phase `target-state.json` `domainSkill` lookup, portfolio-prefix inference, the subset-portfolio hard-stop, a portfolio → skill registry table, and the mandatory skill load order (client → domain → `migration` → `cagen-programs` → `mermaid` when diagramming). Same "agents must not embed their own copy" pattern as `mflens-mcp`.
- **28 agents slimmed**: the ~20–27-line resolution block in every `asis-*`, `lld-*`, `tobe-*`, and `fwd-*` agent (including `lld-java-orchestrator`'s custom variant) is replaced by a 1-paragraph pointer that instructs the agent to Read the shared skill first. Agents that emit Mermaid diagrams (A07, A11, L02, tobe-A09) keep an explicit reminder to load the `mermaid` skill. Adding a portfolio or fixing a resolution rule is now a one-file change.
- **Behavior change** (intentional): `lld-java-orchestrator` previously said "log a warning and continue" when a resolved skill file was missing. The shared procedure makes a missing skill a hard STOP — continuing with a partial or wrong domain context produces confidently wrong output.
- **CLAUDE.md**: `portfolio-resolution` added to the Shared Skills catalog; the Skill Resolution section now defers to the shared skill as the authoritative procedure (the bash examples remain as a summary).

## 2026-07-20 — Agentic-flow architecture cleanup

Result of a full cross-reference audit of `.claude/agents/` (52 agents), `.claude/skills/` (20 skills), the orchestrators, and `CLAUDE.md`. Every agent→skill, skill→input, and orchestrator→agent reference was verified against what exists on disk.

### Fixed — broken references

- **`lld-orchestrator`**: renamed the invoked agent `lld-L05-epic-story-generator` → `lld-L05-epic-story-orchestrator` (4 occurrences). The old name matched no agent, so Step 3.5 of the .NET route could never run. (`lld-java-orchestrator` already used the correct name.)
- **Skill-resolution blocks in 26 agents** (all `asis-*`, `lld-*`, `tobe-*`, `fwd-*` agents that carry the shared block):
  - Removed the dead rule `UWR-* → uwr-modernization` — no such skill exists.
  - Added the missing `RevDB* → revdb-modernization` / `revdb-domain` prefix rules. Previously a RevDB run without explicit skill args silently fell through to the NPW default and loaded the wrong domain knowledge.
  - Added a subset guard: portfolios whose name contains `-subset` now STOP with an error unless `client_skill=`/`domain_skill=` are passed explicitly. Previously `NPW-H421-subset` prefix-matched to the full-portfolio `npw-modernization` skill.
  - Replaced the silent `Otherwise → npw-modernization (default)` fallback with a hard STOP-with-error for unmapped portfolios.
- **`lld-java-orchestrator`**: replaced the phantom `trvs` client skill (`client_skill=trvs` example and `Default: trvs`) with real skills (`revdb-modernization` example) and the same subset-guard / STOP-on-unresolved rules.
- **`.claude/skills/revdb-domain`**: fixed 11 `inputs/RefDB/…` citation paths (typo) → `inputs/RevDB/…`.
- **`.claude/skills/migration`**: fixed 3 stale target-stack paths — `inputs/target-stack.md` / `inputs/target-stack-java.md` (root-level, nonexistent) → portfolio-scoped `inputs/{portfolio}/target-stack-net.md` / `inputs/{portfolio}/target-stack-java.md`.
- **`.claude/skills/revdb-modernization`**: fixed 2 citations of nonexistent `inputs/RevDB/target-stack.md` → `inputs/RevDB/target-stack-java.md`.
- **`.claude/skills/trvs-underwriting-domain`**: removed 2 references to the nonexistent client-specific `trvs` skill; now points to the real client skills (`npw-modernization`, `revdb-modernization`).

### Fixed — orchestration gaps

- **`asis-orchestrator`**: added the two agents that appeared in the pipeline diagram but had no invocation step:
  - Layer 1 step 5: `asis-A02j-ingest-jcl-dependencies` (after A02g, before the A02x readiness gate).
  - Layer 2 step 2: `asis-A03b-portfolio-summary` (after A03; produces `portfolio-summary.json`, which A08 depends on — previously an orchestrated run never created it). Subsequent Layer 2 steps renumbered.
- **`lld-orchestrator`**: added optional Step 3.4b invoking `lld-L04b-business-rules-e2e-test-generator` (.NET route only, gated on `e2e_tests=true`), matching CLAUDE.md's claim that L04b is part of the Per-MU Phase.
- **`cagen-programs` skill was loaded by zero agents** despite CLAUDE.md mandating it for any COBOL analysis. Added it to the skill-load list of the 25 pipeline agents that carry the shared load list.

### Fixed — documentation (CLAUDE.md)

- Repaired the corrupted **Skill Resolution** section: removed the duplicated block, stray code fence, and the wrong skill name `npw-subset-modernization` (actual: `npw-h421-subset-modernization`).
- Removed the `portfolio=UWR-POC → uwr-modernization + …` inference example; documented that no `uwr-modernization` client skill currently exists.
- Layer lists now include the previously undocumented agents: A02j (JCL), A02x (Layer-1 readiness gate), A03b (portfolio summary), and the A07/A08/tobe-A09 validators.
- Documented the three standalone design validators in `.claude/agents/validators/` (`call-tree-coverage-validator`, `sequence-diagram-coverage-validator`, `wcf-exit-state-coverage-validator`), which previously appeared in no documentation and were invoked by nothing.
- Noted `NPW-H421-subset-no-cobol` among the subset portfolios requiring explicit skill arguments (it exists in `inputs/` and `knowledge-store/` but had no documented skill mapping).

### Fixed — misleading examples

- **`lld-java-L03-implementation-detailer`**: added an explicit note that all `uwr-*` Maven module names, `com.insurance.uwr` group IDs, and UWRSCORE/UWRFMT examples are illustrative and must be re-derived per MU — the only Java-stack portfolios today are RevDB, and the agent previously read as if `uwr-*` were the required output.

### Known issues — deliberately NOT changed (need a project decision)

- **`mod-*` command family** (`.claude/commands/mod-*.md`) belongs to a different project ("Open Workbench" — .NET 10 / Angular 21) and collides with `.claude/skills/mod-implement/` (this repo's speckit wrapper): `/mod-implement` is ambiguous between the two. Deleting or renaming would affect whichever workflow still uses them — decide and remove one side.
- **speckit triplication**: `speckit.impact` exists as both a command (349 lines) and a skill (169 lines) with divergent content; `speckit.review` as both a skill and an agent; the other speckit steps as command + agent pairs. Consolidation to a single mechanism per step is recommended but not applied.
- `reports/pipeline-status-NPW-H421*.html` sit at `reports/` root instead of `reports/{portfolio}/` (produced by `scripts/hooks/regen_status_on_artifact.py`, which has uncommitted local changes — left untouched).
- `sonar.projectKey=uwr-modernization-java` in `lld-java-L04-test-strategy-author.md` is an example config string (not a skill reference); rename if UWR examples are replaced wholesale.
